import{c5 as r,b4 as o}from"./entry.PV282jgu.js";function a(e,t){return r.get(`${o}/community/user/${e}`,{},{headers:{Authorization:t}})}export{a as g};
