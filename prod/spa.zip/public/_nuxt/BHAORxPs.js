import{e}from"./BkwXzkPO.js";function a(i,s,t){const o=e({title:i,body:s,icon:"/logo.png",...t});o.isSupported&&o.show()}export{a as u};
