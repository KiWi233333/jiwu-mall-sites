import { p as publicAssetsURL } from '../../handlers/renderer.mjs';

const _imports_0 = "" + publicAssetsURL("images/logo/logo_dark.png");

export { _imports_0 as _ };
//# sourceMappingURL=logo_dark-9gSLJMhE.mjs.map
