const client_manifest = {
  "_ApplyDialog.vue.kJUj3Udd.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ApplyDialog.vue.kJUj3Udd.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_dialog.Yt_iz6Sc.js",
      "_notification.qe9EsX_4.js",
      "_friend.kks2XXaj.js"
    ]
  },
  "_AutoIncre.vue.X3Tv3UDL.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "AutoIncre.vue.X3Tv3UDL.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_CategoryTabs.!~{014}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "CategoryTabs.787nBCiN.css",
    "src": "_CategoryTabs.!~{014}~.js"
  },
  "_CategoryTabs.r5LuUyEz.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "CategoryTabs.787nBCiN.css"
    ],
    "file": "CategoryTabs.r5LuUyEz.js",
    "imports": [
      "_tabs.8qzfQfEZ.js",
      "node_modules/nuxt/dist/app/entry.js",
      "components/Comm/PostList.vue",
      "components/list/GoodsList.vue"
    ]
  },
  "CategoryTabs.787nBCiN.css": {
    "file": "CategoryTabs.787nBCiN.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_CommentPreview.!~{019}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "CommentPreview.mYLkOLZt.css",
    "src": "_CommentPreview.!~{019}~.js"
  },
  "_CommentPreview.B4PXLCuS.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "CommentPreview.mYLkOLZt.css"
    ],
    "file": "CommentPreview.B4PXLCuS.js",
    "imports": [
      "_ElImage.8lCJ1V3q.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_select.BqpNHvAi.js",
      "_OssFileUpload.7trMrZMp.js",
      "_nuxt-link.g75woKBL.js",
      "_tag.eNhCwUom.js",
      "_AutoIncre.vue.X3Tv3UDL.js",
      "_scrollbar.I2vPmCtb.js",
      "_popper.4o1574AU.js",
      "_notification.qe9EsX_4.js"
    ]
  },
  "CommentPreview.mYLkOLZt.css": {
    "file": "CommentPreview.mYLkOLZt.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_DelayTimer.vue.bdBacTMI.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "DelayTimer.vue.bdBacTMI.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_ElImage.!~{00B}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "ElImage.6ybrNKBL.css",
    "src": "_ElImage.!~{00B}~.js"
  },
  "_ElImage.8lCJ1V3q.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "ElImage.6ybrNKBL.css"
    ],
    "file": "ElImage.8lCJ1V3q.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_debounce.Ks9NfFzx.js"
    ]
  },
  "ElImage.6ybrNKBL.css": {
    "file": "ElImage.6ybrNKBL.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_Footer.!~{01Q}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Footer.y5ruypfy.css",
    "src": "_Footer.!~{01Q}~.js"
  },
  "_Footer.JE1CXWEl.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "Footer.y5ruypfy.css"
    ],
    "file": "Footer.JE1CXWEl.js",
    "imports": [
      "_nuxt-link.g75woKBL.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_logo_dark.ZPOuYKQQ.js",
      "_Switch.NMri1Y-g.js"
    ]
  },
  "Footer.y5ruypfy.css": {
    "file": "Footer.y5ruypfy.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_GoodsListSsr.!~{01n}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "GoodsListSsr.P5hBZBtk.css",
    "src": "_GoodsListSsr.!~{01n}~.js"
  },
  "_GoodsListSsr.gDnTAQ6n.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "GoodsListSsr.P5hBZBtk.css"
    ],
    "file": "GoodsListSsr.gDnTAQ6n.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.w2XVvOqe.js",
      "_nuxt-link.g75woKBL.js",
      "node_modules/element-plus/es/components/text/index.mjs"
    ]
  },
  "GoodsListSsr.P5hBZBtk.css": {
    "file": "GoodsListSsr.P5hBZBtk.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_Main.!~{00z}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Main.NrGMXl3O.css",
    "src": "_Main.!~{00z}~.js"
  },
  "_Main.h-TpnM_a.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "Main.NrGMXl3O.css"
    ],
    "file": "Main.h-TpnM_a.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_contact.e_2KdKkO.js",
      "_ElImage.8lCJ1V3q.js",
      "_tag.eNhCwUom.js"
    ]
  },
  "Main.NrGMXl3O.css": {
    "file": "Main.NrGMXl3O.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_OssFileUpload.!~{00W}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "OssFileUpload.f4DKzIfB.css",
    "src": "_OssFileUpload.!~{00W}~.js"
  },
  "_OssFileUpload.7trMrZMp.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "OssFileUpload.f4DKzIfB.css"
    ],
    "file": "OssFileUpload.7trMrZMp.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.8lCJ1V3q.js",
      "_progress.XvBCmKKY.js",
      "_index.5Ghl8XGW.js"
    ]
  },
  "OssFileUpload.f4DKzIfB.css": {
    "file": "OssFileUpload.f4DKzIfB.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_ShopLine.!~{01K}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "ShopLine.Wq74ulT-.css",
    "src": "_ShopLine.!~{01K}~.js"
  },
  "_ShopLine.NOoQxm3f.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "ShopLine.Wq74ulT-.css"
    ],
    "file": "ShopLine.NOoQxm3f.js",
    "imports": [
      "_ElImage.8lCJ1V3q.js",
      "_nuxt-link.g75woKBL.js",
      "_select.BqpNHvAi.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_input-number.9iSkt-XV.js",
      "_tag.eNhCwUom.js",
      "_scrollbar.I2vPmCtb.js",
      "_popper.4o1574AU.js",
      "_sku.DITaIO81.js"
    ]
  },
  "ShopLine.Wq74ulT-.css": {
    "file": "ShopLine.Wq74ulT-.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_SigninCard.vue.vP5WGlM7.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "popover.LAISAeEG.css"
    ],
    "file": "SigninCard.vue.vP5WGlM7.js",
    "imports": [
      "_progress.XvBCmKKY.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.uDNa5rfU.js",
      "_popper.4o1574AU.js"
    ]
  },
  "popover.LAISAeEG.css": {
    "file": "popover.LAISAeEG.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_StatusTag.!~{01l}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "StatusTag.IETAoY75.css",
    "src": "_StatusTag.!~{01l}~.js"
  },
  "_StatusTag.-07-kXkn.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "StatusTag.IETAoY75.css"
    ],
    "file": "StatusTag.-07-kXkn.js",
    "imports": [
      "_tag.eNhCwUom.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_post.HyyszCAI.js"
    ]
  },
  "StatusTag.IETAoY75.css": {
    "file": "StatusTag.IETAoY75.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_Switch.!~{01e}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Switch.JXXa2UnD.css",
    "src": "_Switch.!~{01e}~.js"
  },
  "_Switch.NMri1Y-g.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "Switch.JXXa2UnD.css"
    ],
    "file": "Switch.NMri1Y-g.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "Switch.JXXa2UnD.css": {
    "file": "Switch.JXXa2UnD.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_TagList.vue.GONtJwxu.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TagList.vue.GONtJwxu.js",
    "imports": [
      "_tag.eNhCwUom.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_UserPostTotal.vue.LK7H1ixP.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "UserPostTotal.vue.LK7H1ixP.js",
    "imports": [
      "_ElImage.8lCJ1V3q.js",
      "_nuxt-link.g75woKBL.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_post.HyyszCAI.js"
    ]
  },
  "___commonjsHelpers__.1J56E-h6.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "__commonjsHelpers__.1J56E-h6.js"
  },
  "_arrays.9GuX8ZvT.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "arrays.9GuX8ZvT.js"
  },
  "_avatar.!~{01J}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "avatar.bZH1-Oig.css",
    "src": "_avatar.!~{01J}~.js"
  },
  "_avatar.gbsApbHF.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "avatar.bZH1-Oig.css"
    ],
    "file": "avatar.gbsApbHF.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "avatar.bZH1-Oig.css": {
    "file": "avatar.bZH1-Oig.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_bills.7u1Xnj1i.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "bills.7u1Xnj1i.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_checkbox-group.!~{01H}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "checkbox-group.d5XbR8TY.css",
    "src": "_checkbox-group.!~{01H}~.js"
  },
  "_checkbox.!~{01y}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "checkbox.MJHvI1xB.css",
    "src": "_checkbox.!~{01y}~.js"
  },
  "_checkbox.9IwwzgIx.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "checkbox.MJHvI1xB.css"
    ],
    "file": "checkbox.9IwwzgIx.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_isEqual.4gvyVEHC.js",
      "_hasIn.ilVBUtyE.js",
      "_flatten.G9UgQF_S.js"
    ]
  },
  "checkbox.MJHvI1xB.css": {
    "file": "checkbox.MJHvI1xB.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_cloneDeep.IE38ijpa.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "cloneDeep.IE38ijpa.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_collect.iOEnxm1K.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "collect.iOEnxm1K.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_contact.e_2KdKkO.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "contact.e_2KdKkO.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_useWs.zjavPj1e.js"
    ]
  },
  "_create-shadow.O2fgC1s_.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "create-shadow.O2fgC1s_.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_date-picker.!~{01E}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "date-picker.sSkDKlix.css",
    "src": "_date-picker.!~{01E}~.js"
  },
  "_date-picker.SZ9NtVEP.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "date-picker.sSkDKlix.css"
    ],
    "file": "date-picker.SZ9NtVEP.js",
    "imports": [
      "_localeData.FMM2ZQ75.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_arrays.9GuX8ZvT.js",
      "_flatten.G9UgQF_S.js",
      "_popper.4o1574AU.js",
      "_scrollbar.I2vPmCtb.js",
      "_index.K3NjyUwU.js",
      "_debounce.Ks9NfFzx.js",
      "_index.Pt091gh7.js",
      "_isEqual.4gvyVEHC.js"
    ]
  },
  "date-picker.sSkDKlix.css": {
    "file": "date-picker.sSkDKlix.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_debounce.Ks9NfFzx.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "debounce.Ks9NfFzx.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_dialog.!~{00Q}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "dialog.mDs1vky2.css",
    "src": "_dialog.!~{00Q}~.js"
  },
  "_dialog.Yt_iz6Sc.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "dialog.mDs1vky2.css"
    ],
    "file": "dialog.Yt_iz6Sc.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_isUndefined.IZwZ21d-.js"
    ]
  },
  "dialog.mDs1vky2.css": {
    "file": "dialog.mDs1vky2.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_divider.!~{00N}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "divider.mvCfgREV.css",
    "src": "_divider.!~{00N}~.js"
  },
  "_divider.eGAv1joe.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "divider.mvCfgREV.css"
    ],
    "file": "divider.eGAv1joe.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "divider.mvCfgREV.css": {
    "file": "divider.mvCfgREV.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_effect-creative.ughK3TEs.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "effect-creative.ughK3TEs.js",
    "imports": [
      "_create-shadow.O2fgC1s_.js"
    ]
  },
  "_empty.!~{00J}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "empty.sDhVTJEQ.css",
    "src": "_empty.!~{00J}~.js"
  },
  "_empty.vkBaGm1c.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "empty.sDhVTJEQ.css"
    ],
    "file": "empty.vkBaGm1c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "empty.sDhVTJEQ.css": {
    "file": "empty.sDhVTJEQ.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_flatten.G9UgQF_S.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "flatten.G9UgQF_S.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_friend.kks2XXaj.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "friend.kks2XXaj.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_hasIn.ilVBUtyE.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "hasIn.ilVBUtyE.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.!~{01c}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.BbVs9JM6.css",
    "src": "_index.!~{01c}~.js"
  },
  "_index.-Zc7vbn_.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.-Zc7vbn_.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.5Ghl8XGW.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.5Ghl8XGW.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ]
  },
  "_index.9-eF-C1h.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.9-eF-C1h.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.K3NjyUwU.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.K3NjyUwU.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.Pt091gh7.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.Pt091gh7.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.Wx6-_x6Y.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.Wx6-_x6Y.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.hboeLvE_.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.hboeLvE_.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.rk2ex1ne.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.rk2ex1ne.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.sisnfLww.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.sisnfLww.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.uDNa5rfU.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.uDNa5rfU.js",
    "imports": [
      "_popper.4o1574AU.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.w2XVvOqe.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.BbVs9JM6.css"
    ],
    "file": "index.w2XVvOqe.js",
    "imports": [
      "_ElImage.8lCJ1V3q.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "index.BbVs9JM6.css": {
    "file": "index.BbVs9JM6.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_input-number.!~{01p}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "input-number.5AezeF1g.css",
    "src": "_input-number.!~{01p}~.js"
  },
  "_input-number.9iSkt-XV.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "input-number.5AezeF1g.css"
    ],
    "file": "input-number.9iSkt-XV.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.K3NjyUwU.js"
    ]
  },
  "input-number.5AezeF1g.css": {
    "file": "input-number.5AezeF1g.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_isEqual.4gvyVEHC.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "isEqual.4gvyVEHC.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_isUndefined.IZwZ21d-.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "isUndefined.IZwZ21d-.js"
  },
  "_localeData.FMM2ZQ75.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "localeData.FMM2ZQ75.js",
    "imports": [
      "___commonjsHelpers__.1J56E-h6.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_logo_dark.ZPOuYKQQ.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "popover.LAISAeEG.css"
    ],
    "dynamicImports": [
      "components/card/UserLine.vue"
    ],
    "file": "logo_dark.ZPOuYKQQ.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.g75woKBL.js",
      "_scrollbar.I2vPmCtb.js",
      "_index.uDNa5rfU.js",
      "_popper.4o1574AU.js"
    ]
  },
  "_menu-item.!~{01O}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "menu-item.f0mNRiTD.css",
    "src": "_tooltip.!~{01I}~.js"
  },
  "_menu.!~{01N}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "menu.6YbFhd-D.css",
    "src": "_menu.!~{01N}~.js"
  },
  "_menu.XxwaSUgg.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "menu.6YbFhd-D.css"
    ],
    "file": "menu.XxwaSUgg.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.-Zc7vbn_.js",
      "_popper.4o1574AU.js",
      "_index.Pt091gh7.js"
    ]
  },
  "menu.6YbFhd-D.css": {
    "file": "menu.6YbFhd-D.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_notification.!~{00H}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "notification.8O_B6xHM.css",
    "src": "_notification.!~{00H}~.js"
  },
  "_notification.qe9EsX_4.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "notification.8O_B6xHM.css"
    ],
    "file": "notification.qe9EsX_4.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "notification.8O_B6xHM.css": {
    "file": "notification.8O_B6xHM.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_nuxt-link.g75woKBL.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "nuxt-link.g75woKBL.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_popover.!~{01i}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "popover.LAISAeEG.css",
    "src": "_popover.!~{01i}~.js"
  },
  "_popper.!~{00X}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "popper.nTJkgMH4.css",
    "src": "_popper.!~{00X}~.js"
  },
  "_popper.4o1574AU.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "popper.nTJkgMH4.css"
    ],
    "file": "popper.4o1574AU.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_isUndefined.IZwZ21d-.js"
    ]
  },
  "popper.nTJkgMH4.css": {
    "file": "popper.nTJkgMH4.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_post.HyyszCAI.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "post.HyyszCAI.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_progress.!~{011}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "progress.rXLlm_9F.css",
    "src": "_progress.!~{011}~.js"
  },
  "_progress.XvBCmKKY.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "progress.rXLlm_9F.css"
    ],
    "file": "progress.XvBCmKKY.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "progress.rXLlm_9F.css": {
    "file": "progress.rXLlm_9F.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_radio-button.!~{012}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "radio-button.l7x146Nf.css",
    "src": "_radio-button.!~{012}~.js"
  },
  "_radio-group.!~{00M}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "radio-group.P_Xz2fNs.css",
    "src": "_radio-group.!~{00M}~.js"
  },
  "_radio.!~{00U}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "radio.eYTrrdr6.css",
    "src": "_radio.!~{00U}~.js"
  },
  "_rate.!~{01s}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "rate.mGuCO7Lx.css",
    "src": "_rate.!~{01s}~.js"
  },
  "_rate.pIONEzW5.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "rate.mGuCO7Lx.css"
    ],
    "file": "rate.pIONEzW5.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "rate.mGuCO7Lx.css": {
    "file": "rate.mGuCO7Lx.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_scrollbar.!~{00A}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "scrollbar.Smf0pYfu.css",
    "src": "_scrollbar.!~{00A}~.js"
  },
  "_scrollbar.I2vPmCtb.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "scrollbar.Smf0pYfu.css"
    ],
    "file": "scrollbar.I2vPmCtb.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "scrollbar.Smf0pYfu.css": {
    "file": "scrollbar.Smf0pYfu.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_select.!~{00V}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "select.xPRdjiL2.css",
    "src": "_select.!~{00V}~.js"
  },
  "_select.BqpNHvAi.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "select.xPRdjiL2.css"
    ],
    "file": "select.BqpNHvAi.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_popper.4o1574AU.js",
      "_scrollbar.I2vPmCtb.js",
      "_tag.eNhCwUom.js",
      "_strings.MCAJnFKt.js",
      "_isEqual.4gvyVEHC.js",
      "_debounce.Ks9NfFzx.js",
      "_hasIn.ilVBUtyE.js",
      "_index.Pt091gh7.js"
    ]
  },
  "select.xPRdjiL2.css": {
    "file": "select.xPRdjiL2.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_sku.DITaIO81.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sku.DITaIO81.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_strings.MCAJnFKt.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "strings.MCAJnFKt.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_tabs.!~{015}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "tabs.H-UKPvku.css",
    "src": "_tabs.!~{015}~.js"
  },
  "_tabs.8qzfQfEZ.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "tabs.H-UKPvku.css"
    ],
    "file": "tabs.8qzfQfEZ.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_strings.MCAJnFKt.js",
      "_index.rk2ex1ne.js"
    ]
  },
  "tabs.H-UKPvku.css": {
    "file": "tabs.H-UKPvku.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_tag.!~{00F}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "tag.Wo0upPQu.css",
    "src": "_tag.!~{00F}~.js"
  },
  "_tag.eNhCwUom.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "tag.Wo0upPQu.css"
    ],
    "file": "tag.eNhCwUom.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "tag.Wo0upPQu.css": {
    "file": "tag.Wo0upPQu.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_tooltip.!~{01I}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "menu-item.f0mNRiTD.css",
    "src": "_tooltip.!~{01I}~.js"
  },
  "_upload.!~{01x}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "upload.5r92S6hB.css",
    "src": "_upload.!~{01x}~.js"
  },
  "_upload.VluGrriO.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "upload.5r92S6hB.css"
    ],
    "file": "upload.VluGrriO.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_progress.XvBCmKKY.js",
      "_cloneDeep.IE38ijpa.js",
      "_isEqual.4gvyVEHC.js"
    ]
  },
  "upload.5r92S6hB.css": {
    "file": "upload.5r92S6hB.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_useOrderStore.1sLnZmfa.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useOrderStore.1sLnZmfa.js",
    "imports": [
      "_index.9-eF-C1h.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_useWebToast.pg9-1HsZ.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useWebToast.pg9-1HsZ.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_useWs.zjavPj1e.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useWs.zjavPj1e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_notification.qe9EsX_4.js"
    ]
  },
  "components/Chat/Friend/ApplyDialog.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ApplyDialog.Q8hiXFM-.js",
    "imports": [
      "_ApplyDialog.vue.kJUj3Udd.js",
      "node_modules/nuxt/dist/app/entry.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_dialog.Yt_iz6Sc.js",
      "_isUndefined.IZwZ21d-.js",
      "_notification.qe9EsX_4.js",
      "_friend.kks2XXaj.js"
    ],
    "isDynamicEntry": true,
    "src": "components/Chat/Friend/ApplyDialog.vue"
  },
  "components/Chat/NewGroupDialog.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "NewGroupDialog.Hm5sbp8R.css",
      "checkbox-group.d5XbR8TY.css"
    ],
    "file": "NewGroupDialog.BHsvY_4A.js",
    "imports": [
      "_ElImage.8lCJ1V3q.js",
      "_checkbox.9IwwzgIx.js",
      "_AutoIncre.vue.X3Tv3UDL.js",
      "_scrollbar.I2vPmCtb.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_OssFileUpload.7trMrZMp.js",
      "_dialog.Yt_iz6Sc.js",
      "_notification.qe9EsX_4.js",
      "_contact.e_2KdKkO.js",
      "_Main.h-TpnM_a.js",
      "_friend.kks2XXaj.js",
      "_debounce.Ks9NfFzx.js",
      "_isEqual.4gvyVEHC.js",
      "_hasIn.ilVBUtyE.js",
      "_flatten.G9UgQF_S.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_progress.XvBCmKKY.js",
      "_index.5Ghl8XGW.js",
      "_isUndefined.IZwZ21d-.js",
      "_useWs.zjavPj1e.js",
      "_tag.eNhCwUom.js"
    ],
    "isDynamicEntry": true,
    "src": "components/Chat/NewGroupDialog.vue"
  },
  "NewGroupDialog.Hm5sbp8R.css": {
    "file": "NewGroupDialog.Hm5sbp8R.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "checkbox-group.d5XbR8TY.css": {
    "file": "checkbox-group.d5XbR8TY.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/Comm/PostList.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "PostList._i8MVHra.css"
    ],
    "file": "PostList.4Eu7KhYe.js",
    "imports": [
      "_ElImage.8lCJ1V3q.js",
      "_nuxt-link.g75woKBL.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.eNhCwUom.js",
      "_TagList.vue.GONtJwxu.js",
      "_CommentPreview.B4PXLCuS.js",
      "_AutoIncre.vue.X3Tv3UDL.js",
      "_post.HyyszCAI.js",
      "_debounce.Ks9NfFzx.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_select.BqpNHvAi.js",
      "_popper.4o1574AU.js",
      "_isUndefined.IZwZ21d-.js",
      "_scrollbar.I2vPmCtb.js",
      "_strings.MCAJnFKt.js",
      "_isEqual.4gvyVEHC.js",
      "_hasIn.ilVBUtyE.js",
      "_index.Pt091gh7.js",
      "_OssFileUpload.7trMrZMp.js",
      "_progress.XvBCmKKY.js",
      "_index.5Ghl8XGW.js",
      "_notification.qe9EsX_4.js"
    ],
    "isDynamicEntry": true,
    "src": "components/Comm/PostList.vue"
  },
  "PostList._i8MVHra.css": {
    "file": "PostList._i8MVHra.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/Comm/post/CateGoryLine.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "CateGoryLine.143J1JnR.js",
    "imports": [
      "_ElImage.8lCJ1V3q.js",
      "_nuxt-link.g75woKBL.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_debounce.Ks9NfFzx.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "components/Comm/post/CateGoryLine.vue"
  },
  "components/Comm/post/Rank.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "Rank.y3OSjSFp.css"
    ],
    "file": "Rank.quPUcOUX.js",
    "imports": [
      "_divider.eGAv1joe.js",
      "_tag.eNhCwUom.js",
      "_ElImage.8lCJ1V3q.js",
      "_nuxt-link.g75woKBL.js",
      "_empty.vkBaGm1c.js",
      "_scrollbar.I2vPmCtb.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_post.HyyszCAI.js",
      "_debounce.Ks9NfFzx.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "components/Comm/post/Rank.vue"
  },
  "Rank.y3OSjSFp.css": {
    "file": "Rank.y3OSjSFp.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/card/UserLine.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "UserLine.G_lnDfVq.css",
      "popover.LAISAeEG.css"
    ],
    "file": "UserLine.SbDM5aZ7.js",
    "imports": [
      "_avatar.gbsApbHF.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_upload.VluGrriO.js",
      "_nuxt-link.g75woKBL.js",
      "_index.uDNa5rfU.js",
      "_progress.XvBCmKKY.js",
      "_popper.4o1574AU.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_cloneDeep.IE38ijpa.js",
      "_isEqual.4gvyVEHC.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "components/card/UserLine.vue"
  },
  "UserLine.G_lnDfVq.css": {
    "file": "UserLine.G_lnDfVq.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/list/GoodsList.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "GoodsList.1p6fEF-7.css"
    ],
    "file": "GoodsList.XgC2qqRO.js",
    "imports": [
      "_index.w2XVvOqe.js",
      "_nuxt-link.g75woKBL.js",
      "_AutoIncre.vue.X3Tv3UDL.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.8lCJ1V3q.js",
      "_debounce.Ks9NfFzx.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "components/list/GoodsList.vue"
  },
  "GoodsList.1p6fEF-7.css": {
    "file": "GoodsList.1p6fEF-7.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/menu/DrawerMenu.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "DrawerMenu.0ja6gThp.css",
      "menu-item.f0mNRiTD.css",
      "popover.LAISAeEG.css"
    ],
    "file": "DrawerMenu.Rmq1hC0L.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_menu.XxwaSUgg.js",
      "_scrollbar.I2vPmCtb.js",
      "_popper.4o1574AU.js",
      "_logo_dark.ZPOuYKQQ.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_index.-Zc7vbn_.js",
      "_index.Pt091gh7.js",
      "_isUndefined.IZwZ21d-.js",
      "_nuxt-link.g75woKBL.js",
      "_index.uDNa5rfU.js"
    ],
    "isDynamicEntry": true,
    "src": "components/menu/DrawerMenu.vue"
  },
  "DrawerMenu.0ja6gThp.css": {
    "file": "DrawerMenu.0ja6gThp.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "menu-item.f0mNRiTD.css": {
    "file": "menu-item.f0mNRiTD.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/menu/RightButtons/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.Kxo_iM1u.css",
      "popover.LAISAeEG.css",
      "menu-item.f0mNRiTD.css"
    ],
    "dynamicImports": [
      "components/menu/ShopCartBar.vue"
    ],
    "file": "index.AI2qMfgY.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.g75woKBL.js",
      "_Main.h-TpnM_a.js",
      "_scrollbar.I2vPmCtb.js",
      "_ElImage.8lCJ1V3q.js",
      "_index.uDNa5rfU.js",
      "_popper.4o1574AU.js",
      "_contact.e_2KdKkO.js",
      "_useWs.zjavPj1e.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_tag.eNhCwUom.js",
      "_debounce.Ks9NfFzx.js",
      "_isUndefined.IZwZ21d-.js",
      "_notification.qe9EsX_4.js"
    ],
    "isDynamicEntry": true,
    "src": "components/menu/RightButtons/index.vue"
  },
  "index.Kxo_iM1u.css": {
    "file": "index.Kxo_iM1u.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/menu/ShopCartBar.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "ShopCartBar.EsIq9V-V.css",
      "checkbox-group.d5XbR8TY.css",
      "popover.LAISAeEG.css"
    ],
    "file": "ShopCartBar.lumqpujy.js",
    "imports": [
      "_checkbox.9IwwzgIx.js",
      "_ShopLine.NOoQxm3f.js",
      "_AutoIncre.vue.X3Tv3UDL.js",
      "_scrollbar.I2vPmCtb.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.uDNa5rfU.js",
      "_popper.4o1574AU.js",
      "_useOrderStore.1sLnZmfa.js",
      "_isEqual.4gvyVEHC.js",
      "_hasIn.ilVBUtyE.js",
      "_flatten.G9UgQF_S.js",
      "_ElImage.8lCJ1V3q.js",
      "_debounce.Ks9NfFzx.js",
      "_nuxt-link.g75woKBL.js",
      "_select.BqpNHvAi.js",
      "_tag.eNhCwUom.js",
      "_strings.MCAJnFKt.js",
      "_index.Pt091gh7.js",
      "_input-number.9iSkt-XV.js",
      "_index.K3NjyUwU.js",
      "_sku.DITaIO81.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isUndefined.IZwZ21d-.js",
      "_index.9-eF-C1h.js"
    ],
    "isDynamicEntry": true,
    "src": "components/menu/ShopCartBar.vue"
  },
  "ShopCartBar.EsIq9V-V.css": {
    "file": "ShopCartBar.EsIq9V-V.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "layouts/chat.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "chat.REpaLqUH.css",
      "menu-item.f0mNRiTD.css",
      "popover.LAISAeEG.css"
    ],
    "dynamicImports": [
      "components/menu/RightButtons/index.vue"
    ],
    "file": "chat.eGeoSC2e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.8lCJ1V3q.js",
      "components/card/UserLine.vue",
      "_menu.XxwaSUgg.js",
      "_popper.4o1574AU.js",
      "_useWs.zjavPj1e.js",
      "_friend.kks2XXaj.js",
      "_useWebToast.pg9-1HsZ.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.Ks9NfFzx.js",
      "_avatar.gbsApbHF.js",
      "_upload.VluGrriO.js",
      "_progress.XvBCmKKY.js",
      "_cloneDeep.IE38ijpa.js",
      "_isEqual.4gvyVEHC.js",
      "_nuxt-link.g75woKBL.js",
      "_index.uDNa5rfU.js",
      "_index.-Zc7vbn_.js",
      "_index.Pt091gh7.js",
      "_isUndefined.IZwZ21d-.js",
      "_notification.qe9EsX_4.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/chat.vue"
  },
  "chat.REpaLqUH.css": {
    "file": "chat.REpaLqUH.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "layouts/error.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "error.mqtnLi4_.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/error.vue"
  },
  "layouts/main.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "popover.LAISAeEG.css",
      "menu-item.f0mNRiTD.css"
    ],
    "dynamicImports": [
      "components/menu/DrawerMenu.vue"
    ],
    "file": "main.rnymeFQQ.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_Footer.JE1CXWEl.js",
      "components/menu/RightButtons/index.vue",
      "___commonjsHelpers__.1J56E-h6.js",
      "_nuxt-link.g75woKBL.js",
      "_logo_dark.ZPOuYKQQ.js",
      "_scrollbar.I2vPmCtb.js",
      "_index.uDNa5rfU.js",
      "_popper.4o1574AU.js",
      "_isUndefined.IZwZ21d-.js",
      "_Switch.NMri1Y-g.js",
      "_Main.h-TpnM_a.js",
      "_contact.e_2KdKkO.js",
      "_useWs.zjavPj1e.js",
      "_notification.qe9EsX_4.js",
      "_ElImage.8lCJ1V3q.js",
      "_debounce.Ks9NfFzx.js",
      "_tag.eNhCwUom.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/main.vue"
  },
  "layouts/second.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "second.JqdAvVfB.css",
      "popover.LAISAeEG.css",
      "menu-item.f0mNRiTD.css"
    ],
    "file": "second.j5FX88wf.js",
    "imports": [
      "_Footer.JE1CXWEl.js",
      "components/menu/RightButtons/index.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.g75woKBL.js",
      "_logo_dark.ZPOuYKQQ.js",
      "_scrollbar.I2vPmCtb.js",
      "_index.uDNa5rfU.js",
      "_popper.4o1574AU.js",
      "_isUndefined.IZwZ21d-.js",
      "_Switch.NMri1Y-g.js",
      "_Main.h-TpnM_a.js",
      "_contact.e_2KdKkO.js",
      "_useWs.zjavPj1e.js",
      "_notification.qe9EsX_4.js",
      "_ElImage.8lCJ1V3q.js",
      "_debounce.Ks9NfFzx.js",
      "_tag.eNhCwUom.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/second.vue"
  },
  "second.JqdAvVfB.css": {
    "file": "second.JqdAvVfB.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "layouts/user.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "user.yAuj-VgQ.css",
      "menu-item.f0mNRiTD.css",
      "popover.LAISAeEG.css"
    ],
    "file": "user.DhFiHtZV.js",
    "imports": [
      "_nuxt-link.g75woKBL.js",
      "_logo_dark.ZPOuYKQQ.js",
      "_Switch.NMri1Y-g.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_menu.XxwaSUgg.js",
      "_popper.4o1574AU.js",
      "components/menu/RightButtons/index.vue",
      "_scrollbar.I2vPmCtb.js",
      "_index.uDNa5rfU.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_index.-Zc7vbn_.js",
      "_index.Pt091gh7.js",
      "_isUndefined.IZwZ21d-.js",
      "_Main.h-TpnM_a.js",
      "_contact.e_2KdKkO.js",
      "_useWs.zjavPj1e.js",
      "_notification.qe9EsX_4.js",
      "_ElImage.8lCJ1V3q.js",
      "_debounce.Ks9NfFzx.js",
      "_tag.eNhCwUom.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/user.vue"
  },
  "user.yAuj-VgQ.css": {
    "file": "user.yAuj-VgQ.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/element-plus/es/components/text/index.mjs": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.l5CC8IXT.css"
    ],
    "file": "index._65pbO5j.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/element-plus/es/components/text/index.mjs"
  },
  "index.l5CC8IXT.css": {
    "file": "index.l5CC8IXT.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "entry.o9YI8Z1z.css"
    ],
    "dynamicImports": [
      "layouts/chat.vue",
      "layouts/error.vue",
      "layouts/main.vue",
      "layouts/second.vue",
      "layouts/user.vue",
      "node_modules/workbox-window/build/workbox-window.prod.es5.mjs"
    ],
    "file": "entry.PV282jgu.js",
    "imports": [
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js"
  },
  "entry.o9YI8Z1z.css": {
    "file": "entry.o9YI8Z1z.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/workbox-window/build/workbox-window.prod.es5.mjs": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "workbox-window.prod.es5.prqDwDSL.js",
    "isDynamicEntry": true,
    "src": "node_modules/workbox-window/build/workbox-window.prod.es5.mjs"
  },
  "pages/[...all].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_...all_.SWxFdLDl.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/[...all].vue"
  },
  "pages/chat/ai.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "ai.df74smAD.css"
    ],
    "file": "ai.vvYWl2Ho.js",
    "imports": [
      "_Main.h-TpnM_a.js",
      "_scrollbar.I2vPmCtb.js",
      "_ElImage.8lCJ1V3q.js",
      "_nuxt-link.g75woKBL.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_contact.e_2KdKkO.js",
      "_useWs.zjavPj1e.js",
      "_tag.eNhCwUom.js",
      "_debounce.Ks9NfFzx.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_notification.qe9EsX_4.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/chat/ai.vue"
  },
  "ai.df74smAD.css": {
    "file": "ai.df74smAD.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/chat/friend.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "friend.chnzZ23W.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "file": "friend.NzMIsqf0.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.eNhCwUom.js",
      "_ElImage.8lCJ1V3q.js",
      "_AutoIncre.vue.X3Tv3UDL.js",
      "_scrollbar.I2vPmCtb.js",
      "_empty.vkBaGm1c.js",
      "_friend.kks2XXaj.js",
      "_index.Wx6-_x6Y.js",
      "_contact.e_2KdKkO.js",
      "_useWs.zjavPj1e.js",
      "_notification.qe9EsX_4.js",
      "_divider.eGAv1joe.js",
      "_ApplyDialog.vue.kJUj3Udd.js",
      "_index.hboeLvE_.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.Ks9NfFzx.js",
      "_dialog.Yt_iz6Sc.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/chat/friend.vue"
  },
  "friend.chnzZ23W.css": {
    "file": "friend.chnzZ23W.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "radio-group.P_Xz2fNs.css": {
    "file": "radio-group.P_Xz2fNs.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/chat/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.0vnPmkGu.css",
      "radio.eYTrrdr6.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "dynamicImports": [
      "components/Chat/NewGroupDialog.vue",
      "components/Chat/NewGroupDialog.vue",
      "components/Chat/Friend/ApplyDialog.vue"
    ],
    "file": "index.gFg5KjW0.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.8lCJ1V3q.js",
      "_index.Wx6-_x6Y.js",
      "_AutoIncre.vue.X3Tv3UDL.js",
      "_notification.qe9EsX_4.js",
      "_contact.e_2KdKkO.js",
      "_Main.h-TpnM_a.js",
      "_friend.kks2XXaj.js",
      "_useWs.zjavPj1e.js",
      "_tag.eNhCwUom.js",
      "_scrollbar.I2vPmCtb.js",
      "_select.BqpNHvAi.js",
      "_OssFileUpload.7trMrZMp.js",
      "_nuxt-link.g75woKBL.js",
      "_popper.4o1574AU.js",
      "_index.5Ghl8XGW.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.Ks9NfFzx.js",
      "_strings.MCAJnFKt.js",
      "_isEqual.4gvyVEHC.js",
      "_hasIn.ilVBUtyE.js",
      "_index.Pt091gh7.js",
      "_progress.XvBCmKKY.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/chat/index.vue"
  },
  "index.0vnPmkGu.css": {
    "file": "index.0vnPmkGu.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "radio.eYTrrdr6.css": {
    "file": "radio.eYTrrdr6.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/chat/setting.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "setting.SSmFdXUR.css",
      "radio-button.l7x146Nf.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "file": "setting.L--DY00M.js",
    "imports": [
      "_divider.eGAv1joe.js",
      "_select.BqpNHvAi.js",
      "_index.Wx6-_x6Y.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.eNhCwUom.js",
      "_scrollbar.I2vPmCtb.js",
      "_popper.4o1574AU.js",
      "_notification.qe9EsX_4.js",
      "_strings.MCAJnFKt.js",
      "_isEqual.4gvyVEHC.js",
      "_debounce.Ks9NfFzx.js",
      "_hasIn.ilVBUtyE.js",
      "_index.Pt091gh7.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/chat/setting.vue"
  },
  "setting.SSmFdXUR.css": {
    "file": "setting.SSmFdXUR.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "radio-button.l7x146Nf.css": {
    "file": "radio-button.l7x146Nf.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/category/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "_id_.uLLhAsoU.css"
    ],
    "dynamicImports": [
      "components/Comm/post/Rank.vue"
    ],
    "file": "_id_.k6owCaN8.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.8lCJ1V3q.js",
      "_CategoryTabs.r5LuUyEz.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.Ks9NfFzx.js",
      "_tabs.8qzfQfEZ.js",
      "_strings.MCAJnFKt.js",
      "_index.rk2ex1ne.js",
      "components/Comm/PostList.vue",
      "_nuxt-link.g75woKBL.js",
      "_tag.eNhCwUom.js",
      "_TagList.vue.GONtJwxu.js",
      "_CommentPreview.B4PXLCuS.js",
      "_select.BqpNHvAi.js",
      "_popper.4o1574AU.js",
      "_isUndefined.IZwZ21d-.js",
      "_scrollbar.I2vPmCtb.js",
      "_isEqual.4gvyVEHC.js",
      "_hasIn.ilVBUtyE.js",
      "_index.Pt091gh7.js",
      "_OssFileUpload.7trMrZMp.js",
      "_progress.XvBCmKKY.js",
      "_index.5Ghl8XGW.js",
      "_AutoIncre.vue.X3Tv3UDL.js",
      "_notification.qe9EsX_4.js",
      "_post.HyyszCAI.js",
      "components/list/GoodsList.vue",
      "_index.w2XVvOqe.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/category/[id].vue"
  },
  "_id_.uLLhAsoU.css": {
    "file": "_id_.uLLhAsoU.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/category/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.EaIT1GIC.css"
    ],
    "dynamicImports": [
      "components/Comm/post/Rank.vue"
    ],
    "file": "index.AFurqbNh.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_CategoryTabs.r5LuUyEz.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_tabs.8qzfQfEZ.js",
      "_strings.MCAJnFKt.js",
      "_index.rk2ex1ne.js",
      "components/Comm/PostList.vue",
      "_ElImage.8lCJ1V3q.js",
      "_debounce.Ks9NfFzx.js",
      "_nuxt-link.g75woKBL.js",
      "_tag.eNhCwUom.js",
      "_TagList.vue.GONtJwxu.js",
      "_CommentPreview.B4PXLCuS.js",
      "_select.BqpNHvAi.js",
      "_popper.4o1574AU.js",
      "_isUndefined.IZwZ21d-.js",
      "_scrollbar.I2vPmCtb.js",
      "_isEqual.4gvyVEHC.js",
      "_hasIn.ilVBUtyE.js",
      "_index.Pt091gh7.js",
      "_OssFileUpload.7trMrZMp.js",
      "_progress.XvBCmKKY.js",
      "_index.5Ghl8XGW.js",
      "_AutoIncre.vue.X3Tv3UDL.js",
      "_notification.qe9EsX_4.js",
      "_post.HyyszCAI.js",
      "components/list/GoodsList.vue",
      "_index.w2XVvOqe.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/category/index.vue"
  },
  "index.EaIT1GIC.css": {
    "file": "index.EaIT1GIC.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/post/detail/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "_id_.8W7c6sq_.css",
      "popover.LAISAeEG.css"
    ],
    "dynamicImports": [
      "components/Comm/post/CateGoryLine.vue"
    ],
    "file": "_id_._I7P71dG.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.8lCJ1V3q.js",
      "_Switch.NMri1Y-g.js",
      "_tag.eNhCwUom.js",
      "_nuxt-link.g75woKBL.js",
      "_TagList.vue.GONtJwxu.js",
      "_divider.eGAv1joe.js",
      "_post.HyyszCAI.js",
      "_CommentPreview.B4PXLCuS.js",
      "_UserPostTotal.vue.LK7H1ixP.js",
      "_SigninCard.vue.vP5WGlM7.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.Ks9NfFzx.js",
      "_select.BqpNHvAi.js",
      "_popper.4o1574AU.js",
      "_isUndefined.IZwZ21d-.js",
      "_scrollbar.I2vPmCtb.js",
      "_strings.MCAJnFKt.js",
      "_isEqual.4gvyVEHC.js",
      "_hasIn.ilVBUtyE.js",
      "_index.Pt091gh7.js",
      "_OssFileUpload.7trMrZMp.js",
      "_progress.XvBCmKKY.js",
      "_index.5Ghl8XGW.js",
      "_AutoIncre.vue.X3Tv3UDL.js",
      "_notification.qe9EsX_4.js",
      "_index.uDNa5rfU.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/post/detail/[id].vue"
  },
  "_id_.8W7c6sq_.css": {
    "file": "_id_.8W7c6sq_.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/post/list.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "list.aADC_aru.css",
      "popover.LAISAeEG.css"
    ],
    "file": "list.6-l3q7Uu.js",
    "imports": [
      "_nuxt-link.g75woKBL.js",
      "_tag.eNhCwUom.js",
      "_create-shadow.O2fgC1s_.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_effect-creative.ughK3TEs.js",
      "_post.HyyszCAI.js",
      "_ElImage.8lCJ1V3q.js",
      "components/Comm/PostList.vue",
      "_tabs.8qzfQfEZ.js",
      "_SigninCard.vue.vP5WGlM7.js",
      "components/Comm/post/Rank.vue",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.Ks9NfFzx.js",
      "_TagList.vue.GONtJwxu.js",
      "_CommentPreview.B4PXLCuS.js",
      "_select.BqpNHvAi.js",
      "_popper.4o1574AU.js",
      "_isUndefined.IZwZ21d-.js",
      "_scrollbar.I2vPmCtb.js",
      "_strings.MCAJnFKt.js",
      "_isEqual.4gvyVEHC.js",
      "_hasIn.ilVBUtyE.js",
      "_index.Pt091gh7.js",
      "_OssFileUpload.7trMrZMp.js",
      "_progress.XvBCmKKY.js",
      "_index.5Ghl8XGW.js",
      "_AutoIncre.vue.X3Tv3UDL.js",
      "_notification.qe9EsX_4.js",
      "_index.rk2ex1ne.js",
      "_index.uDNa5rfU.js",
      "_divider.eGAv1joe.js",
      "_empty.vkBaGm1c.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/post/list.vue"
  },
  "list.aADC_aru.css": {
    "file": "list.aADC_aru.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/post/new.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "new.9wZIBQf0.css",
      "radio-button.l7x146Nf.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "file": "new.jY7SWjfy.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_OssFileUpload.7trMrZMp.js",
      "_index.Wx6-_x6Y.js",
      "_ElImage.8lCJ1V3q.js",
      "_select.BqpNHvAi.js",
      "_tag.eNhCwUom.js",
      "_scrollbar.I2vPmCtb.js",
      "_popper.4o1574AU.js",
      "_notification.qe9EsX_4.js",
      "_index.5Ghl8XGW.js",
      "_StatusTag.-07-kXkn.js",
      "_post.HyyszCAI.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_progress.XvBCmKKY.js",
      "_debounce.Ks9NfFzx.js",
      "_strings.MCAJnFKt.js",
      "_isEqual.4gvyVEHC.js",
      "_hasIn.ilVBUtyE.js",
      "_index.Pt091gh7.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/post/new.vue"
  },
  "new.9wZIBQf0.css": {
    "file": "new.9wZIBQf0.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/event/detail/[eid].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "_eid_.NtANQ6Xa.css"
    ],
    "file": "_eid_.3jC7-wY_.js",
    "imports": [
      "_ElImage.8lCJ1V3q.js",
      "_tag.eNhCwUom.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.g75woKBL.js",
      "_index.sisnfLww.js",
      "_debounce.Ks9NfFzx.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/event/detail/[eid].vue"
  },
  "_eid_.NtANQ6Xa.css": {
    "file": "_eid_.NtANQ6Xa.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/goods/comments/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_id_.kiwB_HHP.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/goods/comments/[id].vue"
  },
  "pages/goods/detail/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "_id_.spxRS6Bk.css",
      "popover.LAISAeEG.css",
      "radio-button.l7x146Nf.css",
      "radio-group.P_Xz2fNs.css",
      "radio.eYTrrdr6.css"
    ],
    "file": "_id_.NvrsHtLT.js",
    "imports": [
      "_nuxt-link.g75woKBL.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_GoodsListSsr.gDnTAQ6n.js",
      "_ElImage.8lCJ1V3q.js",
      "_index.rk2ex1ne.js",
      "_scrollbar.I2vPmCtb.js",
      "_tag.eNhCwUom.js",
      "_popper.4o1574AU.js",
      "_collect.iOEnxm1K.js",
      "_index.Wx6-_x6Y.js",
      "_input-number.9iSkt-XV.js",
      "_useOrderStore.1sLnZmfa.js",
      "_index.sisnfLww.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_tabs.8qzfQfEZ.js",
      "_rate.pIONEzW5.js",
      "_AutoIncre.vue.X3Tv3UDL.js",
      "_dialog.Yt_iz6Sc.js",
      "_index.-Zc7vbn_.js",
      "_index.w2XVvOqe.js",
      "_sku.DITaIO81.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.Ks9NfFzx.js",
      "_isUndefined.IZwZ21d-.js",
      "_index.K3NjyUwU.js",
      "_index.9-eF-C1h.js",
      "_strings.MCAJnFKt.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/goods/detail/[id].vue"
  },
  "_id_.spxRS6Bk.css": {
    "file": "_id_.spxRS6Bk.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.IfgpexZK.css",
      "popover.LAISAeEG.css"
    ],
    "dynamicImports": [
      "components/list/GoodsList.vue"
    ],
    "file": "index.4NJ8Ikhi.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.eNhCwUom.js",
      "_nuxt-link.g75woKBL.js",
      "_AutoIncre.vue.X3Tv3UDL.js",
      "_empty.vkBaGm1c.js",
      "_scrollbar.I2vPmCtb.js",
      "_index.uDNa5rfU.js",
      "_popper.4o1574AU.js",
      "_index.w2XVvOqe.js",
      "_create-shadow.O2fgC1s_.js",
      "_effect-creative.ughK3TEs.js",
      "_index.sisnfLww.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_GoodsListSsr.gDnTAQ6n.js",
      "_tabs.8qzfQfEZ.js",
      "_ElImage.8lCJ1V3q.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isUndefined.IZwZ21d-.js",
      "_strings.MCAJnFKt.js",
      "_index.rk2ex1ne.js",
      "_debounce.Ks9NfFzx.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.IfgpexZK.css": {
    "file": "index.IfgpexZK.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/order/comment/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "_id_.65PfMBS2.css"
    ],
    "file": "_id_.9jSs27YO.js",
    "imports": [
      "_Switch.NMri1Y-g.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_progress.XvBCmKKY.js",
      "_upload.VluGrriO.js",
      "_dialog.Yt_iz6Sc.js",
      "_index.5Ghl8XGW.js",
      "_ElImage.8lCJ1V3q.js",
      "_rate.pIONEzW5.js",
      "_checkbox.9IwwzgIx.js",
      "_nuxt-link.g75woKBL.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_notification.qe9EsX_4.js",
      "_index.9-eF-C1h.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_cloneDeep.IE38ijpa.js",
      "_isEqual.4gvyVEHC.js",
      "_isUndefined.IZwZ21d-.js",
      "_debounce.Ks9NfFzx.js",
      "_hasIn.ilVBUtyE.js",
      "_flatten.G9UgQF_S.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/order/comment/[id].vue"
  },
  "_id_.65PfMBS2.css": {
    "file": "_id_.65PfMBS2.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/order/detail.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "detail.Zq1m3l4e.css",
      "radio.eYTrrdr6.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "dynamicImports": [
      "node_modules/element-plus/es/components/text/index.mjs"
    ],
    "file": "detail.LufjBhHH.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.8lCJ1V3q.js",
      "_nuxt-link.g75woKBL.js",
      "_divider.eGAv1joe.js",
      "_DelayTimer.vue.bdBacTMI.js",
      "_Switch.NMri1Y-g.js",
      "_index.rk2ex1ne.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_bills.7u1Xnj1i.js",
      "_index.9-eF-C1h.js",
      "_useOrderStore.1sLnZmfa.js",
      "_index.Wx6-_x6Y.js",
      "_tag.eNhCwUom.js",
      "_scrollbar.I2vPmCtb.js",
      "_select.BqpNHvAi.js",
      "_input-number.9iSkt-XV.js",
      "_popper.4o1574AU.js",
      "_index.sisnfLww.js",
      "_sku.DITaIO81.js",
      "_empty.vkBaGm1c.js",
      "_notification.qe9EsX_4.js",
      "_useWebToast.pg9-1HsZ.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.Ks9NfFzx.js",
      "_strings.MCAJnFKt.js",
      "_isEqual.4gvyVEHC.js",
      "_hasIn.ilVBUtyE.js",
      "_index.Pt091gh7.js",
      "_index.K3NjyUwU.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/order/detail.vue"
  },
  "detail.Zq1m3l4e.css": {
    "file": "detail.Zq1m3l4e.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/order/list.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "list.pKmG3IwD.css"
    ],
    "file": "list.-nSKhG75.js",
    "imports": [
      "_divider.eGAv1joe.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_date-picker.SZ9NtVEP.js",
      "_DelayTimer.vue.bdBacTMI.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_ElImage.8lCJ1V3q.js",
      "_tag.eNhCwUom.js",
      "_useOrderStore.1sLnZmfa.js",
      "_index.9-eF-C1h.js",
      "_AutoIncre.vue.X3Tv3UDL.js",
      "_scrollbar.I2vPmCtb.js",
      "_popper.4o1574AU.js",
      "_notification.qe9EsX_4.js",
      "_tabs.8qzfQfEZ.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_localeData.FMM2ZQ75.js",
      "_arrays.9GuX8ZvT.js",
      "_flatten.G9UgQF_S.js",
      "_index.K3NjyUwU.js",
      "_debounce.Ks9NfFzx.js",
      "_index.Pt091gh7.js",
      "_isEqual.4gvyVEHC.js",
      "_isUndefined.IZwZ21d-.js",
      "_strings.MCAJnFKt.js",
      "_index.rk2ex1ne.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/order/list.vue"
  },
  "list.pKmG3IwD.css": {
    "file": "list.pKmG3IwD.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/search/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.avLsXlFQ.css"
    ],
    "dynamicImports": [
      "components/list/GoodsList.vue",
      "components/Comm/PostList.vue"
    ],
    "file": "index.cURfH8Tb.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_checkbox.9IwwzgIx.js",
      "_select.BqpNHvAi.js",
      "_tag.eNhCwUom.js",
      "_tabs.8qzfQfEZ.js",
      "_empty.vkBaGm1c.js",
      "_scrollbar.I2vPmCtb.js",
      "_popper.4o1574AU.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isEqual.4gvyVEHC.js",
      "_hasIn.ilVBUtyE.js",
      "_flatten.G9UgQF_S.js",
      "_strings.MCAJnFKt.js",
      "_debounce.Ks9NfFzx.js",
      "_index.Pt091gh7.js",
      "_index.rk2ex1ne.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/search/index.vue"
  },
  "index.avLsXlFQ.css": {
    "file": "index.avLsXlFQ.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/setting/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.z1SuaKix.css",
      "radio-button.l7x146Nf.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "file": "index.Jfw6jKYm.js",
    "imports": [
      "_divider.eGAv1joe.js",
      "_select.BqpNHvAi.js",
      "_index.Wx6-_x6Y.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.eNhCwUom.js",
      "_scrollbar.I2vPmCtb.js",
      "_popper.4o1574AU.js",
      "_notification.qe9EsX_4.js",
      "_strings.MCAJnFKt.js",
      "_isEqual.4gvyVEHC.js",
      "_debounce.Ks9NfFzx.js",
      "_hasIn.ilVBUtyE.js",
      "_index.Pt091gh7.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/setting/index.vue"
  },
  "index.z1SuaKix.css": {
    "file": "index.z1SuaKix.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/address.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "address.RlqThWjN.css",
      "radio.eYTrrdr6.css",
      "checkbox-group.d5XbR8TY.css"
    ],
    "file": "address.XnlABl0f.js",
    "imports": [
      "node_modules/element-plus/es/components/text/index.mjs",
      "node_modules/nuxt/dist/app/entry.js",
      "_scrollbar.I2vPmCtb.js",
      "_checkbox.9IwwzgIx.js",
      "_index.Wx6-_x6Y.js",
      "_strings.MCAJnFKt.js",
      "_isEqual.4gvyVEHC.js",
      "_arrays.9GuX8ZvT.js",
      "_flatten.G9UgQF_S.js",
      "_cloneDeep.IE38ijpa.js",
      "_popper.4o1574AU.js",
      "_tag.eNhCwUom.js",
      "_index.Pt091gh7.js",
      "_debounce.Ks9NfFzx.js",
      "_dialog.Yt_iz6Sc.js",
      "_divider.eGAv1joe.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_hasIn.ilVBUtyE.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/address.vue"
  },
  "address.RlqThWjN.css": {
    "file": "address.RlqThWjN.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/collect.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "collect.4jK4CO3w.css",
      "checkbox-group.d5XbR8TY.css"
    ],
    "file": "collect.GdBxYAyX.js",
    "imports": [
      "_divider.eGAv1joe.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_checkbox.9IwwzgIx.js",
      "_ElImage.8lCJ1V3q.js",
      "_scrollbar.I2vPmCtb.js",
      "_collect.iOEnxm1K.js",
      "_tabs.8qzfQfEZ.js",
      "_tag.eNhCwUom.js",
      "_nuxt-link.g75woKBL.js",
      "_TagList.vue.GONtJwxu.js",
      "_AutoIncre.vue.X3Tv3UDL.js",
      "_post.HyyszCAI.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isEqual.4gvyVEHC.js",
      "_hasIn.ilVBUtyE.js",
      "_flatten.G9UgQF_S.js",
      "_debounce.Ks9NfFzx.js",
      "_strings.MCAJnFKt.js",
      "_index.rk2ex1ne.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/collect.vue"
  },
  "collect.4jK4CO3w.css": {
    "file": "collect.4jK4CO3w.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/info.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "info.ZO--Iv68.css",
      "popover.LAISAeEG.css",
      "menu-item.f0mNRiTD.css"
    ],
    "file": "info.wQcbcMBn.js",
    "imports": [
      "_ElImage.8lCJ1V3q.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.uDNa5rfU.js",
      "_popper.4o1574AU.js",
      "_upload.VluGrriO.js",
      "_date-picker.SZ9NtVEP.js",
      "_select.BqpNHvAi.js",
      "_progress.XvBCmKKY.js",
      "_scrollbar.I2vPmCtb.js",
      "_tag.eNhCwUom.js",
      "_nuxt-link.g75woKBL.js",
      "_TagList.vue.GONtJwxu.js",
      "_AutoIncre.vue.X3Tv3UDL.js",
      "_post.HyyszCAI.js",
      "_tabs.8qzfQfEZ.js",
      "_UserPostTotal.vue.LK7H1ixP.js",
      "_SigninCard.vue.vP5WGlM7.js",
      "_index.hboeLvE_.js",
      "_debounce.Ks9NfFzx.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isUndefined.IZwZ21d-.js",
      "_cloneDeep.IE38ijpa.js",
      "_isEqual.4gvyVEHC.js",
      "_localeData.FMM2ZQ75.js",
      "_arrays.9GuX8ZvT.js",
      "_flatten.G9UgQF_S.js",
      "_index.K3NjyUwU.js",
      "_index.Pt091gh7.js",
      "_strings.MCAJnFKt.js",
      "_hasIn.ilVBUtyE.js",
      "_index.rk2ex1ne.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/info.vue"
  },
  "info.ZO--Iv68.css": {
    "file": "info.ZO--Iv68.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/post.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "post.yVQn8Ib0.css"
    ],
    "file": "post.jhpJrmsG.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.8lCJ1V3q.js",
      "_select.BqpNHvAi.js",
      "_tag.eNhCwUom.js",
      "_scrollbar.I2vPmCtb.js",
      "_popper.4o1574AU.js",
      "_StatusTag.-07-kXkn.js",
      "_nuxt-link.g75woKBL.js",
      "_TagList.vue.GONtJwxu.js",
      "_post.HyyszCAI.js",
      "_AutoIncre.vue.X3Tv3UDL.js",
      "_notification.qe9EsX_4.js",
      "_tabs.8qzfQfEZ.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.Ks9NfFzx.js",
      "_strings.MCAJnFKt.js",
      "_isEqual.4gvyVEHC.js",
      "_hasIn.ilVBUtyE.js",
      "_index.Pt091gh7.js",
      "_isUndefined.IZwZ21d-.js",
      "_index.rk2ex1ne.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/post.vue"
  },
  "post.yVQn8Ib0.css": {
    "file": "post.yVQn8Ib0.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/safe.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "safe.73roRH3g.css"
    ],
    "file": "safe.FTaiDTg9.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.eNhCwUom.js",
      "_scrollbar.I2vPmCtb.js",
      "_avatar.gbsApbHF.js",
      "_divider.eGAv1joe.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_useOrderStore.1sLnZmfa.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_index.9-eF-C1h.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/safe.vue"
  },
  "safe.73roRH3g.css": {
    "file": "safe.73roRH3g.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/shopcart.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "shopcart.T7K9gx-c.css",
      "checkbox-group.d5XbR8TY.css"
    ],
    "file": "shopcart.xdmUAKkS.js",
    "imports": [
      "_checkbox.9IwwzgIx.js",
      "_ShopLine.NOoQxm3f.js",
      "_nuxt-link.g75woKBL.js",
      "_AutoIncre.vue.X3Tv3UDL.js",
      "_scrollbar.I2vPmCtb.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useOrderStore.1sLnZmfa.js",
      "_isEqual.4gvyVEHC.js",
      "_hasIn.ilVBUtyE.js",
      "_flatten.G9UgQF_S.js",
      "_ElImage.8lCJ1V3q.js",
      "_debounce.Ks9NfFzx.js",
      "_select.BqpNHvAi.js",
      "_popper.4o1574AU.js",
      "_isUndefined.IZwZ21d-.js",
      "_tag.eNhCwUom.js",
      "_strings.MCAJnFKt.js",
      "_index.Pt091gh7.js",
      "_input-number.9iSkt-XV.js",
      "_index.K3NjyUwU.js",
      "_sku.DITaIO81.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_index.9-eF-C1h.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/shopcart.vue"
  },
  "shopcart.T7K9gx-c.css": {
    "file": "shopcart.T7K9gx-c.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/wallet.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "wallet.JgZZuLIl.css",
      "popover.LAISAeEG.css"
    ],
    "file": "wallet.0RZIstKI.js",
    "imports": [
      "node_modules/element-plus/es/components/text/index.mjs",
      "node_modules/nuxt/dist/app/entry.js",
      "_create-shadow.O2fgC1s_.js",
      "_progress.XvBCmKKY.js",
      "_index.uDNa5rfU.js",
      "_popper.4o1574AU.js",
      "_bills.7u1Xnj1i.js",
      "_scrollbar.I2vPmCtb.js",
      "_input-number.9iSkt-XV.js",
      "_select.BqpNHvAi.js",
      "_tag.eNhCwUom.js",
      "_localeData.FMM2ZQ75.js",
      "_divider.eGAv1joe.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isUndefined.IZwZ21d-.js",
      "_index.K3NjyUwU.js",
      "_strings.MCAJnFKt.js",
      "_isEqual.4gvyVEHC.js",
      "_debounce.Ks9NfFzx.js",
      "_hasIn.ilVBUtyE.js",
      "_index.Pt091gh7.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/wallet.vue"
  },
  "wallet.JgZZuLIl.css": {
    "file": "wallet.JgZZuLIl.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
