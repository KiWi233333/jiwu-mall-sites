const client_manifest = {
  "_ApplyDialog.vue.BA5OPWry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ApplyDialog.vue.BA5OPWry.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_dialog.Z0ZPFGm7.js",
      "_notification.bPhslSCw.js",
      "_friend.1Gtj4m1q.js"
    ]
  },
  "_AutoIncre.vue.HmMISQBD.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "AutoIncre.vue.HmMISQBD.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_CategoryTabs.!~{014}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "CategoryTabs.787nBCiN.css",
    "src": "_CategoryTabs.!~{014}~.js"
  },
  "_CategoryTabs.GoZy5KrR.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "CategoryTabs.787nBCiN.css"
    ],
    "file": "CategoryTabs.GoZy5KrR.js",
    "imports": [
      "_tabs.KnuYfSzH.js",
      "node_modules/nuxt/dist/app/entry.js",
      "components/Comm/PostList.vue",
      "components/list/GoodsList.vue"
    ]
  },
  "CategoryTabs.787nBCiN.css": {
    "file": "CategoryTabs.787nBCiN.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_CommentPreview.!~{019}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "CommentPreview.J3-ZHx6B.css",
    "src": "_CommentPreview.!~{019}~.js"
  },
  "_CommentPreview.0ixMT9bC.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "CommentPreview.J3-ZHx6B.css"
    ],
    "file": "CommentPreview.0ixMT9bC.js",
    "imports": [
      "_ElImage.5WDhO1BH.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_select.c4knoYXW.js",
      "_OssFileUpload.1Tq0h7TC.js",
      "_nuxt-link.BNcfrMFj.js",
      "_tag.ejdlgglv.js",
      "_AutoIncre.vue.HmMISQBD.js",
      "_scrollbar.5a1hNI7p.js",
      "_popper.yLZM-Qas.js",
      "_notification.bPhslSCw.js"
    ]
  },
  "CommentPreview.J3-ZHx6B.css": {
    "file": "CommentPreview.J3-ZHx6B.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_DelayTimer.vue.GNX6zafv.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "DelayTimer.vue.GNX6zafv.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_ElImage.!~{00B}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "ElImage.6ybrNKBL.css",
    "src": "_ElImage.!~{00B}~.js"
  },
  "_ElImage.5WDhO1BH.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "ElImage.6ybrNKBL.css"
    ],
    "file": "ElImage.5WDhO1BH.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_debounce.xjuk_Vs-.js"
    ]
  },
  "ElImage.6ybrNKBL.css": {
    "file": "ElImage.6ybrNKBL.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_Footer.!~{01Q}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Footer.y5ruypfy.css",
    "src": "_Footer.!~{01Q}~.js"
  },
  "_Footer.jyUwsvJx.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "Footer.y5ruypfy.css"
    ],
    "file": "Footer.jyUwsvJx.js",
    "imports": [
      "_nuxt-link.BNcfrMFj.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_logo_dark.1DIXUGGI.js",
      "_Switch.EQMwqIiY.js"
    ]
  },
  "Footer.y5ruypfy.css": {
    "file": "Footer.y5ruypfy.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_GoodsListSsr.!~{01n}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "GoodsListSsr.P5hBZBtk.css",
    "src": "_GoodsListSsr.!~{01n}~.js"
  },
  "_GoodsListSsr.cZYLBc_z.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "GoodsListSsr.P5hBZBtk.css"
    ],
    "file": "GoodsListSsr.cZYLBc_z.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.1310Fh4S.js",
      "_nuxt-link.BNcfrMFj.js",
      "node_modules/element-plus/es/components/text/index.mjs"
    ]
  },
  "GoodsListSsr.P5hBZBtk.css": {
    "file": "GoodsListSsr.P5hBZBtk.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_Main.vue.!~{00z}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Main.dWFRPFzh.css",
    "src": "_Main.vue.!~{00z}~.js"
  },
  "_Main.vue.n2TxAZI_.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "Main.dWFRPFzh.css"
    ],
    "file": "Main.vue.n2TxAZI_.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_contact.kDPuvqBB.js",
      "_ElImage.5WDhO1BH.js",
      "_tag.ejdlgglv.js"
    ]
  },
  "Main.dWFRPFzh.css": {
    "file": "Main.dWFRPFzh.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_OssFileUpload.!~{00W}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "OssFileUpload.-TDo8IgO.css",
    "src": "_OssFileUpload.!~{00W}~.js"
  },
  "_OssFileUpload.1Tq0h7TC.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "OssFileUpload.-TDo8IgO.css"
    ],
    "file": "OssFileUpload.1Tq0h7TC.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.5WDhO1BH.js",
      "_progress.CqPBCswU.js",
      "_index.NPry77wz.js"
    ]
  },
  "OssFileUpload.-TDo8IgO.css": {
    "file": "OssFileUpload.-TDo8IgO.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_ShopLine.!~{01K}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "ShopLine.Wq74ulT-.css",
    "src": "_ShopLine.!~{01K}~.js"
  },
  "_ShopLine.NDrhvFs-.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "ShopLine.Wq74ulT-.css"
    ],
    "file": "ShopLine.NDrhvFs-.js",
    "imports": [
      "_ElImage.5WDhO1BH.js",
      "_nuxt-link.BNcfrMFj.js",
      "_select.c4knoYXW.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_input-number.IyBy1gM2.js",
      "_tag.ejdlgglv.js",
      "_scrollbar.5a1hNI7p.js",
      "_popper.yLZM-Qas.js",
      "_sku.ixYUps6X.js"
    ]
  },
  "ShopLine.Wq74ulT-.css": {
    "file": "ShopLine.Wq74ulT-.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_SigninCard.vue.CRBlHToQ.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "popover.LAISAeEG.css"
    ],
    "file": "SigninCard.vue.CRBlHToQ.js",
    "imports": [
      "_progress.CqPBCswU.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.7cJwbaIa.js",
      "_popper.yLZM-Qas.js"
    ]
  },
  "popover.LAISAeEG.css": {
    "file": "popover.LAISAeEG.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_StatusTag.!~{01l}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "StatusTag.IETAoY75.css",
    "src": "_StatusTag.!~{01l}~.js"
  },
  "_StatusTag.RGhUc9O0.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "StatusTag.IETAoY75.css"
    ],
    "file": "StatusTag.RGhUc9O0.js",
    "imports": [
      "_tag.ejdlgglv.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_post.mqx4BAUD.js"
    ]
  },
  "StatusTag.IETAoY75.css": {
    "file": "StatusTag.IETAoY75.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_Switch.!~{01e}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Switch.JXXa2UnD.css",
    "src": "_Switch.!~{01e}~.js"
  },
  "_Switch.EQMwqIiY.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "Switch.JXXa2UnD.css"
    ],
    "file": "Switch.EQMwqIiY.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "Switch.JXXa2UnD.css": {
    "file": "Switch.JXXa2UnD.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_TagList.vue.Fx31Fs2F.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TagList.vue.Fx31Fs2F.js",
    "imports": [
      "_tag.ejdlgglv.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_UserPostTotal.vue.npe23eQh.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "UserPostTotal.vue.npe23eQh.js",
    "imports": [
      "_ElImage.5WDhO1BH.js",
      "_nuxt-link.BNcfrMFj.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_post.mqx4BAUD.js"
    ]
  },
  "___commonjsHelpers__.1J56E-h6.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "__commonjsHelpers__.1J56E-h6.js"
  },
  "_arrays.9GuX8ZvT.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "arrays.9GuX8ZvT.js"
  },
  "_avatar.!~{01J}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "avatar.bZH1-Oig.css",
    "src": "_avatar.!~{01J}~.js"
  },
  "_avatar.4zUOF2Ms.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "avatar.bZH1-Oig.css"
    ],
    "file": "avatar.4zUOF2Ms.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "avatar.bZH1-Oig.css": {
    "file": "avatar.bZH1-Oig.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_bills.ZNqJByr7.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "bills.ZNqJByr7.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_checkbox-group.!~{01H}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "checkbox-group.d5XbR8TY.css",
    "src": "_checkbox-group.!~{01H}~.js"
  },
  "_checkbox.!~{01y}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "checkbox.MJHvI1xB.css",
    "src": "_checkbox.!~{01y}~.js"
  },
  "_checkbox.SySnXQpj.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "checkbox.MJHvI1xB.css"
    ],
    "file": "checkbox.SySnXQpj.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_isEqual.-Fg3IVvN.js",
      "_hasIn.yu-tCwH2.js",
      "_flatten.j5spiMWK.js"
    ]
  },
  "checkbox.MJHvI1xB.css": {
    "file": "checkbox.MJHvI1xB.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_cloneDeep.7q44oITJ.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "cloneDeep.7q44oITJ.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_collect.Am8wdZE_.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "collect.Am8wdZE_.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_contact.kDPuvqBB.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "contact.kDPuvqBB.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_useWs.qjQFUgR3.js"
    ]
  },
  "_create-shadow.K27cSXNM.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "create-shadow.K27cSXNM.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_date-picker.!~{01E}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "date-picker.sSkDKlix.css",
    "src": "_date-picker.!~{01E}~.js"
  },
  "_date-picker.XTD-Joov.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "date-picker.sSkDKlix.css"
    ],
    "file": "date-picker.XTD-Joov.js",
    "imports": [
      "_localeData.wKXK0DM5.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_arrays.9GuX8ZvT.js",
      "_flatten.j5spiMWK.js",
      "_popper.yLZM-Qas.js",
      "_scrollbar.5a1hNI7p.js",
      "_index.LtiwoJKK.js",
      "_debounce.xjuk_Vs-.js",
      "_index.RQafNwYw.js",
      "_isEqual.-Fg3IVvN.js"
    ]
  },
  "date-picker.sSkDKlix.css": {
    "file": "date-picker.sSkDKlix.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_debounce.xjuk_Vs-.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "debounce.xjuk_Vs-.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_dialog.!~{00Q}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "dialog.mDs1vky2.css",
    "src": "_dialog.!~{00Q}~.js"
  },
  "_dialog.Z0ZPFGm7.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "dialog.mDs1vky2.css"
    ],
    "file": "dialog.Z0ZPFGm7.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_isUndefined.IZwZ21d-.js"
    ]
  },
  "dialog.mDs1vky2.css": {
    "file": "dialog.mDs1vky2.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_divider.!~{00N}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "divider.mvCfgREV.css",
    "src": "_divider.!~{00N}~.js"
  },
  "_divider.NEcQdmHH.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "divider.mvCfgREV.css"
    ],
    "file": "divider.NEcQdmHH.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "divider.mvCfgREV.css": {
    "file": "divider.mvCfgREV.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_effect-creative.paLJTlNn.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "effect-creative.paLJTlNn.js",
    "imports": [
      "_create-shadow.K27cSXNM.js"
    ]
  },
  "_empty.!~{00J}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "empty.sDhVTJEQ.css",
    "src": "_empty.!~{00J}~.js"
  },
  "_empty.SuGhbvAo.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "empty.sDhVTJEQ.css"
    ],
    "file": "empty.SuGhbvAo.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "empty.sDhVTJEQ.css": {
    "file": "empty.sDhVTJEQ.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_flatten.j5spiMWK.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "flatten.j5spiMWK.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_friend.1Gtj4m1q.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "friend.1Gtj4m1q.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_hasIn.yu-tCwH2.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "hasIn.yu-tCwH2.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.!~{01c}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.BbVs9JM6.css",
    "src": "_index.!~{01c}~.js"
  },
  "_index.1310Fh4S.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.BbVs9JM6.css"
    ],
    "file": "index.1310Fh4S.js",
    "imports": [
      "_ElImage.5WDhO1BH.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "index.BbVs9JM6.css": {
    "file": "index.BbVs9JM6.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_index.1HcAdTHG.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.1HcAdTHG.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.7cJwbaIa.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.7cJwbaIa.js",
    "imports": [
      "_popper.yLZM-Qas.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.LtiwoJKK.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.LtiwoJKK.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.NPry77wz.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.NPry77wz.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ]
  },
  "_index.RQafNwYw.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.RQafNwYw.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.XCLyjk56.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.XCLyjk56.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.bY785nZd.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.bY785nZd.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.nfNIF6u_.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.nfNIF6u_.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.wx8byyUK.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.wx8byyUK.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.y-S5yCMy.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.y-S5yCMy.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_input-number.!~{01p}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "input-number.5AezeF1g.css",
    "src": "_input-number.!~{01p}~.js"
  },
  "_input-number.IyBy1gM2.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "input-number.5AezeF1g.css"
    ],
    "file": "input-number.IyBy1gM2.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.LtiwoJKK.js"
    ]
  },
  "input-number.5AezeF1g.css": {
    "file": "input-number.5AezeF1g.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_isEqual.-Fg3IVvN.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "isEqual.-Fg3IVvN.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_isUndefined.IZwZ21d-.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "isUndefined.IZwZ21d-.js"
  },
  "_localeData.wKXK0DM5.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "localeData.wKXK0DM5.js",
    "imports": [
      "___commonjsHelpers__.1J56E-h6.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_logo_dark.1DIXUGGI.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "popover.LAISAeEG.css"
    ],
    "dynamicImports": [
      "components/card/UserLine.vue"
    ],
    "file": "logo_dark.1DIXUGGI.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.BNcfrMFj.js",
      "_scrollbar.5a1hNI7p.js",
      "_index.7cJwbaIa.js",
      "_popper.yLZM-Qas.js"
    ]
  },
  "_menu-item.!~{01O}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "menu-item.f0mNRiTD.css",
    "src": "_tooltip.!~{01I}~.js"
  },
  "_menu.!~{01N}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "menu.6YbFhd-D.css",
    "src": "_menu.!~{01N}~.js"
  },
  "_menu.OZZXJVoK.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "menu.6YbFhd-D.css"
    ],
    "file": "menu.OZZXJVoK.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.wx8byyUK.js",
      "_popper.yLZM-Qas.js",
      "_index.RQafNwYw.js"
    ]
  },
  "menu.6YbFhd-D.css": {
    "file": "menu.6YbFhd-D.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_notification.!~{00H}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "notification.8O_B6xHM.css",
    "src": "_notification.!~{00H}~.js"
  },
  "_notification.bPhslSCw.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "notification.8O_B6xHM.css"
    ],
    "file": "notification.bPhslSCw.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "notification.8O_B6xHM.css": {
    "file": "notification.8O_B6xHM.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_nuxt-link.BNcfrMFj.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "nuxt-link.BNcfrMFj.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_popover.!~{01i}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "popover.LAISAeEG.css",
    "src": "_popover.!~{01i}~.js"
  },
  "_popper.!~{00X}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "popper.nTJkgMH4.css",
    "src": "_popper.!~{00X}~.js"
  },
  "_popper.yLZM-Qas.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "popper.nTJkgMH4.css"
    ],
    "file": "popper.yLZM-Qas.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_isUndefined.IZwZ21d-.js"
    ]
  },
  "popper.nTJkgMH4.css": {
    "file": "popper.nTJkgMH4.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_post.mqx4BAUD.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "post.mqx4BAUD.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_progress.!~{011}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "progress.rXLlm_9F.css",
    "src": "_progress.!~{011}~.js"
  },
  "_progress.CqPBCswU.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "progress.rXLlm_9F.css"
    ],
    "file": "progress.CqPBCswU.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "progress.rXLlm_9F.css": {
    "file": "progress.rXLlm_9F.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_radio-button.!~{012}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "radio-button.l7x146Nf.css",
    "src": "_radio-button.!~{012}~.js"
  },
  "_radio-group.!~{00M}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "radio-group.P_Xz2fNs.css",
    "src": "_radio-group.!~{00M}~.js"
  },
  "_radio.!~{00U}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "radio.eYTrrdr6.css",
    "src": "_radio.!~{00U}~.js"
  },
  "_rate.!~{01s}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "rate.mGuCO7Lx.css",
    "src": "_rate.!~{01s}~.js"
  },
  "_rate.O-kbePdu.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "rate.mGuCO7Lx.css"
    ],
    "file": "rate.O-kbePdu.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "rate.mGuCO7Lx.css": {
    "file": "rate.mGuCO7Lx.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_scrollbar.!~{00A}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "scrollbar.Smf0pYfu.css",
    "src": "_scrollbar.!~{00A}~.js"
  },
  "_scrollbar.5a1hNI7p.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "scrollbar.Smf0pYfu.css"
    ],
    "file": "scrollbar.5a1hNI7p.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "scrollbar.Smf0pYfu.css": {
    "file": "scrollbar.Smf0pYfu.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_select.!~{00V}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "select.xPRdjiL2.css",
    "src": "_select.!~{00V}~.js"
  },
  "_select.c4knoYXW.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "select.xPRdjiL2.css"
    ],
    "file": "select.c4knoYXW.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_popper.yLZM-Qas.js",
      "_scrollbar.5a1hNI7p.js",
      "_tag.ejdlgglv.js",
      "_strings.TNpXu6t_.js",
      "_isEqual.-Fg3IVvN.js",
      "_debounce.xjuk_Vs-.js",
      "_hasIn.yu-tCwH2.js",
      "_index.RQafNwYw.js"
    ]
  },
  "select.xPRdjiL2.css": {
    "file": "select.xPRdjiL2.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_sku.ixYUps6X.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sku.ixYUps6X.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_strings.TNpXu6t_.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "strings.TNpXu6t_.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_tabs.!~{015}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "tabs.H-UKPvku.css",
    "src": "_tabs.!~{015}~.js"
  },
  "_tabs.KnuYfSzH.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "tabs.H-UKPvku.css"
    ],
    "file": "tabs.KnuYfSzH.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_strings.TNpXu6t_.js",
      "_index.y-S5yCMy.js"
    ]
  },
  "tabs.H-UKPvku.css": {
    "file": "tabs.H-UKPvku.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_tag.!~{00F}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "tag.Wo0upPQu.css",
    "src": "_tag.!~{00F}~.js"
  },
  "_tag.ejdlgglv.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "tag.Wo0upPQu.css"
    ],
    "file": "tag.ejdlgglv.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "tag.Wo0upPQu.css": {
    "file": "tag.Wo0upPQu.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_tooltip.!~{01I}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "menu-item.f0mNRiTD.css",
    "src": "_tooltip.!~{01I}~.js"
  },
  "_upload.!~{01x}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "upload.5r92S6hB.css",
    "src": "_upload.!~{01x}~.js"
  },
  "_upload.JTx2BE3N.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "upload.5r92S6hB.css"
    ],
    "file": "upload.JTx2BE3N.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_progress.CqPBCswU.js",
      "_cloneDeep.7q44oITJ.js",
      "_isEqual.-Fg3IVvN.js"
    ]
  },
  "upload.5r92S6hB.css": {
    "file": "upload.5r92S6hB.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_useOrderStore.uk8zr6Xq.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useOrderStore.uk8zr6Xq.js",
    "imports": [
      "_index.XCLyjk56.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_useWebToast.srPXJUk3.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useWebToast.srPXJUk3.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_useWs.qjQFUgR3.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useWs.qjQFUgR3.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_notification.bPhslSCw.js"
    ]
  },
  "components/Chat/Friend/ApplyDialog.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ApplyDialog.K_s3m0J1.js",
    "imports": [
      "_ApplyDialog.vue.BA5OPWry.js",
      "node_modules/nuxt/dist/app/entry.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_dialog.Z0ZPFGm7.js",
      "_isUndefined.IZwZ21d-.js",
      "_notification.bPhslSCw.js",
      "_friend.1Gtj4m1q.js"
    ],
    "isDynamicEntry": true,
    "src": "components/Chat/Friend/ApplyDialog.vue"
  },
  "components/Chat/NewGroupDialog.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "NewGroupDialog.Hm5sbp8R.css",
      "checkbox-group.d5XbR8TY.css"
    ],
    "file": "NewGroupDialog.ud6opZyy.js",
    "imports": [
      "_ElImage.5WDhO1BH.js",
      "_checkbox.SySnXQpj.js",
      "_AutoIncre.vue.HmMISQBD.js",
      "_scrollbar.5a1hNI7p.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_OssFileUpload.1Tq0h7TC.js",
      "_dialog.Z0ZPFGm7.js",
      "_notification.bPhslSCw.js",
      "_contact.kDPuvqBB.js",
      "_Main.vue.n2TxAZI_.js",
      "_friend.1Gtj4m1q.js",
      "_debounce.xjuk_Vs-.js",
      "_isEqual.-Fg3IVvN.js",
      "_hasIn.yu-tCwH2.js",
      "_flatten.j5spiMWK.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_progress.CqPBCswU.js",
      "_index.NPry77wz.js",
      "_isUndefined.IZwZ21d-.js",
      "_useWs.qjQFUgR3.js",
      "_tag.ejdlgglv.js"
    ],
    "isDynamicEntry": true,
    "src": "components/Chat/NewGroupDialog.vue"
  },
  "NewGroupDialog.Hm5sbp8R.css": {
    "file": "NewGroupDialog.Hm5sbp8R.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "checkbox-group.d5XbR8TY.css": {
    "file": "checkbox-group.d5XbR8TY.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/Comm/PostList.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "PostList._i8MVHra.css"
    ],
    "file": "PostList.Rdgl9KBM.js",
    "imports": [
      "_ElImage.5WDhO1BH.js",
      "_nuxt-link.BNcfrMFj.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.ejdlgglv.js",
      "_TagList.vue.Fx31Fs2F.js",
      "_CommentPreview.0ixMT9bC.js",
      "_AutoIncre.vue.HmMISQBD.js",
      "_post.mqx4BAUD.js",
      "_debounce.xjuk_Vs-.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_select.c4knoYXW.js",
      "_popper.yLZM-Qas.js",
      "_isUndefined.IZwZ21d-.js",
      "_scrollbar.5a1hNI7p.js",
      "_strings.TNpXu6t_.js",
      "_isEqual.-Fg3IVvN.js",
      "_hasIn.yu-tCwH2.js",
      "_index.RQafNwYw.js",
      "_OssFileUpload.1Tq0h7TC.js",
      "_progress.CqPBCswU.js",
      "_index.NPry77wz.js",
      "_notification.bPhslSCw.js"
    ],
    "isDynamicEntry": true,
    "src": "components/Comm/PostList.vue"
  },
  "PostList._i8MVHra.css": {
    "file": "PostList._i8MVHra.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/Comm/post/CateGoryLine.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "CateGoryLine.AgQzLroU.js",
    "imports": [
      "_ElImage.5WDhO1BH.js",
      "_nuxt-link.BNcfrMFj.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_debounce.xjuk_Vs-.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "components/Comm/post/CateGoryLine.vue"
  },
  "components/Comm/post/Rank.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "Rank.y3OSjSFp.css"
    ],
    "file": "Rank.31tgepv7.js",
    "imports": [
      "_divider.NEcQdmHH.js",
      "_tag.ejdlgglv.js",
      "_ElImage.5WDhO1BH.js",
      "_nuxt-link.BNcfrMFj.js",
      "_empty.SuGhbvAo.js",
      "_scrollbar.5a1hNI7p.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_post.mqx4BAUD.js",
      "_debounce.xjuk_Vs-.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "components/Comm/post/Rank.vue"
  },
  "Rank.y3OSjSFp.css": {
    "file": "Rank.y3OSjSFp.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/card/UserLine.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "UserLine.G_lnDfVq.css",
      "popover.LAISAeEG.css"
    ],
    "file": "UserLine.TwuPcb65.js",
    "imports": [
      "_avatar.4zUOF2Ms.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_upload.JTx2BE3N.js",
      "_nuxt-link.BNcfrMFj.js",
      "_index.7cJwbaIa.js",
      "_progress.CqPBCswU.js",
      "_popper.yLZM-Qas.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_cloneDeep.7q44oITJ.js",
      "_isEqual.-Fg3IVvN.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "components/card/UserLine.vue"
  },
  "UserLine.G_lnDfVq.css": {
    "file": "UserLine.G_lnDfVq.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/list/GoodsList.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "GoodsList.1p6fEF-7.css"
    ],
    "file": "GoodsList.h7r1dFqO.js",
    "imports": [
      "_index.1310Fh4S.js",
      "_nuxt-link.BNcfrMFj.js",
      "_AutoIncre.vue.HmMISQBD.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.5WDhO1BH.js",
      "_debounce.xjuk_Vs-.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "components/list/GoodsList.vue"
  },
  "GoodsList.1p6fEF-7.css": {
    "file": "GoodsList.1p6fEF-7.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/menu/DrawerMenu.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "DrawerMenu.0ja6gThp.css",
      "menu-item.f0mNRiTD.css",
      "popover.LAISAeEG.css"
    ],
    "file": "DrawerMenu.7AcrwduB.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_menu.OZZXJVoK.js",
      "_scrollbar.5a1hNI7p.js",
      "_popper.yLZM-Qas.js",
      "_logo_dark.1DIXUGGI.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_index.wx8byyUK.js",
      "_index.RQafNwYw.js",
      "_isUndefined.IZwZ21d-.js",
      "_nuxt-link.BNcfrMFj.js",
      "_index.7cJwbaIa.js"
    ],
    "isDynamicEntry": true,
    "src": "components/menu/DrawerMenu.vue"
  },
  "DrawerMenu.0ja6gThp.css": {
    "file": "DrawerMenu.0ja6gThp.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "menu-item.f0mNRiTD.css": {
    "file": "menu-item.f0mNRiTD.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/menu/RightButtons/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.d8QRz2qr.css",
      "popover.LAISAeEG.css",
      "menu-item.f0mNRiTD.css"
    ],
    "dynamicImports": [
      "components/menu/ShopCartBar.vue"
    ],
    "file": "index.zf4KX3W_.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.BNcfrMFj.js",
      "_Main.vue.n2TxAZI_.js",
      "_scrollbar.5a1hNI7p.js",
      "_ElImage.5WDhO1BH.js",
      "_index.7cJwbaIa.js",
      "_popper.yLZM-Qas.js",
      "_contact.kDPuvqBB.js",
      "_useWs.qjQFUgR3.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_tag.ejdlgglv.js",
      "_debounce.xjuk_Vs-.js",
      "_isUndefined.IZwZ21d-.js",
      "_notification.bPhslSCw.js"
    ],
    "isDynamicEntry": true,
    "src": "components/menu/RightButtons/index.vue"
  },
  "index.d8QRz2qr.css": {
    "file": "index.d8QRz2qr.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/menu/ShopCartBar.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "ShopCartBar.EsIq9V-V.css",
      "checkbox-group.d5XbR8TY.css",
      "popover.LAISAeEG.css"
    ],
    "file": "ShopCartBar.ufRgO6jY.js",
    "imports": [
      "_checkbox.SySnXQpj.js",
      "_ShopLine.NDrhvFs-.js",
      "_AutoIncre.vue.HmMISQBD.js",
      "_scrollbar.5a1hNI7p.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.7cJwbaIa.js",
      "_popper.yLZM-Qas.js",
      "_useOrderStore.uk8zr6Xq.js",
      "_isEqual.-Fg3IVvN.js",
      "_hasIn.yu-tCwH2.js",
      "_flatten.j5spiMWK.js",
      "_ElImage.5WDhO1BH.js",
      "_debounce.xjuk_Vs-.js",
      "_nuxt-link.BNcfrMFj.js",
      "_select.c4knoYXW.js",
      "_tag.ejdlgglv.js",
      "_strings.TNpXu6t_.js",
      "_index.RQafNwYw.js",
      "_input-number.IyBy1gM2.js",
      "_index.LtiwoJKK.js",
      "_sku.ixYUps6X.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isUndefined.IZwZ21d-.js",
      "_index.XCLyjk56.js"
    ],
    "isDynamicEntry": true,
    "src": "components/menu/ShopCartBar.vue"
  },
  "ShopCartBar.EsIq9V-V.css": {
    "file": "ShopCartBar.EsIq9V-V.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "layouts/chat.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "chat.5knOEY9m.css",
      "menu-item.f0mNRiTD.css",
      "popover.LAISAeEG.css"
    ],
    "dynamicImports": [
      "components/menu/RightButtons/index.vue"
    ],
    "file": "chat.CgF60wBZ.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.5WDhO1BH.js",
      "components/card/UserLine.vue",
      "_menu.OZZXJVoK.js",
      "_popper.yLZM-Qas.js",
      "_useWs.qjQFUgR3.js",
      "_friend.1Gtj4m1q.js",
      "_useWebToast.srPXJUk3.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.xjuk_Vs-.js",
      "_avatar.4zUOF2Ms.js",
      "_upload.JTx2BE3N.js",
      "_progress.CqPBCswU.js",
      "_cloneDeep.7q44oITJ.js",
      "_isEqual.-Fg3IVvN.js",
      "_nuxt-link.BNcfrMFj.js",
      "_index.7cJwbaIa.js",
      "_index.wx8byyUK.js",
      "_index.RQafNwYw.js",
      "_isUndefined.IZwZ21d-.js",
      "_notification.bPhslSCw.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/chat.vue"
  },
  "chat.5knOEY9m.css": {
    "file": "chat.5knOEY9m.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "layouts/error.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "error.AM3mEUdz.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/error.vue"
  },
  "layouts/main.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "popover.LAISAeEG.css",
      "menu-item.f0mNRiTD.css"
    ],
    "dynamicImports": [
      "components/menu/DrawerMenu.vue"
    ],
    "file": "main.IYe5FxOJ.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_Footer.jyUwsvJx.js",
      "components/menu/RightButtons/index.vue",
      "___commonjsHelpers__.1J56E-h6.js",
      "_nuxt-link.BNcfrMFj.js",
      "_logo_dark.1DIXUGGI.js",
      "_scrollbar.5a1hNI7p.js",
      "_index.7cJwbaIa.js",
      "_popper.yLZM-Qas.js",
      "_isUndefined.IZwZ21d-.js",
      "_Switch.EQMwqIiY.js",
      "_Main.vue.n2TxAZI_.js",
      "_contact.kDPuvqBB.js",
      "_useWs.qjQFUgR3.js",
      "_notification.bPhslSCw.js",
      "_ElImage.5WDhO1BH.js",
      "_debounce.xjuk_Vs-.js",
      "_tag.ejdlgglv.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/main.vue"
  },
  "layouts/second.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "second.JqdAvVfB.css",
      "popover.LAISAeEG.css",
      "menu-item.f0mNRiTD.css"
    ],
    "file": "second.p5rS_t4Y.js",
    "imports": [
      "_Footer.jyUwsvJx.js",
      "components/menu/RightButtons/index.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.BNcfrMFj.js",
      "_logo_dark.1DIXUGGI.js",
      "_scrollbar.5a1hNI7p.js",
      "_index.7cJwbaIa.js",
      "_popper.yLZM-Qas.js",
      "_isUndefined.IZwZ21d-.js",
      "_Switch.EQMwqIiY.js",
      "_Main.vue.n2TxAZI_.js",
      "_contact.kDPuvqBB.js",
      "_useWs.qjQFUgR3.js",
      "_notification.bPhslSCw.js",
      "_ElImage.5WDhO1BH.js",
      "_debounce.xjuk_Vs-.js",
      "_tag.ejdlgglv.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/second.vue"
  },
  "second.JqdAvVfB.css": {
    "file": "second.JqdAvVfB.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "layouts/user.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "user.yAuj-VgQ.css",
      "menu-item.f0mNRiTD.css",
      "popover.LAISAeEG.css"
    ],
    "file": "user.IeSk8Eiv.js",
    "imports": [
      "_nuxt-link.BNcfrMFj.js",
      "_logo_dark.1DIXUGGI.js",
      "_Switch.EQMwqIiY.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_menu.OZZXJVoK.js",
      "_popper.yLZM-Qas.js",
      "components/menu/RightButtons/index.vue",
      "_scrollbar.5a1hNI7p.js",
      "_index.7cJwbaIa.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_index.wx8byyUK.js",
      "_index.RQafNwYw.js",
      "_isUndefined.IZwZ21d-.js",
      "_Main.vue.n2TxAZI_.js",
      "_contact.kDPuvqBB.js",
      "_useWs.qjQFUgR3.js",
      "_notification.bPhslSCw.js",
      "_ElImage.5WDhO1BH.js",
      "_debounce.xjuk_Vs-.js",
      "_tag.ejdlgglv.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/user.vue"
  },
  "user.yAuj-VgQ.css": {
    "file": "user.yAuj-VgQ.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/element-plus/es/components/text/index.mjs": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.l5CC8IXT.css"
    ],
    "file": "index.jdrApd8v.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/element-plus/es/components/text/index.mjs"
  },
  "index.l5CC8IXT.css": {
    "file": "index.l5CC8IXT.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "entry.BTnpSHkW.css"
    ],
    "dynamicImports": [
      "layouts/chat.vue",
      "layouts/error.vue",
      "layouts/main.vue",
      "layouts/second.vue",
      "layouts/user.vue",
      "node_modules/workbox-window/build/workbox-window.prod.es5.mjs"
    ],
    "file": "entry.iPFf8iV4.js",
    "imports": [
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js"
  },
  "entry.BTnpSHkW.css": {
    "file": "entry.BTnpSHkW.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/workbox-window/build/workbox-window.prod.es5.mjs": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "workbox-window.prod.es5.prqDwDSL.js",
    "isDynamicEntry": true,
    "src": "node_modules/workbox-window/build/workbox-window.prod.es5.mjs"
  },
  "pages/[...all].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_...all_.3JAE29xu.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/[...all].vue"
  },
  "pages/chat/ai.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "ai.df74smAD.css"
    ],
    "file": "ai.pgCJbSqc.js",
    "imports": [
      "_Main.vue.n2TxAZI_.js",
      "_scrollbar.5a1hNI7p.js",
      "_ElImage.5WDhO1BH.js",
      "_nuxt-link.BNcfrMFj.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_contact.kDPuvqBB.js",
      "_useWs.qjQFUgR3.js",
      "_tag.ejdlgglv.js",
      "_debounce.xjuk_Vs-.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_notification.bPhslSCw.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/chat/ai.vue"
  },
  "ai.df74smAD.css": {
    "file": "ai.df74smAD.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/chat/friend.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "friend.chnzZ23W.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "file": "friend.xP0i-ML1.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.ejdlgglv.js",
      "_ElImage.5WDhO1BH.js",
      "_AutoIncre.vue.HmMISQBD.js",
      "_scrollbar.5a1hNI7p.js",
      "_empty.SuGhbvAo.js",
      "_friend.1Gtj4m1q.js",
      "_index.bY785nZd.js",
      "_contact.kDPuvqBB.js",
      "_useWs.qjQFUgR3.js",
      "_notification.bPhslSCw.js",
      "_divider.NEcQdmHH.js",
      "_ApplyDialog.vue.BA5OPWry.js",
      "_index.nfNIF6u_.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.xjuk_Vs-.js",
      "_dialog.Z0ZPFGm7.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/chat/friend.vue"
  },
  "friend.chnzZ23W.css": {
    "file": "friend.chnzZ23W.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "radio-group.P_Xz2fNs.css": {
    "file": "radio-group.P_Xz2fNs.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/chat/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.JpUzHRVI.css",
      "radio.eYTrrdr6.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "dynamicImports": [
      "components/Chat/NewGroupDialog.vue",
      "components/Chat/NewGroupDialog.vue",
      "components/Chat/Friend/ApplyDialog.vue"
    ],
    "file": "index.tdsEWtcI.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.5WDhO1BH.js",
      "_index.bY785nZd.js",
      "_AutoIncre.vue.HmMISQBD.js",
      "_notification.bPhslSCw.js",
      "_contact.kDPuvqBB.js",
      "_Main.vue.n2TxAZI_.js",
      "_friend.1Gtj4m1q.js",
      "_useWs.qjQFUgR3.js",
      "_tag.ejdlgglv.js",
      "_scrollbar.5a1hNI7p.js",
      "_select.c4knoYXW.js",
      "_OssFileUpload.1Tq0h7TC.js",
      "_nuxt-link.BNcfrMFj.js",
      "_popper.yLZM-Qas.js",
      "_index.NPry77wz.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.xjuk_Vs-.js",
      "_strings.TNpXu6t_.js",
      "_isEqual.-Fg3IVvN.js",
      "_hasIn.yu-tCwH2.js",
      "_index.RQafNwYw.js",
      "_progress.CqPBCswU.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/chat/index.vue"
  },
  "index.JpUzHRVI.css": {
    "file": "index.JpUzHRVI.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "radio.eYTrrdr6.css": {
    "file": "radio.eYTrrdr6.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/chat/setting.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "setting.SSmFdXUR.css",
      "radio-button.l7x146Nf.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "file": "setting.k7AaLBkz.js",
    "imports": [
      "_divider.NEcQdmHH.js",
      "_select.c4knoYXW.js",
      "_index.bY785nZd.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.ejdlgglv.js",
      "_scrollbar.5a1hNI7p.js",
      "_popper.yLZM-Qas.js",
      "_notification.bPhslSCw.js",
      "_strings.TNpXu6t_.js",
      "_isEqual.-Fg3IVvN.js",
      "_debounce.xjuk_Vs-.js",
      "_hasIn.yu-tCwH2.js",
      "_index.RQafNwYw.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/chat/setting.vue"
  },
  "setting.SSmFdXUR.css": {
    "file": "setting.SSmFdXUR.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "radio-button.l7x146Nf.css": {
    "file": "radio-button.l7x146Nf.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/category/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "_id_.uLLhAsoU.css"
    ],
    "dynamicImports": [
      "components/Comm/post/Rank.vue"
    ],
    "file": "_id_.K5wfH6DI.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.5WDhO1BH.js",
      "_CategoryTabs.GoZy5KrR.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.xjuk_Vs-.js",
      "_tabs.KnuYfSzH.js",
      "_strings.TNpXu6t_.js",
      "_index.y-S5yCMy.js",
      "components/Comm/PostList.vue",
      "_nuxt-link.BNcfrMFj.js",
      "_tag.ejdlgglv.js",
      "_TagList.vue.Fx31Fs2F.js",
      "_CommentPreview.0ixMT9bC.js",
      "_select.c4knoYXW.js",
      "_popper.yLZM-Qas.js",
      "_isUndefined.IZwZ21d-.js",
      "_scrollbar.5a1hNI7p.js",
      "_isEqual.-Fg3IVvN.js",
      "_hasIn.yu-tCwH2.js",
      "_index.RQafNwYw.js",
      "_OssFileUpload.1Tq0h7TC.js",
      "_progress.CqPBCswU.js",
      "_index.NPry77wz.js",
      "_AutoIncre.vue.HmMISQBD.js",
      "_notification.bPhslSCw.js",
      "_post.mqx4BAUD.js",
      "components/list/GoodsList.vue",
      "_index.1310Fh4S.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/category/[id].vue"
  },
  "_id_.uLLhAsoU.css": {
    "file": "_id_.uLLhAsoU.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/category/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.EaIT1GIC.css"
    ],
    "dynamicImports": [
      "components/Comm/post/Rank.vue"
    ],
    "file": "index.PFAALssx.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_CategoryTabs.GoZy5KrR.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_tabs.KnuYfSzH.js",
      "_strings.TNpXu6t_.js",
      "_index.y-S5yCMy.js",
      "components/Comm/PostList.vue",
      "_ElImage.5WDhO1BH.js",
      "_debounce.xjuk_Vs-.js",
      "_nuxt-link.BNcfrMFj.js",
      "_tag.ejdlgglv.js",
      "_TagList.vue.Fx31Fs2F.js",
      "_CommentPreview.0ixMT9bC.js",
      "_select.c4knoYXW.js",
      "_popper.yLZM-Qas.js",
      "_isUndefined.IZwZ21d-.js",
      "_scrollbar.5a1hNI7p.js",
      "_isEqual.-Fg3IVvN.js",
      "_hasIn.yu-tCwH2.js",
      "_index.RQafNwYw.js",
      "_OssFileUpload.1Tq0h7TC.js",
      "_progress.CqPBCswU.js",
      "_index.NPry77wz.js",
      "_AutoIncre.vue.HmMISQBD.js",
      "_notification.bPhslSCw.js",
      "_post.mqx4BAUD.js",
      "components/list/GoodsList.vue",
      "_index.1310Fh4S.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/category/index.vue"
  },
  "index.EaIT1GIC.css": {
    "file": "index.EaIT1GIC.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/post/detail/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "_id_.N0o7W9bX.css",
      "popover.LAISAeEG.css"
    ],
    "dynamicImports": [
      "components/Comm/post/CateGoryLine.vue"
    ],
    "file": "_id_.N0esB3Ui.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.5WDhO1BH.js",
      "_Switch.EQMwqIiY.js",
      "_tag.ejdlgglv.js",
      "_nuxt-link.BNcfrMFj.js",
      "_TagList.vue.Fx31Fs2F.js",
      "_divider.NEcQdmHH.js",
      "_post.mqx4BAUD.js",
      "_CommentPreview.0ixMT9bC.js",
      "_UserPostTotal.vue.npe23eQh.js",
      "_SigninCard.vue.CRBlHToQ.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.xjuk_Vs-.js",
      "_select.c4knoYXW.js",
      "_popper.yLZM-Qas.js",
      "_isUndefined.IZwZ21d-.js",
      "_scrollbar.5a1hNI7p.js",
      "_strings.TNpXu6t_.js",
      "_isEqual.-Fg3IVvN.js",
      "_hasIn.yu-tCwH2.js",
      "_index.RQafNwYw.js",
      "_OssFileUpload.1Tq0h7TC.js",
      "_progress.CqPBCswU.js",
      "_index.NPry77wz.js",
      "_AutoIncre.vue.HmMISQBD.js",
      "_notification.bPhslSCw.js",
      "_index.7cJwbaIa.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/post/detail/[id].vue"
  },
  "_id_.N0o7W9bX.css": {
    "file": "_id_.N0o7W9bX.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/post/list.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "list.aADC_aru.css",
      "popover.LAISAeEG.css"
    ],
    "file": "list.VqfCCOaj.js",
    "imports": [
      "_nuxt-link.BNcfrMFj.js",
      "_tag.ejdlgglv.js",
      "_create-shadow.K27cSXNM.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_effect-creative.paLJTlNn.js",
      "_post.mqx4BAUD.js",
      "_ElImage.5WDhO1BH.js",
      "components/Comm/PostList.vue",
      "_tabs.KnuYfSzH.js",
      "_SigninCard.vue.CRBlHToQ.js",
      "components/Comm/post/Rank.vue",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.xjuk_Vs-.js",
      "_TagList.vue.Fx31Fs2F.js",
      "_CommentPreview.0ixMT9bC.js",
      "_select.c4knoYXW.js",
      "_popper.yLZM-Qas.js",
      "_isUndefined.IZwZ21d-.js",
      "_scrollbar.5a1hNI7p.js",
      "_strings.TNpXu6t_.js",
      "_isEqual.-Fg3IVvN.js",
      "_hasIn.yu-tCwH2.js",
      "_index.RQafNwYw.js",
      "_OssFileUpload.1Tq0h7TC.js",
      "_progress.CqPBCswU.js",
      "_index.NPry77wz.js",
      "_AutoIncre.vue.HmMISQBD.js",
      "_notification.bPhslSCw.js",
      "_index.y-S5yCMy.js",
      "_index.7cJwbaIa.js",
      "_divider.NEcQdmHH.js",
      "_empty.SuGhbvAo.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/post/list.vue"
  },
  "list.aADC_aru.css": {
    "file": "list.aADC_aru.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/post/new.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "new.0TTT8KuO.css",
      "radio-button.l7x146Nf.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "file": "new.3pc8fpT0.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_OssFileUpload.1Tq0h7TC.js",
      "_index.bY785nZd.js",
      "_ElImage.5WDhO1BH.js",
      "_select.c4knoYXW.js",
      "_tag.ejdlgglv.js",
      "_scrollbar.5a1hNI7p.js",
      "_popper.yLZM-Qas.js",
      "_notification.bPhslSCw.js",
      "_index.NPry77wz.js",
      "_StatusTag.RGhUc9O0.js",
      "_post.mqx4BAUD.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_progress.CqPBCswU.js",
      "_debounce.xjuk_Vs-.js",
      "_strings.TNpXu6t_.js",
      "_isEqual.-Fg3IVvN.js",
      "_hasIn.yu-tCwH2.js",
      "_index.RQafNwYw.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/post/new.vue"
  },
  "new.0TTT8KuO.css": {
    "file": "new.0TTT8KuO.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/event/detail/[eid].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "_eid_.NtANQ6Xa.css"
    ],
    "file": "_eid_.tEGnl6uk.js",
    "imports": [
      "_ElImage.5WDhO1BH.js",
      "_tag.ejdlgglv.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.BNcfrMFj.js",
      "_index.1HcAdTHG.js",
      "_debounce.xjuk_Vs-.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/event/detail/[eid].vue"
  },
  "_eid_.NtANQ6Xa.css": {
    "file": "_eid_.NtANQ6Xa.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/goods/comments/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_id_.BuLOl7ip.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/goods/comments/[id].vue"
  },
  "pages/goods/detail/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "_id_.spxRS6Bk.css",
      "popover.LAISAeEG.css",
      "radio-button.l7x146Nf.css",
      "radio-group.P_Xz2fNs.css",
      "radio.eYTrrdr6.css"
    ],
    "file": "_id_.8H98RTcY.js",
    "imports": [
      "_nuxt-link.BNcfrMFj.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_GoodsListSsr.cZYLBc_z.js",
      "_ElImage.5WDhO1BH.js",
      "_index.y-S5yCMy.js",
      "_scrollbar.5a1hNI7p.js",
      "_tag.ejdlgglv.js",
      "_popper.yLZM-Qas.js",
      "_collect.Am8wdZE_.js",
      "_index.bY785nZd.js",
      "_input-number.IyBy1gM2.js",
      "_useOrderStore.uk8zr6Xq.js",
      "_index.1HcAdTHG.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_tabs.KnuYfSzH.js",
      "_rate.O-kbePdu.js",
      "_AutoIncre.vue.HmMISQBD.js",
      "_dialog.Z0ZPFGm7.js",
      "_index.wx8byyUK.js",
      "_index.1310Fh4S.js",
      "_sku.ixYUps6X.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.xjuk_Vs-.js",
      "_isUndefined.IZwZ21d-.js",
      "_index.LtiwoJKK.js",
      "_index.XCLyjk56.js",
      "_strings.TNpXu6t_.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/goods/detail/[id].vue"
  },
  "_id_.spxRS6Bk.css": {
    "file": "_id_.spxRS6Bk.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.IfgpexZK.css",
      "popover.LAISAeEG.css"
    ],
    "dynamicImports": [
      "components/list/GoodsList.vue"
    ],
    "file": "index.v3yise1A.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.ejdlgglv.js",
      "_nuxt-link.BNcfrMFj.js",
      "_AutoIncre.vue.HmMISQBD.js",
      "_empty.SuGhbvAo.js",
      "_scrollbar.5a1hNI7p.js",
      "_index.7cJwbaIa.js",
      "_popper.yLZM-Qas.js",
      "_index.1310Fh4S.js",
      "_create-shadow.K27cSXNM.js",
      "_effect-creative.paLJTlNn.js",
      "_index.1HcAdTHG.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_GoodsListSsr.cZYLBc_z.js",
      "_tabs.KnuYfSzH.js",
      "_ElImage.5WDhO1BH.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isUndefined.IZwZ21d-.js",
      "_strings.TNpXu6t_.js",
      "_index.y-S5yCMy.js",
      "_debounce.xjuk_Vs-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.IfgpexZK.css": {
    "file": "index.IfgpexZK.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/order/comment/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "_id_.65PfMBS2.css"
    ],
    "file": "_id_.UxKV1hmo.js",
    "imports": [
      "_Switch.EQMwqIiY.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_progress.CqPBCswU.js",
      "_upload.JTx2BE3N.js",
      "_dialog.Z0ZPFGm7.js",
      "_index.NPry77wz.js",
      "_ElImage.5WDhO1BH.js",
      "_rate.O-kbePdu.js",
      "_checkbox.SySnXQpj.js",
      "_nuxt-link.BNcfrMFj.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_notification.bPhslSCw.js",
      "_index.XCLyjk56.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_cloneDeep.7q44oITJ.js",
      "_isEqual.-Fg3IVvN.js",
      "_isUndefined.IZwZ21d-.js",
      "_debounce.xjuk_Vs-.js",
      "_hasIn.yu-tCwH2.js",
      "_flatten.j5spiMWK.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/order/comment/[id].vue"
  },
  "_id_.65PfMBS2.css": {
    "file": "_id_.65PfMBS2.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/order/detail.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "detail.Zq1m3l4e.css",
      "radio.eYTrrdr6.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "dynamicImports": [
      "node_modules/element-plus/es/components/text/index.mjs"
    ],
    "file": "detail._ojsyX72.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.5WDhO1BH.js",
      "_nuxt-link.BNcfrMFj.js",
      "_divider.NEcQdmHH.js",
      "_DelayTimer.vue.GNX6zafv.js",
      "_Switch.EQMwqIiY.js",
      "_index.y-S5yCMy.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_bills.ZNqJByr7.js",
      "_index.XCLyjk56.js",
      "_useOrderStore.uk8zr6Xq.js",
      "_index.bY785nZd.js",
      "_tag.ejdlgglv.js",
      "_scrollbar.5a1hNI7p.js",
      "_select.c4knoYXW.js",
      "_input-number.IyBy1gM2.js",
      "_popper.yLZM-Qas.js",
      "_index.1HcAdTHG.js",
      "_sku.ixYUps6X.js",
      "_empty.SuGhbvAo.js",
      "_notification.bPhslSCw.js",
      "_useWebToast.srPXJUk3.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.xjuk_Vs-.js",
      "_strings.TNpXu6t_.js",
      "_isEqual.-Fg3IVvN.js",
      "_hasIn.yu-tCwH2.js",
      "_index.RQafNwYw.js",
      "_index.LtiwoJKK.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/order/detail.vue"
  },
  "detail.Zq1m3l4e.css": {
    "file": "detail.Zq1m3l4e.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/order/list.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "list.pKmG3IwD.css"
    ],
    "file": "list.Z1n8ApKb.js",
    "imports": [
      "_divider.NEcQdmHH.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_date-picker.XTD-Joov.js",
      "_DelayTimer.vue.GNX6zafv.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_ElImage.5WDhO1BH.js",
      "_tag.ejdlgglv.js",
      "_useOrderStore.uk8zr6Xq.js",
      "_index.XCLyjk56.js",
      "_AutoIncre.vue.HmMISQBD.js",
      "_scrollbar.5a1hNI7p.js",
      "_popper.yLZM-Qas.js",
      "_notification.bPhslSCw.js",
      "_tabs.KnuYfSzH.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_localeData.wKXK0DM5.js",
      "_arrays.9GuX8ZvT.js",
      "_flatten.j5spiMWK.js",
      "_index.LtiwoJKK.js",
      "_debounce.xjuk_Vs-.js",
      "_index.RQafNwYw.js",
      "_isEqual.-Fg3IVvN.js",
      "_isUndefined.IZwZ21d-.js",
      "_strings.TNpXu6t_.js",
      "_index.y-S5yCMy.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/order/list.vue"
  },
  "list.pKmG3IwD.css": {
    "file": "list.pKmG3IwD.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/search/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.avLsXlFQ.css"
    ],
    "dynamicImports": [
      "components/list/GoodsList.vue",
      "components/Comm/PostList.vue"
    ],
    "file": "index.RJZFRicI.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_checkbox.SySnXQpj.js",
      "_select.c4knoYXW.js",
      "_tag.ejdlgglv.js",
      "_tabs.KnuYfSzH.js",
      "_empty.SuGhbvAo.js",
      "_scrollbar.5a1hNI7p.js",
      "_popper.yLZM-Qas.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isEqual.-Fg3IVvN.js",
      "_hasIn.yu-tCwH2.js",
      "_flatten.j5spiMWK.js",
      "_strings.TNpXu6t_.js",
      "_debounce.xjuk_Vs-.js",
      "_index.RQafNwYw.js",
      "_index.y-S5yCMy.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/search/index.vue"
  },
  "index.avLsXlFQ.css": {
    "file": "index.avLsXlFQ.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/setting/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.z1SuaKix.css",
      "radio-button.l7x146Nf.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "file": "index.Ii94tqfE.js",
    "imports": [
      "_divider.NEcQdmHH.js",
      "_select.c4knoYXW.js",
      "_index.bY785nZd.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.ejdlgglv.js",
      "_scrollbar.5a1hNI7p.js",
      "_popper.yLZM-Qas.js",
      "_notification.bPhslSCw.js",
      "_strings.TNpXu6t_.js",
      "_isEqual.-Fg3IVvN.js",
      "_debounce.xjuk_Vs-.js",
      "_hasIn.yu-tCwH2.js",
      "_index.RQafNwYw.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/setting/index.vue"
  },
  "index.z1SuaKix.css": {
    "file": "index.z1SuaKix.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/address.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "address.RlqThWjN.css",
      "radio.eYTrrdr6.css",
      "checkbox-group.d5XbR8TY.css"
    ],
    "file": "address.17Diz7oR.js",
    "imports": [
      "node_modules/element-plus/es/components/text/index.mjs",
      "node_modules/nuxt/dist/app/entry.js",
      "_scrollbar.5a1hNI7p.js",
      "_checkbox.SySnXQpj.js",
      "_index.bY785nZd.js",
      "_strings.TNpXu6t_.js",
      "_isEqual.-Fg3IVvN.js",
      "_arrays.9GuX8ZvT.js",
      "_flatten.j5spiMWK.js",
      "_cloneDeep.7q44oITJ.js",
      "_popper.yLZM-Qas.js",
      "_tag.ejdlgglv.js",
      "_index.RQafNwYw.js",
      "_debounce.xjuk_Vs-.js",
      "_dialog.Z0ZPFGm7.js",
      "_divider.NEcQdmHH.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_hasIn.yu-tCwH2.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/address.vue"
  },
  "address.RlqThWjN.css": {
    "file": "address.RlqThWjN.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/collect.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "collect.4jK4CO3w.css",
      "checkbox-group.d5XbR8TY.css"
    ],
    "file": "collect.cRNnpViH.js",
    "imports": [
      "_divider.NEcQdmHH.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_checkbox.SySnXQpj.js",
      "_ElImage.5WDhO1BH.js",
      "_scrollbar.5a1hNI7p.js",
      "_collect.Am8wdZE_.js",
      "_tabs.KnuYfSzH.js",
      "_tag.ejdlgglv.js",
      "_nuxt-link.BNcfrMFj.js",
      "_TagList.vue.Fx31Fs2F.js",
      "_AutoIncre.vue.HmMISQBD.js",
      "_post.mqx4BAUD.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isEqual.-Fg3IVvN.js",
      "_hasIn.yu-tCwH2.js",
      "_flatten.j5spiMWK.js",
      "_debounce.xjuk_Vs-.js",
      "_strings.TNpXu6t_.js",
      "_index.y-S5yCMy.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/collect.vue"
  },
  "collect.4jK4CO3w.css": {
    "file": "collect.4jK4CO3w.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/info.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "info.iWvGf_B4.css",
      "popover.LAISAeEG.css",
      "menu-item.f0mNRiTD.css"
    ],
    "file": "info.5dLWT39f.js",
    "imports": [
      "_ElImage.5WDhO1BH.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.7cJwbaIa.js",
      "_popper.yLZM-Qas.js",
      "_upload.JTx2BE3N.js",
      "_date-picker.XTD-Joov.js",
      "_select.c4knoYXW.js",
      "_progress.CqPBCswU.js",
      "_scrollbar.5a1hNI7p.js",
      "_tag.ejdlgglv.js",
      "_nuxt-link.BNcfrMFj.js",
      "_TagList.vue.Fx31Fs2F.js",
      "_AutoIncre.vue.HmMISQBD.js",
      "_post.mqx4BAUD.js",
      "_tabs.KnuYfSzH.js",
      "_UserPostTotal.vue.npe23eQh.js",
      "_SigninCard.vue.CRBlHToQ.js",
      "_index.nfNIF6u_.js",
      "_debounce.xjuk_Vs-.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isUndefined.IZwZ21d-.js",
      "_cloneDeep.7q44oITJ.js",
      "_isEqual.-Fg3IVvN.js",
      "_localeData.wKXK0DM5.js",
      "_arrays.9GuX8ZvT.js",
      "_flatten.j5spiMWK.js",
      "_index.LtiwoJKK.js",
      "_index.RQafNwYw.js",
      "_strings.TNpXu6t_.js",
      "_hasIn.yu-tCwH2.js",
      "_index.y-S5yCMy.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/info.vue"
  },
  "info.iWvGf_B4.css": {
    "file": "info.iWvGf_B4.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/post.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "post.yVQn8Ib0.css"
    ],
    "file": "post.hr4n265O.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.5WDhO1BH.js",
      "_select.c4knoYXW.js",
      "_tag.ejdlgglv.js",
      "_scrollbar.5a1hNI7p.js",
      "_popper.yLZM-Qas.js",
      "_StatusTag.RGhUc9O0.js",
      "_nuxt-link.BNcfrMFj.js",
      "_TagList.vue.Fx31Fs2F.js",
      "_post.mqx4BAUD.js",
      "_AutoIncre.vue.HmMISQBD.js",
      "_notification.bPhslSCw.js",
      "_tabs.KnuYfSzH.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.xjuk_Vs-.js",
      "_strings.TNpXu6t_.js",
      "_isEqual.-Fg3IVvN.js",
      "_hasIn.yu-tCwH2.js",
      "_index.RQafNwYw.js",
      "_isUndefined.IZwZ21d-.js",
      "_index.y-S5yCMy.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/post.vue"
  },
  "post.yVQn8Ib0.css": {
    "file": "post.yVQn8Ib0.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/safe.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "safe.73roRH3g.css"
    ],
    "file": "safe.Ea_wSKLJ.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.ejdlgglv.js",
      "_scrollbar.5a1hNI7p.js",
      "_avatar.4zUOF2Ms.js",
      "_divider.NEcQdmHH.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_useOrderStore.uk8zr6Xq.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_index.XCLyjk56.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/safe.vue"
  },
  "safe.73roRH3g.css": {
    "file": "safe.73roRH3g.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/shopcart.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "shopcart.T7K9gx-c.css",
      "checkbox-group.d5XbR8TY.css"
    ],
    "file": "shopcart.QhThVvR3.js",
    "imports": [
      "_checkbox.SySnXQpj.js",
      "_ShopLine.NDrhvFs-.js",
      "_nuxt-link.BNcfrMFj.js",
      "_AutoIncre.vue.HmMISQBD.js",
      "_scrollbar.5a1hNI7p.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useOrderStore.uk8zr6Xq.js",
      "_isEqual.-Fg3IVvN.js",
      "_hasIn.yu-tCwH2.js",
      "_flatten.j5spiMWK.js",
      "_ElImage.5WDhO1BH.js",
      "_debounce.xjuk_Vs-.js",
      "_select.c4knoYXW.js",
      "_popper.yLZM-Qas.js",
      "_isUndefined.IZwZ21d-.js",
      "_tag.ejdlgglv.js",
      "_strings.TNpXu6t_.js",
      "_index.RQafNwYw.js",
      "_input-number.IyBy1gM2.js",
      "_index.LtiwoJKK.js",
      "_sku.ixYUps6X.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_index.XCLyjk56.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/shopcart.vue"
  },
  "shopcart.T7K9gx-c.css": {
    "file": "shopcart.T7K9gx-c.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/wallet.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "wallet.JgZZuLIl.css",
      "popover.LAISAeEG.css"
    ],
    "file": "wallet.MTmisbGG.js",
    "imports": [
      "node_modules/element-plus/es/components/text/index.mjs",
      "node_modules/nuxt/dist/app/entry.js",
      "_create-shadow.K27cSXNM.js",
      "_progress.CqPBCswU.js",
      "_index.7cJwbaIa.js",
      "_popper.yLZM-Qas.js",
      "_bills.ZNqJByr7.js",
      "_scrollbar.5a1hNI7p.js",
      "_input-number.IyBy1gM2.js",
      "_select.c4knoYXW.js",
      "_tag.ejdlgglv.js",
      "_localeData.wKXK0DM5.js",
      "_divider.NEcQdmHH.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isUndefined.IZwZ21d-.js",
      "_index.LtiwoJKK.js",
      "_strings.TNpXu6t_.js",
      "_isEqual.-Fg3IVvN.js",
      "_debounce.xjuk_Vs-.js",
      "_hasIn.yu-tCwH2.js",
      "_index.RQafNwYw.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/wallet.vue"
  },
  "wallet.JgZZuLIl.css": {
    "file": "wallet.JgZZuLIl.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
