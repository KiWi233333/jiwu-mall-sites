const a=()=>Math.floor(Math.random()*1e4);export{a as g};
