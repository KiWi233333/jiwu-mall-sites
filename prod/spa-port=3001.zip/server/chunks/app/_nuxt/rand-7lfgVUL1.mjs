const generateId = () => Math.floor(Math.random() * 1e4);

export { generateId as g };
//# sourceMappingURL=rand-7lfgVUL1.mjs.map
