const client_manifest = {
  "_ApplyDialog.vue.1sZxZiUb.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ApplyDialog.vue.1sZxZiUb.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_dialog.ZEROU_9m.js",
      "_notification.KOWZGWjQ.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_friend.cnlrQOsn.js"
    ]
  },
  "_AutoIncre.vue.F6ckzkCf.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "AutoIncre.vue.F6ckzkCf.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "_CategoryTabs.!~{012}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "CategoryTabs.787nBCiN.css",
    "src": "_CategoryTabs.!~{012}~.js"
  },
  "_CategoryTabs.o-ZBEK_U.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "CategoryTabs.787nBCiN.css"
    ],
    "file": "CategoryTabs.o-ZBEK_U.js",
    "imports": [
      "_tabs.kwoWmf4E.js",
      "node_modules/nuxt/dist/app/entry.js",
      "components/Comm/PostList.vue",
      "components/list/GoodsList.vue",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "CategoryTabs.787nBCiN.css": {
    "file": "CategoryTabs.787nBCiN.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_CommentPreview.!~{017}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "CommentPreview.JFJ3T4Gg.css",
    "src": "_CommentPreview.!~{017}~.js"
  },
  "_CommentPreview.D06OIesj.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "CommentPreview.JFJ3T4Gg.css"
    ],
    "file": "CommentPreview.D06OIesj.js",
    "imports": [
      "_ElImage.n1w696EP.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_select._URXApTC.js",
      "_OssFileUpload.XsYTp1cz.js",
      "_nuxt-link.XGyP7oTZ.js",
      "_tag.0aE3xOWb.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_AutoIncre.vue.F6ckzkCf.js",
      "_scrollbar.sI6RLwsZ.js",
      "_popper.spGJhrtx.js",
      "_notification.KOWZGWjQ.js"
    ]
  },
  "CommentPreview.JFJ3T4Gg.css": {
    "file": "CommentPreview.JFJ3T4Gg.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_DelayTimer.vue.wX8oRdGJ.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "DelayTimer.vue.wX8oRdGJ.js",
    "imports": [
      "_swiper-vue.Dj7aAS3P.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_ElImage.!~{00z}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "ElImage.t6Ajzk8E.css",
    "src": "_ElImage.!~{00z}~.js"
  },
  "_ElImage.n1w696EP.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "ElImage.t6Ajzk8E.css"
    ],
    "file": "ElImage.n1w696EP.js",
    "imports": [
      "_swiper-vue.Dj7aAS3P.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_debounce.JkEshjc7.js"
    ]
  },
  "ElImage.t6Ajzk8E.css": {
    "file": "ElImage.t6Ajzk8E.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_Footer.!~{01N}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Footer.y5ruypfy.css",
    "src": "_Footer.!~{01N}~.js"
  },
  "_Footer.pgBZaBnn.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "Footer.y5ruypfy.css"
    ],
    "file": "Footer.pgBZaBnn.js",
    "imports": [
      "_nuxt-link.XGyP7oTZ.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_logo_dark.bVtpUsFq.js",
      "_Switch.85CpPrDe.js"
    ]
  },
  "Footer.y5ruypfy.css": {
    "file": "Footer.y5ruypfy.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_GoodsListSsr.!~{01j}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "GoodsListSsr.P5hBZBtk.css",
    "src": "_GoodsListSsr.!~{01j}~.js"
  },
  "_GoodsListSsr.L0xERvzS.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "GoodsListSsr.P5hBZBtk.css"
    ],
    "file": "GoodsListSsr.L0xERvzS.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.ICtiDBHK.js",
      "_nuxt-link.XGyP7oTZ.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "GoodsListSsr.P5hBZBtk.css": {
    "file": "GoodsListSsr.P5hBZBtk.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_Main.vue.!~{00R}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Main.IaUZe0bo.css",
    "src": "_Main.vue.!~{00R}~.js"
  },
  "_Main.vue.cpwjK1zd.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "Main.IaUZe0bo.css"
    ],
    "file": "Main.vue.cpwjK1zd.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_contact.O1CEoDgP.js",
      "_ElImage.n1w696EP.js",
      "_tag.0aE3xOWb.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "Main.IaUZe0bo.css": {
    "file": "Main.IaUZe0bo.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_OssFileUpload.!~{00T}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "OssFileUpload.-TDo8IgO.css",
    "src": "_OssFileUpload.!~{00T}~.js"
  },
  "_OssFileUpload.XsYTp1cz.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "OssFileUpload.-TDo8IgO.css"
    ],
    "file": "OssFileUpload.XsYTp1cz.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.n1w696EP.js",
      "_progress.FrFEJ-OC.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_index.ZiKhRbOu.js"
    ]
  },
  "OssFileUpload.-TDo8IgO.css": {
    "file": "OssFileUpload.-TDo8IgO.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_ShopLine.!~{01H}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "ShopLine.PGliGu9i.css",
    "src": "_ShopLine.!~{01H}~.js"
  },
  "_ShopLine.X7FCjoWZ.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "ShopLine.PGliGu9i.css"
    ],
    "file": "ShopLine.X7FCjoWZ.js",
    "imports": [
      "_ElImage.n1w696EP.js",
      "_nuxt-link.XGyP7oTZ.js",
      "_select._URXApTC.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_input-number.IHyUz0QJ.js",
      "_tag.0aE3xOWb.js",
      "_scrollbar.sI6RLwsZ.js",
      "_popper.spGJhrtx.js",
      "_sku.6hjTkifM.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "ShopLine.PGliGu9i.css": {
    "file": "ShopLine.PGliGu9i.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_SigninCard.vue.d6ALKyXq.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "popover.N-GW0j1A.css"
    ],
    "file": "SigninCard.vue.d6ALKyXq.js",
    "imports": [
      "_progress.FrFEJ-OC.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.e0Fib0RP.js",
      "_popper.spGJhrtx.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "popover.N-GW0j1A.css": {
    "file": "popover.N-GW0j1A.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_StatusTag.!~{01h}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "StatusTag.IETAoY75.css",
    "src": "_StatusTag.!~{01h}~.js"
  },
  "_StatusTag.KpcqejDn.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "StatusTag.IETAoY75.css"
    ],
    "file": "StatusTag.KpcqejDn.js",
    "imports": [
      "_tag.0aE3xOWb.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_post._A9YvOoY.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "StatusTag.IETAoY75.css": {
    "file": "StatusTag.IETAoY75.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_Switch.!~{01c}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Switch.JXXa2UnD.css",
    "src": "_Switch.!~{01c}~.js"
  },
  "_Switch.85CpPrDe.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "Switch.JXXa2UnD.css"
    ],
    "file": "Switch.85CpPrDe.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "Switch.JXXa2UnD.css": {
    "file": "Switch.JXXa2UnD.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_TagList.vue.xLlkOJQv.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TagList.vue.xLlkOJQv.js",
    "imports": [
      "_tag.0aE3xOWb.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "_UserPostTotal.vue.TXXLV1-b.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "UserPostTotal.vue.TXXLV1-b.js",
    "imports": [
      "_ElImage.n1w696EP.js",
      "_nuxt-link.XGyP7oTZ.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_post._A9YvOoY.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "_arrays.9GuX8ZvT.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "arrays.9GuX8ZvT.js"
  },
  "_avatar.!~{01G}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "avatar.bZH1-Oig.css",
    "src": "_avatar.!~{01G}~.js"
  },
  "_avatar.39vlKpyH.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "avatar.bZH1-Oig.css"
    ],
    "file": "avatar.39vlKpyH.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "avatar.bZH1-Oig.css": {
    "file": "avatar.bZH1-Oig.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_bills.z6aW0zLL.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "bills.z6aW0zLL.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_checkbox-group.!~{01E}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "checkbox-group.d5XbR8TY.css",
    "src": "_checkbox-group.!~{01E}~.js"
  },
  "_checkbox.!~{01v}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "checkbox.MJHvI1xB.css",
    "src": "_checkbox.!~{01v}~.js"
  },
  "_checkbox.4DsK3zkC.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "checkbox.MJHvI1xB.css"
    ],
    "file": "checkbox.4DsK3zkC.js",
    "imports": [
      "_swiper-vue.Dj7aAS3P.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_isEqual.m_TWAEwp.js",
      "_hasIn.SVItdnMC.js",
      "_flatten.M5xJS_dT.js"
    ]
  },
  "checkbox.MJHvI1xB.css": {
    "file": "checkbox.MJHvI1xB.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_cloneDeep.NiapePgQ.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "cloneDeep.NiapePgQ.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_collect.G7Oxmypa.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "collect.G7Oxmypa.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_contact.O1CEoDgP.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "contact.O1CEoDgP.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_useWs.7KTDcioA.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "_date-picker.!~{01B}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "date-picker.Nk-pBymI.css",
    "src": "_date-picker.!~{01B}~.js"
  },
  "_date-picker.a-XpruBi.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "date-picker.Nk-pBymI.css"
    ],
    "file": "date-picker.a-XpruBi.js",
    "imports": [
      "_localeData.8G9Laf4t.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_arrays.9GuX8ZvT.js",
      "_flatten.M5xJS_dT.js",
      "_popper.spGJhrtx.js",
      "_scrollbar.sI6RLwsZ.js",
      "_index.m5OxfFYg.js",
      "_debounce.JkEshjc7.js",
      "_index.3F527jeo.js",
      "_isEqual.m_TWAEwp.js"
    ]
  },
  "date-picker.Nk-pBymI.css": {
    "file": "date-picker.Nk-pBymI.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_debounce.JkEshjc7.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "debounce.JkEshjc7.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_dialog.!~{00N}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "dialog.NzY-5hTp.css",
    "src": "_dialog.!~{00N}~.js"
  },
  "_dialog.ZEROU_9m.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "dialog.NzY-5hTp.css"
    ],
    "file": "dialog.ZEROU_9m.js",
    "imports": [
      "_swiper-vue.Dj7aAS3P.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "dialog.NzY-5hTp.css": {
    "file": "dialog.NzY-5hTp.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_divider.!~{00J}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "divider.mvCfgREV.css",
    "src": "_divider.!~{00J}~.js"
  },
  "_divider.Tj-rVA6-.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "divider.mvCfgREV.css"
    ],
    "file": "divider.Tj-rVA6-.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "divider.mvCfgREV.css": {
    "file": "divider.mvCfgREV.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_empty.!~{00C}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "empty.sDhVTJEQ.css",
    "src": "_empty.!~{00C}~.js"
  },
  "_empty.4FggPXII.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "empty.sDhVTJEQ.css"
    ],
    "file": "empty.4FggPXII.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "empty.sDhVTJEQ.css": {
    "file": "empty.sDhVTJEQ.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_flatten.M5xJS_dT.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "flatten.M5xJS_dT.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_friend.cnlrQOsn.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "friend.cnlrQOsn.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_hasIn.SVItdnMC.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "hasIn.SVItdnMC.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.!~{01a}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.8uyA1Q9v.css",
    "src": "_index.!~{01a}~.js"
  },
  "_index.3F527jeo.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.3F527jeo.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.5ERnaCeM.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.5ERnaCeM.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "_index.ICtiDBHK.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.8uyA1Q9v.css"
    ],
    "file": "index.ICtiDBHK.js",
    "imports": [
      "_ElImage.n1w696EP.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "index.8uyA1Q9v.css": {
    "file": "index.8uyA1Q9v.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_index.Qq0FgSVl.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.Qq0FgSVl.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.ZiKhRbOu.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.ZiKhRbOu.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.e0Fib0RP.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.e0Fib0RP.js",
    "imports": [
      "_popper.spGJhrtx.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "_index.kkAswpOJ.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.kkAswpOJ.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.m5OxfFYg.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.m5OxfFYg.js",
    "imports": [
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "_index.pRYu4RGv.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.pRYu4RGv.js",
    "imports": [
      "_swiper-vue.Dj7aAS3P.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.vd55MiH5.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.vd55MiH5.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.w4tQZFEj.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.w4tQZFEj.js",
    "imports": [
      "_swiper-vue.Dj7aAS3P.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_input-number.!~{01l}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "input-number.5AezeF1g.css",
    "src": "_input-number.!~{01l}~.js"
  },
  "_input-number.IHyUz0QJ.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "input-number.5AezeF1g.css"
    ],
    "file": "input-number.IHyUz0QJ.js",
    "imports": [
      "_swiper-vue.Dj7aAS3P.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.m5OxfFYg.js"
    ]
  },
  "input-number.5AezeF1g.css": {
    "file": "input-number.5AezeF1g.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_isEqual.m_TWAEwp.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "isEqual.m_TWAEwp.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_localeData.8G9Laf4t.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "localeData.8G9Laf4t.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "_logo_dark.bVtpUsFq.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "popover.N-GW0j1A.css"
    ],
    "dynamicImports": [
      "components/card/UserLine.vue"
    ],
    "file": "logo_dark.bVtpUsFq.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.XGyP7oTZ.js",
      "_scrollbar.sI6RLwsZ.js",
      "_index.e0Fib0RP.js",
      "_popper.spGJhrtx.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "_menu-item.!~{01L}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "menu-item.f0mNRiTD.css",
    "src": "_tooltip.!~{01F}~.js"
  },
  "_menu.!~{01K}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "menu.QOppk9eM.css",
    "src": "_menu.!~{01K}~.js"
  },
  "_menu.bMzn290l.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "menu.QOppk9eM.css"
    ],
    "file": "menu.bMzn290l.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_index.w4tQZFEj.js",
      "_popper.spGJhrtx.js"
    ]
  },
  "menu.QOppk9eM.css": {
    "file": "menu.QOppk9eM.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_notification.!~{00I}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "notification.6oJvQm9r.css",
    "src": "_notification.!~{00I}~.js"
  },
  "_notification.KOWZGWjQ.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "notification.6oJvQm9r.css"
    ],
    "file": "notification.KOWZGWjQ.js",
    "imports": [
      "_swiper-vue.Dj7aAS3P.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "notification.6oJvQm9r.css": {
    "file": "notification.6oJvQm9r.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_nuxt-link.XGyP7oTZ.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "nuxt-link.XGyP7oTZ.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "_popover.!~{01g}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "popover.N-GW0j1A.css",
    "src": "_popover.!~{01g}~.js"
  },
  "_popper.!~{00V}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "popper.2BhxBuwE.css",
    "src": "_popper.!~{00V}~.js"
  },
  "_popper.spGJhrtx.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "popper.2BhxBuwE.css"
    ],
    "file": "popper.spGJhrtx.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "popper.2BhxBuwE.css": {
    "file": "popper.2BhxBuwE.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_post._A9YvOoY.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "post._A9YvOoY.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_progress.!~{00$}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "progress.rXLlm_9F.css",
    "src": "_progress.!~{00$}~.js"
  },
  "_progress.FrFEJ-OC.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "progress.rXLlm_9F.css"
    ],
    "file": "progress.FrFEJ-OC.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "progress.rXLlm_9F.css": {
    "file": "progress.rXLlm_9F.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_radio-button.!~{010}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "radio-button.l7x146Nf.css",
    "src": "_radio-button.!~{010}~.js"
  },
  "_radio-group.!~{00F}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "radio-group.P_Xz2fNs.css",
    "src": "_radio-group.!~{00F}~.js"
  },
  "_radio.!~{00Q}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "radio.eYTrrdr6.css",
    "src": "_radio.!~{00Q}~.js"
  },
  "_rand.mzGjE9Jh.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "rand.mzGjE9Jh.js"
  },
  "_rate.!~{01o}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "rate.xvbXIp1h.css",
    "src": "_rate.!~{01o}~.js"
  },
  "_rate.8XKL9JK7.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "rate.xvbXIp1h.css"
    ],
    "file": "rate.8XKL9JK7.js",
    "imports": [
      "_swiper-vue.Dj7aAS3P.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "rate.xvbXIp1h.css": {
    "file": "rate.xvbXIp1h.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_scrollbar.!~{00B}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "scrollbar.Smf0pYfu.css",
    "src": "_scrollbar.!~{00B}~.js"
  },
  "_scrollbar.sI6RLwsZ.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "scrollbar.Smf0pYfu.css"
    ],
    "file": "scrollbar.sI6RLwsZ.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "scrollbar.Smf0pYfu.css": {
    "file": "scrollbar.Smf0pYfu.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_select.!~{00S}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "select.WyCmEko8.css",
    "src": "_select.!~{00S}~.js"
  },
  "_select._URXApTC.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "select.WyCmEko8.css"
    ],
    "file": "select._URXApTC.js",
    "imports": [
      "_swiper-vue.Dj7aAS3P.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_popper.spGJhrtx.js",
      "_scrollbar.sI6RLwsZ.js",
      "_tag.0aE3xOWb.js",
      "_strings.Y1vdtDWm.js",
      "_isEqual.m_TWAEwp.js",
      "_debounce.JkEshjc7.js",
      "_hasIn.SVItdnMC.js",
      "_index.3F527jeo.js"
    ]
  },
  "select.WyCmEko8.css": {
    "file": "select.WyCmEko8.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_sku.6hjTkifM.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sku.6hjTkifM.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_strings.Y1vdtDWm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "strings.Y1vdtDWm.js",
    "imports": [
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "_swiper-vue.!~{002}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "swiper-vue.CRufKKKm.css",
    "src": "_swiper-vue.!~{002}~.js"
  },
  "_swiper-vue.Dj7aAS3P.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "swiper-vue.CRufKKKm.css"
    ],
    "file": "swiper-vue.Dj7aAS3P.js"
  },
  "swiper-vue.CRufKKKm.css": {
    "file": "swiper-vue.CRufKKKm.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_tabs.!~{013}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "tabs.H-UKPvku.css",
    "src": "_tabs.!~{013}~.js"
  },
  "_tabs.kwoWmf4E.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "tabs.H-UKPvku.css"
    ],
    "file": "tabs.kwoWmf4E.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_strings.Y1vdtDWm.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_index.5ERnaCeM.js"
    ]
  },
  "tabs.H-UKPvku.css": {
    "file": "tabs.H-UKPvku.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_tag.!~{00y}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "tag.ItIytdvz.css",
    "src": "_tag.!~{00y}~.js"
  },
  "_tag.0aE3xOWb.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "tag.ItIytdvz.css"
    ],
    "file": "tag.0aE3xOWb.js",
    "imports": [
      "_swiper-vue.Dj7aAS3P.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "tag.ItIytdvz.css": {
    "file": "tag.ItIytdvz.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_tooltip.!~{01F}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "menu-item.f0mNRiTD.css",
    "src": "_tooltip.!~{01F}~.js"
  },
  "_upload.!~{01u}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "upload.5r92S6hB.css",
    "src": "_upload.!~{01u}~.js"
  },
  "_upload.n6NwzSPY.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "upload.5r92S6hB.css"
    ],
    "file": "upload.n6NwzSPY.js",
    "imports": [
      "_swiper-vue.Dj7aAS3P.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_progress.FrFEJ-OC.js",
      "_cloneDeep.NiapePgQ.js",
      "_isEqual.m_TWAEwp.js"
    ]
  },
  "upload.5r92S6hB.css": {
    "file": "upload.5r92S6hB.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_useOrderStore.H12LzYZr.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useOrderStore.H12LzYZr.js",
    "imports": [
      "_index.kkAswpOJ.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "_useWebToast.X9cq2c7C.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useWebToast.X9cq2c7C.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_useWs.7KTDcioA.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useWs.7KTDcioA.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_notification.KOWZGWjQ.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "components/Chat/Friend/ApplyDialog.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ApplyDialog.OngG2s-L.js",
    "imports": [
      "_ApplyDialog.vue.1sZxZiUb.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_dialog.ZEROU_9m.js",
      "_notification.KOWZGWjQ.js",
      "_friend.cnlrQOsn.js"
    ],
    "isDynamicEntry": true,
    "src": "components/Chat/Friend/ApplyDialog.vue"
  },
  "components/Chat/NewGroupDialog.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "NewGroupDialog.VBKd-Cia.css",
      "checkbox-group.d5XbR8TY.css"
    ],
    "file": "NewGroupDialog.0m9DMyhP.js",
    "imports": [
      "_ElImage.n1w696EP.js",
      "_checkbox.4DsK3zkC.js",
      "_AutoIncre.vue.F6ckzkCf.js",
      "_scrollbar.sI6RLwsZ.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_OssFileUpload.XsYTp1cz.js",
      "_dialog.ZEROU_9m.js",
      "_notification.KOWZGWjQ.js",
      "_contact.O1CEoDgP.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_Main.vue.cpwjK1zd.js",
      "_friend.cnlrQOsn.js",
      "_debounce.JkEshjc7.js",
      "_isEqual.m_TWAEwp.js",
      "_hasIn.SVItdnMC.js",
      "_flatten.M5xJS_dT.js",
      "_progress.FrFEJ-OC.js",
      "_index.ZiKhRbOu.js",
      "_useWs.7KTDcioA.js",
      "_tag.0aE3xOWb.js"
    ],
    "isDynamicEntry": true,
    "src": "components/Chat/NewGroupDialog.vue"
  },
  "NewGroupDialog.VBKd-Cia.css": {
    "file": "NewGroupDialog.VBKd-Cia.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "checkbox-group.d5XbR8TY.css": {
    "file": "checkbox-group.d5XbR8TY.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/Comm/PostList.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "PostList.BPaQlUWh.css"
    ],
    "file": "PostList.BmG_SHHX.js",
    "imports": [
      "_ElImage.n1w696EP.js",
      "_nuxt-link.XGyP7oTZ.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.0aE3xOWb.js",
      "_TagList.vue.xLlkOJQv.js",
      "_CommentPreview.D06OIesj.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_AutoIncre.vue.F6ckzkCf.js",
      "_post._A9YvOoY.js",
      "_debounce.JkEshjc7.js",
      "_select._URXApTC.js",
      "_popper.spGJhrtx.js",
      "_scrollbar.sI6RLwsZ.js",
      "_strings.Y1vdtDWm.js",
      "_isEqual.m_TWAEwp.js",
      "_hasIn.SVItdnMC.js",
      "_index.3F527jeo.js",
      "_OssFileUpload.XsYTp1cz.js",
      "_progress.FrFEJ-OC.js",
      "_index.ZiKhRbOu.js",
      "_notification.KOWZGWjQ.js"
    ],
    "isDynamicEntry": true,
    "src": "components/Comm/PostList.vue"
  },
  "PostList.BPaQlUWh.css": {
    "file": "PostList.BPaQlUWh.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/Comm/post/CateGoryLine.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "CateGoryLine.yx2GUPRD.js",
    "imports": [
      "_ElImage.n1w696EP.js",
      "_nuxt-link.XGyP7oTZ.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_debounce.JkEshjc7.js"
    ],
    "isDynamicEntry": true,
    "src": "components/Comm/post/CateGoryLine.vue"
  },
  "components/Comm/post/Rank.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "Rank.y3OSjSFp.css"
    ],
    "file": "Rank.xkZl07Cy.js",
    "imports": [
      "_divider.Tj-rVA6-.js",
      "_tag.0aE3xOWb.js",
      "_ElImage.n1w696EP.js",
      "_nuxt-link.XGyP7oTZ.js",
      "_empty.4FggPXII.js",
      "_scrollbar.sI6RLwsZ.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_post._A9YvOoY.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_debounce.JkEshjc7.js"
    ],
    "isDynamicEntry": true,
    "src": "components/Comm/post/Rank.vue"
  },
  "Rank.y3OSjSFp.css": {
    "file": "Rank.y3OSjSFp.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/card/UserLine.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "UserLine.G_lnDfVq.css",
      "popover.N-GW0j1A.css"
    ],
    "file": "UserLine.mQY7f_tO.js",
    "imports": [
      "_avatar.39vlKpyH.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_upload.n6NwzSPY.js",
      "_nuxt-link.XGyP7oTZ.js",
      "_index.e0Fib0RP.js",
      "_progress.FrFEJ-OC.js",
      "_popper.spGJhrtx.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_cloneDeep.NiapePgQ.js",
      "_isEqual.m_TWAEwp.js"
    ],
    "isDynamicEntry": true,
    "src": "components/card/UserLine.vue"
  },
  "UserLine.G_lnDfVq.css": {
    "file": "UserLine.G_lnDfVq.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/list/GoodsList.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "GoodsList.1p6fEF-7.css"
    ],
    "file": "GoodsList.6UwjQqWm.js",
    "imports": [
      "_index.ICtiDBHK.js",
      "_nuxt-link.XGyP7oTZ.js",
      "_AutoIncre.vue.F6ckzkCf.js",
      "_swiper-vue.Dj7aAS3P.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.n1w696EP.js",
      "_debounce.JkEshjc7.js"
    ],
    "isDynamicEntry": true,
    "src": "components/list/GoodsList.vue"
  },
  "GoodsList.1p6fEF-7.css": {
    "file": "GoodsList.1p6fEF-7.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/menu/DrawerMenu.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "DrawerMenu.0ja6gThp.css",
      "menu-item.f0mNRiTD.css",
      "popover.N-GW0j1A.css"
    ],
    "file": "DrawerMenu.kPj4qJBT.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_menu.bMzn290l.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_scrollbar.sI6RLwsZ.js",
      "_popper.spGJhrtx.js",
      "_logo_dark.bVtpUsFq.js",
      "_index.w4tQZFEj.js",
      "_nuxt-link.XGyP7oTZ.js",
      "_index.e0Fib0RP.js"
    ],
    "isDynamicEntry": true,
    "src": "components/menu/DrawerMenu.vue"
  },
  "DrawerMenu.0ja6gThp.css": {
    "file": "DrawerMenu.0ja6gThp.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "menu-item.f0mNRiTD.css": {
    "file": "menu-item.f0mNRiTD.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/menu/RightButtons/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.d8QRz2qr.css",
      "popover.N-GW0j1A.css",
      "menu-item.f0mNRiTD.css"
    ],
    "dynamicImports": [
      "components/menu/ShopCartBar.vue"
    ],
    "file": "index._tSZBcWP.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_nuxt-link.XGyP7oTZ.js",
      "_Main.vue.cpwjK1zd.js",
      "_scrollbar.sI6RLwsZ.js",
      "_ElImage.n1w696EP.js",
      "_index.e0Fib0RP.js",
      "_popper.spGJhrtx.js",
      "_contact.O1CEoDgP.js",
      "_useWs.7KTDcioA.js",
      "_tag.0aE3xOWb.js",
      "_debounce.JkEshjc7.js",
      "_notification.KOWZGWjQ.js"
    ],
    "isDynamicEntry": true,
    "src": "components/menu/RightButtons/index.vue"
  },
  "index.d8QRz2qr.css": {
    "file": "index.d8QRz2qr.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/menu/ShopCartBar.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "ShopCartBar.iS6Wm7Is.css",
      "checkbox-group.d5XbR8TY.css",
      "popover.N-GW0j1A.css"
    ],
    "file": "ShopCartBar.gW0J5LgT.js",
    "imports": [
      "_checkbox.4DsK3zkC.js",
      "_ShopLine.X7FCjoWZ.js",
      "_AutoIncre.vue.F6ckzkCf.js",
      "_scrollbar.sI6RLwsZ.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.e0Fib0RP.js",
      "_popper.spGJhrtx.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_useOrderStore.H12LzYZr.js",
      "_isEqual.m_TWAEwp.js",
      "_hasIn.SVItdnMC.js",
      "_flatten.M5xJS_dT.js",
      "_ElImage.n1w696EP.js",
      "_debounce.JkEshjc7.js",
      "_nuxt-link.XGyP7oTZ.js",
      "_select._URXApTC.js",
      "_tag.0aE3xOWb.js",
      "_strings.Y1vdtDWm.js",
      "_index.3F527jeo.js",
      "_input-number.IHyUz0QJ.js",
      "_index.m5OxfFYg.js",
      "_sku.6hjTkifM.js",
      "_index.kkAswpOJ.js"
    ],
    "isDynamicEntry": true,
    "src": "components/menu/ShopCartBar.vue"
  },
  "ShopCartBar.iS6Wm7Is.css": {
    "file": "ShopCartBar.iS6Wm7Is.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "layouts/chat.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "chat.v6D4Qv8B.css",
      "menu-item.f0mNRiTD.css",
      "popover.N-GW0j1A.css"
    ],
    "dynamicImports": [
      "components/menu/RightButtons/index.vue"
    ],
    "file": "chat._yOMMwXy.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.n1w696EP.js",
      "components/card/UserLine.vue",
      "_swiper-vue.Dj7aAS3P.js",
      "_menu.bMzn290l.js",
      "_popper.spGJhrtx.js",
      "_useWs.7KTDcioA.js",
      "_friend.cnlrQOsn.js",
      "_useWebToast.X9cq2c7C.js",
      "_debounce.JkEshjc7.js",
      "_avatar.39vlKpyH.js",
      "_upload.n6NwzSPY.js",
      "_progress.FrFEJ-OC.js",
      "_cloneDeep.NiapePgQ.js",
      "_isEqual.m_TWAEwp.js",
      "_nuxt-link.XGyP7oTZ.js",
      "_index.e0Fib0RP.js",
      "_index.w4tQZFEj.js",
      "_notification.KOWZGWjQ.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/chat.vue"
  },
  "chat.v6D4Qv8B.css": {
    "file": "chat.v6D4Qv8B.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "layouts/error.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "error.rg8cxx26.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/error.vue"
  },
  "layouts/main.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "popover.N-GW0j1A.css",
      "menu-item.f0mNRiTD.css"
    ],
    "dynamicImports": [
      "components/menu/DrawerMenu.vue"
    ],
    "file": "main.pSfxsWM7.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_Footer.pgBZaBnn.js",
      "components/menu/RightButtons/index.vue",
      "_swiper-vue.Dj7aAS3P.js",
      "_nuxt-link.XGyP7oTZ.js",
      "_logo_dark.bVtpUsFq.js",
      "_scrollbar.sI6RLwsZ.js",
      "_index.e0Fib0RP.js",
      "_popper.spGJhrtx.js",
      "_Switch.85CpPrDe.js",
      "_Main.vue.cpwjK1zd.js",
      "_contact.O1CEoDgP.js",
      "_useWs.7KTDcioA.js",
      "_notification.KOWZGWjQ.js",
      "_ElImage.n1w696EP.js",
      "_debounce.JkEshjc7.js",
      "_tag.0aE3xOWb.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/main.vue"
  },
  "layouts/second.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "second.JqdAvVfB.css",
      "popover.N-GW0j1A.css",
      "menu-item.f0mNRiTD.css"
    ],
    "file": "second.XYpGABFY.js",
    "imports": [
      "_Footer.pgBZaBnn.js",
      "components/menu/RightButtons/index.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_nuxt-link.XGyP7oTZ.js",
      "_logo_dark.bVtpUsFq.js",
      "_scrollbar.sI6RLwsZ.js",
      "_index.e0Fib0RP.js",
      "_popper.spGJhrtx.js",
      "_Switch.85CpPrDe.js",
      "_Main.vue.cpwjK1zd.js",
      "_contact.O1CEoDgP.js",
      "_useWs.7KTDcioA.js",
      "_notification.KOWZGWjQ.js",
      "_ElImage.n1w696EP.js",
      "_debounce.JkEshjc7.js",
      "_tag.0aE3xOWb.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/second.vue"
  },
  "second.JqdAvVfB.css": {
    "file": "second.JqdAvVfB.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "layouts/user.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "user.yAuj-VgQ.css",
      "menu-item.f0mNRiTD.css",
      "popover.N-GW0j1A.css"
    ],
    "file": "user.J2UFnb9P.js",
    "imports": [
      "_nuxt-link.XGyP7oTZ.js",
      "_logo_dark.bVtpUsFq.js",
      "_Switch.85CpPrDe.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_menu.bMzn290l.js",
      "_popper.spGJhrtx.js",
      "components/menu/RightButtons/index.vue",
      "_scrollbar.sI6RLwsZ.js",
      "_index.e0Fib0RP.js",
      "_index.w4tQZFEj.js",
      "_Main.vue.cpwjK1zd.js",
      "_contact.O1CEoDgP.js",
      "_useWs.7KTDcioA.js",
      "_notification.KOWZGWjQ.js",
      "_ElImage.n1w696EP.js",
      "_debounce.JkEshjc7.js",
      "_tag.0aE3xOWb.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/user.vue"
  },
  "user.yAuj-VgQ.css": {
    "file": "user.yAuj-VgQ.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/element-plus/es/components/text/index.mjs": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.R13h4Vtw.css"
    ],
    "file": "index.6z8INJ9S.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/element-plus/es/components/text/index.mjs"
  },
  "index.R13h4Vtw.css": {
    "file": "index.R13h4Vtw.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "entry.3PN328n9.css"
    ],
    "dynamicImports": [
      "layouts/chat.vue",
      "layouts/error.vue",
      "layouts/main.vue",
      "layouts/second.vue",
      "layouts/user.vue",
      "node_modules/workbox-window/build/workbox-window.prod.es5.mjs"
    ],
    "file": "entry.T-DgZ826.js",
    "imports": [
      "_swiper-vue.Dj7aAS3P.js"
    ],
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js"
  },
  "entry.3PN328n9.css": {
    "file": "entry.3PN328n9.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/workbox-window/build/workbox-window.prod.es5.mjs": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "workbox-window.prod.es5.prqDwDSL.js",
    "isDynamicEntry": true,
    "src": "node_modules/workbox-window/build/workbox-window.prod.es5.mjs"
  },
  "pages/[...all].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_...all_.7KnorAxz.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/[...all].vue"
  },
  "pages/chat/friend.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "friend.9C4eh_nv.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "file": "friend.dandNplT.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.0aE3xOWb.js",
      "_ElImage.n1w696EP.js",
      "_AutoIncre.vue.F6ckzkCf.js",
      "_scrollbar.sI6RLwsZ.js",
      "_empty.4FggPXII.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_friend.cnlrQOsn.js",
      "_index.pRYu4RGv.js",
      "_contact.O1CEoDgP.js",
      "_useWs.7KTDcioA.js",
      "_notification.KOWZGWjQ.js",
      "_divider.Tj-rVA6-.js",
      "_ApplyDialog.vue.1sZxZiUb.js",
      "_index.Qq0FgSVl.js",
      "_debounce.JkEshjc7.js",
      "_dialog.ZEROU_9m.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/chat/friend.vue"
  },
  "friend.9C4eh_nv.css": {
    "file": "friend.9C4eh_nv.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "radio-group.P_Xz2fNs.css": {
    "file": "radio-group.P_Xz2fNs.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/chat/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.xScC5fds.css",
      "radio.eYTrrdr6.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "dynamicImports": [
      "components/Chat/NewGroupDialog.vue",
      "components/Chat/NewGroupDialog.vue",
      "components/Chat/Friend/ApplyDialog.vue"
    ],
    "file": "index.f5Jy3dsB.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.n1w696EP.js",
      "_index.pRYu4RGv.js",
      "_AutoIncre.vue.F6ckzkCf.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_notification.KOWZGWjQ.js",
      "_contact.O1CEoDgP.js",
      "_Main.vue.cpwjK1zd.js",
      "_friend.cnlrQOsn.js",
      "_useWs.7KTDcioA.js",
      "_tag.0aE3xOWb.js",
      "_scrollbar.sI6RLwsZ.js",
      "_select._URXApTC.js",
      "_OssFileUpload.XsYTp1cz.js",
      "_nuxt-link.XGyP7oTZ.js",
      "_popper.spGJhrtx.js",
      "_index.ZiKhRbOu.js",
      "_debounce.JkEshjc7.js",
      "_strings.Y1vdtDWm.js",
      "_isEqual.m_TWAEwp.js",
      "_hasIn.SVItdnMC.js",
      "_index.3F527jeo.js",
      "_progress.FrFEJ-OC.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/chat/index.vue"
  },
  "index.xScC5fds.css": {
    "file": "index.xScC5fds.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "radio.eYTrrdr6.css": {
    "file": "radio.eYTrrdr6.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/chat/setting.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "setting.1OV0DNN5.css",
      "radio-button.l7x146Nf.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "file": "setting.Ighr7dA0.js",
    "imports": [
      "_divider.Tj-rVA6-.js",
      "_select._URXApTC.js",
      "_index.pRYu4RGv.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.0aE3xOWb.js",
      "_scrollbar.sI6RLwsZ.js",
      "_popper.spGJhrtx.js",
      "_notification.KOWZGWjQ.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_strings.Y1vdtDWm.js",
      "_isEqual.m_TWAEwp.js",
      "_debounce.JkEshjc7.js",
      "_hasIn.SVItdnMC.js",
      "_index.3F527jeo.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/chat/setting.vue"
  },
  "setting.1OV0DNN5.css": {
    "file": "setting.1OV0DNN5.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "radio-button.l7x146Nf.css": {
    "file": "radio-button.l7x146Nf.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/category/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "_id_.uLLhAsoU.css"
    ],
    "dynamicImports": [
      "components/Comm/post/Rank.vue"
    ],
    "file": "_id_.uOqLJOpI.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.n1w696EP.js",
      "_CategoryTabs.o-ZBEK_U.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_debounce.JkEshjc7.js",
      "_tabs.kwoWmf4E.js",
      "_strings.Y1vdtDWm.js",
      "_index.5ERnaCeM.js",
      "components/Comm/PostList.vue",
      "_nuxt-link.XGyP7oTZ.js",
      "_tag.0aE3xOWb.js",
      "_TagList.vue.xLlkOJQv.js",
      "_CommentPreview.D06OIesj.js",
      "_select._URXApTC.js",
      "_popper.spGJhrtx.js",
      "_scrollbar.sI6RLwsZ.js",
      "_isEqual.m_TWAEwp.js",
      "_hasIn.SVItdnMC.js",
      "_index.3F527jeo.js",
      "_OssFileUpload.XsYTp1cz.js",
      "_progress.FrFEJ-OC.js",
      "_index.ZiKhRbOu.js",
      "_AutoIncre.vue.F6ckzkCf.js",
      "_notification.KOWZGWjQ.js",
      "_post._A9YvOoY.js",
      "components/list/GoodsList.vue",
      "_index.ICtiDBHK.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/category/[id].vue"
  },
  "_id_.uLLhAsoU.css": {
    "file": "_id_.uLLhAsoU.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/category/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.EaIT1GIC.css"
    ],
    "dynamicImports": [
      "components/Comm/post/Rank.vue"
    ],
    "file": "index.8bifOY9z.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_CategoryTabs.o-ZBEK_U.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_tabs.kwoWmf4E.js",
      "_strings.Y1vdtDWm.js",
      "_index.5ERnaCeM.js",
      "components/Comm/PostList.vue",
      "_ElImage.n1w696EP.js",
      "_debounce.JkEshjc7.js",
      "_nuxt-link.XGyP7oTZ.js",
      "_tag.0aE3xOWb.js",
      "_TagList.vue.xLlkOJQv.js",
      "_CommentPreview.D06OIesj.js",
      "_select._URXApTC.js",
      "_popper.spGJhrtx.js",
      "_scrollbar.sI6RLwsZ.js",
      "_isEqual.m_TWAEwp.js",
      "_hasIn.SVItdnMC.js",
      "_index.3F527jeo.js",
      "_OssFileUpload.XsYTp1cz.js",
      "_progress.FrFEJ-OC.js",
      "_index.ZiKhRbOu.js",
      "_AutoIncre.vue.F6ckzkCf.js",
      "_notification.KOWZGWjQ.js",
      "_post._A9YvOoY.js",
      "components/list/GoodsList.vue",
      "_index.ICtiDBHK.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/category/index.vue"
  },
  "index.EaIT1GIC.css": {
    "file": "index.EaIT1GIC.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/post/detail/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "_id_.72oiqwWe.css",
      "popover.N-GW0j1A.css"
    ],
    "dynamicImports": [
      "components/Comm/post/CateGoryLine.vue"
    ],
    "file": "_id_.28U0cz83.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.n1w696EP.js",
      "_Switch.85CpPrDe.js",
      "_tag.0aE3xOWb.js",
      "_nuxt-link.XGyP7oTZ.js",
      "_TagList.vue.xLlkOJQv.js",
      "_divider.Tj-rVA6-.js",
      "_post._A9YvOoY.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_CommentPreview.D06OIesj.js",
      "_UserPostTotal.vue.TXXLV1-b.js",
      "_SigninCard.vue.d6ALKyXq.js",
      "_debounce.JkEshjc7.js",
      "_select._URXApTC.js",
      "_popper.spGJhrtx.js",
      "_scrollbar.sI6RLwsZ.js",
      "_strings.Y1vdtDWm.js",
      "_isEqual.m_TWAEwp.js",
      "_hasIn.SVItdnMC.js",
      "_index.3F527jeo.js",
      "_OssFileUpload.XsYTp1cz.js",
      "_progress.FrFEJ-OC.js",
      "_index.ZiKhRbOu.js",
      "_AutoIncre.vue.F6ckzkCf.js",
      "_notification.KOWZGWjQ.js",
      "_index.e0Fib0RP.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/post/detail/[id].vue"
  },
  "_id_.72oiqwWe.css": {
    "file": "_id_.72oiqwWe.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/post/list.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "list.aADC_aru.css",
      "popover.N-GW0j1A.css"
    ],
    "file": "list.e5vErBB1.js",
    "imports": [
      "_nuxt-link.XGyP7oTZ.js",
      "_tag.0aE3xOWb.js",
      "_swiper-vue.Dj7aAS3P.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_post._A9YvOoY.js",
      "_ElImage.n1w696EP.js",
      "components/Comm/PostList.vue",
      "_tabs.kwoWmf4E.js",
      "_SigninCard.vue.d6ALKyXq.js",
      "components/Comm/post/Rank.vue",
      "_debounce.JkEshjc7.js",
      "_TagList.vue.xLlkOJQv.js",
      "_CommentPreview.D06OIesj.js",
      "_select._URXApTC.js",
      "_popper.spGJhrtx.js",
      "_scrollbar.sI6RLwsZ.js",
      "_strings.Y1vdtDWm.js",
      "_isEqual.m_TWAEwp.js",
      "_hasIn.SVItdnMC.js",
      "_index.3F527jeo.js",
      "_OssFileUpload.XsYTp1cz.js",
      "_progress.FrFEJ-OC.js",
      "_index.ZiKhRbOu.js",
      "_AutoIncre.vue.F6ckzkCf.js",
      "_notification.KOWZGWjQ.js",
      "_index.5ERnaCeM.js",
      "_index.e0Fib0RP.js",
      "_divider.Tj-rVA6-.js",
      "_empty.4FggPXII.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/post/list.vue"
  },
  "list.aADC_aru.css": {
    "file": "list.aADC_aru.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/post/new.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "new.0TTT8KuO.css",
      "radio-button.l7x146Nf.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "file": "new.bp9y4rDV.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_OssFileUpload.XsYTp1cz.js",
      "_index.pRYu4RGv.js",
      "_ElImage.n1w696EP.js",
      "_select._URXApTC.js",
      "_tag.0aE3xOWb.js",
      "_scrollbar.sI6RLwsZ.js",
      "_popper.spGJhrtx.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_notification.KOWZGWjQ.js",
      "_index.ZiKhRbOu.js",
      "_StatusTag.KpcqejDn.js",
      "_post._A9YvOoY.js",
      "_progress.FrFEJ-OC.js",
      "_debounce.JkEshjc7.js",
      "_strings.Y1vdtDWm.js",
      "_isEqual.m_TWAEwp.js",
      "_hasIn.SVItdnMC.js",
      "_index.3F527jeo.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/post/new.vue"
  },
  "new.0TTT8KuO.css": {
    "file": "new.0TTT8KuO.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/event/detail/[eid].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "_eid_.NtANQ6Xa.css"
    ],
    "file": "_eid_.oSuPgovY.js",
    "imports": [
      "_ElImage.n1w696EP.js",
      "_tag.0aE3xOWb.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_nuxt-link.XGyP7oTZ.js",
      "_index.vd55MiH5.js",
      "_debounce.JkEshjc7.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/event/detail/[eid].vue"
  },
  "_eid_.NtANQ6Xa.css": {
    "file": "_eid_.NtANQ6Xa.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/goods/comments/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_id_.oSzZS8qb.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/goods/comments/[id].vue"
  },
  "pages/goods/detail/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "_id_.6sdekYJX.css",
      "popover.N-GW0j1A.css",
      "radio-button.l7x146Nf.css",
      "radio-group.P_Xz2fNs.css",
      "radio.eYTrrdr6.css"
    ],
    "file": "_id_.atZNn3gy.js",
    "imports": [
      "_nuxt-link.XGyP7oTZ.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_GoodsListSsr.L0xERvzS.js",
      "_ElImage.n1w696EP.js",
      "_index.5ERnaCeM.js",
      "_scrollbar.sI6RLwsZ.js",
      "_tag.0aE3xOWb.js",
      "_popper.spGJhrtx.js",
      "_collect.G7Oxmypa.js",
      "_index.pRYu4RGv.js",
      "_input-number.IHyUz0QJ.js",
      "_useOrderStore.H12LzYZr.js",
      "_index.vd55MiH5.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_tabs.kwoWmf4E.js",
      "_rate.8XKL9JK7.js",
      "_AutoIncre.vue.F6ckzkCf.js",
      "_dialog.ZEROU_9m.js",
      "_index.w4tQZFEj.js",
      "_rand.mzGjE9Jh.js",
      "_index.ICtiDBHK.js",
      "_sku.6hjTkifM.js",
      "_debounce.JkEshjc7.js",
      "_index.m5OxfFYg.js",
      "_index.kkAswpOJ.js",
      "_strings.Y1vdtDWm.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/goods/detail/[id].vue"
  },
  "_id_.6sdekYJX.css": {
    "file": "_id_.6sdekYJX.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.Ik5BYhtU.css",
      "popover.N-GW0j1A.css"
    ],
    "dynamicImports": [
      "components/list/GoodsList.vue"
    ],
    "file": "index.G6QQ3rtK.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.0aE3xOWb.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_nuxt-link.XGyP7oTZ.js",
      "_AutoIncre.vue.F6ckzkCf.js",
      "_empty.4FggPXII.js",
      "_scrollbar.sI6RLwsZ.js",
      "_index.e0Fib0RP.js",
      "_popper.spGJhrtx.js",
      "_index.ICtiDBHK.js",
      "_index.vd55MiH5.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_GoodsListSsr.L0xERvzS.js",
      "_tabs.kwoWmf4E.js",
      "_ElImage.n1w696EP.js",
      "_strings.Y1vdtDWm.js",
      "_index.5ERnaCeM.js",
      "_debounce.JkEshjc7.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.Ik5BYhtU.css": {
    "file": "index.Ik5BYhtU.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/order/comment/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "_id_.65PfMBS2.css"
    ],
    "file": "_id_.5bYctR6t.js",
    "imports": [
      "_Switch.85CpPrDe.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_progress.FrFEJ-OC.js",
      "_upload.n6NwzSPY.js",
      "_dialog.ZEROU_9m.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_index.ZiKhRbOu.js",
      "_ElImage.n1w696EP.js",
      "_rate.8XKL9JK7.js",
      "_checkbox.4DsK3zkC.js",
      "_nuxt-link.XGyP7oTZ.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_notification.KOWZGWjQ.js",
      "_index.kkAswpOJ.js",
      "_cloneDeep.NiapePgQ.js",
      "_isEqual.m_TWAEwp.js",
      "_debounce.JkEshjc7.js",
      "_hasIn.SVItdnMC.js",
      "_flatten.M5xJS_dT.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/order/comment/[id].vue"
  },
  "_id_.65PfMBS2.css": {
    "file": "_id_.65PfMBS2.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/order/detail.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "detail.FQzghYYY.css",
      "radio.eYTrrdr6.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "dynamicImports": [
      "node_modules/element-plus/es/components/text/index.mjs"
    ],
    "file": "detail.zApwwckx.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.n1w696EP.js",
      "_nuxt-link.XGyP7oTZ.js",
      "_divider.Tj-rVA6-.js",
      "_DelayTimer.vue.wX8oRdGJ.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_Switch.85CpPrDe.js",
      "_index.5ERnaCeM.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_bills.z6aW0zLL.js",
      "_index.kkAswpOJ.js",
      "_useOrderStore.H12LzYZr.js",
      "_index.pRYu4RGv.js",
      "_tag.0aE3xOWb.js",
      "_scrollbar.sI6RLwsZ.js",
      "_select._URXApTC.js",
      "_input-number.IHyUz0QJ.js",
      "_popper.spGJhrtx.js",
      "_index.vd55MiH5.js",
      "_sku.6hjTkifM.js",
      "_empty.4FggPXII.js",
      "_notification.KOWZGWjQ.js",
      "_useWebToast.X9cq2c7C.js",
      "_debounce.JkEshjc7.js",
      "_strings.Y1vdtDWm.js",
      "_isEqual.m_TWAEwp.js",
      "_hasIn.SVItdnMC.js",
      "_index.3F527jeo.js",
      "_index.m5OxfFYg.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/order/detail.vue"
  },
  "detail.FQzghYYY.css": {
    "file": "detail.FQzghYYY.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/order/list.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "list.pKmG3IwD.css"
    ],
    "file": "list.eI-os2Pm.js",
    "imports": [
      "_divider.Tj-rVA6-.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_date-picker.a-XpruBi.js",
      "_DelayTimer.vue.wX8oRdGJ.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_ElImage.n1w696EP.js",
      "_tag.0aE3xOWb.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_useOrderStore.H12LzYZr.js",
      "_index.kkAswpOJ.js",
      "_AutoIncre.vue.F6ckzkCf.js",
      "_scrollbar.sI6RLwsZ.js",
      "_popper.spGJhrtx.js",
      "_notification.KOWZGWjQ.js",
      "_tabs.kwoWmf4E.js",
      "_localeData.8G9Laf4t.js",
      "_arrays.9GuX8ZvT.js",
      "_flatten.M5xJS_dT.js",
      "_index.m5OxfFYg.js",
      "_debounce.JkEshjc7.js",
      "_index.3F527jeo.js",
      "_isEqual.m_TWAEwp.js",
      "_strings.Y1vdtDWm.js",
      "_index.5ERnaCeM.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/order/list.vue"
  },
  "list.pKmG3IwD.css": {
    "file": "list.pKmG3IwD.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/search/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.gADI8LgY.css"
    ],
    "dynamicImports": [
      "components/list/GoodsList.vue",
      "components/Comm/PostList.vue"
    ],
    "file": "index.GUYqcIFN.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_checkbox.4DsK3zkC.js",
      "_select._URXApTC.js",
      "_tag.0aE3xOWb.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_tabs.kwoWmf4E.js",
      "_empty.4FggPXII.js",
      "_scrollbar.sI6RLwsZ.js",
      "_popper.spGJhrtx.js",
      "_isEqual.m_TWAEwp.js",
      "_hasIn.SVItdnMC.js",
      "_flatten.M5xJS_dT.js",
      "_strings.Y1vdtDWm.js",
      "_debounce.JkEshjc7.js",
      "_index.3F527jeo.js",
      "_index.5ERnaCeM.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/search/index.vue"
  },
  "index.gADI8LgY.css": {
    "file": "index.gADI8LgY.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/setting/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.p8ZulH49.css",
      "radio-button.l7x146Nf.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "file": "index.a2DIgaxM.js",
    "imports": [
      "_divider.Tj-rVA6-.js",
      "_select._URXApTC.js",
      "_index.pRYu4RGv.js",
      "_swiper-vue.Dj7aAS3P.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.0aE3xOWb.js",
      "_scrollbar.sI6RLwsZ.js",
      "_popper.spGJhrtx.js",
      "_notification.KOWZGWjQ.js",
      "_strings.Y1vdtDWm.js",
      "_isEqual.m_TWAEwp.js",
      "_debounce.JkEshjc7.js",
      "_hasIn.SVItdnMC.js",
      "_index.3F527jeo.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/setting/index.vue"
  },
  "index.p8ZulH49.css": {
    "file": "index.p8ZulH49.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/address.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "address.WdFNjMwU.css",
      "radio.eYTrrdr6.css",
      "checkbox-group.d5XbR8TY.css"
    ],
    "file": "address.pyfibFrZ.js",
    "imports": [
      "node_modules/element-plus/es/components/text/index.mjs",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_scrollbar.sI6RLwsZ.js",
      "_checkbox.4DsK3zkC.js",
      "_index.pRYu4RGv.js",
      "_rand.mzGjE9Jh.js",
      "_strings.Y1vdtDWm.js",
      "_isEqual.m_TWAEwp.js",
      "_arrays.9GuX8ZvT.js",
      "_flatten.M5xJS_dT.js",
      "_cloneDeep.NiapePgQ.js",
      "_popper.spGJhrtx.js",
      "_tag.0aE3xOWb.js",
      "_index.3F527jeo.js",
      "_debounce.JkEshjc7.js",
      "_dialog.ZEROU_9m.js",
      "_divider.Tj-rVA6-.js",
      "_hasIn.SVItdnMC.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/address.vue"
  },
  "address.WdFNjMwU.css": {
    "file": "address.WdFNjMwU.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/collect.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "collect.7bC4-ld9.css",
      "checkbox-group.d5XbR8TY.css"
    ],
    "file": "collect.re9dbUAY.js",
    "imports": [
      "_divider.Tj-rVA6-.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_checkbox.4DsK3zkC.js",
      "_ElImage.n1w696EP.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_scrollbar.sI6RLwsZ.js",
      "_collect.G7Oxmypa.js",
      "_tabs.kwoWmf4E.js",
      "_tag.0aE3xOWb.js",
      "_nuxt-link.XGyP7oTZ.js",
      "_TagList.vue.xLlkOJQv.js",
      "_AutoIncre.vue.F6ckzkCf.js",
      "_post._A9YvOoY.js",
      "_isEqual.m_TWAEwp.js",
      "_hasIn.SVItdnMC.js",
      "_flatten.M5xJS_dT.js",
      "_debounce.JkEshjc7.js",
      "_strings.Y1vdtDWm.js",
      "_index.5ERnaCeM.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/collect.vue"
  },
  "collect.7bC4-ld9.css": {
    "file": "collect.7bC4-ld9.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/info.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "info._k_JpRFF.css",
      "popover.N-GW0j1A.css",
      "menu-item.f0mNRiTD.css"
    ],
    "file": "info.k6SpN3p8.js",
    "imports": [
      "_ElImage.n1w696EP.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.e0Fib0RP.js",
      "_popper.spGJhrtx.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_upload.n6NwzSPY.js",
      "_date-picker.a-XpruBi.js",
      "_select._URXApTC.js",
      "_progress.FrFEJ-OC.js",
      "_scrollbar.sI6RLwsZ.js",
      "_tag.0aE3xOWb.js",
      "_nuxt-link.XGyP7oTZ.js",
      "_TagList.vue.xLlkOJQv.js",
      "_AutoIncre.vue.F6ckzkCf.js",
      "_post._A9YvOoY.js",
      "_tabs.kwoWmf4E.js",
      "_UserPostTotal.vue.TXXLV1-b.js",
      "_SigninCard.vue.d6ALKyXq.js",
      "_index.Qq0FgSVl.js",
      "_debounce.JkEshjc7.js",
      "_cloneDeep.NiapePgQ.js",
      "_isEqual.m_TWAEwp.js",
      "_localeData.8G9Laf4t.js",
      "_arrays.9GuX8ZvT.js",
      "_flatten.M5xJS_dT.js",
      "_index.m5OxfFYg.js",
      "_index.3F527jeo.js",
      "_strings.Y1vdtDWm.js",
      "_hasIn.SVItdnMC.js",
      "_index.5ERnaCeM.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/info.vue"
  },
  "info._k_JpRFF.css": {
    "file": "info._k_JpRFF.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/post.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "post.yVQn8Ib0.css"
    ],
    "file": "post.xZ1DPVS8.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.n1w696EP.js",
      "_select._URXApTC.js",
      "_tag.0aE3xOWb.js",
      "_scrollbar.sI6RLwsZ.js",
      "_popper.spGJhrtx.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_StatusTag.KpcqejDn.js",
      "_nuxt-link.XGyP7oTZ.js",
      "_TagList.vue.xLlkOJQv.js",
      "_post._A9YvOoY.js",
      "_AutoIncre.vue.F6ckzkCf.js",
      "_notification.KOWZGWjQ.js",
      "_tabs.kwoWmf4E.js",
      "_debounce.JkEshjc7.js",
      "_strings.Y1vdtDWm.js",
      "_isEqual.m_TWAEwp.js",
      "_hasIn.SVItdnMC.js",
      "_index.3F527jeo.js",
      "_index.5ERnaCeM.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/post.vue"
  },
  "post.yVQn8Ib0.css": {
    "file": "post.yVQn8Ib0.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/safe.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "safe.73roRH3g.css"
    ],
    "file": "safe.P3nc7pkw.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.0aE3xOWb.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_scrollbar.sI6RLwsZ.js",
      "_avatar.39vlKpyH.js",
      "_divider.Tj-rVA6-.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_useOrderStore.H12LzYZr.js",
      "_index.kkAswpOJ.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/safe.vue"
  },
  "safe.73roRH3g.css": {
    "file": "safe.73roRH3g.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/shopcart.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "shopcart.cNizIJyk.css",
      "checkbox-group.d5XbR8TY.css"
    ],
    "file": "shopcart.T8TwS_H_.js",
    "imports": [
      "_checkbox.4DsK3zkC.js",
      "_ShopLine.X7FCjoWZ.js",
      "_nuxt-link.XGyP7oTZ.js",
      "_AutoIncre.vue.F6ckzkCf.js",
      "_scrollbar.sI6RLwsZ.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_useOrderStore.H12LzYZr.js",
      "_isEqual.m_TWAEwp.js",
      "_hasIn.SVItdnMC.js",
      "_flatten.M5xJS_dT.js",
      "_ElImage.n1w696EP.js",
      "_debounce.JkEshjc7.js",
      "_select._URXApTC.js",
      "_popper.spGJhrtx.js",
      "_tag.0aE3xOWb.js",
      "_strings.Y1vdtDWm.js",
      "_index.3F527jeo.js",
      "_input-number.IHyUz0QJ.js",
      "_index.m5OxfFYg.js",
      "_sku.6hjTkifM.js",
      "_index.kkAswpOJ.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/shopcart.vue"
  },
  "shopcart.cNizIJyk.css": {
    "file": "shopcart.cNizIJyk.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/wallet.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "wallet.7z599r9w.css",
      "popover.N-GW0j1A.css"
    ],
    "file": "wallet.nrOx1mtd.js",
    "imports": [
      "node_modules/element-plus/es/components/text/index.mjs",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_progress.FrFEJ-OC.js",
      "_index.e0Fib0RP.js",
      "_popper.spGJhrtx.js",
      "_bills.z6aW0zLL.js",
      "_scrollbar.sI6RLwsZ.js",
      "_input-number.IHyUz0QJ.js",
      "_select._URXApTC.js",
      "_tag.0aE3xOWb.js",
      "_localeData.8G9Laf4t.js",
      "_divider.Tj-rVA6-.js",
      "_index.m5OxfFYg.js",
      "_strings.Y1vdtDWm.js",
      "_isEqual.m_TWAEwp.js",
      "_debounce.JkEshjc7.js",
      "_hasIn.SVItdnMC.js",
      "_index.3F527jeo.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/wallet.vue"
  },
  "wallet.7z599r9w.css": {
    "file": "wallet.7z599r9w.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
