import{c5 as r,b4 as o}from"./entry.N_rLiM8b.js";function a(e,t){return r.get(`${o}/community/user/${e}`,{},{headers:{Authorization:t}})}export{a as g};
