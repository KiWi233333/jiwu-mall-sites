import{go as n}from"./entry.WP8H-FeB.js";function a(i,s,t){const o=n({title:i,body:s,icon:"/logo.png",...t});o.isSupported&&o.show()}export{a as u};
