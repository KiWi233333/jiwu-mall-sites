import{hF as o}from"./entry.G5dQYRyk.js";var r=1,n=4;function a(e){return o(e,r|n)}export{a as c};
