import{a$ as r,ab as o}from"./BsZrsGSf.js";function s(e,t){return r.get(`${o}/community/user/${e}`,{},{headers:{Authorization:t}})}export{s as g};
