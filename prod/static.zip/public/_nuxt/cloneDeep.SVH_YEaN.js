import{iZ as o}from"./entry.N_rLiM8b.js";var r=1,n=4;function a(e){return o(e,r|n)}export{a as c};
