import{ht as n}from"./entry.P4c2WukM.js";function a(t,i,s){const o=n({title:t,body:i,icon:"/logo.png",...s});o.isSupported&&o.show()}export{a as u};
