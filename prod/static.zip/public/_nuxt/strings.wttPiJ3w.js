import{iJ as a}from"./entry.N_rLiM8b.js";const p=(e="")=>e.replace(/[|\\{}()[\]^$+*?.]/g,"\\$&").replace(/-/g,"\\x2d"),i=e=>a(e);export{i as c,p as e};
