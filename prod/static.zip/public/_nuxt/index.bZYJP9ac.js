import{b4 as r,ag as o}from"./entry.WP8H-FeB.js";function a(e,t){return r.get(`${o}/community/user/${e}`,{},{headers:{Authorization:t}})}export{a as g};
