import{b4 as o,b5 as t,c6 as u}from"./entry.P4c2WukM.js";function d(s){return o(`${t}/goods/sku?gid=${s}`,"$AfkcphgTcz")}function r(s){return u.post("/goods/sku",{ids:[...s]})}export{r as a,d as g};
