import{hF as o}from"./entry.qdCIn5w-.js";var r=1,n=4;function a(e){return o(e,r|n)}export{a as c};
