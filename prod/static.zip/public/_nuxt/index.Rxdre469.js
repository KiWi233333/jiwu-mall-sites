import{c6 as r,b5 as o}from"./entry.P4c2WukM.js";function a(e,t){return r.get(`${o}/community/user/${e}`,{},{headers:{Authorization:t}})}export{a as g};
