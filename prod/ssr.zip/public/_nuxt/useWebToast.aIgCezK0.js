import{hu as n}from"./entry.2CJ4nrLU.js";function u(i,s,t){const o=n({title:i,body:s,icon:"/logo.png",...t});o.isSupported&&o.show()}export{u};
