import{iL as a}from"./entry.2CJ4nrLU.js";const p=(e="")=>e.replace(/[|\\{}()[\]^$+*?.]/g,"\\$&").replace(/-/g,"\\x2d"),i=e=>a(e);export{i as c,p as e};
