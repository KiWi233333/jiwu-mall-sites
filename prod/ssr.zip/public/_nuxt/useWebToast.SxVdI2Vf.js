import{hs as n}from"./entry.VP2ougng.js";function a(s,i,t){const o=n({title:s,body:i,icon:"/logo.png",...t});o.isSupported&&o.show()}export{a as u};
