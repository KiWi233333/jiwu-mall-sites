import{ht as n}from"./entry.8ecdJnBa.js";function a(t,i,s){const o=n({title:t,body:i,icon:"/logo.png",...s});o.isSupported&&o.show()}export{a as u};
