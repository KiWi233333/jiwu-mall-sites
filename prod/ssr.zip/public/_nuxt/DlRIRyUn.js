import{cX as o}from"./C3MmMtNw.js";const p=o("/logo.png");export{p as _};
