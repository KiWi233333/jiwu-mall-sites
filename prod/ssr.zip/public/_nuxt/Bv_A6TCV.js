import{a$ as r,ab as o}from"./Dk9C9tpq.js";function s(e,t){return r.get(`${o}/community/user/${e}`,{},{headers:{Authorization:t}})}export{s as g};
