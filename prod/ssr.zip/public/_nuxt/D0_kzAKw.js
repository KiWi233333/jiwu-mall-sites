import{aa as o,ab as t,a$ as a}from"./Dk9C9tpq.js";function e(s){return o(`${t}/goods/sku?gid=${s}`,"$AfkcphgTcz")}function d(s){return a.post("/goods/sku",{ids:[...s]})}export{d as a,e as g};
