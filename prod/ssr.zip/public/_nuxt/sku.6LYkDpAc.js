import{b3 as o,b4 as t,c5 as u}from"./entry.JZpcxbrR.js";function d(s){return o(`${t}/goods/sku?gid=${s}`,"$AfkcphgTcz")}function r(s){return u.post("/goods/sku",{ids:[...s]})}export{r as a,d as g};
