const client_manifest = {
  "_ApplyDialog.vue.S3AUf9Ii.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ApplyDialog.vue.S3AUf9Ii.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_dialog.jFAPlFAt.js",
      "_notification.XBrm9l6C.js",
      "_friend.VoldwS30.js"
    ]
  },
  "_AutoIncre.vue.0Ch5nUxt.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "AutoIncre.vue.0Ch5nUxt.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_CategoryTabs.!~{014}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "CategoryTabs.787nBCiN.css",
    "src": "_CategoryTabs.!~{014}~.js"
  },
  "_CategoryTabs.lJlo84z7.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "CategoryTabs.787nBCiN.css"
    ],
    "file": "CategoryTabs.lJlo84z7.js",
    "imports": [
      "_tabs.t1RgyD45.js",
      "node_modules/nuxt/dist/app/entry.js",
      "components/Comm/PostList.vue",
      "components/list/GoodsList.vue"
    ]
  },
  "CategoryTabs.787nBCiN.css": {
    "file": "CategoryTabs.787nBCiN.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_CommentPreview.!~{019}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "CommentPreview.mYLkOLZt.css",
    "src": "_CommentPreview.!~{019}~.js"
  },
  "_CommentPreview._X0no8e2.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "CommentPreview.mYLkOLZt.css"
    ],
    "file": "CommentPreview._X0no8e2.js",
    "imports": [
      "_ElImage.N4HcXALN.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_select.0vnI2MVe.js",
      "_OssFileUpload.4LUV6w65.js",
      "_nuxt-link.ziHOUCB7.js",
      "_tag.cgGFhm6N.js",
      "_AutoIncre.vue.0Ch5nUxt.js",
      "_scrollbar.5ezCorGI.js",
      "_popper.O9tQ7Dae.js",
      "_notification.XBrm9l6C.js"
    ]
  },
  "CommentPreview.mYLkOLZt.css": {
    "file": "CommentPreview.mYLkOLZt.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_DelayTimer.vue.iY8Lf6xU.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "DelayTimer.vue.iY8Lf6xU.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_ElImage.!~{00B}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "ElImage.6ybrNKBL.css",
    "src": "_ElImage.!~{00B}~.js"
  },
  "_ElImage.N4HcXALN.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "ElImage.6ybrNKBL.css"
    ],
    "file": "ElImage.N4HcXALN.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_debounce.FconTdz-.js"
    ]
  },
  "ElImage.6ybrNKBL.css": {
    "file": "ElImage.6ybrNKBL.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_Footer.!~{01Q}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Footer.y5ruypfy.css",
    "src": "_Footer.!~{01Q}~.js"
  },
  "_Footer.3VViGyd7.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "Footer.y5ruypfy.css"
    ],
    "file": "Footer.3VViGyd7.js",
    "imports": [
      "_nuxt-link.ziHOUCB7.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_logo_dark.pttUYYX3.js",
      "_Switch.zLKumwEf.js"
    ]
  },
  "Footer.y5ruypfy.css": {
    "file": "Footer.y5ruypfy.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_GoodsListSsr.!~{01n}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "GoodsListSsr.P5hBZBtk.css",
    "src": "_GoodsListSsr.!~{01n}~.js"
  },
  "_GoodsListSsr.E0c5bXBv.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "GoodsListSsr.P5hBZBtk.css"
    ],
    "file": "GoodsListSsr.E0c5bXBv.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.hRM60x37.js",
      "_nuxt-link.ziHOUCB7.js",
      "node_modules/element-plus/es/components/text/index.mjs"
    ]
  },
  "GoodsListSsr.P5hBZBtk.css": {
    "file": "GoodsListSsr.P5hBZBtk.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_Main.!~{00z}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Main.NrGMXl3O.css",
    "src": "_Main.!~{00z}~.js"
  },
  "_Main.NWJvXKDl.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "Main.NrGMXl3O.css"
    ],
    "file": "Main.NWJvXKDl.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_contact.ng7D7NaS.js",
      "_ElImage.N4HcXALN.js",
      "_tag.cgGFhm6N.js"
    ]
  },
  "Main.NrGMXl3O.css": {
    "file": "Main.NrGMXl3O.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_OssFileUpload.!~{00W}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "OssFileUpload.f4DKzIfB.css",
    "src": "_OssFileUpload.!~{00W}~.js"
  },
  "_OssFileUpload.4LUV6w65.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "OssFileUpload.f4DKzIfB.css"
    ],
    "file": "OssFileUpload.4LUV6w65.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.N4HcXALN.js",
      "_progress.8HIBJk6c.js",
      "_index.g588nUAn.js"
    ]
  },
  "OssFileUpload.f4DKzIfB.css": {
    "file": "OssFileUpload.f4DKzIfB.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_ShopLine.!~{01K}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "ShopLine.Wq74ulT-.css",
    "src": "_ShopLine.!~{01K}~.js"
  },
  "_ShopLine.iMo2a7zT.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "ShopLine.Wq74ulT-.css"
    ],
    "file": "ShopLine.iMo2a7zT.js",
    "imports": [
      "_ElImage.N4HcXALN.js",
      "_nuxt-link.ziHOUCB7.js",
      "_select.0vnI2MVe.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_input-number.f60sKgNh.js",
      "_tag.cgGFhm6N.js",
      "_scrollbar.5ezCorGI.js",
      "_popper.O9tQ7Dae.js",
      "_sku.6LYkDpAc.js"
    ]
  },
  "ShopLine.Wq74ulT-.css": {
    "file": "ShopLine.Wq74ulT-.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_SigninCard.vue.NwgfYIns.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "popover.LAISAeEG.css"
    ],
    "file": "SigninCard.vue.NwgfYIns.js",
    "imports": [
      "_progress.8HIBJk6c.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.nfpRm3oW.js",
      "_popper.O9tQ7Dae.js"
    ]
  },
  "popover.LAISAeEG.css": {
    "file": "popover.LAISAeEG.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_StatusTag.!~{01l}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "StatusTag.IETAoY75.css",
    "src": "_StatusTag.!~{01l}~.js"
  },
  "_StatusTag.74ZF8UBX.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "StatusTag.IETAoY75.css"
    ],
    "file": "StatusTag.74ZF8UBX.js",
    "imports": [
      "_tag.cgGFhm6N.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_post.Th7QFVpT.js"
    ]
  },
  "StatusTag.IETAoY75.css": {
    "file": "StatusTag.IETAoY75.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_Switch.!~{01e}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Switch.JXXa2UnD.css",
    "src": "_Switch.!~{01e}~.js"
  },
  "_Switch.zLKumwEf.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "Switch.JXXa2UnD.css"
    ],
    "file": "Switch.zLKumwEf.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "Switch.JXXa2UnD.css": {
    "file": "Switch.JXXa2UnD.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_TagList.vue.Uo1KJ4jk.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TagList.vue.Uo1KJ4jk.js",
    "imports": [
      "_tag.cgGFhm6N.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_UserPostTotal.vue.KMzfEJqn.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "UserPostTotal.vue.KMzfEJqn.js",
    "imports": [
      "_ElImage.N4HcXALN.js",
      "_nuxt-link.ziHOUCB7.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_post.Th7QFVpT.js"
    ]
  },
  "___commonjsHelpers__.1J56E-h6.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "__commonjsHelpers__.1J56E-h6.js"
  },
  "_arrays.9GuX8ZvT.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "arrays.9GuX8ZvT.js"
  },
  "_avatar.!~{01J}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "avatar.bZH1-Oig.css",
    "src": "_avatar.!~{01J}~.js"
  },
  "_avatar.F_eY8A6y.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "avatar.bZH1-Oig.css"
    ],
    "file": "avatar.F_eY8A6y.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "avatar.bZH1-Oig.css": {
    "file": "avatar.bZH1-Oig.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_bills.ggSo-lLQ.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "bills.ggSo-lLQ.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_checkbox-group.!~{01H}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "checkbox-group.d5XbR8TY.css",
    "src": "_checkbox-group.!~{01H}~.js"
  },
  "_checkbox.!~{01y}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "checkbox.MJHvI1xB.css",
    "src": "_checkbox.!~{01y}~.js"
  },
  "_checkbox.INotFvCX.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "checkbox.MJHvI1xB.css"
    ],
    "file": "checkbox.INotFvCX.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_isEqual.ouEoZz40.js",
      "_hasIn.-H__E5zv.js",
      "_flatten.2BRkJ_94.js"
    ]
  },
  "checkbox.MJHvI1xB.css": {
    "file": "checkbox.MJHvI1xB.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_cloneDeep.yjpaYQ6s.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "cloneDeep.yjpaYQ6s.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_collect.e95C5X6X.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "collect.e95C5X6X.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_contact.ng7D7NaS.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "contact.ng7D7NaS.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_useWs.tFUymKQj.js"
    ]
  },
  "_create-shadow.1WkZ6EH9.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "create-shadow.1WkZ6EH9.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_date-picker.!~{01E}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "date-picker.sSkDKlix.css",
    "src": "_date-picker.!~{01E}~.js"
  },
  "_date-picker.FrErj8Du.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "date-picker.sSkDKlix.css"
    ],
    "file": "date-picker.FrErj8Du.js",
    "imports": [
      "_localeData._AXmWfIZ.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_arrays.9GuX8ZvT.js",
      "_flatten.2BRkJ_94.js",
      "_popper.O9tQ7Dae.js",
      "_scrollbar.5ezCorGI.js",
      "_index.nOErYuRE.js",
      "_debounce.FconTdz-.js",
      "_index.LjzXrPD3.js",
      "_isEqual.ouEoZz40.js"
    ]
  },
  "date-picker.sSkDKlix.css": {
    "file": "date-picker.sSkDKlix.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_debounce.FconTdz-.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "debounce.FconTdz-.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_dialog.!~{00Q}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "dialog.mDs1vky2.css",
    "src": "_dialog.!~{00Q}~.js"
  },
  "_dialog.jFAPlFAt.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "dialog.mDs1vky2.css"
    ],
    "file": "dialog.jFAPlFAt.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_isUndefined.IZwZ21d-.js"
    ]
  },
  "dialog.mDs1vky2.css": {
    "file": "dialog.mDs1vky2.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_divider.!~{00N}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "divider.mvCfgREV.css",
    "src": "_divider.!~{00N}~.js"
  },
  "_divider.SzSAruyT.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "divider.mvCfgREV.css"
    ],
    "file": "divider.SzSAruyT.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "divider.mvCfgREV.css": {
    "file": "divider.mvCfgREV.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_effect-creative.HiJmGJ8F.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "effect-creative.HiJmGJ8F.js",
    "imports": [
      "_create-shadow.1WkZ6EH9.js"
    ]
  },
  "_empty.!~{00J}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "empty.sDhVTJEQ.css",
    "src": "_empty.!~{00J}~.js"
  },
  "_empty.7jW9whiq.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "empty.sDhVTJEQ.css"
    ],
    "file": "empty.7jW9whiq.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "empty.sDhVTJEQ.css": {
    "file": "empty.sDhVTJEQ.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_flatten.2BRkJ_94.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "flatten.2BRkJ_94.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_friend.VoldwS30.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "friend.VoldwS30.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_hasIn.-H__E5zv.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "hasIn.-H__E5zv.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.!~{01c}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.BbVs9JM6.css",
    "src": "_index.!~{01c}~.js"
  },
  "_index.LjzXrPD3.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.LjzXrPD3.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.QGw_ZaYP.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.QGw_ZaYP.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.Vyu9vtT4.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.Vyu9vtT4.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.e4XjUoyZ.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.e4XjUoyZ.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.g588nUAn.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.g588nUAn.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ]
  },
  "_index.hRM60x37.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.BbVs9JM6.css"
    ],
    "file": "index.hRM60x37.js",
    "imports": [
      "_ElImage.N4HcXALN.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "index.BbVs9JM6.css": {
    "file": "index.BbVs9JM6.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_index.l0789WFd.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.l0789WFd.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.nOErYuRE.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.nOErYuRE.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.nfpRm3oW.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.nfpRm3oW.js",
    "imports": [
      "_popper.O9tQ7Dae.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.o6d2ZpWB.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.o6d2ZpWB.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.saMJatr7.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.saMJatr7.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_input-number.!~{01p}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "input-number.5AezeF1g.css",
    "src": "_input-number.!~{01p}~.js"
  },
  "_input-number.f60sKgNh.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "input-number.5AezeF1g.css"
    ],
    "file": "input-number.f60sKgNh.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.nOErYuRE.js"
    ]
  },
  "input-number.5AezeF1g.css": {
    "file": "input-number.5AezeF1g.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_isEqual.ouEoZz40.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "isEqual.ouEoZz40.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_isUndefined.IZwZ21d-.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "isUndefined.IZwZ21d-.js"
  },
  "_localeData._AXmWfIZ.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "localeData._AXmWfIZ.js",
    "imports": [
      "___commonjsHelpers__.1J56E-h6.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_logo_dark.pttUYYX3.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "popover.LAISAeEG.css"
    ],
    "dynamicImports": [
      "components/card/UserLine.vue"
    ],
    "file": "logo_dark.pttUYYX3.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.ziHOUCB7.js",
      "_scrollbar.5ezCorGI.js",
      "_index.nfpRm3oW.js",
      "_popper.O9tQ7Dae.js"
    ]
  },
  "_menu-item.!~{01O}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "menu-item.f0mNRiTD.css",
    "src": "_tooltip.!~{01I}~.js"
  },
  "_menu.!~{01N}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "menu.6YbFhd-D.css",
    "src": "_menu.!~{01N}~.js"
  },
  "_menu.540qzyOG.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "menu.6YbFhd-D.css"
    ],
    "file": "menu.540qzyOG.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.e4XjUoyZ.js",
      "_popper.O9tQ7Dae.js",
      "_index.LjzXrPD3.js"
    ]
  },
  "menu.6YbFhd-D.css": {
    "file": "menu.6YbFhd-D.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_notification.!~{00H}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "notification.8O_B6xHM.css",
    "src": "_notification.!~{00H}~.js"
  },
  "_notification.XBrm9l6C.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "notification.8O_B6xHM.css"
    ],
    "file": "notification.XBrm9l6C.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "notification.8O_B6xHM.css": {
    "file": "notification.8O_B6xHM.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_nuxt-link.ziHOUCB7.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "nuxt-link.ziHOUCB7.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_popover.!~{01i}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "popover.LAISAeEG.css",
    "src": "_popover.!~{01i}~.js"
  },
  "_popper.!~{00X}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "popper.nTJkgMH4.css",
    "src": "_popper.!~{00X}~.js"
  },
  "_popper.O9tQ7Dae.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "popper.nTJkgMH4.css"
    ],
    "file": "popper.O9tQ7Dae.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_isUndefined.IZwZ21d-.js"
    ]
  },
  "popper.nTJkgMH4.css": {
    "file": "popper.nTJkgMH4.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_post.Th7QFVpT.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "post.Th7QFVpT.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_progress.!~{011}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "progress.rXLlm_9F.css",
    "src": "_progress.!~{011}~.js"
  },
  "_progress.8HIBJk6c.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "progress.rXLlm_9F.css"
    ],
    "file": "progress.8HIBJk6c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "progress.rXLlm_9F.css": {
    "file": "progress.rXLlm_9F.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_radio-button.!~{012}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "radio-button.l7x146Nf.css",
    "src": "_radio-button.!~{012}~.js"
  },
  "_radio-group.!~{00M}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "radio-group.P_Xz2fNs.css",
    "src": "_radio-group.!~{00M}~.js"
  },
  "_radio.!~{00U}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "radio.eYTrrdr6.css",
    "src": "_radio.!~{00U}~.js"
  },
  "_rate.!~{01s}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "rate.mGuCO7Lx.css",
    "src": "_rate.!~{01s}~.js"
  },
  "_rate.eLQyL1yh.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "rate.mGuCO7Lx.css"
    ],
    "file": "rate.eLQyL1yh.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "rate.mGuCO7Lx.css": {
    "file": "rate.mGuCO7Lx.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_scrollbar.!~{00A}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "scrollbar.Smf0pYfu.css",
    "src": "_scrollbar.!~{00A}~.js"
  },
  "_scrollbar.5ezCorGI.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "scrollbar.Smf0pYfu.css"
    ],
    "file": "scrollbar.5ezCorGI.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "scrollbar.Smf0pYfu.css": {
    "file": "scrollbar.Smf0pYfu.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_select.!~{00V}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "select.xPRdjiL2.css",
    "src": "_select.!~{00V}~.js"
  },
  "_select.0vnI2MVe.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "select.xPRdjiL2.css"
    ],
    "file": "select.0vnI2MVe.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_popper.O9tQ7Dae.js",
      "_scrollbar.5ezCorGI.js",
      "_tag.cgGFhm6N.js",
      "_strings.qR0ln6qd.js",
      "_isEqual.ouEoZz40.js",
      "_debounce.FconTdz-.js",
      "_hasIn.-H__E5zv.js",
      "_index.LjzXrPD3.js"
    ]
  },
  "select.xPRdjiL2.css": {
    "file": "select.xPRdjiL2.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_sku.6LYkDpAc.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sku.6LYkDpAc.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_strings.qR0ln6qd.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "strings.qR0ln6qd.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_tabs.!~{015}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "tabs.H-UKPvku.css",
    "src": "_tabs.!~{015}~.js"
  },
  "_tabs.t1RgyD45.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "tabs.H-UKPvku.css"
    ],
    "file": "tabs.t1RgyD45.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_strings.qR0ln6qd.js",
      "_index.QGw_ZaYP.js"
    ]
  },
  "tabs.H-UKPvku.css": {
    "file": "tabs.H-UKPvku.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_tag.!~{00F}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "tag.Wo0upPQu.css",
    "src": "_tag.!~{00F}~.js"
  },
  "_tag.cgGFhm6N.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "tag.Wo0upPQu.css"
    ],
    "file": "tag.cgGFhm6N.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "tag.Wo0upPQu.css": {
    "file": "tag.Wo0upPQu.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_tooltip.!~{01I}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "menu-item.f0mNRiTD.css",
    "src": "_tooltip.!~{01I}~.js"
  },
  "_upload.!~{01x}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "upload.5r92S6hB.css",
    "src": "_upload.!~{01x}~.js"
  },
  "_upload.n0ZSCkUA.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "upload.5r92S6hB.css"
    ],
    "file": "upload.n0ZSCkUA.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_progress.8HIBJk6c.js",
      "_cloneDeep.yjpaYQ6s.js",
      "_isEqual.ouEoZz40.js"
    ]
  },
  "upload.5r92S6hB.css": {
    "file": "upload.5r92S6hB.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_useOrderStore.dJUSblpE.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useOrderStore.dJUSblpE.js",
    "imports": [
      "_index.l0789WFd.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_useWebToast.QrRLv6_O.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useWebToast.QrRLv6_O.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_useWs.tFUymKQj.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useWs.tFUymKQj.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_notification.XBrm9l6C.js"
    ]
  },
  "components/Chat/Friend/ApplyDialog.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ApplyDialog.PI1OVtfd.js",
    "imports": [
      "_ApplyDialog.vue.S3AUf9Ii.js",
      "node_modules/nuxt/dist/app/entry.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_dialog.jFAPlFAt.js",
      "_isUndefined.IZwZ21d-.js",
      "_notification.XBrm9l6C.js",
      "_friend.VoldwS30.js"
    ],
    "isDynamicEntry": true,
    "src": "components/Chat/Friend/ApplyDialog.vue"
  },
  "components/Chat/NewGroupDialog.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "NewGroupDialog.Hm5sbp8R.css",
      "checkbox-group.d5XbR8TY.css"
    ],
    "file": "NewGroupDialog.Z9Slu96Z.js",
    "imports": [
      "_ElImage.N4HcXALN.js",
      "_checkbox.INotFvCX.js",
      "_AutoIncre.vue.0Ch5nUxt.js",
      "_scrollbar.5ezCorGI.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_OssFileUpload.4LUV6w65.js",
      "_dialog.jFAPlFAt.js",
      "_notification.XBrm9l6C.js",
      "_contact.ng7D7NaS.js",
      "_Main.NWJvXKDl.js",
      "_friend.VoldwS30.js",
      "_debounce.FconTdz-.js",
      "_isEqual.ouEoZz40.js",
      "_hasIn.-H__E5zv.js",
      "_flatten.2BRkJ_94.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_progress.8HIBJk6c.js",
      "_index.g588nUAn.js",
      "_isUndefined.IZwZ21d-.js",
      "_useWs.tFUymKQj.js",
      "_tag.cgGFhm6N.js"
    ],
    "isDynamicEntry": true,
    "src": "components/Chat/NewGroupDialog.vue"
  },
  "NewGroupDialog.Hm5sbp8R.css": {
    "file": "NewGroupDialog.Hm5sbp8R.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "checkbox-group.d5XbR8TY.css": {
    "file": "checkbox-group.d5XbR8TY.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/Comm/PostList.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "PostList._i8MVHra.css"
    ],
    "file": "PostList.Z6h5dozj.js",
    "imports": [
      "_ElImage.N4HcXALN.js",
      "_nuxt-link.ziHOUCB7.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.cgGFhm6N.js",
      "_TagList.vue.Uo1KJ4jk.js",
      "_CommentPreview._X0no8e2.js",
      "_AutoIncre.vue.0Ch5nUxt.js",
      "_post.Th7QFVpT.js",
      "_debounce.FconTdz-.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_select.0vnI2MVe.js",
      "_popper.O9tQ7Dae.js",
      "_isUndefined.IZwZ21d-.js",
      "_scrollbar.5ezCorGI.js",
      "_strings.qR0ln6qd.js",
      "_isEqual.ouEoZz40.js",
      "_hasIn.-H__E5zv.js",
      "_index.LjzXrPD3.js",
      "_OssFileUpload.4LUV6w65.js",
      "_progress.8HIBJk6c.js",
      "_index.g588nUAn.js",
      "_notification.XBrm9l6C.js"
    ],
    "isDynamicEntry": true,
    "src": "components/Comm/PostList.vue"
  },
  "PostList._i8MVHra.css": {
    "file": "PostList._i8MVHra.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/Comm/post/CateGoryLine.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "CateGoryLine.LRjthLli.js",
    "imports": [
      "_ElImage.N4HcXALN.js",
      "_nuxt-link.ziHOUCB7.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_debounce.FconTdz-.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "components/Comm/post/CateGoryLine.vue"
  },
  "components/Comm/post/Rank.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "Rank.y3OSjSFp.css"
    ],
    "file": "Rank.GkXja9dR.js",
    "imports": [
      "_divider.SzSAruyT.js",
      "_tag.cgGFhm6N.js",
      "_ElImage.N4HcXALN.js",
      "_nuxt-link.ziHOUCB7.js",
      "_empty.7jW9whiq.js",
      "_scrollbar.5ezCorGI.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_post.Th7QFVpT.js",
      "_debounce.FconTdz-.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "components/Comm/post/Rank.vue"
  },
  "Rank.y3OSjSFp.css": {
    "file": "Rank.y3OSjSFp.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/card/UserLine.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "UserLine.G_lnDfVq.css",
      "popover.LAISAeEG.css"
    ],
    "file": "UserLine.5tkLkQdK.js",
    "imports": [
      "_avatar.F_eY8A6y.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_upload.n0ZSCkUA.js",
      "_nuxt-link.ziHOUCB7.js",
      "_index.nfpRm3oW.js",
      "_progress.8HIBJk6c.js",
      "_popper.O9tQ7Dae.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_cloneDeep.yjpaYQ6s.js",
      "_isEqual.ouEoZz40.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "components/card/UserLine.vue"
  },
  "UserLine.G_lnDfVq.css": {
    "file": "UserLine.G_lnDfVq.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/list/GoodsList.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "GoodsList.1p6fEF-7.css"
    ],
    "file": "GoodsList.SFBdyH5v.js",
    "imports": [
      "_index.hRM60x37.js",
      "_nuxt-link.ziHOUCB7.js",
      "_AutoIncre.vue.0Ch5nUxt.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.N4HcXALN.js",
      "_debounce.FconTdz-.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "components/list/GoodsList.vue"
  },
  "GoodsList.1p6fEF-7.css": {
    "file": "GoodsList.1p6fEF-7.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/menu/DrawerMenu.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "DrawerMenu.0ja6gThp.css",
      "menu-item.f0mNRiTD.css",
      "popover.LAISAeEG.css"
    ],
    "file": "DrawerMenu.g4XwAFWv.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_menu.540qzyOG.js",
      "_scrollbar.5ezCorGI.js",
      "_popper.O9tQ7Dae.js",
      "_logo_dark.pttUYYX3.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_index.e4XjUoyZ.js",
      "_index.LjzXrPD3.js",
      "_isUndefined.IZwZ21d-.js",
      "_nuxt-link.ziHOUCB7.js",
      "_index.nfpRm3oW.js"
    ],
    "isDynamicEntry": true,
    "src": "components/menu/DrawerMenu.vue"
  },
  "DrawerMenu.0ja6gThp.css": {
    "file": "DrawerMenu.0ja6gThp.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "menu-item.f0mNRiTD.css": {
    "file": "menu-item.f0mNRiTD.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/menu/RightButtons/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.Kxo_iM1u.css",
      "popover.LAISAeEG.css",
      "menu-item.f0mNRiTD.css"
    ],
    "dynamicImports": [
      "components/menu/ShopCartBar.vue"
    ],
    "file": "index.UxFY3Ykc.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.ziHOUCB7.js",
      "_Main.NWJvXKDl.js",
      "_scrollbar.5ezCorGI.js",
      "_ElImage.N4HcXALN.js",
      "_index.nfpRm3oW.js",
      "_popper.O9tQ7Dae.js",
      "_contact.ng7D7NaS.js",
      "_useWs.tFUymKQj.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_tag.cgGFhm6N.js",
      "_debounce.FconTdz-.js",
      "_isUndefined.IZwZ21d-.js",
      "_notification.XBrm9l6C.js"
    ],
    "isDynamicEntry": true,
    "src": "components/menu/RightButtons/index.vue"
  },
  "index.Kxo_iM1u.css": {
    "file": "index.Kxo_iM1u.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/menu/ShopCartBar.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "ShopCartBar.EsIq9V-V.css",
      "checkbox-group.d5XbR8TY.css",
      "popover.LAISAeEG.css"
    ],
    "file": "ShopCartBar.TafZ_ecG.js",
    "imports": [
      "_checkbox.INotFvCX.js",
      "_ShopLine.iMo2a7zT.js",
      "_AutoIncre.vue.0Ch5nUxt.js",
      "_scrollbar.5ezCorGI.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.nfpRm3oW.js",
      "_popper.O9tQ7Dae.js",
      "_useOrderStore.dJUSblpE.js",
      "_isEqual.ouEoZz40.js",
      "_hasIn.-H__E5zv.js",
      "_flatten.2BRkJ_94.js",
      "_ElImage.N4HcXALN.js",
      "_debounce.FconTdz-.js",
      "_nuxt-link.ziHOUCB7.js",
      "_select.0vnI2MVe.js",
      "_tag.cgGFhm6N.js",
      "_strings.qR0ln6qd.js",
      "_index.LjzXrPD3.js",
      "_input-number.f60sKgNh.js",
      "_index.nOErYuRE.js",
      "_sku.6LYkDpAc.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isUndefined.IZwZ21d-.js",
      "_index.l0789WFd.js"
    ],
    "isDynamicEntry": true,
    "src": "components/menu/ShopCartBar.vue"
  },
  "ShopCartBar.EsIq9V-V.css": {
    "file": "ShopCartBar.EsIq9V-V.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "layouts/chat.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "chat.REpaLqUH.css",
      "menu-item.f0mNRiTD.css",
      "popover.LAISAeEG.css"
    ],
    "dynamicImports": [
      "components/menu/RightButtons/index.vue"
    ],
    "file": "chat.RO4MV6K6.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.N4HcXALN.js",
      "components/card/UserLine.vue",
      "_menu.540qzyOG.js",
      "_popper.O9tQ7Dae.js",
      "_useWs.tFUymKQj.js",
      "_friend.VoldwS30.js",
      "_useWebToast.QrRLv6_O.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.FconTdz-.js",
      "_avatar.F_eY8A6y.js",
      "_upload.n0ZSCkUA.js",
      "_progress.8HIBJk6c.js",
      "_cloneDeep.yjpaYQ6s.js",
      "_isEqual.ouEoZz40.js",
      "_nuxt-link.ziHOUCB7.js",
      "_index.nfpRm3oW.js",
      "_index.e4XjUoyZ.js",
      "_index.LjzXrPD3.js",
      "_isUndefined.IZwZ21d-.js",
      "_notification.XBrm9l6C.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/chat.vue"
  },
  "chat.REpaLqUH.css": {
    "file": "chat.REpaLqUH.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "layouts/error.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "error.Fg3cAtGz.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/error.vue"
  },
  "layouts/main.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "popover.LAISAeEG.css",
      "menu-item.f0mNRiTD.css"
    ],
    "dynamicImports": [
      "components/menu/DrawerMenu.vue"
    ],
    "file": "main.XfCgom-h.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_Footer.3VViGyd7.js",
      "components/menu/RightButtons/index.vue",
      "___commonjsHelpers__.1J56E-h6.js",
      "_nuxt-link.ziHOUCB7.js",
      "_logo_dark.pttUYYX3.js",
      "_scrollbar.5ezCorGI.js",
      "_index.nfpRm3oW.js",
      "_popper.O9tQ7Dae.js",
      "_isUndefined.IZwZ21d-.js",
      "_Switch.zLKumwEf.js",
      "_Main.NWJvXKDl.js",
      "_contact.ng7D7NaS.js",
      "_useWs.tFUymKQj.js",
      "_notification.XBrm9l6C.js",
      "_ElImage.N4HcXALN.js",
      "_debounce.FconTdz-.js",
      "_tag.cgGFhm6N.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/main.vue"
  },
  "layouts/second.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "second.JqdAvVfB.css",
      "popover.LAISAeEG.css",
      "menu-item.f0mNRiTD.css"
    ],
    "file": "second.slxybCpK.js",
    "imports": [
      "_Footer.3VViGyd7.js",
      "components/menu/RightButtons/index.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.ziHOUCB7.js",
      "_logo_dark.pttUYYX3.js",
      "_scrollbar.5ezCorGI.js",
      "_index.nfpRm3oW.js",
      "_popper.O9tQ7Dae.js",
      "_isUndefined.IZwZ21d-.js",
      "_Switch.zLKumwEf.js",
      "_Main.NWJvXKDl.js",
      "_contact.ng7D7NaS.js",
      "_useWs.tFUymKQj.js",
      "_notification.XBrm9l6C.js",
      "_ElImage.N4HcXALN.js",
      "_debounce.FconTdz-.js",
      "_tag.cgGFhm6N.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/second.vue"
  },
  "second.JqdAvVfB.css": {
    "file": "second.JqdAvVfB.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "layouts/user.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "user.yAuj-VgQ.css",
      "menu-item.f0mNRiTD.css",
      "popover.LAISAeEG.css"
    ],
    "file": "user.ZXADyknj.js",
    "imports": [
      "_nuxt-link.ziHOUCB7.js",
      "_logo_dark.pttUYYX3.js",
      "_Switch.zLKumwEf.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_menu.540qzyOG.js",
      "_popper.O9tQ7Dae.js",
      "components/menu/RightButtons/index.vue",
      "_scrollbar.5ezCorGI.js",
      "_index.nfpRm3oW.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_index.e4XjUoyZ.js",
      "_index.LjzXrPD3.js",
      "_isUndefined.IZwZ21d-.js",
      "_Main.NWJvXKDl.js",
      "_contact.ng7D7NaS.js",
      "_useWs.tFUymKQj.js",
      "_notification.XBrm9l6C.js",
      "_ElImage.N4HcXALN.js",
      "_debounce.FconTdz-.js",
      "_tag.cgGFhm6N.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/user.vue"
  },
  "user.yAuj-VgQ.css": {
    "file": "user.yAuj-VgQ.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/element-plus/es/components/text/index.mjs": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.l5CC8IXT.css"
    ],
    "file": "index.W3piUF6r.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/element-plus/es/components/text/index.mjs"
  },
  "index.l5CC8IXT.css": {
    "file": "index.l5CC8IXT.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "entry.o9YI8Z1z.css"
    ],
    "dynamicImports": [
      "layouts/chat.vue",
      "layouts/error.vue",
      "layouts/main.vue",
      "layouts/second.vue",
      "layouts/user.vue",
      "node_modules/workbox-window/build/workbox-window.prod.es5.mjs"
    ],
    "file": "entry.JZpcxbrR.js",
    "imports": [
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js"
  },
  "entry.o9YI8Z1z.css": {
    "file": "entry.o9YI8Z1z.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/workbox-window/build/workbox-window.prod.es5.mjs": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "workbox-window.prod.es5.prqDwDSL.js",
    "isDynamicEntry": true,
    "src": "node_modules/workbox-window/build/workbox-window.prod.es5.mjs"
  },
  "pages/[...all].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_...all_.FBvM9bK2.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/[...all].vue"
  },
  "pages/chat/ai.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "ai.df74smAD.css"
    ],
    "file": "ai.FBlf3lVf.js",
    "imports": [
      "_Main.NWJvXKDl.js",
      "_scrollbar.5ezCorGI.js",
      "_ElImage.N4HcXALN.js",
      "_nuxt-link.ziHOUCB7.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_contact.ng7D7NaS.js",
      "_useWs.tFUymKQj.js",
      "_tag.cgGFhm6N.js",
      "_debounce.FconTdz-.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_notification.XBrm9l6C.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/chat/ai.vue"
  },
  "ai.df74smAD.css": {
    "file": "ai.df74smAD.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/chat/friend.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "friend.chnzZ23W.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "file": "friend.fBdW91bq.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.cgGFhm6N.js",
      "_ElImage.N4HcXALN.js",
      "_AutoIncre.vue.0Ch5nUxt.js",
      "_scrollbar.5ezCorGI.js",
      "_empty.7jW9whiq.js",
      "_friend.VoldwS30.js",
      "_index.o6d2ZpWB.js",
      "_contact.ng7D7NaS.js",
      "_useWs.tFUymKQj.js",
      "_notification.XBrm9l6C.js",
      "_divider.SzSAruyT.js",
      "_ApplyDialog.vue.S3AUf9Ii.js",
      "_index.saMJatr7.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.FconTdz-.js",
      "_dialog.jFAPlFAt.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/chat/friend.vue"
  },
  "friend.chnzZ23W.css": {
    "file": "friend.chnzZ23W.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "radio-group.P_Xz2fNs.css": {
    "file": "radio-group.P_Xz2fNs.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/chat/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.0vnPmkGu.css",
      "radio.eYTrrdr6.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "dynamicImports": [
      "components/Chat/NewGroupDialog.vue",
      "components/Chat/NewGroupDialog.vue",
      "components/Chat/Friend/ApplyDialog.vue"
    ],
    "file": "index._HgMTt3m.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.N4HcXALN.js",
      "_index.o6d2ZpWB.js",
      "_AutoIncre.vue.0Ch5nUxt.js",
      "_notification.XBrm9l6C.js",
      "_contact.ng7D7NaS.js",
      "_Main.NWJvXKDl.js",
      "_friend.VoldwS30.js",
      "_useWs.tFUymKQj.js",
      "_tag.cgGFhm6N.js",
      "_scrollbar.5ezCorGI.js",
      "_select.0vnI2MVe.js",
      "_OssFileUpload.4LUV6w65.js",
      "_nuxt-link.ziHOUCB7.js",
      "_popper.O9tQ7Dae.js",
      "_index.g588nUAn.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.FconTdz-.js",
      "_strings.qR0ln6qd.js",
      "_isEqual.ouEoZz40.js",
      "_hasIn.-H__E5zv.js",
      "_index.LjzXrPD3.js",
      "_progress.8HIBJk6c.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/chat/index.vue"
  },
  "index.0vnPmkGu.css": {
    "file": "index.0vnPmkGu.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "radio.eYTrrdr6.css": {
    "file": "radio.eYTrrdr6.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/chat/setting.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "setting.SSmFdXUR.css",
      "radio-button.l7x146Nf.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "file": "setting.RDYxn5S9.js",
    "imports": [
      "_divider.SzSAruyT.js",
      "_select.0vnI2MVe.js",
      "_index.o6d2ZpWB.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.cgGFhm6N.js",
      "_scrollbar.5ezCorGI.js",
      "_popper.O9tQ7Dae.js",
      "_notification.XBrm9l6C.js",
      "_strings.qR0ln6qd.js",
      "_isEqual.ouEoZz40.js",
      "_debounce.FconTdz-.js",
      "_hasIn.-H__E5zv.js",
      "_index.LjzXrPD3.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/chat/setting.vue"
  },
  "setting.SSmFdXUR.css": {
    "file": "setting.SSmFdXUR.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "radio-button.l7x146Nf.css": {
    "file": "radio-button.l7x146Nf.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/category/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "_id_.uLLhAsoU.css"
    ],
    "dynamicImports": [
      "components/Comm/post/Rank.vue"
    ],
    "file": "_id_.2mFoOfLm.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.N4HcXALN.js",
      "_CategoryTabs.lJlo84z7.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.FconTdz-.js",
      "_tabs.t1RgyD45.js",
      "_strings.qR0ln6qd.js",
      "_index.QGw_ZaYP.js",
      "components/Comm/PostList.vue",
      "_nuxt-link.ziHOUCB7.js",
      "_tag.cgGFhm6N.js",
      "_TagList.vue.Uo1KJ4jk.js",
      "_CommentPreview._X0no8e2.js",
      "_select.0vnI2MVe.js",
      "_popper.O9tQ7Dae.js",
      "_isUndefined.IZwZ21d-.js",
      "_scrollbar.5ezCorGI.js",
      "_isEqual.ouEoZz40.js",
      "_hasIn.-H__E5zv.js",
      "_index.LjzXrPD3.js",
      "_OssFileUpload.4LUV6w65.js",
      "_progress.8HIBJk6c.js",
      "_index.g588nUAn.js",
      "_AutoIncre.vue.0Ch5nUxt.js",
      "_notification.XBrm9l6C.js",
      "_post.Th7QFVpT.js",
      "components/list/GoodsList.vue",
      "_index.hRM60x37.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/category/[id].vue"
  },
  "_id_.uLLhAsoU.css": {
    "file": "_id_.uLLhAsoU.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/category/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.EaIT1GIC.css"
    ],
    "dynamicImports": [
      "components/Comm/post/Rank.vue"
    ],
    "file": "index.EvU2NzWT.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_CategoryTabs.lJlo84z7.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_tabs.t1RgyD45.js",
      "_strings.qR0ln6qd.js",
      "_index.QGw_ZaYP.js",
      "components/Comm/PostList.vue",
      "_ElImage.N4HcXALN.js",
      "_debounce.FconTdz-.js",
      "_nuxt-link.ziHOUCB7.js",
      "_tag.cgGFhm6N.js",
      "_TagList.vue.Uo1KJ4jk.js",
      "_CommentPreview._X0no8e2.js",
      "_select.0vnI2MVe.js",
      "_popper.O9tQ7Dae.js",
      "_isUndefined.IZwZ21d-.js",
      "_scrollbar.5ezCorGI.js",
      "_isEqual.ouEoZz40.js",
      "_hasIn.-H__E5zv.js",
      "_index.LjzXrPD3.js",
      "_OssFileUpload.4LUV6w65.js",
      "_progress.8HIBJk6c.js",
      "_index.g588nUAn.js",
      "_AutoIncre.vue.0Ch5nUxt.js",
      "_notification.XBrm9l6C.js",
      "_post.Th7QFVpT.js",
      "components/list/GoodsList.vue",
      "_index.hRM60x37.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/category/index.vue"
  },
  "index.EaIT1GIC.css": {
    "file": "index.EaIT1GIC.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/post/detail/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "_id_.8W7c6sq_.css",
      "popover.LAISAeEG.css"
    ],
    "dynamicImports": [
      "components/Comm/post/CateGoryLine.vue"
    ],
    "file": "_id_.8N3GhXnj.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.N4HcXALN.js",
      "_Switch.zLKumwEf.js",
      "_tag.cgGFhm6N.js",
      "_nuxt-link.ziHOUCB7.js",
      "_TagList.vue.Uo1KJ4jk.js",
      "_divider.SzSAruyT.js",
      "_post.Th7QFVpT.js",
      "_CommentPreview._X0no8e2.js",
      "_UserPostTotal.vue.KMzfEJqn.js",
      "_SigninCard.vue.NwgfYIns.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.FconTdz-.js",
      "_select.0vnI2MVe.js",
      "_popper.O9tQ7Dae.js",
      "_isUndefined.IZwZ21d-.js",
      "_scrollbar.5ezCorGI.js",
      "_strings.qR0ln6qd.js",
      "_isEqual.ouEoZz40.js",
      "_hasIn.-H__E5zv.js",
      "_index.LjzXrPD3.js",
      "_OssFileUpload.4LUV6w65.js",
      "_progress.8HIBJk6c.js",
      "_index.g588nUAn.js",
      "_AutoIncre.vue.0Ch5nUxt.js",
      "_notification.XBrm9l6C.js",
      "_index.nfpRm3oW.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/post/detail/[id].vue"
  },
  "_id_.8W7c6sq_.css": {
    "file": "_id_.8W7c6sq_.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/post/list.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "list.aADC_aru.css",
      "popover.LAISAeEG.css"
    ],
    "file": "list.T-8rQVWw.js",
    "imports": [
      "_nuxt-link.ziHOUCB7.js",
      "_tag.cgGFhm6N.js",
      "_create-shadow.1WkZ6EH9.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_effect-creative.HiJmGJ8F.js",
      "_post.Th7QFVpT.js",
      "_ElImage.N4HcXALN.js",
      "components/Comm/PostList.vue",
      "_tabs.t1RgyD45.js",
      "_SigninCard.vue.NwgfYIns.js",
      "components/Comm/post/Rank.vue",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.FconTdz-.js",
      "_TagList.vue.Uo1KJ4jk.js",
      "_CommentPreview._X0no8e2.js",
      "_select.0vnI2MVe.js",
      "_popper.O9tQ7Dae.js",
      "_isUndefined.IZwZ21d-.js",
      "_scrollbar.5ezCorGI.js",
      "_strings.qR0ln6qd.js",
      "_isEqual.ouEoZz40.js",
      "_hasIn.-H__E5zv.js",
      "_index.LjzXrPD3.js",
      "_OssFileUpload.4LUV6w65.js",
      "_progress.8HIBJk6c.js",
      "_index.g588nUAn.js",
      "_AutoIncre.vue.0Ch5nUxt.js",
      "_notification.XBrm9l6C.js",
      "_index.QGw_ZaYP.js",
      "_index.nfpRm3oW.js",
      "_divider.SzSAruyT.js",
      "_empty.7jW9whiq.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/post/list.vue"
  },
  "list.aADC_aru.css": {
    "file": "list.aADC_aru.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/post/new.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "new.9wZIBQf0.css",
      "radio-button.l7x146Nf.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "file": "new.5WYCFQPW.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_OssFileUpload.4LUV6w65.js",
      "_index.o6d2ZpWB.js",
      "_ElImage.N4HcXALN.js",
      "_select.0vnI2MVe.js",
      "_tag.cgGFhm6N.js",
      "_scrollbar.5ezCorGI.js",
      "_popper.O9tQ7Dae.js",
      "_notification.XBrm9l6C.js",
      "_index.g588nUAn.js",
      "_StatusTag.74ZF8UBX.js",
      "_post.Th7QFVpT.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_progress.8HIBJk6c.js",
      "_debounce.FconTdz-.js",
      "_strings.qR0ln6qd.js",
      "_isEqual.ouEoZz40.js",
      "_hasIn.-H__E5zv.js",
      "_index.LjzXrPD3.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/post/new.vue"
  },
  "new.9wZIBQf0.css": {
    "file": "new.9wZIBQf0.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/event/detail/[eid].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "_eid_.NtANQ6Xa.css"
    ],
    "file": "_eid_.4FNArSc5.js",
    "imports": [
      "_ElImage.N4HcXALN.js",
      "_tag.cgGFhm6N.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.ziHOUCB7.js",
      "_index.Vyu9vtT4.js",
      "_debounce.FconTdz-.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/event/detail/[eid].vue"
  },
  "_eid_.NtANQ6Xa.css": {
    "file": "_eid_.NtANQ6Xa.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/goods/comments/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_id_.8mNA836f.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/goods/comments/[id].vue"
  },
  "pages/goods/detail/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "_id_.spxRS6Bk.css",
      "popover.LAISAeEG.css",
      "radio-button.l7x146Nf.css",
      "radio-group.P_Xz2fNs.css",
      "radio.eYTrrdr6.css"
    ],
    "file": "_id_.Lt2AXA8q.js",
    "imports": [
      "_nuxt-link.ziHOUCB7.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_GoodsListSsr.E0c5bXBv.js",
      "_ElImage.N4HcXALN.js",
      "_index.QGw_ZaYP.js",
      "_scrollbar.5ezCorGI.js",
      "_tag.cgGFhm6N.js",
      "_popper.O9tQ7Dae.js",
      "_collect.e95C5X6X.js",
      "_index.o6d2ZpWB.js",
      "_input-number.f60sKgNh.js",
      "_useOrderStore.dJUSblpE.js",
      "_index.Vyu9vtT4.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_tabs.t1RgyD45.js",
      "_rate.eLQyL1yh.js",
      "_AutoIncre.vue.0Ch5nUxt.js",
      "_dialog.jFAPlFAt.js",
      "_index.e4XjUoyZ.js",
      "_index.hRM60x37.js",
      "_sku.6LYkDpAc.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.FconTdz-.js",
      "_isUndefined.IZwZ21d-.js",
      "_index.nOErYuRE.js",
      "_index.l0789WFd.js",
      "_strings.qR0ln6qd.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/goods/detail/[id].vue"
  },
  "_id_.spxRS6Bk.css": {
    "file": "_id_.spxRS6Bk.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.IfgpexZK.css",
      "popover.LAISAeEG.css"
    ],
    "dynamicImports": [
      "components/list/GoodsList.vue"
    ],
    "file": "index.L_GG57PS.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.cgGFhm6N.js",
      "_nuxt-link.ziHOUCB7.js",
      "_AutoIncre.vue.0Ch5nUxt.js",
      "_empty.7jW9whiq.js",
      "_scrollbar.5ezCorGI.js",
      "_index.nfpRm3oW.js",
      "_popper.O9tQ7Dae.js",
      "_index.hRM60x37.js",
      "_create-shadow.1WkZ6EH9.js",
      "_effect-creative.HiJmGJ8F.js",
      "_index.Vyu9vtT4.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_GoodsListSsr.E0c5bXBv.js",
      "_tabs.t1RgyD45.js",
      "_ElImage.N4HcXALN.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isUndefined.IZwZ21d-.js",
      "_strings.qR0ln6qd.js",
      "_index.QGw_ZaYP.js",
      "_debounce.FconTdz-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.IfgpexZK.css": {
    "file": "index.IfgpexZK.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/order/comment/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "_id_.65PfMBS2.css"
    ],
    "file": "_id_.rrinI-Ho.js",
    "imports": [
      "_Switch.zLKumwEf.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_progress.8HIBJk6c.js",
      "_upload.n0ZSCkUA.js",
      "_dialog.jFAPlFAt.js",
      "_index.g588nUAn.js",
      "_ElImage.N4HcXALN.js",
      "_rate.eLQyL1yh.js",
      "_checkbox.INotFvCX.js",
      "_nuxt-link.ziHOUCB7.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_notification.XBrm9l6C.js",
      "_index.l0789WFd.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_cloneDeep.yjpaYQ6s.js",
      "_isEqual.ouEoZz40.js",
      "_isUndefined.IZwZ21d-.js",
      "_debounce.FconTdz-.js",
      "_hasIn.-H__E5zv.js",
      "_flatten.2BRkJ_94.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/order/comment/[id].vue"
  },
  "_id_.65PfMBS2.css": {
    "file": "_id_.65PfMBS2.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/order/detail.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "detail.Zq1m3l4e.css",
      "radio.eYTrrdr6.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "dynamicImports": [
      "node_modules/element-plus/es/components/text/index.mjs"
    ],
    "file": "detail.2oB74-Ee.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.N4HcXALN.js",
      "_nuxt-link.ziHOUCB7.js",
      "_divider.SzSAruyT.js",
      "_DelayTimer.vue.iY8Lf6xU.js",
      "_Switch.zLKumwEf.js",
      "_index.QGw_ZaYP.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_bills.ggSo-lLQ.js",
      "_index.l0789WFd.js",
      "_useOrderStore.dJUSblpE.js",
      "_index.o6d2ZpWB.js",
      "_tag.cgGFhm6N.js",
      "_scrollbar.5ezCorGI.js",
      "_select.0vnI2MVe.js",
      "_input-number.f60sKgNh.js",
      "_popper.O9tQ7Dae.js",
      "_index.Vyu9vtT4.js",
      "_sku.6LYkDpAc.js",
      "_empty.7jW9whiq.js",
      "_notification.XBrm9l6C.js",
      "_useWebToast.QrRLv6_O.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.FconTdz-.js",
      "_strings.qR0ln6qd.js",
      "_isEqual.ouEoZz40.js",
      "_hasIn.-H__E5zv.js",
      "_index.LjzXrPD3.js",
      "_index.nOErYuRE.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/order/detail.vue"
  },
  "detail.Zq1m3l4e.css": {
    "file": "detail.Zq1m3l4e.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/order/list.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "list.pKmG3IwD.css"
    ],
    "file": "list.Pq7D0s-e.js",
    "imports": [
      "_divider.SzSAruyT.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_date-picker.FrErj8Du.js",
      "_DelayTimer.vue.iY8Lf6xU.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_ElImage.N4HcXALN.js",
      "_tag.cgGFhm6N.js",
      "_useOrderStore.dJUSblpE.js",
      "_index.l0789WFd.js",
      "_AutoIncre.vue.0Ch5nUxt.js",
      "_scrollbar.5ezCorGI.js",
      "_popper.O9tQ7Dae.js",
      "_notification.XBrm9l6C.js",
      "_tabs.t1RgyD45.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_localeData._AXmWfIZ.js",
      "_arrays.9GuX8ZvT.js",
      "_flatten.2BRkJ_94.js",
      "_index.nOErYuRE.js",
      "_debounce.FconTdz-.js",
      "_index.LjzXrPD3.js",
      "_isEqual.ouEoZz40.js",
      "_isUndefined.IZwZ21d-.js",
      "_strings.qR0ln6qd.js",
      "_index.QGw_ZaYP.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/order/list.vue"
  },
  "list.pKmG3IwD.css": {
    "file": "list.pKmG3IwD.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/search/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.avLsXlFQ.css"
    ],
    "dynamicImports": [
      "components/list/GoodsList.vue",
      "components/Comm/PostList.vue"
    ],
    "file": "index.jSwWNUsG.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_checkbox.INotFvCX.js",
      "_select.0vnI2MVe.js",
      "_tag.cgGFhm6N.js",
      "_tabs.t1RgyD45.js",
      "_empty.7jW9whiq.js",
      "_scrollbar.5ezCorGI.js",
      "_popper.O9tQ7Dae.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isEqual.ouEoZz40.js",
      "_hasIn.-H__E5zv.js",
      "_flatten.2BRkJ_94.js",
      "_strings.qR0ln6qd.js",
      "_debounce.FconTdz-.js",
      "_index.LjzXrPD3.js",
      "_index.QGw_ZaYP.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/search/index.vue"
  },
  "index.avLsXlFQ.css": {
    "file": "index.avLsXlFQ.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/setting/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.z1SuaKix.css",
      "radio-button.l7x146Nf.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "file": "index.ymrtNf4J.js",
    "imports": [
      "_divider.SzSAruyT.js",
      "_select.0vnI2MVe.js",
      "_index.o6d2ZpWB.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.cgGFhm6N.js",
      "_scrollbar.5ezCorGI.js",
      "_popper.O9tQ7Dae.js",
      "_notification.XBrm9l6C.js",
      "_strings.qR0ln6qd.js",
      "_isEqual.ouEoZz40.js",
      "_debounce.FconTdz-.js",
      "_hasIn.-H__E5zv.js",
      "_index.LjzXrPD3.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/setting/index.vue"
  },
  "index.z1SuaKix.css": {
    "file": "index.z1SuaKix.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/address.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "address.RlqThWjN.css",
      "radio.eYTrrdr6.css",
      "checkbox-group.d5XbR8TY.css"
    ],
    "file": "address.V7qSD9lT.js",
    "imports": [
      "node_modules/element-plus/es/components/text/index.mjs",
      "node_modules/nuxt/dist/app/entry.js",
      "_scrollbar.5ezCorGI.js",
      "_checkbox.INotFvCX.js",
      "_index.o6d2ZpWB.js",
      "_strings.qR0ln6qd.js",
      "_isEqual.ouEoZz40.js",
      "_arrays.9GuX8ZvT.js",
      "_flatten.2BRkJ_94.js",
      "_cloneDeep.yjpaYQ6s.js",
      "_popper.O9tQ7Dae.js",
      "_tag.cgGFhm6N.js",
      "_index.LjzXrPD3.js",
      "_debounce.FconTdz-.js",
      "_dialog.jFAPlFAt.js",
      "_divider.SzSAruyT.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_hasIn.-H__E5zv.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/address.vue"
  },
  "address.RlqThWjN.css": {
    "file": "address.RlqThWjN.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/collect.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "collect.4jK4CO3w.css",
      "checkbox-group.d5XbR8TY.css"
    ],
    "file": "collect.VNmeaeBy.js",
    "imports": [
      "_divider.SzSAruyT.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_checkbox.INotFvCX.js",
      "_ElImage.N4HcXALN.js",
      "_scrollbar.5ezCorGI.js",
      "_collect.e95C5X6X.js",
      "_tabs.t1RgyD45.js",
      "_tag.cgGFhm6N.js",
      "_nuxt-link.ziHOUCB7.js",
      "_TagList.vue.Uo1KJ4jk.js",
      "_AutoIncre.vue.0Ch5nUxt.js",
      "_post.Th7QFVpT.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isEqual.ouEoZz40.js",
      "_hasIn.-H__E5zv.js",
      "_flatten.2BRkJ_94.js",
      "_debounce.FconTdz-.js",
      "_strings.qR0ln6qd.js",
      "_index.QGw_ZaYP.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/collect.vue"
  },
  "collect.4jK4CO3w.css": {
    "file": "collect.4jK4CO3w.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/info.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "info.ZO--Iv68.css",
      "popover.LAISAeEG.css",
      "menu-item.f0mNRiTD.css"
    ],
    "file": "info.ZMql62qA.js",
    "imports": [
      "_ElImage.N4HcXALN.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.nfpRm3oW.js",
      "_popper.O9tQ7Dae.js",
      "_upload.n0ZSCkUA.js",
      "_date-picker.FrErj8Du.js",
      "_select.0vnI2MVe.js",
      "_progress.8HIBJk6c.js",
      "_scrollbar.5ezCorGI.js",
      "_tag.cgGFhm6N.js",
      "_nuxt-link.ziHOUCB7.js",
      "_TagList.vue.Uo1KJ4jk.js",
      "_AutoIncre.vue.0Ch5nUxt.js",
      "_post.Th7QFVpT.js",
      "_tabs.t1RgyD45.js",
      "_UserPostTotal.vue.KMzfEJqn.js",
      "_SigninCard.vue.NwgfYIns.js",
      "_index.saMJatr7.js",
      "_debounce.FconTdz-.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isUndefined.IZwZ21d-.js",
      "_cloneDeep.yjpaYQ6s.js",
      "_isEqual.ouEoZz40.js",
      "_localeData._AXmWfIZ.js",
      "_arrays.9GuX8ZvT.js",
      "_flatten.2BRkJ_94.js",
      "_index.nOErYuRE.js",
      "_index.LjzXrPD3.js",
      "_strings.qR0ln6qd.js",
      "_hasIn.-H__E5zv.js",
      "_index.QGw_ZaYP.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/info.vue"
  },
  "info.ZO--Iv68.css": {
    "file": "info.ZO--Iv68.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/post.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "post.yVQn8Ib0.css"
    ],
    "file": "post.bxVAvgI1.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.N4HcXALN.js",
      "_select.0vnI2MVe.js",
      "_tag.cgGFhm6N.js",
      "_scrollbar.5ezCorGI.js",
      "_popper.O9tQ7Dae.js",
      "_StatusTag.74ZF8UBX.js",
      "_nuxt-link.ziHOUCB7.js",
      "_TagList.vue.Uo1KJ4jk.js",
      "_post.Th7QFVpT.js",
      "_AutoIncre.vue.0Ch5nUxt.js",
      "_notification.XBrm9l6C.js",
      "_tabs.t1RgyD45.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.FconTdz-.js",
      "_strings.qR0ln6qd.js",
      "_isEqual.ouEoZz40.js",
      "_hasIn.-H__E5zv.js",
      "_index.LjzXrPD3.js",
      "_isUndefined.IZwZ21d-.js",
      "_index.QGw_ZaYP.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/post.vue"
  },
  "post.yVQn8Ib0.css": {
    "file": "post.yVQn8Ib0.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/safe.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "safe.73roRH3g.css"
    ],
    "file": "safe.cByssS2X.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.cgGFhm6N.js",
      "_scrollbar.5ezCorGI.js",
      "_avatar.F_eY8A6y.js",
      "_divider.SzSAruyT.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_useOrderStore.dJUSblpE.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_index.l0789WFd.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/safe.vue"
  },
  "safe.73roRH3g.css": {
    "file": "safe.73roRH3g.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/shopcart.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "shopcart.T7K9gx-c.css",
      "checkbox-group.d5XbR8TY.css"
    ],
    "file": "shopcart.FYaMBWFW.js",
    "imports": [
      "_checkbox.INotFvCX.js",
      "_ShopLine.iMo2a7zT.js",
      "_nuxt-link.ziHOUCB7.js",
      "_AutoIncre.vue.0Ch5nUxt.js",
      "_scrollbar.5ezCorGI.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useOrderStore.dJUSblpE.js",
      "_isEqual.ouEoZz40.js",
      "_hasIn.-H__E5zv.js",
      "_flatten.2BRkJ_94.js",
      "_ElImage.N4HcXALN.js",
      "_debounce.FconTdz-.js",
      "_select.0vnI2MVe.js",
      "_popper.O9tQ7Dae.js",
      "_isUndefined.IZwZ21d-.js",
      "_tag.cgGFhm6N.js",
      "_strings.qR0ln6qd.js",
      "_index.LjzXrPD3.js",
      "_input-number.f60sKgNh.js",
      "_index.nOErYuRE.js",
      "_sku.6LYkDpAc.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_index.l0789WFd.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/shopcart.vue"
  },
  "shopcart.T7K9gx-c.css": {
    "file": "shopcart.T7K9gx-c.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/wallet.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "wallet.JgZZuLIl.css",
      "popover.LAISAeEG.css"
    ],
    "file": "wallet.khiwQ_DU.js",
    "imports": [
      "node_modules/element-plus/es/components/text/index.mjs",
      "node_modules/nuxt/dist/app/entry.js",
      "_create-shadow.1WkZ6EH9.js",
      "_progress.8HIBJk6c.js",
      "_index.nfpRm3oW.js",
      "_popper.O9tQ7Dae.js",
      "_bills.ggSo-lLQ.js",
      "_scrollbar.5ezCorGI.js",
      "_input-number.f60sKgNh.js",
      "_select.0vnI2MVe.js",
      "_tag.cgGFhm6N.js",
      "_localeData._AXmWfIZ.js",
      "_divider.SzSAruyT.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isUndefined.IZwZ21d-.js",
      "_index.nOErYuRE.js",
      "_strings.qR0ln6qd.js",
      "_isEqual.ouEoZz40.js",
      "_debounce.FconTdz-.js",
      "_hasIn.-H__E5zv.js",
      "_index.LjzXrPD3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/wallet.vue"
  },
  "wallet.JgZZuLIl.css": {
    "file": "wallet.JgZZuLIl.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
