const client_manifest = {
  "_ApplyDialog.vue.pC2t2WC3.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ApplyDialog.vue.pC2t2WC3.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_dialog.w6rBusy-.js",
      "_notification.FURaEZ0O.js",
      "_friend.K97Fn_tH.js"
    ]
  },
  "_AutoIncre.vue.hHhgvjPp.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "AutoIncre.vue.hHhgvjPp.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_CategoryTabs.!~{014}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "CategoryTabs.787nBCiN.css",
    "src": "_CategoryTabs.!~{014}~.js"
  },
  "_CategoryTabs.UJhFUFEg.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "CategoryTabs.UJhFUFEg.js",
    "imports": [
      "_tabs.2ktlM5to.js",
      "node_modules/nuxt/dist/app/entry.js",
      "components/Comm/PostList.vue",
      "components/list/GoodsList.vue"
    ],
    "css": [
      "CategoryTabs.787nBCiN.css"
    ]
  },
  "CategoryTabs.787nBCiN.css": {
    "file": "CategoryTabs.787nBCiN.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_CommentPreview.!~{019}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "CommentPreview.GjCmskTw.css",
    "src": "_CommentPreview.!~{019}~.js"
  },
  "_CommentPreview.wGHQvKEF.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "CommentPreview.wGHQvKEF.js",
    "imports": [
      "_ElImage.T2cl7jzi.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_select.1Rc1zILe.js",
      "_OssFileUpload.oYHTXXfM.js",
      "_nuxt-link.G8oUHrJE.js",
      "_tag.TD0iuaSf.js",
      "_AutoIncre.vue.hHhgvjPp.js",
      "_scrollbar.FcbrmRKP.js",
      "_popper.72A3ygos.js",
      "_notification.FURaEZ0O.js"
    ],
    "css": [
      "CommentPreview.GjCmskTw.css"
    ]
  },
  "CommentPreview.GjCmskTw.css": {
    "file": "CommentPreview.GjCmskTw.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_DelayTimer.vue.Wws7-X5Y.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "DelayTimer.vue.Wws7-X5Y.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_ElImage.!~{00B}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "ElImage.6ybrNKBL.css",
    "src": "_ElImage.!~{00B}~.js"
  },
  "_ElImage.T2cl7jzi.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ElImage.T2cl7jzi.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_debounce.Dgmvm5TF.js"
    ],
    "css": [
      "ElImage.6ybrNKBL.css"
    ]
  },
  "ElImage.6ybrNKBL.css": {
    "file": "ElImage.6ybrNKBL.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_Footer.!~{01Q}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Footer._4VSJBz3.css",
    "src": "_Footer.!~{01Q}~.js"
  },
  "_Footer.YxJa2VF1.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Footer.YxJa2VF1.js",
    "imports": [
      "_nuxt-link.G8oUHrJE.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_logo_dark.0K5wPclg.js",
      "_Switch.CZmtGS0o.js"
    ],
    "css": [
      "Footer._4VSJBz3.css"
    ]
  },
  "Footer._4VSJBz3.css": {
    "file": "Footer._4VSJBz3.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_GoodsListSsr.!~{01n}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "GoodsListSsr.P5hBZBtk.css",
    "src": "_GoodsListSsr.!~{01n}~.js"
  },
  "_GoodsListSsr.c7NL1Faq.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "GoodsListSsr.c7NL1Faq.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.B8GdQimC.js",
      "_nuxt-link.G8oUHrJE.js",
      "node_modules/element-plus/es/components/text/index.mjs"
    ],
    "css": [
      "GoodsListSsr.P5hBZBtk.css"
    ]
  },
  "GoodsListSsr.P5hBZBtk.css": {
    "file": "GoodsListSsr.P5hBZBtk.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_Main.!~{00z}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Main.SJ5yTJq1.css",
    "src": "_Main.!~{00z}~.js"
  },
  "_Main.-16TCjWV.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Main.-16TCjWV.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_contact.BPR6dLYg.js",
      "_ElImage.T2cl7jzi.js"
    ],
    "css": [
      "Main.SJ5yTJq1.css"
    ]
  },
  "Main.SJ5yTJq1.css": {
    "file": "Main.SJ5yTJq1.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_OssFileUpload.!~{00W}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "OssFileUpload.f4DKzIfB.css",
    "src": "_OssFileUpload.!~{00W}~.js"
  },
  "_OssFileUpload.oYHTXXfM.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "OssFileUpload.oYHTXXfM.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.T2cl7jzi.js",
      "_progress.VtWhLZu1.js",
      "_index.xU0rlrWx.js"
    ],
    "css": [
      "OssFileUpload.f4DKzIfB.css"
    ]
  },
  "OssFileUpload.f4DKzIfB.css": {
    "file": "OssFileUpload.f4DKzIfB.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_ShopLine.!~{01K}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "ShopLine.Wq74ulT-.css",
    "src": "_ShopLine.!~{01K}~.js"
  },
  "_ShopLine.F2HhGUcV.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ShopLine.F2HhGUcV.js",
    "imports": [
      "_ElImage.T2cl7jzi.js",
      "_nuxt-link.G8oUHrJE.js",
      "_select.1Rc1zILe.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_input-number._E5Hn-el.js",
      "_tag.TD0iuaSf.js",
      "_scrollbar.FcbrmRKP.js",
      "_popper.72A3ygos.js",
      "_sku.F2j30h1k.js"
    ],
    "css": [
      "ShopLine.Wq74ulT-.css"
    ]
  },
  "ShopLine.Wq74ulT-.css": {
    "file": "ShopLine.Wq74ulT-.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_SigninCard.vue.IjuYXXgQ.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "SigninCard.vue.IjuYXXgQ.js",
    "imports": [
      "_progress.VtWhLZu1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.4EwzueT5.js",
      "_popper.72A3ygos.js"
    ],
    "css": [
      "popover.LAISAeEG.css"
    ]
  },
  "popover.LAISAeEG.css": {
    "file": "popover.LAISAeEG.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_StatusTag.!~{01l}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "StatusTag.IETAoY75.css",
    "src": "_StatusTag.!~{01l}~.js"
  },
  "_StatusTag.Y3cZLxU7.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "StatusTag.Y3cZLxU7.js",
    "imports": [
      "_tag.TD0iuaSf.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_post.QhbummqR.js"
    ],
    "css": [
      "StatusTag.IETAoY75.css"
    ]
  },
  "StatusTag.IETAoY75.css": {
    "file": "StatusTag.IETAoY75.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_Switch.!~{01e}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Switch.6FgKIDc6.css",
    "src": "_Switch.!~{01e}~.js"
  },
  "_Switch.CZmtGS0o.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Switch.CZmtGS0o.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "css": [
      "Switch.6FgKIDc6.css"
    ]
  },
  "Switch.6FgKIDc6.css": {
    "file": "Switch.6FgKIDc6.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_TagList.vue.7jDQq1xn.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TagList.vue.7jDQq1xn.js",
    "imports": [
      "_tag.TD0iuaSf.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_UserPostTotal.vue.sWxlRbTe.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "UserPostTotal.vue.sWxlRbTe.js",
    "imports": [
      "_ElImage.T2cl7jzi.js",
      "_nuxt-link.G8oUHrJE.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_post.QhbummqR.js"
    ]
  },
  "___commonjsHelpers__.1J56E-h6.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "__commonjsHelpers__.1J56E-h6.js"
  },
  "_arrays.9GuX8ZvT.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "arrays.9GuX8ZvT.js"
  },
  "_avatar.!~{01J}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "avatar.bZH1-Oig.css",
    "src": "_avatar.!~{01J}~.js"
  },
  "_avatar.h7eUm_b0.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "avatar.h7eUm_b0.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "css": [
      "avatar.bZH1-Oig.css"
    ]
  },
  "avatar.bZH1-Oig.css": {
    "file": "avatar.bZH1-Oig.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_bills.MF30gBNx.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "bills.MF30gBNx.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_checkbox-group.!~{01H}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "checkbox-group.d5XbR8TY.css",
    "src": "_checkbox-group.!~{01H}~.js"
  },
  "_checkbox.!~{01y}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "checkbox.MJHvI1xB.css",
    "src": "_checkbox.!~{01y}~.js"
  },
  "_checkbox.htTWQyb9.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "checkbox.htTWQyb9.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_isEqual.L9QjCfx8.js",
      "_hasIn.hJzZptBh.js",
      "_flatten.wqv5xcaQ.js"
    ],
    "css": [
      "checkbox.MJHvI1xB.css"
    ]
  },
  "checkbox.MJHvI1xB.css": {
    "file": "checkbox.MJHvI1xB.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_cloneDeep.r2YMfIBN.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "cloneDeep.r2YMfIBN.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_collect.dw9HzQRZ.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "collect.dw9HzQRZ.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_contact.BPR6dLYg.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "contact.BPR6dLYg.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_useWs.VWW8hc49.js"
    ]
  },
  "_create-shadow.mAugYdYc.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "create-shadow.mAugYdYc.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_date-picker.!~{01E}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "date-picker.sSkDKlix.css",
    "src": "_date-picker.!~{01E}~.js"
  },
  "_date-picker.MdIIfGcX.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "date-picker.MdIIfGcX.js",
    "imports": [
      "_localeData.ktyBOuRZ.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_arrays.9GuX8ZvT.js",
      "_flatten.wqv5xcaQ.js",
      "_popper.72A3ygos.js",
      "_scrollbar.FcbrmRKP.js",
      "_index.lvubdVY-.js",
      "_debounce.Dgmvm5TF.js",
      "_index.AN-d_JvZ.js",
      "_isEqual.L9QjCfx8.js"
    ],
    "css": [
      "date-picker.sSkDKlix.css"
    ]
  },
  "date-picker.sSkDKlix.css": {
    "file": "date-picker.sSkDKlix.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_debounce.Dgmvm5TF.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "debounce.Dgmvm5TF.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_dialog.!~{00Q}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "dialog.mDs1vky2.css",
    "src": "_dialog.!~{00Q}~.js"
  },
  "_dialog.w6rBusy-.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "dialog.w6rBusy-.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "css": [
      "dialog.mDs1vky2.css"
    ]
  },
  "dialog.mDs1vky2.css": {
    "file": "dialog.mDs1vky2.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_divider.!~{00N}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "divider.mvCfgREV.css",
    "src": "_divider.!~{00N}~.js"
  },
  "_divider.ozohExRg.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "divider.ozohExRg.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "css": [
      "divider.mvCfgREV.css"
    ]
  },
  "divider.mvCfgREV.css": {
    "file": "divider.mvCfgREV.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_effect-creative.oyW6_KqW.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "effect-creative.oyW6_KqW.js",
    "imports": [
      "_create-shadow.mAugYdYc.js"
    ]
  },
  "_empty.!~{00J}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "empty.sDhVTJEQ.css",
    "src": "_empty.!~{00J}~.js"
  },
  "_empty._rLIWHHD.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "empty._rLIWHHD.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "css": [
      "empty.sDhVTJEQ.css"
    ]
  },
  "empty.sDhVTJEQ.css": {
    "file": "empty.sDhVTJEQ.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_flatten.wqv5xcaQ.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "flatten.wqv5xcaQ.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_friend.K97Fn_tH.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "friend.K97Fn_tH.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_hasIn.hJzZptBh.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "hasIn.hJzZptBh.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.!~{01c}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.BbVs9JM6.css",
    "src": "_index.!~{01c}~.js"
  },
  "_index.4EwzueT5.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.4EwzueT5.js",
    "imports": [
      "_popper.72A3ygos.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.AN-d_JvZ.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.AN-d_JvZ.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.B8GdQimC.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.B8GdQimC.js",
    "imports": [
      "_ElImage.T2cl7jzi.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "css": [
      "index.BbVs9JM6.css"
    ]
  },
  "index.BbVs9JM6.css": {
    "file": "index.BbVs9JM6.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_index.FNQXNVm4.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.FNQXNVm4.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.Qmhohhe7.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.Qmhohhe7.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.hhBNrJZ-.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.hhBNrJZ-.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.inpxOwzP.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.inpxOwzP.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.jas4pLjK.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.jas4pLjK.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.lvubdVY-.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.lvubdVY-.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.vp3IuNfq.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.vp3IuNfq.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.xU0rlrWx.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.xU0rlrWx.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ]
  },
  "_input-number.!~{01p}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "input-number.5AezeF1g.css",
    "src": "_input-number.!~{01p}~.js"
  },
  "_input-number._E5Hn-el.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "input-number._E5Hn-el.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.lvubdVY-.js"
    ],
    "css": [
      "input-number.5AezeF1g.css"
    ]
  },
  "input-number.5AezeF1g.css": {
    "file": "input-number.5AezeF1g.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_isEqual.L9QjCfx8.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "isEqual.L9QjCfx8.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_isUndefined.IZwZ21d-.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "isUndefined.IZwZ21d-.js"
  },
  "_localeData.ktyBOuRZ.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "localeData.ktyBOuRZ.js",
    "imports": [
      "___commonjsHelpers__.1J56E-h6.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_logo_dark.0K5wPclg.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "logo_dark.0K5wPclg.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.G8oUHrJE.js",
      "_scrollbar.FcbrmRKP.js",
      "_index.4EwzueT5.js",
      "_popper.72A3ygos.js"
    ],
    "dynamicImports": [
      "components/card/UserLine.vue"
    ],
    "css": [
      "popover.LAISAeEG.css"
    ]
  },
  "_menu-item.!~{01O}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "menu-item.f0mNRiTD.css",
    "src": "_tooltip.!~{01I}~.js"
  },
  "_menu.!~{01N}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "menu.6YbFhd-D.css",
    "src": "_menu.!~{01N}~.js"
  },
  "_menu.KYanD88r.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "menu.KYanD88r.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.hhBNrJZ-.js",
      "_popper.72A3ygos.js",
      "_index.AN-d_JvZ.js"
    ],
    "css": [
      "menu.6YbFhd-D.css"
    ]
  },
  "menu.6YbFhd-D.css": {
    "file": "menu.6YbFhd-D.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_notification.!~{00G}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "notification.8O_B6xHM.css",
    "src": "_notification.!~{00G}~.js"
  },
  "_notification.FURaEZ0O.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "notification.FURaEZ0O.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "css": [
      "notification.8O_B6xHM.css"
    ]
  },
  "notification.8O_B6xHM.css": {
    "file": "notification.8O_B6xHM.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_nuxt-link.G8oUHrJE.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "nuxt-link.G8oUHrJE.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_popover.!~{01i}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "popover.LAISAeEG.css",
    "src": "_popover.!~{01i}~.js"
  },
  "_popper.!~{00X}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "popper.nTJkgMH4.css",
    "src": "_popper.!~{00X}~.js"
  },
  "_popper.72A3ygos.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "popper.72A3ygos.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "css": [
      "popper.nTJkgMH4.css"
    ]
  },
  "popper.nTJkgMH4.css": {
    "file": "popper.nTJkgMH4.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_post.QhbummqR.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "post.QhbummqR.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_progress.!~{011}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "progress.rXLlm_9F.css",
    "src": "_progress.!~{011}~.js"
  },
  "_progress.VtWhLZu1.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "progress.VtWhLZu1.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "css": [
      "progress.rXLlm_9F.css"
    ]
  },
  "progress.rXLlm_9F.css": {
    "file": "progress.rXLlm_9F.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_radio-button.!~{012}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "radio-button.l7x146Nf.css",
    "src": "_radio-button.!~{012}~.js"
  },
  "_radio-group.!~{00M}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "radio-group.P_Xz2fNs.css",
    "src": "_radio-group.!~{00M}~.js"
  },
  "_radio.!~{00U}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "radio.eYTrrdr6.css",
    "src": "_radio.!~{00U}~.js"
  },
  "_rate.!~{01s}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "rate.mGuCO7Lx.css",
    "src": "_rate.!~{01s}~.js"
  },
  "_rate.UnbeKbPm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "rate.UnbeKbPm.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "css": [
      "rate.mGuCO7Lx.css"
    ]
  },
  "rate.mGuCO7Lx.css": {
    "file": "rate.mGuCO7Lx.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_scrollbar.!~{00A}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "scrollbar.Smf0pYfu.css",
    "src": "_scrollbar.!~{00A}~.js"
  },
  "_scrollbar.FcbrmRKP.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "scrollbar.FcbrmRKP.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "css": [
      "scrollbar.Smf0pYfu.css"
    ]
  },
  "scrollbar.Smf0pYfu.css": {
    "file": "scrollbar.Smf0pYfu.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_select.!~{00V}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "select.xPRdjiL2.css",
    "src": "_select.!~{00V}~.js"
  },
  "_select.1Rc1zILe.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "select.1Rc1zILe.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_popper.72A3ygos.js",
      "_scrollbar.FcbrmRKP.js",
      "_tag.TD0iuaSf.js",
      "_strings.X5TzmLDs.js",
      "_isEqual.L9QjCfx8.js",
      "_debounce.Dgmvm5TF.js",
      "_hasIn.hJzZptBh.js",
      "_index.AN-d_JvZ.js"
    ],
    "css": [
      "select.xPRdjiL2.css"
    ]
  },
  "select.xPRdjiL2.css": {
    "file": "select.xPRdjiL2.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_sku.F2j30h1k.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sku.F2j30h1k.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_strings.X5TzmLDs.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "strings.X5TzmLDs.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_tabs.!~{015}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "tabs.H-UKPvku.css",
    "src": "_tabs.!~{015}~.js"
  },
  "_tabs.2ktlM5to.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "tabs.2ktlM5to.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_strings.X5TzmLDs.js",
      "_index.Qmhohhe7.js"
    ],
    "css": [
      "tabs.H-UKPvku.css"
    ]
  },
  "tabs.H-UKPvku.css": {
    "file": "tabs.H-UKPvku.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_tag.!~{00H}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "tag.Wo0upPQu.css",
    "src": "_tag.!~{00H}~.js"
  },
  "_tag.TD0iuaSf.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "tag.TD0iuaSf.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "css": [
      "tag.Wo0upPQu.css"
    ]
  },
  "tag.Wo0upPQu.css": {
    "file": "tag.Wo0upPQu.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_tooltip.!~{01I}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "menu-item.f0mNRiTD.css",
    "src": "_tooltip.!~{01I}~.js"
  },
  "_upload.!~{01x}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "upload.5r92S6hB.css",
    "src": "_upload.!~{01x}~.js"
  },
  "_upload.NbPagz-B.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "upload.NbPagz-B.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_progress.VtWhLZu1.js",
      "_cloneDeep.r2YMfIBN.js",
      "_isEqual.L9QjCfx8.js"
    ],
    "css": [
      "upload.5r92S6hB.css"
    ]
  },
  "upload.5r92S6hB.css": {
    "file": "upload.5r92S6hB.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_useOrderStore.CssBOsye.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useOrderStore.CssBOsye.js",
    "imports": [
      "_index.vp3IuNfq.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_useWebToast.GeKpuGx8.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useWebToast.GeKpuGx8.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_useWs.VWW8hc49.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useWs.VWW8hc49.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_notification.FURaEZ0O.js"
    ]
  },
  "components/Chat/Friend/ApplyDialog.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ApplyDialog.yUq8fo46.js",
    "src": "components/Chat/Friend/ApplyDialog.vue",
    "isDynamicEntry": true,
    "imports": [
      "_ApplyDialog.vue.pC2t2WC3.js",
      "node_modules/nuxt/dist/app/entry.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_dialog.w6rBusy-.js",
      "_isUndefined.IZwZ21d-.js",
      "_notification.FURaEZ0O.js",
      "_friend.K97Fn_tH.js"
    ]
  },
  "components/Chat/NewGroupDialog.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "NewGroupDialog.uMgfkVwm.js",
    "src": "components/Chat/NewGroupDialog.vue",
    "isDynamicEntry": true,
    "imports": [
      "_ElImage.T2cl7jzi.js",
      "_checkbox.htTWQyb9.js",
      "_AutoIncre.vue.hHhgvjPp.js",
      "_scrollbar.FcbrmRKP.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_OssFileUpload.oYHTXXfM.js",
      "_dialog.w6rBusy-.js",
      "_notification.FURaEZ0O.js",
      "_contact.BPR6dLYg.js",
      "_Main.-16TCjWV.js",
      "_friend.K97Fn_tH.js",
      "_debounce.Dgmvm5TF.js",
      "_isEqual.L9QjCfx8.js",
      "_hasIn.hJzZptBh.js",
      "_flatten.wqv5xcaQ.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_progress.VtWhLZu1.js",
      "_index.xU0rlrWx.js",
      "_isUndefined.IZwZ21d-.js",
      "_useWs.VWW8hc49.js"
    ],
    "css": [
      "NewGroupDialog.Hm5sbp8R.css",
      "checkbox-group.d5XbR8TY.css"
    ]
  },
  "NewGroupDialog.Hm5sbp8R.css": {
    "file": "NewGroupDialog.Hm5sbp8R.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "checkbox-group.d5XbR8TY.css": {
    "file": "checkbox-group.d5XbR8TY.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/Comm/PostList.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "PostList.NGcFnjjP.js",
    "src": "components/Comm/PostList.vue",
    "isDynamicEntry": true,
    "imports": [
      "_ElImage.T2cl7jzi.js",
      "_nuxt-link.G8oUHrJE.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.TD0iuaSf.js",
      "_TagList.vue.7jDQq1xn.js",
      "_CommentPreview.wGHQvKEF.js",
      "_AutoIncre.vue.hHhgvjPp.js",
      "_post.QhbummqR.js",
      "_debounce.Dgmvm5TF.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_select.1Rc1zILe.js",
      "_popper.72A3ygos.js",
      "_isUndefined.IZwZ21d-.js",
      "_scrollbar.FcbrmRKP.js",
      "_strings.X5TzmLDs.js",
      "_isEqual.L9QjCfx8.js",
      "_hasIn.hJzZptBh.js",
      "_index.AN-d_JvZ.js",
      "_OssFileUpload.oYHTXXfM.js",
      "_progress.VtWhLZu1.js",
      "_index.xU0rlrWx.js",
      "_notification.FURaEZ0O.js"
    ],
    "css": [
      "PostList.zoch9zzo.css"
    ]
  },
  "PostList.zoch9zzo.css": {
    "file": "PostList.zoch9zzo.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/Comm/post/CateGoryLine.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "CateGoryLine.6ZN1xbjL.js",
    "src": "components/Comm/post/CateGoryLine.vue",
    "isDynamicEntry": true,
    "imports": [
      "_ElImage.T2cl7jzi.js",
      "_nuxt-link.G8oUHrJE.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_debounce.Dgmvm5TF.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ]
  },
  "components/Comm/post/Rank.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Rank.qYWqATHD.js",
    "src": "components/Comm/post/Rank.vue",
    "isDynamicEntry": true,
    "imports": [
      "_divider.ozohExRg.js",
      "_tag.TD0iuaSf.js",
      "_ElImage.T2cl7jzi.js",
      "_nuxt-link.G8oUHrJE.js",
      "_empty._rLIWHHD.js",
      "_scrollbar.FcbrmRKP.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_post.QhbummqR.js",
      "_debounce.Dgmvm5TF.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "css": [
      "Rank.y3dQ8fHf.css"
    ]
  },
  "Rank.y3dQ8fHf.css": {
    "file": "Rank.y3dQ8fHf.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/card/UserLine.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "UserLine.2d94fBYb.js",
    "src": "components/card/UserLine.vue",
    "isDynamicEntry": true,
    "imports": [
      "_avatar.h7eUm_b0.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_upload.NbPagz-B.js",
      "_nuxt-link.G8oUHrJE.js",
      "_index.4EwzueT5.js",
      "_progress.VtWhLZu1.js",
      "_popper.72A3ygos.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_cloneDeep.r2YMfIBN.js",
      "_isEqual.L9QjCfx8.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "css": [
      "UserLine.G_lnDfVq.css",
      "popover.LAISAeEG.css"
    ]
  },
  "UserLine.G_lnDfVq.css": {
    "file": "UserLine.G_lnDfVq.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/list/GoodsList.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "GoodsList.oDq-oQqT.js",
    "src": "components/list/GoodsList.vue",
    "isDynamicEntry": true,
    "imports": [
      "_index.B8GdQimC.js",
      "_nuxt-link.G8oUHrJE.js",
      "_AutoIncre.vue.hHhgvjPp.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.T2cl7jzi.js",
      "_debounce.Dgmvm5TF.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "css": [
      "GoodsList.1p6fEF-7.css"
    ]
  },
  "GoodsList.1p6fEF-7.css": {
    "file": "GoodsList.1p6fEF-7.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/menu/DrawerMenu.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "DrawerMenu.4yEzMIl6.js",
    "src": "components/menu/DrawerMenu.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_menu.KYanD88r.js",
      "_scrollbar.FcbrmRKP.js",
      "_popper.72A3ygos.js",
      "_logo_dark.0K5wPclg.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_index.hhBNrJZ-.js",
      "_index.AN-d_JvZ.js",
      "_isUndefined.IZwZ21d-.js",
      "_nuxt-link.G8oUHrJE.js",
      "_index.4EwzueT5.js"
    ],
    "css": [
      "DrawerMenu.0ja6gThp.css",
      "menu-item.f0mNRiTD.css",
      "popover.LAISAeEG.css"
    ]
  },
  "DrawerMenu.0ja6gThp.css": {
    "file": "DrawerMenu.0ja6gThp.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "menu-item.f0mNRiTD.css": {
    "file": "menu-item.f0mNRiTD.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/menu/RightButtons/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.nm5ZAabN.js",
    "src": "components/menu/RightButtons/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.G8oUHrJE.js",
      "_Main.-16TCjWV.js",
      "_scrollbar.FcbrmRKP.js",
      "_ElImage.T2cl7jzi.js",
      "_index.4EwzueT5.js",
      "_popper.72A3ygos.js",
      "_contact.BPR6dLYg.js",
      "_useWs.VWW8hc49.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.Dgmvm5TF.js",
      "_isUndefined.IZwZ21d-.js",
      "_notification.FURaEZ0O.js"
    ],
    "dynamicImports": [
      "components/menu/ShopCartBar.vue"
    ],
    "css": [
      "index.qlwUIxJd.css",
      "popover.LAISAeEG.css",
      "menu-item.f0mNRiTD.css"
    ]
  },
  "index.qlwUIxJd.css": {
    "file": "index.qlwUIxJd.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/menu/ShopCartBar.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ShopCartBar.eU9L8Nwb.js",
    "src": "components/menu/ShopCartBar.vue",
    "isDynamicEntry": true,
    "imports": [
      "_checkbox.htTWQyb9.js",
      "_ShopLine.F2HhGUcV.js",
      "_AutoIncre.vue.hHhgvjPp.js",
      "_scrollbar.FcbrmRKP.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.4EwzueT5.js",
      "_popper.72A3ygos.js",
      "_useOrderStore.CssBOsye.js",
      "_isEqual.L9QjCfx8.js",
      "_hasIn.hJzZptBh.js",
      "_flatten.wqv5xcaQ.js",
      "_ElImage.T2cl7jzi.js",
      "_debounce.Dgmvm5TF.js",
      "_nuxt-link.G8oUHrJE.js",
      "_select.1Rc1zILe.js",
      "_tag.TD0iuaSf.js",
      "_strings.X5TzmLDs.js",
      "_index.AN-d_JvZ.js",
      "_input-number._E5Hn-el.js",
      "_index.lvubdVY-.js",
      "_sku.F2j30h1k.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isUndefined.IZwZ21d-.js",
      "_index.vp3IuNfq.js"
    ],
    "css": [
      "ShopCartBar.BHANagyi.css",
      "checkbox-group.d5XbR8TY.css",
      "popover.LAISAeEG.css"
    ]
  },
  "ShopCartBar.BHANagyi.css": {
    "file": "ShopCartBar.BHANagyi.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "layouts/chat.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "chat.Qrohj0MP.js",
    "src": "layouts/chat.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.T2cl7jzi.js",
      "components/card/UserLine.vue",
      "_menu.KYanD88r.js",
      "_popper.72A3ygos.js",
      "_useWs.VWW8hc49.js",
      "_friend.K97Fn_tH.js",
      "_useWebToast.GeKpuGx8.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.Dgmvm5TF.js",
      "_avatar.h7eUm_b0.js",
      "_upload.NbPagz-B.js",
      "_progress.VtWhLZu1.js",
      "_cloneDeep.r2YMfIBN.js",
      "_isEqual.L9QjCfx8.js",
      "_nuxt-link.G8oUHrJE.js",
      "_index.4EwzueT5.js",
      "_index.hhBNrJZ-.js",
      "_index.AN-d_JvZ.js",
      "_isUndefined.IZwZ21d-.js",
      "_notification.FURaEZ0O.js"
    ],
    "dynamicImports": [
      "components/menu/RightButtons/index.vue"
    ],
    "css": [
      "chat.vRH9Isjp.css",
      "menu-item.f0mNRiTD.css",
      "popover.LAISAeEG.css"
    ]
  },
  "chat.vRH9Isjp.css": {
    "file": "chat.vRH9Isjp.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "layouts/error.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "error.6p3HJ21q.js",
    "src": "layouts/error.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ]
  },
  "layouts/main.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "main.uijI2W3Z.js",
    "src": "layouts/main.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_Footer.YxJa2VF1.js",
      "components/menu/RightButtons/index.vue",
      "___commonjsHelpers__.1J56E-h6.js",
      "_nuxt-link.G8oUHrJE.js",
      "_logo_dark.0K5wPclg.js",
      "_scrollbar.FcbrmRKP.js",
      "_index.4EwzueT5.js",
      "_popper.72A3ygos.js",
      "_isUndefined.IZwZ21d-.js",
      "_Switch.CZmtGS0o.js",
      "_Main.-16TCjWV.js",
      "_contact.BPR6dLYg.js",
      "_useWs.VWW8hc49.js",
      "_notification.FURaEZ0O.js",
      "_ElImage.T2cl7jzi.js",
      "_debounce.Dgmvm5TF.js"
    ],
    "dynamicImports": [
      "components/menu/DrawerMenu.vue"
    ],
    "css": [
      "popover.LAISAeEG.css",
      "menu-item.f0mNRiTD.css"
    ]
  },
  "layouts/second.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "second.rx_cCmgB.js",
    "src": "layouts/second.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Footer.YxJa2VF1.js",
      "components/menu/RightButtons/index.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.G8oUHrJE.js",
      "_logo_dark.0K5wPclg.js",
      "_scrollbar.FcbrmRKP.js",
      "_index.4EwzueT5.js",
      "_popper.72A3ygos.js",
      "_isUndefined.IZwZ21d-.js",
      "_Switch.CZmtGS0o.js",
      "_Main.-16TCjWV.js",
      "_contact.BPR6dLYg.js",
      "_useWs.VWW8hc49.js",
      "_notification.FURaEZ0O.js",
      "_ElImage.T2cl7jzi.js",
      "_debounce.Dgmvm5TF.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "css": [
      "second.JqdAvVfB.css",
      "popover.LAISAeEG.css",
      "menu-item.f0mNRiTD.css"
    ]
  },
  "second.JqdAvVfB.css": {
    "file": "second.JqdAvVfB.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "layouts/user.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "user.ANWpj_kl.js",
    "src": "layouts/user.vue",
    "isDynamicEntry": true,
    "imports": [
      "_nuxt-link.G8oUHrJE.js",
      "_logo_dark.0K5wPclg.js",
      "_Switch.CZmtGS0o.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_menu.KYanD88r.js",
      "_popper.72A3ygos.js",
      "components/menu/RightButtons/index.vue",
      "_scrollbar.FcbrmRKP.js",
      "_index.4EwzueT5.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_index.hhBNrJZ-.js",
      "_index.AN-d_JvZ.js",
      "_isUndefined.IZwZ21d-.js",
      "_Main.-16TCjWV.js",
      "_contact.BPR6dLYg.js",
      "_useWs.VWW8hc49.js",
      "_notification.FURaEZ0O.js",
      "_ElImage.T2cl7jzi.js",
      "_debounce.Dgmvm5TF.js"
    ],
    "css": [
      "user.yAuj-VgQ.css",
      "menu-item.f0mNRiTD.css",
      "popover.LAISAeEG.css"
    ]
  },
  "user.yAuj-VgQ.css": {
    "file": "user.yAuj-VgQ.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/element-plus/es/components/text/index.mjs": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.2w9xIAf5.js",
    "src": "node_modules/element-plus/es/components/text/index.mjs",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "css": [
      "index.l5CC8IXT.css"
    ]
  },
  "index.l5CC8IXT.css": {
    "file": "index.l5CC8IXT.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "entry.bQQ0Ogbi.js",
    "src": "node_modules/nuxt/dist/app/entry.js",
    "isEntry": true,
    "imports": [
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "dynamicImports": [
      "layouts/chat.vue",
      "layouts/error.vue",
      "layouts/main.vue",
      "layouts/second.vue",
      "layouts/user.vue",
      "node_modules/workbox-window/build/workbox-window.prod.es5.mjs"
    ],
    "css": [
      "entry.OCEmENdu.css"
    ]
  },
  "entry.OCEmENdu.css": {
    "file": "entry.OCEmENdu.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/workbox-window/build/workbox-window.prod.es5.mjs": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "workbox-window.prod.es5.prqDwDSL.js",
    "src": "node_modules/workbox-window/build/workbox-window.prod.es5.mjs",
    "isDynamicEntry": true
  },
  "pages/[...all].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_...all_.5gRAOEXT.js",
    "src": "pages/[...all].vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ]
  },
  "pages/chat/ai.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ai.BWnj2xXF.js",
    "src": "pages/chat/ai.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Main.-16TCjWV.js",
      "_scrollbar.FcbrmRKP.js",
      "_ElImage.T2cl7jzi.js",
      "_nuxt-link.G8oUHrJE.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_contact.BPR6dLYg.js",
      "_useWs.VWW8hc49.js",
      "_debounce.Dgmvm5TF.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_notification.FURaEZ0O.js"
    ],
    "css": [
      "ai.SiTMStRP.css"
    ]
  },
  "ai.SiTMStRP.css": {
    "file": "ai.SiTMStRP.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/chat/friend.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "friend.zPL5QjBW.js",
    "src": "pages/chat/friend.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.TD0iuaSf.js",
      "_ElImage.T2cl7jzi.js",
      "_AutoIncre.vue.hHhgvjPp.js",
      "_scrollbar.FcbrmRKP.js",
      "_empty._rLIWHHD.js",
      "_friend.K97Fn_tH.js",
      "_index.FNQXNVm4.js",
      "_contact.BPR6dLYg.js",
      "_useWs.VWW8hc49.js",
      "_notification.FURaEZ0O.js",
      "_divider.ozohExRg.js",
      "_ApplyDialog.vue.pC2t2WC3.js",
      "_index.jas4pLjK.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.Dgmvm5TF.js",
      "_dialog.w6rBusy-.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "css": [
      "friend.IKhbuxAS.css",
      "radio-group.P_Xz2fNs.css"
    ]
  },
  "friend.IKhbuxAS.css": {
    "file": "friend.IKhbuxAS.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "radio-group.P_Xz2fNs.css": {
    "file": "radio-group.P_Xz2fNs.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/chat/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.uD86WTDm.js",
    "src": "pages/chat/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.T2cl7jzi.js",
      "_index.FNQXNVm4.js",
      "_AutoIncre.vue.hHhgvjPp.js",
      "_notification.FURaEZ0O.js",
      "_contact.BPR6dLYg.js",
      "_Main.-16TCjWV.js",
      "_friend.K97Fn_tH.js",
      "_useWs.VWW8hc49.js",
      "_tag.TD0iuaSf.js",
      "_scrollbar.FcbrmRKP.js",
      "_select.1Rc1zILe.js",
      "_OssFileUpload.oYHTXXfM.js",
      "_nuxt-link.G8oUHrJE.js",
      "_popper.72A3ygos.js",
      "_index.xU0rlrWx.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.Dgmvm5TF.js",
      "_strings.X5TzmLDs.js",
      "_isEqual.L9QjCfx8.js",
      "_hasIn.hJzZptBh.js",
      "_index.AN-d_JvZ.js",
      "_progress.VtWhLZu1.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "dynamicImports": [
      "components/Chat/NewGroupDialog.vue",
      "components/Chat/NewGroupDialog.vue",
      "components/Chat/Friend/ApplyDialog.vue"
    ],
    "css": [
      "index.qEcPa3dd.css",
      "radio.eYTrrdr6.css",
      "radio-group.P_Xz2fNs.css"
    ]
  },
  "index.qEcPa3dd.css": {
    "file": "index.qEcPa3dd.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "radio.eYTrrdr6.css": {
    "file": "radio.eYTrrdr6.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/chat/setting.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "setting.2ucau4mi.js",
    "src": "pages/chat/setting.vue",
    "isDynamicEntry": true,
    "imports": [
      "_divider.ozohExRg.js",
      "_select.1Rc1zILe.js",
      "_index.FNQXNVm4.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.TD0iuaSf.js",
      "_scrollbar.FcbrmRKP.js",
      "_popper.72A3ygos.js",
      "_notification.FURaEZ0O.js",
      "_strings.X5TzmLDs.js",
      "_isEqual.L9QjCfx8.js",
      "_debounce.Dgmvm5TF.js",
      "_hasIn.hJzZptBh.js",
      "_index.AN-d_JvZ.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "css": [
      "setting.SSmFdXUR.css",
      "radio-button.l7x146Nf.css",
      "radio-group.P_Xz2fNs.css"
    ]
  },
  "setting.SSmFdXUR.css": {
    "file": "setting.SSmFdXUR.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "radio-button.l7x146Nf.css": {
    "file": "radio-button.l7x146Nf.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/category/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_id_.KrQfQ8KW.js",
    "src": "pages/community/category/[id].vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.T2cl7jzi.js",
      "_CategoryTabs.UJhFUFEg.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.Dgmvm5TF.js",
      "_tabs.2ktlM5to.js",
      "_strings.X5TzmLDs.js",
      "_index.Qmhohhe7.js",
      "components/Comm/PostList.vue",
      "_nuxt-link.G8oUHrJE.js",
      "_tag.TD0iuaSf.js",
      "_TagList.vue.7jDQq1xn.js",
      "_CommentPreview.wGHQvKEF.js",
      "_select.1Rc1zILe.js",
      "_popper.72A3ygos.js",
      "_isUndefined.IZwZ21d-.js",
      "_scrollbar.FcbrmRKP.js",
      "_isEqual.L9QjCfx8.js",
      "_hasIn.hJzZptBh.js",
      "_index.AN-d_JvZ.js",
      "_OssFileUpload.oYHTXXfM.js",
      "_progress.VtWhLZu1.js",
      "_index.xU0rlrWx.js",
      "_AutoIncre.vue.hHhgvjPp.js",
      "_notification.FURaEZ0O.js",
      "_post.QhbummqR.js",
      "components/list/GoodsList.vue",
      "_index.B8GdQimC.js"
    ],
    "dynamicImports": [
      "components/Comm/post/Rank.vue"
    ],
    "css": [
      "_id_.uLLhAsoU.css"
    ]
  },
  "_id_.uLLhAsoU.css": {
    "file": "_id_.uLLhAsoU.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/category/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.jPDUKNEX.js",
    "src": "pages/community/category/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_CategoryTabs.UJhFUFEg.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_tabs.2ktlM5to.js",
      "_strings.X5TzmLDs.js",
      "_index.Qmhohhe7.js",
      "components/Comm/PostList.vue",
      "_ElImage.T2cl7jzi.js",
      "_debounce.Dgmvm5TF.js",
      "_nuxt-link.G8oUHrJE.js",
      "_tag.TD0iuaSf.js",
      "_TagList.vue.7jDQq1xn.js",
      "_CommentPreview.wGHQvKEF.js",
      "_select.1Rc1zILe.js",
      "_popper.72A3ygos.js",
      "_isUndefined.IZwZ21d-.js",
      "_scrollbar.FcbrmRKP.js",
      "_isEqual.L9QjCfx8.js",
      "_hasIn.hJzZptBh.js",
      "_index.AN-d_JvZ.js",
      "_OssFileUpload.oYHTXXfM.js",
      "_progress.VtWhLZu1.js",
      "_index.xU0rlrWx.js",
      "_AutoIncre.vue.hHhgvjPp.js",
      "_notification.FURaEZ0O.js",
      "_post.QhbummqR.js",
      "components/list/GoodsList.vue",
      "_index.B8GdQimC.js"
    ],
    "dynamicImports": [
      "components/Comm/post/Rank.vue"
    ],
    "css": [
      "index.EaIT1GIC.css"
    ]
  },
  "index.EaIT1GIC.css": {
    "file": "index.EaIT1GIC.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/post/detail/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_id_.-xYv46LL.js",
    "src": "pages/community/post/detail/[id].vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.T2cl7jzi.js",
      "_Switch.CZmtGS0o.js",
      "_tag.TD0iuaSf.js",
      "_nuxt-link.G8oUHrJE.js",
      "_TagList.vue.7jDQq1xn.js",
      "_divider.ozohExRg.js",
      "_post.QhbummqR.js",
      "_CommentPreview.wGHQvKEF.js",
      "_UserPostTotal.vue.sWxlRbTe.js",
      "_SigninCard.vue.IjuYXXgQ.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.Dgmvm5TF.js",
      "_select.1Rc1zILe.js",
      "_popper.72A3ygos.js",
      "_isUndefined.IZwZ21d-.js",
      "_scrollbar.FcbrmRKP.js",
      "_strings.X5TzmLDs.js",
      "_isEqual.L9QjCfx8.js",
      "_hasIn.hJzZptBh.js",
      "_index.AN-d_JvZ.js",
      "_OssFileUpload.oYHTXXfM.js",
      "_progress.VtWhLZu1.js",
      "_index.xU0rlrWx.js",
      "_AutoIncre.vue.hHhgvjPp.js",
      "_notification.FURaEZ0O.js",
      "_index.4EwzueT5.js"
    ],
    "dynamicImports": [
      "components/Comm/post/CateGoryLine.vue"
    ],
    "css": [
      "_id_.zKV61XL4.css",
      "popover.LAISAeEG.css"
    ]
  },
  "_id_.zKV61XL4.css": {
    "file": "_id_.zKV61XL4.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/post/list.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "list.tDNKVMXa.js",
    "src": "pages/community/post/list.vue",
    "isDynamicEntry": true,
    "imports": [
      "_nuxt-link.G8oUHrJE.js",
      "_tag.TD0iuaSf.js",
      "_create-shadow.mAugYdYc.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_effect-creative.oyW6_KqW.js",
      "_post.QhbummqR.js",
      "_ElImage.T2cl7jzi.js",
      "components/Comm/PostList.vue",
      "_tabs.2ktlM5to.js",
      "_SigninCard.vue.IjuYXXgQ.js",
      "components/Comm/post/Rank.vue",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.Dgmvm5TF.js",
      "_TagList.vue.7jDQq1xn.js",
      "_CommentPreview.wGHQvKEF.js",
      "_select.1Rc1zILe.js",
      "_popper.72A3ygos.js",
      "_isUndefined.IZwZ21d-.js",
      "_scrollbar.FcbrmRKP.js",
      "_strings.X5TzmLDs.js",
      "_isEqual.L9QjCfx8.js",
      "_hasIn.hJzZptBh.js",
      "_index.AN-d_JvZ.js",
      "_OssFileUpload.oYHTXXfM.js",
      "_progress.VtWhLZu1.js",
      "_index.xU0rlrWx.js",
      "_AutoIncre.vue.hHhgvjPp.js",
      "_notification.FURaEZ0O.js",
      "_index.Qmhohhe7.js",
      "_index.4EwzueT5.js",
      "_divider.ozohExRg.js",
      "_empty._rLIWHHD.js"
    ],
    "css": [
      "list.aADC_aru.css",
      "popover.LAISAeEG.css"
    ]
  },
  "list.aADC_aru.css": {
    "file": "list.aADC_aru.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/post/new.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "new.Zk43aYtB.js",
    "src": "pages/community/post/new.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_OssFileUpload.oYHTXXfM.js",
      "_index.FNQXNVm4.js",
      "_ElImage.T2cl7jzi.js",
      "_select.1Rc1zILe.js",
      "_tag.TD0iuaSf.js",
      "_scrollbar.FcbrmRKP.js",
      "_popper.72A3ygos.js",
      "_notification.FURaEZ0O.js",
      "_index.xU0rlrWx.js",
      "_StatusTag.Y3cZLxU7.js",
      "_post.QhbummqR.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_progress.VtWhLZu1.js",
      "_debounce.Dgmvm5TF.js",
      "_strings.X5TzmLDs.js",
      "_isEqual.L9QjCfx8.js",
      "_hasIn.hJzZptBh.js",
      "_index.AN-d_JvZ.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "css": [
      "new.ZVTFxoFy.css",
      "radio-button.l7x146Nf.css",
      "radio-group.P_Xz2fNs.css"
    ]
  },
  "new.ZVTFxoFy.css": {
    "file": "new.ZVTFxoFy.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/event/detail/[eid].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_eid_.QLvVJMJ-.js",
    "src": "pages/event/detail/[eid].vue",
    "isDynamicEntry": true,
    "imports": [
      "_ElImage.T2cl7jzi.js",
      "_tag.TD0iuaSf.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.G8oUHrJE.js",
      "_index.inpxOwzP.js",
      "_debounce.Dgmvm5TF.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "css": [
      "_eid_.NtANQ6Xa.css"
    ]
  },
  "_eid_.NtANQ6Xa.css": {
    "file": "_eid_.NtANQ6Xa.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/goods/comments/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_id_.u16Y2giZ.js",
    "src": "pages/goods/comments/[id].vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ]
  },
  "pages/goods/detail/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_id_.jbQZqiJ8.js",
    "src": "pages/goods/detail/[id].vue",
    "isDynamicEntry": true,
    "imports": [
      "_nuxt-link.G8oUHrJE.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_GoodsListSsr.c7NL1Faq.js",
      "_ElImage.T2cl7jzi.js",
      "_index.Qmhohhe7.js",
      "_scrollbar.FcbrmRKP.js",
      "_tag.TD0iuaSf.js",
      "_popper.72A3ygos.js",
      "_collect.dw9HzQRZ.js",
      "_index.FNQXNVm4.js",
      "_input-number._E5Hn-el.js",
      "_useOrderStore.CssBOsye.js",
      "_index.inpxOwzP.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_tabs.2ktlM5to.js",
      "_rate.UnbeKbPm.js",
      "_AutoIncre.vue.hHhgvjPp.js",
      "_dialog.w6rBusy-.js",
      "_index.hhBNrJZ-.js",
      "_index.B8GdQimC.js",
      "_sku.F2j30h1k.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.Dgmvm5TF.js",
      "_isUndefined.IZwZ21d-.js",
      "_index.lvubdVY-.js",
      "_index.vp3IuNfq.js",
      "_strings.X5TzmLDs.js"
    ],
    "css": [
      "_id_.m-29Dv0K.css",
      "popover.LAISAeEG.css",
      "radio-button.l7x146Nf.css",
      "radio-group.P_Xz2fNs.css",
      "radio.eYTrrdr6.css"
    ]
  },
  "_id_.m-29Dv0K.css": {
    "file": "_id_.m-29Dv0K.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.qQvfDBRe.js",
    "src": "pages/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.TD0iuaSf.js",
      "_nuxt-link.G8oUHrJE.js",
      "_AutoIncre.vue.hHhgvjPp.js",
      "_empty._rLIWHHD.js",
      "_scrollbar.FcbrmRKP.js",
      "_index.4EwzueT5.js",
      "_popper.72A3ygos.js",
      "_index.B8GdQimC.js",
      "_create-shadow.mAugYdYc.js",
      "_effect-creative.oyW6_KqW.js",
      "_index.inpxOwzP.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_GoodsListSsr.c7NL1Faq.js",
      "_tabs.2ktlM5to.js",
      "_ElImage.T2cl7jzi.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isUndefined.IZwZ21d-.js",
      "_strings.X5TzmLDs.js",
      "_index.Qmhohhe7.js",
      "_debounce.Dgmvm5TF.js"
    ],
    "dynamicImports": [
      "components/list/GoodsList.vue"
    ],
    "css": [
      "index.IfgpexZK.css",
      "popover.LAISAeEG.css"
    ]
  },
  "index.IfgpexZK.css": {
    "file": "index.IfgpexZK.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/order/comment/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_id_.l0xsNkli.js",
    "src": "pages/order/comment/[id].vue",
    "isDynamicEntry": true,
    "imports": [
      "_Switch.CZmtGS0o.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_progress.VtWhLZu1.js",
      "_upload.NbPagz-B.js",
      "_dialog.w6rBusy-.js",
      "_index.xU0rlrWx.js",
      "_ElImage.T2cl7jzi.js",
      "_rate.UnbeKbPm.js",
      "_checkbox.htTWQyb9.js",
      "_nuxt-link.G8oUHrJE.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_notification.FURaEZ0O.js",
      "_index.vp3IuNfq.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_cloneDeep.r2YMfIBN.js",
      "_isEqual.L9QjCfx8.js",
      "_isUndefined.IZwZ21d-.js",
      "_debounce.Dgmvm5TF.js",
      "_hasIn.hJzZptBh.js",
      "_flatten.wqv5xcaQ.js"
    ],
    "css": [
      "_id_.65PfMBS2.css"
    ]
  },
  "_id_.65PfMBS2.css": {
    "file": "_id_.65PfMBS2.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/order/detail.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "detail.izj6GYE-.js",
    "src": "pages/order/detail.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.T2cl7jzi.js",
      "_nuxt-link.G8oUHrJE.js",
      "_divider.ozohExRg.js",
      "_DelayTimer.vue.Wws7-X5Y.js",
      "_Switch.CZmtGS0o.js",
      "_index.Qmhohhe7.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_bills.MF30gBNx.js",
      "_index.vp3IuNfq.js",
      "_useOrderStore.CssBOsye.js",
      "_index.FNQXNVm4.js",
      "_tag.TD0iuaSf.js",
      "_scrollbar.FcbrmRKP.js",
      "_select.1Rc1zILe.js",
      "_input-number._E5Hn-el.js",
      "_popper.72A3ygos.js",
      "_index.inpxOwzP.js",
      "_sku.F2j30h1k.js",
      "_empty._rLIWHHD.js",
      "_notification.FURaEZ0O.js",
      "_useWebToast.GeKpuGx8.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.Dgmvm5TF.js",
      "_strings.X5TzmLDs.js",
      "_isEqual.L9QjCfx8.js",
      "_hasIn.hJzZptBh.js",
      "_index.AN-d_JvZ.js",
      "_index.lvubdVY-.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "dynamicImports": [
      "node_modules/element-plus/es/components/text/index.mjs"
    ],
    "css": [
      "detail.BmClJIDc.css",
      "radio.eYTrrdr6.css",
      "radio-group.P_Xz2fNs.css"
    ]
  },
  "detail.BmClJIDc.css": {
    "file": "detail.BmClJIDc.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/order/list.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "list.t-0w-H2C.js",
    "src": "pages/order/list.vue",
    "isDynamicEntry": true,
    "imports": [
      "_divider.ozohExRg.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_date-picker.MdIIfGcX.js",
      "_DelayTimer.vue.Wws7-X5Y.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_ElImage.T2cl7jzi.js",
      "_tag.TD0iuaSf.js",
      "_useOrderStore.CssBOsye.js",
      "_index.vp3IuNfq.js",
      "_AutoIncre.vue.hHhgvjPp.js",
      "_scrollbar.FcbrmRKP.js",
      "_popper.72A3ygos.js",
      "_notification.FURaEZ0O.js",
      "_tabs.2ktlM5to.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_localeData.ktyBOuRZ.js",
      "_arrays.9GuX8ZvT.js",
      "_flatten.wqv5xcaQ.js",
      "_index.lvubdVY-.js",
      "_debounce.Dgmvm5TF.js",
      "_index.AN-d_JvZ.js",
      "_isEqual.L9QjCfx8.js",
      "_isUndefined.IZwZ21d-.js",
      "_strings.X5TzmLDs.js",
      "_index.Qmhohhe7.js"
    ],
    "css": [
      "list.pKmG3IwD.css"
    ]
  },
  "list.pKmG3IwD.css": {
    "file": "list.pKmG3IwD.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/search/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index._qE4klx5.js",
    "src": "pages/search/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_checkbox.htTWQyb9.js",
      "_select.1Rc1zILe.js",
      "_tag.TD0iuaSf.js",
      "_tabs.2ktlM5to.js",
      "_empty._rLIWHHD.js",
      "_scrollbar.FcbrmRKP.js",
      "_popper.72A3ygos.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isEqual.L9QjCfx8.js",
      "_hasIn.hJzZptBh.js",
      "_flatten.wqv5xcaQ.js",
      "_strings.X5TzmLDs.js",
      "_debounce.Dgmvm5TF.js",
      "_index.AN-d_JvZ.js",
      "_index.Qmhohhe7.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "dynamicImports": [
      "components/list/GoodsList.vue",
      "components/Comm/PostList.vue"
    ],
    "css": [
      "index.J2x3iyFg.css"
    ]
  },
  "index.J2x3iyFg.css": {
    "file": "index.J2x3iyFg.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/setting/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.iyOr24rf.js",
    "src": "pages/setting/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "_divider.ozohExRg.js",
      "_select.1Rc1zILe.js",
      "_index.FNQXNVm4.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.TD0iuaSf.js",
      "_scrollbar.FcbrmRKP.js",
      "_popper.72A3ygos.js",
      "_notification.FURaEZ0O.js",
      "_strings.X5TzmLDs.js",
      "_isEqual.L9QjCfx8.js",
      "_debounce.Dgmvm5TF.js",
      "_hasIn.hJzZptBh.js",
      "_index.AN-d_JvZ.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "css": [
      "index.z1SuaKix.css",
      "radio-button.l7x146Nf.css",
      "radio-group.P_Xz2fNs.css"
    ]
  },
  "index.z1SuaKix.css": {
    "file": "index.z1SuaKix.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/address.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "address.oBaulVwU.js",
    "src": "pages/user/address.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/element-plus/es/components/text/index.mjs",
      "node_modules/nuxt/dist/app/entry.js",
      "_scrollbar.FcbrmRKP.js",
      "_checkbox.htTWQyb9.js",
      "_index.FNQXNVm4.js",
      "_strings.X5TzmLDs.js",
      "_isEqual.L9QjCfx8.js",
      "_arrays.9GuX8ZvT.js",
      "_flatten.wqv5xcaQ.js",
      "_cloneDeep.r2YMfIBN.js",
      "_popper.72A3ygos.js",
      "_tag.TD0iuaSf.js",
      "_index.AN-d_JvZ.js",
      "_debounce.Dgmvm5TF.js",
      "_dialog.w6rBusy-.js",
      "_divider.ozohExRg.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_hasIn.hJzZptBh.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "css": [
      "address.1z3UCWAo.css",
      "radio.eYTrrdr6.css",
      "checkbox-group.d5XbR8TY.css"
    ]
  },
  "address.1z3UCWAo.css": {
    "file": "address.1z3UCWAo.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/collect.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "collect.1V1E4ziZ.js",
    "src": "pages/user/collect.vue",
    "isDynamicEntry": true,
    "imports": [
      "_divider.ozohExRg.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_checkbox.htTWQyb9.js",
      "_ElImage.T2cl7jzi.js",
      "_scrollbar.FcbrmRKP.js",
      "_collect.dw9HzQRZ.js",
      "_tabs.2ktlM5to.js",
      "_tag.TD0iuaSf.js",
      "_nuxt-link.G8oUHrJE.js",
      "_TagList.vue.7jDQq1xn.js",
      "_AutoIncre.vue.hHhgvjPp.js",
      "_post.QhbummqR.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isEqual.L9QjCfx8.js",
      "_hasIn.hJzZptBh.js",
      "_flatten.wqv5xcaQ.js",
      "_debounce.Dgmvm5TF.js",
      "_strings.X5TzmLDs.js",
      "_index.Qmhohhe7.js"
    ],
    "css": [
      "collect.4jK4CO3w.css",
      "checkbox-group.d5XbR8TY.css"
    ]
  },
  "collect.4jK4CO3w.css": {
    "file": "collect.4jK4CO3w.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/info.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "info.nLrxzpii.js",
    "src": "pages/user/info.vue",
    "isDynamicEntry": true,
    "imports": [
      "_ElImage.T2cl7jzi.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.4EwzueT5.js",
      "_popper.72A3ygos.js",
      "_upload.NbPagz-B.js",
      "_date-picker.MdIIfGcX.js",
      "_select.1Rc1zILe.js",
      "_progress.VtWhLZu1.js",
      "_scrollbar.FcbrmRKP.js",
      "_tag.TD0iuaSf.js",
      "_nuxt-link.G8oUHrJE.js",
      "_TagList.vue.7jDQq1xn.js",
      "_AutoIncre.vue.hHhgvjPp.js",
      "_post.QhbummqR.js",
      "_tabs.2ktlM5to.js",
      "_UserPostTotal.vue.sWxlRbTe.js",
      "_SigninCard.vue.IjuYXXgQ.js",
      "_index.jas4pLjK.js",
      "_debounce.Dgmvm5TF.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isUndefined.IZwZ21d-.js",
      "_cloneDeep.r2YMfIBN.js",
      "_isEqual.L9QjCfx8.js",
      "_localeData.ktyBOuRZ.js",
      "_arrays.9GuX8ZvT.js",
      "_flatten.wqv5xcaQ.js",
      "_index.lvubdVY-.js",
      "_index.AN-d_JvZ.js",
      "_strings.X5TzmLDs.js",
      "_hasIn.hJzZptBh.js",
      "_index.Qmhohhe7.js"
    ],
    "css": [
      "info.ZO--Iv68.css",
      "popover.LAISAeEG.css",
      "menu-item.f0mNRiTD.css"
    ]
  },
  "info.ZO--Iv68.css": {
    "file": "info.ZO--Iv68.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/post.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "post.RrWKg6xq.js",
    "src": "pages/user/post.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.T2cl7jzi.js",
      "_select.1Rc1zILe.js",
      "_tag.TD0iuaSf.js",
      "_scrollbar.FcbrmRKP.js",
      "_popper.72A3ygos.js",
      "_StatusTag.Y3cZLxU7.js",
      "_nuxt-link.G8oUHrJE.js",
      "_TagList.vue.7jDQq1xn.js",
      "_post.QhbummqR.js",
      "_AutoIncre.vue.hHhgvjPp.js",
      "_notification.FURaEZ0O.js",
      "_tabs.2ktlM5to.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.Dgmvm5TF.js",
      "_strings.X5TzmLDs.js",
      "_isEqual.L9QjCfx8.js",
      "_hasIn.hJzZptBh.js",
      "_index.AN-d_JvZ.js",
      "_isUndefined.IZwZ21d-.js",
      "_index.Qmhohhe7.js"
    ],
    "css": [
      "post.yVQn8Ib0.css"
    ]
  },
  "post.yVQn8Ib0.css": {
    "file": "post.yVQn8Ib0.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/safe.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "safe.qnmwLt2n.js",
    "src": "pages/user/safe.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.TD0iuaSf.js",
      "_scrollbar.FcbrmRKP.js",
      "_avatar.h7eUm_b0.js",
      "_divider.ozohExRg.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_useOrderStore.CssBOsye.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_index.vp3IuNfq.js"
    ],
    "css": [
      "safe.73roRH3g.css"
    ]
  },
  "safe.73roRH3g.css": {
    "file": "safe.73roRH3g.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/shopcart.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "shopcart.06jGOjuA.js",
    "src": "pages/user/shopcart.vue",
    "isDynamicEntry": true,
    "imports": [
      "_checkbox.htTWQyb9.js",
      "_ShopLine.F2HhGUcV.js",
      "_nuxt-link.G8oUHrJE.js",
      "_AutoIncre.vue.hHhgvjPp.js",
      "_scrollbar.FcbrmRKP.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useOrderStore.CssBOsye.js",
      "_isEqual.L9QjCfx8.js",
      "_hasIn.hJzZptBh.js",
      "_flatten.wqv5xcaQ.js",
      "_ElImage.T2cl7jzi.js",
      "_debounce.Dgmvm5TF.js",
      "_select.1Rc1zILe.js",
      "_popper.72A3ygos.js",
      "_isUndefined.IZwZ21d-.js",
      "_tag.TD0iuaSf.js",
      "_strings.X5TzmLDs.js",
      "_index.AN-d_JvZ.js",
      "_input-number._E5Hn-el.js",
      "_index.lvubdVY-.js",
      "_sku.F2j30h1k.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_index.vp3IuNfq.js"
    ],
    "css": [
      "shopcart.T7K9gx-c.css",
      "checkbox-group.d5XbR8TY.css"
    ]
  },
  "shopcart.T7K9gx-c.css": {
    "file": "shopcart.T7K9gx-c.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/wallet.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "wallet.ReWS_EW0.js",
    "src": "pages/user/wallet.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/element-plus/es/components/text/index.mjs",
      "node_modules/nuxt/dist/app/entry.js",
      "_create-shadow.mAugYdYc.js",
      "_progress.VtWhLZu1.js",
      "_index.4EwzueT5.js",
      "_popper.72A3ygos.js",
      "_bills.MF30gBNx.js",
      "_scrollbar.FcbrmRKP.js",
      "_input-number._E5Hn-el.js",
      "_select.1Rc1zILe.js",
      "_tag.TD0iuaSf.js",
      "_localeData.ktyBOuRZ.js",
      "_divider.ozohExRg.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isUndefined.IZwZ21d-.js",
      "_index.lvubdVY-.js",
      "_strings.X5TzmLDs.js",
      "_isEqual.L9QjCfx8.js",
      "_debounce.Dgmvm5TF.js",
      "_hasIn.hJzZptBh.js",
      "_index.AN-d_JvZ.js"
    ],
    "css": [
      "wallet.0lzzqGc7.css",
      "popover.LAISAeEG.css"
    ]
  },
  "wallet.0lzzqGc7.css": {
    "file": "wallet.0lzzqGc7.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
