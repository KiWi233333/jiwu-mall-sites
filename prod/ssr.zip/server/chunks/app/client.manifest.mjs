const client_manifest = {
  "_ApplyDialog.vue.5p7SzKVX.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ApplyDialog.vue.5p7SzKVX.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_dialog.JNHYOqeE.js",
      "_notification.WVfyBYTU.js",
      "_friend.6lAwrO12.js"
    ]
  },
  "_AutoIncre.vue.246JS8pi.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "AutoIncre.vue.246JS8pi.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_CategoryTabs.!~{014}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "CategoryTabs.787nBCiN.css",
    "src": "_CategoryTabs.!~{014}~.js"
  },
  "_CategoryTabs.lMPPgJBc.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "CategoryTabs.787nBCiN.css"
    ],
    "file": "CategoryTabs.lMPPgJBc.js",
    "imports": [
      "_tabs.dXl6PtpM.js",
      "node_modules/nuxt/dist/app/entry.js",
      "components/Comm/PostList.vue",
      "components/list/GoodsList.vue"
    ]
  },
  "CategoryTabs.787nBCiN.css": {
    "file": "CategoryTabs.787nBCiN.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_CommentPreview.!~{019}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "CommentPreview.J3-ZHx6B.css",
    "src": "_CommentPreview.!~{019}~.js"
  },
  "_CommentPreview.Xne1zgvu.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "CommentPreview.J3-ZHx6B.css"
    ],
    "file": "CommentPreview.Xne1zgvu.js",
    "imports": [
      "_ElImage.IUF2s1z1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_select.o_WkKnqZ.js",
      "_OssFileUpload.2HhbtfKl.js",
      "_nuxt-link.Ql8t_YNY.js",
      "_tag.bXVQZ_CA.js",
      "_AutoIncre.vue.246JS8pi.js",
      "_scrollbar.ORNOMpK6.js",
      "_popper.iSU8OKeK.js",
      "_notification.WVfyBYTU.js"
    ]
  },
  "CommentPreview.J3-ZHx6B.css": {
    "file": "CommentPreview.J3-ZHx6B.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_DelayTimer.vue.xzHJSGdV.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "DelayTimer.vue.xzHJSGdV.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_ElImage.!~{00B}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "ElImage.6ybrNKBL.css",
    "src": "_ElImage.!~{00B}~.js"
  },
  "_ElImage.IUF2s1z1.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "ElImage.6ybrNKBL.css"
    ],
    "file": "ElImage.IUF2s1z1.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_debounce.pX8CUAd-.js"
    ]
  },
  "ElImage.6ybrNKBL.css": {
    "file": "ElImage.6ybrNKBL.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_Footer.!~{01Q}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Footer.y5ruypfy.css",
    "src": "_Footer.!~{01Q}~.js"
  },
  "_Footer.qqrWYXM6.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "Footer.y5ruypfy.css"
    ],
    "file": "Footer.qqrWYXM6.js",
    "imports": [
      "_nuxt-link.Ql8t_YNY.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_logo_dark.UbNhxNfG.js",
      "_Switch.QbxxHx-r.js"
    ]
  },
  "Footer.y5ruypfy.css": {
    "file": "Footer.y5ruypfy.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_GoodsListSsr.!~{01n}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "GoodsListSsr.P5hBZBtk.css",
    "src": "_GoodsListSsr.!~{01n}~.js"
  },
  "_GoodsListSsr.ZsOcIh1k.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "GoodsListSsr.P5hBZBtk.css"
    ],
    "file": "GoodsListSsr.ZsOcIh1k.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.4YZQYan3.js",
      "_nuxt-link.Ql8t_YNY.js",
      "node_modules/element-plus/es/components/text/index.mjs"
    ]
  },
  "GoodsListSsr.P5hBZBtk.css": {
    "file": "GoodsListSsr.P5hBZBtk.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_Main.vue.!~{00z}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Main.dWFRPFzh.css",
    "src": "_Main.vue.!~{00z}~.js"
  },
  "_Main.vue.I73ByHIE.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "Main.dWFRPFzh.css"
    ],
    "file": "Main.vue.I73ByHIE.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_contact.Ai4EaMRR.js",
      "_ElImage.IUF2s1z1.js",
      "_tag.bXVQZ_CA.js"
    ]
  },
  "Main.dWFRPFzh.css": {
    "file": "Main.dWFRPFzh.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_OssFileUpload.!~{00W}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "OssFileUpload.-TDo8IgO.css",
    "src": "_OssFileUpload.!~{00W}~.js"
  },
  "_OssFileUpload.2HhbtfKl.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "OssFileUpload.-TDo8IgO.css"
    ],
    "file": "OssFileUpload.2HhbtfKl.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.IUF2s1z1.js",
      "_progress.RZY92Mej.js",
      "_index.DBEfs4X3.js"
    ]
  },
  "OssFileUpload.-TDo8IgO.css": {
    "file": "OssFileUpload.-TDo8IgO.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_ShopLine.!~{01K}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "ShopLine.Wq74ulT-.css",
    "src": "_ShopLine.!~{01K}~.js"
  },
  "_ShopLine.AQlEMlH1.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "ShopLine.Wq74ulT-.css"
    ],
    "file": "ShopLine.AQlEMlH1.js",
    "imports": [
      "_ElImage.IUF2s1z1.js",
      "_nuxt-link.Ql8t_YNY.js",
      "_select.o_WkKnqZ.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_input-number.HJiClp0i.js",
      "_tag.bXVQZ_CA.js",
      "_scrollbar.ORNOMpK6.js",
      "_popper.iSU8OKeK.js",
      "_sku.meA3Ek4K.js"
    ]
  },
  "ShopLine.Wq74ulT-.css": {
    "file": "ShopLine.Wq74ulT-.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_SigninCard.vue.LPsVQD8u.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "popover.LAISAeEG.css"
    ],
    "file": "SigninCard.vue.LPsVQD8u.js",
    "imports": [
      "_progress.RZY92Mej.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.bIniYoEa.js",
      "_popper.iSU8OKeK.js"
    ]
  },
  "popover.LAISAeEG.css": {
    "file": "popover.LAISAeEG.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_StatusTag.!~{01l}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "StatusTag.IETAoY75.css",
    "src": "_StatusTag.!~{01l}~.js"
  },
  "_StatusTag.NXv1he1g.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "StatusTag.IETAoY75.css"
    ],
    "file": "StatusTag.NXv1he1g.js",
    "imports": [
      "_tag.bXVQZ_CA.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_post.QeaKke8u.js"
    ]
  },
  "StatusTag.IETAoY75.css": {
    "file": "StatusTag.IETAoY75.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_Switch.!~{01e}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Switch.JXXa2UnD.css",
    "src": "_Switch.!~{01e}~.js"
  },
  "_Switch.QbxxHx-r.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "Switch.JXXa2UnD.css"
    ],
    "file": "Switch.QbxxHx-r.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "Switch.JXXa2UnD.css": {
    "file": "Switch.JXXa2UnD.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_TagList.vue.dUIFsZvg.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TagList.vue.dUIFsZvg.js",
    "imports": [
      "_tag.bXVQZ_CA.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_UserPostTotal.vue.tj8ldB8m.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "UserPostTotal.vue.tj8ldB8m.js",
    "imports": [
      "_ElImage.IUF2s1z1.js",
      "_nuxt-link.Ql8t_YNY.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_post.QeaKke8u.js"
    ]
  },
  "___commonjsHelpers__.1J56E-h6.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "__commonjsHelpers__.1J56E-h6.js"
  },
  "_arrays.9GuX8ZvT.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "arrays.9GuX8ZvT.js"
  },
  "_avatar.!~{01J}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "avatar.bZH1-Oig.css",
    "src": "_avatar.!~{01J}~.js"
  },
  "_avatar.2DAwwOSb.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "avatar.bZH1-Oig.css"
    ],
    "file": "avatar.2DAwwOSb.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "avatar.bZH1-Oig.css": {
    "file": "avatar.bZH1-Oig.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_bills.HxGYQBow.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "bills.HxGYQBow.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_checkbox-group.!~{01H}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "checkbox-group.d5XbR8TY.css",
    "src": "_checkbox-group.!~{01H}~.js"
  },
  "_checkbox.!~{01y}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "checkbox.MJHvI1xB.css",
    "src": "_checkbox.!~{01y}~.js"
  },
  "_checkbox.-VM1AKcy.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "checkbox.MJHvI1xB.css"
    ],
    "file": "checkbox.-VM1AKcy.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_isEqual.2WbiwtQN.js",
      "_hasIn.V2LJ5qln.js",
      "_flatten.vEaIzau5.js"
    ]
  },
  "checkbox.MJHvI1xB.css": {
    "file": "checkbox.MJHvI1xB.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_cloneDeep.5jaWrBkU.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "cloneDeep.5jaWrBkU.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_collect.LPGsm3zf.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "collect.LPGsm3zf.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_contact.Ai4EaMRR.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "contact.Ai4EaMRR.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_useWs.OIEbmDs_.js"
    ]
  },
  "_create-shadow.ZVmSM78z.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "create-shadow.ZVmSM78z.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_date-picker.!~{01E}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "date-picker.sSkDKlix.css",
    "src": "_date-picker.!~{01E}~.js"
  },
  "_date-picker.Y5WXhXqd.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "date-picker.sSkDKlix.css"
    ],
    "file": "date-picker.Y5WXhXqd.js",
    "imports": [
      "_localeData.Iw9YzluB.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_arrays.9GuX8ZvT.js",
      "_flatten.vEaIzau5.js",
      "_popper.iSU8OKeK.js",
      "_scrollbar.ORNOMpK6.js",
      "_index.2Imb-KsY.js",
      "_debounce.pX8CUAd-.js",
      "_index.RHC8v-li.js",
      "_isEqual.2WbiwtQN.js"
    ]
  },
  "date-picker.sSkDKlix.css": {
    "file": "date-picker.sSkDKlix.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_debounce.pX8CUAd-.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "debounce.pX8CUAd-.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_dialog.!~{00Q}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "dialog.mDs1vky2.css",
    "src": "_dialog.!~{00Q}~.js"
  },
  "_dialog.JNHYOqeE.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "dialog.mDs1vky2.css"
    ],
    "file": "dialog.JNHYOqeE.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_isUndefined.IZwZ21d-.js"
    ]
  },
  "dialog.mDs1vky2.css": {
    "file": "dialog.mDs1vky2.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_divider.!~{00N}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "divider.mvCfgREV.css",
    "src": "_divider.!~{00N}~.js"
  },
  "_divider.-dVH-PKa.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "divider.mvCfgREV.css"
    ],
    "file": "divider.-dVH-PKa.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "divider.mvCfgREV.css": {
    "file": "divider.mvCfgREV.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_effect-creative.yIKdMdmd.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "effect-creative.yIKdMdmd.js",
    "imports": [
      "_create-shadow.ZVmSM78z.js"
    ]
  },
  "_empty.!~{00J}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "empty.sDhVTJEQ.css",
    "src": "_empty.!~{00J}~.js"
  },
  "_empty.7UC3C7aI.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "empty.sDhVTJEQ.css"
    ],
    "file": "empty.7UC3C7aI.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "empty.sDhVTJEQ.css": {
    "file": "empty.sDhVTJEQ.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_flatten.vEaIzau5.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "flatten.vEaIzau5.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_friend.6lAwrO12.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "friend.6lAwrO12.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_hasIn.V2LJ5qln.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "hasIn.V2LJ5qln.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.!~{01c}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.BbVs9JM6.css",
    "src": "_index.!~{01c}~.js"
  },
  "_index.2Imb-KsY.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.2Imb-KsY.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.4YZQYan3.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.BbVs9JM6.css"
    ],
    "file": "index.4YZQYan3.js",
    "imports": [
      "_ElImage.IUF2s1z1.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "index.BbVs9JM6.css": {
    "file": "index.BbVs9JM6.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_index.76zUB18l.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.76zUB18l.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.DBEfs4X3.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.DBEfs4X3.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ]
  },
  "_index.RHC8v-li.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.RHC8v-li.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.RqE3nvWB.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.RqE3nvWB.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index._-HOwMct.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index._-HOwMct.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.bIniYoEa.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.bIniYoEa.js",
    "imports": [
      "_popper.iSU8OKeK.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.dpEfVPdZ.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.dpEfVPdZ.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.ndv7SQ1H.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.ndv7SQ1H.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.ttKNZYuc.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.ttKNZYuc.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_input-number.!~{01p}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "input-number.5AezeF1g.css",
    "src": "_input-number.!~{01p}~.js"
  },
  "_input-number.HJiClp0i.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "input-number.5AezeF1g.css"
    ],
    "file": "input-number.HJiClp0i.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.2Imb-KsY.js"
    ]
  },
  "input-number.5AezeF1g.css": {
    "file": "input-number.5AezeF1g.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_isEqual.2WbiwtQN.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "isEqual.2WbiwtQN.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_isUndefined.IZwZ21d-.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "isUndefined.IZwZ21d-.js"
  },
  "_localeData.Iw9YzluB.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "localeData.Iw9YzluB.js",
    "imports": [
      "___commonjsHelpers__.1J56E-h6.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_logo_dark.UbNhxNfG.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "popover.LAISAeEG.css"
    ],
    "dynamicImports": [
      "components/card/UserLine.vue"
    ],
    "file": "logo_dark.UbNhxNfG.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.Ql8t_YNY.js",
      "_scrollbar.ORNOMpK6.js",
      "_index.bIniYoEa.js",
      "_popper.iSU8OKeK.js"
    ]
  },
  "_menu-item.!~{01O}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "menu-item.f0mNRiTD.css",
    "src": "_tooltip.!~{01I}~.js"
  },
  "_menu.!~{01N}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "menu.6YbFhd-D.css",
    "src": "_menu.!~{01N}~.js"
  },
  "_menu.Nc3mLqcn.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "menu.6YbFhd-D.css"
    ],
    "file": "menu.Nc3mLqcn.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.ndv7SQ1H.js",
      "_popper.iSU8OKeK.js",
      "_index.RHC8v-li.js"
    ]
  },
  "menu.6YbFhd-D.css": {
    "file": "menu.6YbFhd-D.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_notification.!~{00H}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "notification.8O_B6xHM.css",
    "src": "_notification.!~{00H}~.js"
  },
  "_notification.WVfyBYTU.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "notification.8O_B6xHM.css"
    ],
    "file": "notification.WVfyBYTU.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "notification.8O_B6xHM.css": {
    "file": "notification.8O_B6xHM.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_nuxt-link.Ql8t_YNY.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "nuxt-link.Ql8t_YNY.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_popover.!~{01i}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "popover.LAISAeEG.css",
    "src": "_popover.!~{01i}~.js"
  },
  "_popper.!~{00X}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "popper.nTJkgMH4.css",
    "src": "_popper.!~{00X}~.js"
  },
  "_popper.iSU8OKeK.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "popper.nTJkgMH4.css"
    ],
    "file": "popper.iSU8OKeK.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_isUndefined.IZwZ21d-.js"
    ]
  },
  "popper.nTJkgMH4.css": {
    "file": "popper.nTJkgMH4.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_post.QeaKke8u.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "post.QeaKke8u.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_progress.!~{011}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "progress.rXLlm_9F.css",
    "src": "_progress.!~{011}~.js"
  },
  "_progress.RZY92Mej.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "progress.rXLlm_9F.css"
    ],
    "file": "progress.RZY92Mej.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "progress.rXLlm_9F.css": {
    "file": "progress.rXLlm_9F.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_radio-button.!~{012}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "radio-button.l7x146Nf.css",
    "src": "_radio-button.!~{012}~.js"
  },
  "_radio-group.!~{00M}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "radio-group.P_Xz2fNs.css",
    "src": "_radio-group.!~{00M}~.js"
  },
  "_radio.!~{00U}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "radio.eYTrrdr6.css",
    "src": "_radio.!~{00U}~.js"
  },
  "_rate.!~{01s}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "rate.mGuCO7Lx.css",
    "src": "_rate.!~{01s}~.js"
  },
  "_rate.4daQI76b.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "rate.mGuCO7Lx.css"
    ],
    "file": "rate.4daQI76b.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "rate.mGuCO7Lx.css": {
    "file": "rate.mGuCO7Lx.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_scrollbar.!~{00A}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "scrollbar.Smf0pYfu.css",
    "src": "_scrollbar.!~{00A}~.js"
  },
  "_scrollbar.ORNOMpK6.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "scrollbar.Smf0pYfu.css"
    ],
    "file": "scrollbar.ORNOMpK6.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "scrollbar.Smf0pYfu.css": {
    "file": "scrollbar.Smf0pYfu.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_select.!~{00V}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "select.xPRdjiL2.css",
    "src": "_select.!~{00V}~.js"
  },
  "_select.o_WkKnqZ.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "select.xPRdjiL2.css"
    ],
    "file": "select.o_WkKnqZ.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_popper.iSU8OKeK.js",
      "_scrollbar.ORNOMpK6.js",
      "_tag.bXVQZ_CA.js",
      "_strings.lS_fR9IB.js",
      "_isEqual.2WbiwtQN.js",
      "_debounce.pX8CUAd-.js",
      "_hasIn.V2LJ5qln.js",
      "_index.RHC8v-li.js"
    ]
  },
  "select.xPRdjiL2.css": {
    "file": "select.xPRdjiL2.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_sku.meA3Ek4K.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sku.meA3Ek4K.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_strings.lS_fR9IB.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "strings.lS_fR9IB.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_tabs.!~{015}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "tabs.H-UKPvku.css",
    "src": "_tabs.!~{015}~.js"
  },
  "_tabs.dXl6PtpM.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "tabs.H-UKPvku.css"
    ],
    "file": "tabs.dXl6PtpM.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_strings.lS_fR9IB.js",
      "_index.ttKNZYuc.js"
    ]
  },
  "tabs.H-UKPvku.css": {
    "file": "tabs.H-UKPvku.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_tag.!~{00F}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "tag.Wo0upPQu.css",
    "src": "_tag.!~{00F}~.js"
  },
  "_tag.bXVQZ_CA.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "tag.Wo0upPQu.css"
    ],
    "file": "tag.bXVQZ_CA.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "tag.Wo0upPQu.css": {
    "file": "tag.Wo0upPQu.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_tooltip.!~{01I}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "menu-item.f0mNRiTD.css",
    "src": "_tooltip.!~{01I}~.js"
  },
  "_upload.!~{01x}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "upload.5r92S6hB.css",
    "src": "_upload.!~{01x}~.js"
  },
  "_upload.IL95GdQe.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "upload.5r92S6hB.css"
    ],
    "file": "upload.IL95GdQe.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_progress.RZY92Mej.js",
      "_cloneDeep.5jaWrBkU.js",
      "_isEqual.2WbiwtQN.js"
    ]
  },
  "upload.5r92S6hB.css": {
    "file": "upload.5r92S6hB.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_useOrderStore.i_fJajYE.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useOrderStore.i_fJajYE.js",
    "imports": [
      "_index._-HOwMct.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_useWebToast.SxVdI2Vf.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useWebToast.SxVdI2Vf.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_useWs.OIEbmDs_.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useWs.OIEbmDs_.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_notification.WVfyBYTU.js"
    ]
  },
  "components/Chat/Friend/ApplyDialog.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ApplyDialog.cIN2xuMI.js",
    "imports": [
      "_ApplyDialog.vue.5p7SzKVX.js",
      "node_modules/nuxt/dist/app/entry.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_dialog.JNHYOqeE.js",
      "_isUndefined.IZwZ21d-.js",
      "_notification.WVfyBYTU.js",
      "_friend.6lAwrO12.js"
    ],
    "isDynamicEntry": true,
    "src": "components/Chat/Friend/ApplyDialog.vue"
  },
  "components/Chat/NewGroupDialog.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "NewGroupDialog.Hm5sbp8R.css",
      "checkbox-group.d5XbR8TY.css"
    ],
    "file": "NewGroupDialog.luXhcM1L.js",
    "imports": [
      "_ElImage.IUF2s1z1.js",
      "_checkbox.-VM1AKcy.js",
      "_AutoIncre.vue.246JS8pi.js",
      "_scrollbar.ORNOMpK6.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_OssFileUpload.2HhbtfKl.js",
      "_dialog.JNHYOqeE.js",
      "_notification.WVfyBYTU.js",
      "_contact.Ai4EaMRR.js",
      "_Main.vue.I73ByHIE.js",
      "_friend.6lAwrO12.js",
      "_debounce.pX8CUAd-.js",
      "_isEqual.2WbiwtQN.js",
      "_hasIn.V2LJ5qln.js",
      "_flatten.vEaIzau5.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_progress.RZY92Mej.js",
      "_index.DBEfs4X3.js",
      "_isUndefined.IZwZ21d-.js",
      "_useWs.OIEbmDs_.js",
      "_tag.bXVQZ_CA.js"
    ],
    "isDynamicEntry": true,
    "src": "components/Chat/NewGroupDialog.vue"
  },
  "NewGroupDialog.Hm5sbp8R.css": {
    "file": "NewGroupDialog.Hm5sbp8R.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "checkbox-group.d5XbR8TY.css": {
    "file": "checkbox-group.d5XbR8TY.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/Comm/PostList.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "PostList._i8MVHra.css"
    ],
    "file": "PostList.phL0iO_f.js",
    "imports": [
      "_ElImage.IUF2s1z1.js",
      "_nuxt-link.Ql8t_YNY.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.bXVQZ_CA.js",
      "_TagList.vue.dUIFsZvg.js",
      "_CommentPreview.Xne1zgvu.js",
      "_AutoIncre.vue.246JS8pi.js",
      "_post.QeaKke8u.js",
      "_debounce.pX8CUAd-.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_select.o_WkKnqZ.js",
      "_popper.iSU8OKeK.js",
      "_isUndefined.IZwZ21d-.js",
      "_scrollbar.ORNOMpK6.js",
      "_strings.lS_fR9IB.js",
      "_isEqual.2WbiwtQN.js",
      "_hasIn.V2LJ5qln.js",
      "_index.RHC8v-li.js",
      "_OssFileUpload.2HhbtfKl.js",
      "_progress.RZY92Mej.js",
      "_index.DBEfs4X3.js",
      "_notification.WVfyBYTU.js"
    ],
    "isDynamicEntry": true,
    "src": "components/Comm/PostList.vue"
  },
  "PostList._i8MVHra.css": {
    "file": "PostList._i8MVHra.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/Comm/post/CateGoryLine.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "CateGoryLine.DnaSNN7G.js",
    "imports": [
      "_ElImage.IUF2s1z1.js",
      "_nuxt-link.Ql8t_YNY.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_debounce.pX8CUAd-.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "components/Comm/post/CateGoryLine.vue"
  },
  "components/Comm/post/Rank.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "Rank.y3OSjSFp.css"
    ],
    "file": "Rank.h4REwVwL.js",
    "imports": [
      "_divider.-dVH-PKa.js",
      "_tag.bXVQZ_CA.js",
      "_ElImage.IUF2s1z1.js",
      "_nuxt-link.Ql8t_YNY.js",
      "_empty.7UC3C7aI.js",
      "_scrollbar.ORNOMpK6.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_post.QeaKke8u.js",
      "_debounce.pX8CUAd-.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "components/Comm/post/Rank.vue"
  },
  "Rank.y3OSjSFp.css": {
    "file": "Rank.y3OSjSFp.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/card/UserLine.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "UserLine.G_lnDfVq.css",
      "popover.LAISAeEG.css"
    ],
    "file": "UserLine.MvF-BiuM.js",
    "imports": [
      "_avatar.2DAwwOSb.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_upload.IL95GdQe.js",
      "_nuxt-link.Ql8t_YNY.js",
      "_index.bIniYoEa.js",
      "_progress.RZY92Mej.js",
      "_popper.iSU8OKeK.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_cloneDeep.5jaWrBkU.js",
      "_isEqual.2WbiwtQN.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "components/card/UserLine.vue"
  },
  "UserLine.G_lnDfVq.css": {
    "file": "UserLine.G_lnDfVq.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/list/GoodsList.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "GoodsList.1p6fEF-7.css"
    ],
    "file": "GoodsList.zs1N4ZOD.js",
    "imports": [
      "_index.4YZQYan3.js",
      "_nuxt-link.Ql8t_YNY.js",
      "_AutoIncre.vue.246JS8pi.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.IUF2s1z1.js",
      "_debounce.pX8CUAd-.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "components/list/GoodsList.vue"
  },
  "GoodsList.1p6fEF-7.css": {
    "file": "GoodsList.1p6fEF-7.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/menu/DrawerMenu.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "DrawerMenu.0ja6gThp.css",
      "menu-item.f0mNRiTD.css",
      "popover.LAISAeEG.css"
    ],
    "file": "DrawerMenu.hI7xycYU.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_menu.Nc3mLqcn.js",
      "_scrollbar.ORNOMpK6.js",
      "_popper.iSU8OKeK.js",
      "_logo_dark.UbNhxNfG.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_index.ndv7SQ1H.js",
      "_index.RHC8v-li.js",
      "_isUndefined.IZwZ21d-.js",
      "_nuxt-link.Ql8t_YNY.js",
      "_index.bIniYoEa.js"
    ],
    "isDynamicEntry": true,
    "src": "components/menu/DrawerMenu.vue"
  },
  "DrawerMenu.0ja6gThp.css": {
    "file": "DrawerMenu.0ja6gThp.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "menu-item.f0mNRiTD.css": {
    "file": "menu-item.f0mNRiTD.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/menu/RightButtons/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.d8QRz2qr.css",
      "popover.LAISAeEG.css",
      "menu-item.f0mNRiTD.css"
    ],
    "dynamicImports": [
      "components/menu/ShopCartBar.vue"
    ],
    "file": "index.Gfp8cGnC.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.Ql8t_YNY.js",
      "_Main.vue.I73ByHIE.js",
      "_scrollbar.ORNOMpK6.js",
      "_ElImage.IUF2s1z1.js",
      "_index.bIniYoEa.js",
      "_popper.iSU8OKeK.js",
      "_contact.Ai4EaMRR.js",
      "_useWs.OIEbmDs_.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_tag.bXVQZ_CA.js",
      "_debounce.pX8CUAd-.js",
      "_isUndefined.IZwZ21d-.js",
      "_notification.WVfyBYTU.js"
    ],
    "isDynamicEntry": true,
    "src": "components/menu/RightButtons/index.vue"
  },
  "index.d8QRz2qr.css": {
    "file": "index.d8QRz2qr.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/menu/ShopCartBar.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "ShopCartBar.EsIq9V-V.css",
      "checkbox-group.d5XbR8TY.css",
      "popover.LAISAeEG.css"
    ],
    "file": "ShopCartBar.-94Dvx8b.js",
    "imports": [
      "_checkbox.-VM1AKcy.js",
      "_ShopLine.AQlEMlH1.js",
      "_AutoIncre.vue.246JS8pi.js",
      "_scrollbar.ORNOMpK6.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.bIniYoEa.js",
      "_popper.iSU8OKeK.js",
      "_useOrderStore.i_fJajYE.js",
      "_isEqual.2WbiwtQN.js",
      "_hasIn.V2LJ5qln.js",
      "_flatten.vEaIzau5.js",
      "_ElImage.IUF2s1z1.js",
      "_debounce.pX8CUAd-.js",
      "_nuxt-link.Ql8t_YNY.js",
      "_select.o_WkKnqZ.js",
      "_tag.bXVQZ_CA.js",
      "_strings.lS_fR9IB.js",
      "_index.RHC8v-li.js",
      "_input-number.HJiClp0i.js",
      "_index.2Imb-KsY.js",
      "_sku.meA3Ek4K.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isUndefined.IZwZ21d-.js",
      "_index._-HOwMct.js"
    ],
    "isDynamicEntry": true,
    "src": "components/menu/ShopCartBar.vue"
  },
  "ShopCartBar.EsIq9V-V.css": {
    "file": "ShopCartBar.EsIq9V-V.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "layouts/chat.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "chat.5knOEY9m.css",
      "menu-item.f0mNRiTD.css",
      "popover.LAISAeEG.css"
    ],
    "dynamicImports": [
      "components/menu/RightButtons/index.vue"
    ],
    "file": "chat.iNVVHjqz.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.IUF2s1z1.js",
      "components/card/UserLine.vue",
      "_menu.Nc3mLqcn.js",
      "_popper.iSU8OKeK.js",
      "_useWs.OIEbmDs_.js",
      "_friend.6lAwrO12.js",
      "_useWebToast.SxVdI2Vf.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.pX8CUAd-.js",
      "_avatar.2DAwwOSb.js",
      "_upload.IL95GdQe.js",
      "_progress.RZY92Mej.js",
      "_cloneDeep.5jaWrBkU.js",
      "_isEqual.2WbiwtQN.js",
      "_nuxt-link.Ql8t_YNY.js",
      "_index.bIniYoEa.js",
      "_index.ndv7SQ1H.js",
      "_index.RHC8v-li.js",
      "_isUndefined.IZwZ21d-.js",
      "_notification.WVfyBYTU.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/chat.vue"
  },
  "chat.5knOEY9m.css": {
    "file": "chat.5knOEY9m.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "layouts/error.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "error.zEYHQ4WJ.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/error.vue"
  },
  "layouts/main.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "popover.LAISAeEG.css",
      "menu-item.f0mNRiTD.css"
    ],
    "dynamicImports": [
      "components/menu/DrawerMenu.vue"
    ],
    "file": "main.heqXhgY6.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_Footer.qqrWYXM6.js",
      "components/menu/RightButtons/index.vue",
      "___commonjsHelpers__.1J56E-h6.js",
      "_nuxt-link.Ql8t_YNY.js",
      "_logo_dark.UbNhxNfG.js",
      "_scrollbar.ORNOMpK6.js",
      "_index.bIniYoEa.js",
      "_popper.iSU8OKeK.js",
      "_isUndefined.IZwZ21d-.js",
      "_Switch.QbxxHx-r.js",
      "_Main.vue.I73ByHIE.js",
      "_contact.Ai4EaMRR.js",
      "_useWs.OIEbmDs_.js",
      "_notification.WVfyBYTU.js",
      "_ElImage.IUF2s1z1.js",
      "_debounce.pX8CUAd-.js",
      "_tag.bXVQZ_CA.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/main.vue"
  },
  "layouts/second.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "second.JqdAvVfB.css",
      "popover.LAISAeEG.css",
      "menu-item.f0mNRiTD.css"
    ],
    "file": "second.8S1QXIWM.js",
    "imports": [
      "_Footer.qqrWYXM6.js",
      "components/menu/RightButtons/index.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.Ql8t_YNY.js",
      "_logo_dark.UbNhxNfG.js",
      "_scrollbar.ORNOMpK6.js",
      "_index.bIniYoEa.js",
      "_popper.iSU8OKeK.js",
      "_isUndefined.IZwZ21d-.js",
      "_Switch.QbxxHx-r.js",
      "_Main.vue.I73ByHIE.js",
      "_contact.Ai4EaMRR.js",
      "_useWs.OIEbmDs_.js",
      "_notification.WVfyBYTU.js",
      "_ElImage.IUF2s1z1.js",
      "_debounce.pX8CUAd-.js",
      "_tag.bXVQZ_CA.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/second.vue"
  },
  "second.JqdAvVfB.css": {
    "file": "second.JqdAvVfB.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "layouts/user.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "user.yAuj-VgQ.css",
      "menu-item.f0mNRiTD.css",
      "popover.LAISAeEG.css"
    ],
    "file": "user.bviVQv-b.js",
    "imports": [
      "_nuxt-link.Ql8t_YNY.js",
      "_logo_dark.UbNhxNfG.js",
      "_Switch.QbxxHx-r.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_menu.Nc3mLqcn.js",
      "_popper.iSU8OKeK.js",
      "components/menu/RightButtons/index.vue",
      "_scrollbar.ORNOMpK6.js",
      "_index.bIniYoEa.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_index.ndv7SQ1H.js",
      "_index.RHC8v-li.js",
      "_isUndefined.IZwZ21d-.js",
      "_Main.vue.I73ByHIE.js",
      "_contact.Ai4EaMRR.js",
      "_useWs.OIEbmDs_.js",
      "_notification.WVfyBYTU.js",
      "_ElImage.IUF2s1z1.js",
      "_debounce.pX8CUAd-.js",
      "_tag.bXVQZ_CA.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/user.vue"
  },
  "user.yAuj-VgQ.css": {
    "file": "user.yAuj-VgQ.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/element-plus/es/components/text/index.mjs": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.l5CC8IXT.css"
    ],
    "file": "index.SRPYS6xC.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/element-plus/es/components/text/index.mjs"
  },
  "index.l5CC8IXT.css": {
    "file": "index.l5CC8IXT.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "entry.BTnpSHkW.css"
    ],
    "dynamicImports": [
      "layouts/chat.vue",
      "layouts/error.vue",
      "layouts/main.vue",
      "layouts/second.vue",
      "layouts/user.vue",
      "node_modules/workbox-window/build/workbox-window.prod.es5.mjs"
    ],
    "file": "entry.VP2ougng.js",
    "imports": [
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js"
  },
  "entry.BTnpSHkW.css": {
    "file": "entry.BTnpSHkW.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/workbox-window/build/workbox-window.prod.es5.mjs": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "workbox-window.prod.es5.prqDwDSL.js",
    "isDynamicEntry": true,
    "src": "node_modules/workbox-window/build/workbox-window.prod.es5.mjs"
  },
  "pages/[...all].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_...all_.FvkH5ANO.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/[...all].vue"
  },
  "pages/chat/ai.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "ai.df74smAD.css"
    ],
    "file": "ai.HSbpTuIm.js",
    "imports": [
      "_Main.vue.I73ByHIE.js",
      "_scrollbar.ORNOMpK6.js",
      "_ElImage.IUF2s1z1.js",
      "_nuxt-link.Ql8t_YNY.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_contact.Ai4EaMRR.js",
      "_useWs.OIEbmDs_.js",
      "_tag.bXVQZ_CA.js",
      "_debounce.pX8CUAd-.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_notification.WVfyBYTU.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/chat/ai.vue"
  },
  "ai.df74smAD.css": {
    "file": "ai.df74smAD.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/chat/friend.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "friend.chnzZ23W.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "file": "friend.j95NJl6t.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.bXVQZ_CA.js",
      "_ElImage.IUF2s1z1.js",
      "_AutoIncre.vue.246JS8pi.js",
      "_scrollbar.ORNOMpK6.js",
      "_empty.7UC3C7aI.js",
      "_friend.6lAwrO12.js",
      "_index.dpEfVPdZ.js",
      "_contact.Ai4EaMRR.js",
      "_useWs.OIEbmDs_.js",
      "_notification.WVfyBYTU.js",
      "_divider.-dVH-PKa.js",
      "_ApplyDialog.vue.5p7SzKVX.js",
      "_index.76zUB18l.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.pX8CUAd-.js",
      "_dialog.JNHYOqeE.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/chat/friend.vue"
  },
  "friend.chnzZ23W.css": {
    "file": "friend.chnzZ23W.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "radio-group.P_Xz2fNs.css": {
    "file": "radio-group.P_Xz2fNs.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/chat/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.JpUzHRVI.css",
      "radio.eYTrrdr6.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "dynamicImports": [
      "components/Chat/NewGroupDialog.vue",
      "components/Chat/NewGroupDialog.vue",
      "components/Chat/Friend/ApplyDialog.vue"
    ],
    "file": "index.kv0oannI.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.IUF2s1z1.js",
      "_index.dpEfVPdZ.js",
      "_AutoIncre.vue.246JS8pi.js",
      "_notification.WVfyBYTU.js",
      "_contact.Ai4EaMRR.js",
      "_Main.vue.I73ByHIE.js",
      "_friend.6lAwrO12.js",
      "_useWs.OIEbmDs_.js",
      "_tag.bXVQZ_CA.js",
      "_scrollbar.ORNOMpK6.js",
      "_select.o_WkKnqZ.js",
      "_OssFileUpload.2HhbtfKl.js",
      "_nuxt-link.Ql8t_YNY.js",
      "_popper.iSU8OKeK.js",
      "_index.DBEfs4X3.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.pX8CUAd-.js",
      "_strings.lS_fR9IB.js",
      "_isEqual.2WbiwtQN.js",
      "_hasIn.V2LJ5qln.js",
      "_index.RHC8v-li.js",
      "_progress.RZY92Mej.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/chat/index.vue"
  },
  "index.JpUzHRVI.css": {
    "file": "index.JpUzHRVI.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "radio.eYTrrdr6.css": {
    "file": "radio.eYTrrdr6.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/chat/setting.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "setting.SSmFdXUR.css",
      "radio-button.l7x146Nf.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "file": "setting.cRsqVmsn.js",
    "imports": [
      "_divider.-dVH-PKa.js",
      "_select.o_WkKnqZ.js",
      "_index.dpEfVPdZ.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.bXVQZ_CA.js",
      "_scrollbar.ORNOMpK6.js",
      "_popper.iSU8OKeK.js",
      "_notification.WVfyBYTU.js",
      "_strings.lS_fR9IB.js",
      "_isEqual.2WbiwtQN.js",
      "_debounce.pX8CUAd-.js",
      "_hasIn.V2LJ5qln.js",
      "_index.RHC8v-li.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/chat/setting.vue"
  },
  "setting.SSmFdXUR.css": {
    "file": "setting.SSmFdXUR.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "radio-button.l7x146Nf.css": {
    "file": "radio-button.l7x146Nf.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/category/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "_id_.uLLhAsoU.css"
    ],
    "dynamicImports": [
      "components/Comm/post/Rank.vue"
    ],
    "file": "_id_.bImtoWsn.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.IUF2s1z1.js",
      "_CategoryTabs.lMPPgJBc.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.pX8CUAd-.js",
      "_tabs.dXl6PtpM.js",
      "_strings.lS_fR9IB.js",
      "_index.ttKNZYuc.js",
      "components/Comm/PostList.vue",
      "_nuxt-link.Ql8t_YNY.js",
      "_tag.bXVQZ_CA.js",
      "_TagList.vue.dUIFsZvg.js",
      "_CommentPreview.Xne1zgvu.js",
      "_select.o_WkKnqZ.js",
      "_popper.iSU8OKeK.js",
      "_isUndefined.IZwZ21d-.js",
      "_scrollbar.ORNOMpK6.js",
      "_isEqual.2WbiwtQN.js",
      "_hasIn.V2LJ5qln.js",
      "_index.RHC8v-li.js",
      "_OssFileUpload.2HhbtfKl.js",
      "_progress.RZY92Mej.js",
      "_index.DBEfs4X3.js",
      "_AutoIncre.vue.246JS8pi.js",
      "_notification.WVfyBYTU.js",
      "_post.QeaKke8u.js",
      "components/list/GoodsList.vue",
      "_index.4YZQYan3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/category/[id].vue"
  },
  "_id_.uLLhAsoU.css": {
    "file": "_id_.uLLhAsoU.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/category/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.EaIT1GIC.css"
    ],
    "dynamicImports": [
      "components/Comm/post/Rank.vue"
    ],
    "file": "index.7Ll3umry.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_CategoryTabs.lMPPgJBc.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_tabs.dXl6PtpM.js",
      "_strings.lS_fR9IB.js",
      "_index.ttKNZYuc.js",
      "components/Comm/PostList.vue",
      "_ElImage.IUF2s1z1.js",
      "_debounce.pX8CUAd-.js",
      "_nuxt-link.Ql8t_YNY.js",
      "_tag.bXVQZ_CA.js",
      "_TagList.vue.dUIFsZvg.js",
      "_CommentPreview.Xne1zgvu.js",
      "_select.o_WkKnqZ.js",
      "_popper.iSU8OKeK.js",
      "_isUndefined.IZwZ21d-.js",
      "_scrollbar.ORNOMpK6.js",
      "_isEqual.2WbiwtQN.js",
      "_hasIn.V2LJ5qln.js",
      "_index.RHC8v-li.js",
      "_OssFileUpload.2HhbtfKl.js",
      "_progress.RZY92Mej.js",
      "_index.DBEfs4X3.js",
      "_AutoIncre.vue.246JS8pi.js",
      "_notification.WVfyBYTU.js",
      "_post.QeaKke8u.js",
      "components/list/GoodsList.vue",
      "_index.4YZQYan3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/category/index.vue"
  },
  "index.EaIT1GIC.css": {
    "file": "index.EaIT1GIC.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/post/detail/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "_id_.N0o7W9bX.css",
      "popover.LAISAeEG.css"
    ],
    "dynamicImports": [
      "components/Comm/post/CateGoryLine.vue"
    ],
    "file": "_id_.u9Q6InHx.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.IUF2s1z1.js",
      "_Switch.QbxxHx-r.js",
      "_tag.bXVQZ_CA.js",
      "_nuxt-link.Ql8t_YNY.js",
      "_TagList.vue.dUIFsZvg.js",
      "_divider.-dVH-PKa.js",
      "_post.QeaKke8u.js",
      "_CommentPreview.Xne1zgvu.js",
      "_UserPostTotal.vue.tj8ldB8m.js",
      "_SigninCard.vue.LPsVQD8u.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.pX8CUAd-.js",
      "_select.o_WkKnqZ.js",
      "_popper.iSU8OKeK.js",
      "_isUndefined.IZwZ21d-.js",
      "_scrollbar.ORNOMpK6.js",
      "_strings.lS_fR9IB.js",
      "_isEqual.2WbiwtQN.js",
      "_hasIn.V2LJ5qln.js",
      "_index.RHC8v-li.js",
      "_OssFileUpload.2HhbtfKl.js",
      "_progress.RZY92Mej.js",
      "_index.DBEfs4X3.js",
      "_AutoIncre.vue.246JS8pi.js",
      "_notification.WVfyBYTU.js",
      "_index.bIniYoEa.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/post/detail/[id].vue"
  },
  "_id_.N0o7W9bX.css": {
    "file": "_id_.N0o7W9bX.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/post/list.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "list.aADC_aru.css",
      "popover.LAISAeEG.css"
    ],
    "file": "list.9LFTBMUj.js",
    "imports": [
      "_nuxt-link.Ql8t_YNY.js",
      "_tag.bXVQZ_CA.js",
      "_create-shadow.ZVmSM78z.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_effect-creative.yIKdMdmd.js",
      "_post.QeaKke8u.js",
      "_ElImage.IUF2s1z1.js",
      "components/Comm/PostList.vue",
      "_tabs.dXl6PtpM.js",
      "_SigninCard.vue.LPsVQD8u.js",
      "components/Comm/post/Rank.vue",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.pX8CUAd-.js",
      "_TagList.vue.dUIFsZvg.js",
      "_CommentPreview.Xne1zgvu.js",
      "_select.o_WkKnqZ.js",
      "_popper.iSU8OKeK.js",
      "_isUndefined.IZwZ21d-.js",
      "_scrollbar.ORNOMpK6.js",
      "_strings.lS_fR9IB.js",
      "_isEqual.2WbiwtQN.js",
      "_hasIn.V2LJ5qln.js",
      "_index.RHC8v-li.js",
      "_OssFileUpload.2HhbtfKl.js",
      "_progress.RZY92Mej.js",
      "_index.DBEfs4X3.js",
      "_AutoIncre.vue.246JS8pi.js",
      "_notification.WVfyBYTU.js",
      "_index.ttKNZYuc.js",
      "_index.bIniYoEa.js",
      "_divider.-dVH-PKa.js",
      "_empty.7UC3C7aI.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/post/list.vue"
  },
  "list.aADC_aru.css": {
    "file": "list.aADC_aru.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/post/new.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "new.0TTT8KuO.css",
      "radio-button.l7x146Nf.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "file": "new.4dsjMu92.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_OssFileUpload.2HhbtfKl.js",
      "_index.dpEfVPdZ.js",
      "_ElImage.IUF2s1z1.js",
      "_select.o_WkKnqZ.js",
      "_tag.bXVQZ_CA.js",
      "_scrollbar.ORNOMpK6.js",
      "_popper.iSU8OKeK.js",
      "_notification.WVfyBYTU.js",
      "_index.DBEfs4X3.js",
      "_StatusTag.NXv1he1g.js",
      "_post.QeaKke8u.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_progress.RZY92Mej.js",
      "_debounce.pX8CUAd-.js",
      "_strings.lS_fR9IB.js",
      "_isEqual.2WbiwtQN.js",
      "_hasIn.V2LJ5qln.js",
      "_index.RHC8v-li.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/post/new.vue"
  },
  "new.0TTT8KuO.css": {
    "file": "new.0TTT8KuO.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/event/detail/[eid].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "_eid_.NtANQ6Xa.css"
    ],
    "file": "_eid_.eBIwGd19.js",
    "imports": [
      "_ElImage.IUF2s1z1.js",
      "_tag.bXVQZ_CA.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.Ql8t_YNY.js",
      "_index.RqE3nvWB.js",
      "_debounce.pX8CUAd-.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/event/detail/[eid].vue"
  },
  "_eid_.NtANQ6Xa.css": {
    "file": "_eid_.NtANQ6Xa.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/goods/comments/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_id_.wKneKR7R.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/goods/comments/[id].vue"
  },
  "pages/goods/detail/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "_id_.spxRS6Bk.css",
      "popover.LAISAeEG.css",
      "radio-button.l7x146Nf.css",
      "radio-group.P_Xz2fNs.css",
      "radio.eYTrrdr6.css"
    ],
    "file": "_id_.r4pXiPmP.js",
    "imports": [
      "_nuxt-link.Ql8t_YNY.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_GoodsListSsr.ZsOcIh1k.js",
      "_ElImage.IUF2s1z1.js",
      "_index.ttKNZYuc.js",
      "_scrollbar.ORNOMpK6.js",
      "_tag.bXVQZ_CA.js",
      "_popper.iSU8OKeK.js",
      "_collect.LPGsm3zf.js",
      "_index.dpEfVPdZ.js",
      "_input-number.HJiClp0i.js",
      "_useOrderStore.i_fJajYE.js",
      "_index.RqE3nvWB.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_tabs.dXl6PtpM.js",
      "_rate.4daQI76b.js",
      "_AutoIncre.vue.246JS8pi.js",
      "_dialog.JNHYOqeE.js",
      "_index.ndv7SQ1H.js",
      "_index.4YZQYan3.js",
      "_sku.meA3Ek4K.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.pX8CUAd-.js",
      "_isUndefined.IZwZ21d-.js",
      "_index.2Imb-KsY.js",
      "_index._-HOwMct.js",
      "_strings.lS_fR9IB.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/goods/detail/[id].vue"
  },
  "_id_.spxRS6Bk.css": {
    "file": "_id_.spxRS6Bk.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.IfgpexZK.css",
      "popover.LAISAeEG.css"
    ],
    "dynamicImports": [
      "components/list/GoodsList.vue"
    ],
    "file": "index.wP1FahCz.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.bXVQZ_CA.js",
      "_nuxt-link.Ql8t_YNY.js",
      "_AutoIncre.vue.246JS8pi.js",
      "_empty.7UC3C7aI.js",
      "_scrollbar.ORNOMpK6.js",
      "_index.bIniYoEa.js",
      "_popper.iSU8OKeK.js",
      "_index.4YZQYan3.js",
      "_create-shadow.ZVmSM78z.js",
      "_effect-creative.yIKdMdmd.js",
      "_index.RqE3nvWB.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_GoodsListSsr.ZsOcIh1k.js",
      "_tabs.dXl6PtpM.js",
      "_ElImage.IUF2s1z1.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isUndefined.IZwZ21d-.js",
      "_strings.lS_fR9IB.js",
      "_index.ttKNZYuc.js",
      "_debounce.pX8CUAd-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.IfgpexZK.css": {
    "file": "index.IfgpexZK.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/order/comment/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "_id_.65PfMBS2.css"
    ],
    "file": "_id_.7fpRFAXk.js",
    "imports": [
      "_Switch.QbxxHx-r.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_progress.RZY92Mej.js",
      "_upload.IL95GdQe.js",
      "_dialog.JNHYOqeE.js",
      "_index.DBEfs4X3.js",
      "_ElImage.IUF2s1z1.js",
      "_rate.4daQI76b.js",
      "_checkbox.-VM1AKcy.js",
      "_nuxt-link.Ql8t_YNY.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_notification.WVfyBYTU.js",
      "_index._-HOwMct.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_cloneDeep.5jaWrBkU.js",
      "_isEqual.2WbiwtQN.js",
      "_isUndefined.IZwZ21d-.js",
      "_debounce.pX8CUAd-.js",
      "_hasIn.V2LJ5qln.js",
      "_flatten.vEaIzau5.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/order/comment/[id].vue"
  },
  "_id_.65PfMBS2.css": {
    "file": "_id_.65PfMBS2.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/order/detail.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "detail.Zq1m3l4e.css",
      "radio.eYTrrdr6.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "dynamicImports": [
      "node_modules/element-plus/es/components/text/index.mjs"
    ],
    "file": "detail.kAe9_geV.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.IUF2s1z1.js",
      "_nuxt-link.Ql8t_YNY.js",
      "_divider.-dVH-PKa.js",
      "_DelayTimer.vue.xzHJSGdV.js",
      "_Switch.QbxxHx-r.js",
      "_index.ttKNZYuc.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_bills.HxGYQBow.js",
      "_index._-HOwMct.js",
      "_useOrderStore.i_fJajYE.js",
      "_index.dpEfVPdZ.js",
      "_tag.bXVQZ_CA.js",
      "_scrollbar.ORNOMpK6.js",
      "_select.o_WkKnqZ.js",
      "_input-number.HJiClp0i.js",
      "_popper.iSU8OKeK.js",
      "_index.RqE3nvWB.js",
      "_sku.meA3Ek4K.js",
      "_empty.7UC3C7aI.js",
      "_notification.WVfyBYTU.js",
      "_useWebToast.SxVdI2Vf.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.pX8CUAd-.js",
      "_strings.lS_fR9IB.js",
      "_isEqual.2WbiwtQN.js",
      "_hasIn.V2LJ5qln.js",
      "_index.RHC8v-li.js",
      "_index.2Imb-KsY.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/order/detail.vue"
  },
  "detail.Zq1m3l4e.css": {
    "file": "detail.Zq1m3l4e.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/order/list.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "list.pKmG3IwD.css"
    ],
    "file": "list.bf_IeDuX.js",
    "imports": [
      "_divider.-dVH-PKa.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_date-picker.Y5WXhXqd.js",
      "_DelayTimer.vue.xzHJSGdV.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_ElImage.IUF2s1z1.js",
      "_tag.bXVQZ_CA.js",
      "_useOrderStore.i_fJajYE.js",
      "_index._-HOwMct.js",
      "_AutoIncre.vue.246JS8pi.js",
      "_scrollbar.ORNOMpK6.js",
      "_popper.iSU8OKeK.js",
      "_notification.WVfyBYTU.js",
      "_tabs.dXl6PtpM.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_localeData.Iw9YzluB.js",
      "_arrays.9GuX8ZvT.js",
      "_flatten.vEaIzau5.js",
      "_index.2Imb-KsY.js",
      "_debounce.pX8CUAd-.js",
      "_index.RHC8v-li.js",
      "_isEqual.2WbiwtQN.js",
      "_isUndefined.IZwZ21d-.js",
      "_strings.lS_fR9IB.js",
      "_index.ttKNZYuc.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/order/list.vue"
  },
  "list.pKmG3IwD.css": {
    "file": "list.pKmG3IwD.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/search/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.avLsXlFQ.css"
    ],
    "dynamicImports": [
      "components/list/GoodsList.vue",
      "components/Comm/PostList.vue"
    ],
    "file": "index.jdtKPvFg.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_checkbox.-VM1AKcy.js",
      "_select.o_WkKnqZ.js",
      "_tag.bXVQZ_CA.js",
      "_tabs.dXl6PtpM.js",
      "_empty.7UC3C7aI.js",
      "_scrollbar.ORNOMpK6.js",
      "_popper.iSU8OKeK.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isEqual.2WbiwtQN.js",
      "_hasIn.V2LJ5qln.js",
      "_flatten.vEaIzau5.js",
      "_strings.lS_fR9IB.js",
      "_debounce.pX8CUAd-.js",
      "_index.RHC8v-li.js",
      "_index.ttKNZYuc.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/search/index.vue"
  },
  "index.avLsXlFQ.css": {
    "file": "index.avLsXlFQ.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/setting/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.z1SuaKix.css",
      "radio-button.l7x146Nf.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "file": "index.Dt8trjAN.js",
    "imports": [
      "_divider.-dVH-PKa.js",
      "_select.o_WkKnqZ.js",
      "_index.dpEfVPdZ.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.bXVQZ_CA.js",
      "_scrollbar.ORNOMpK6.js",
      "_popper.iSU8OKeK.js",
      "_notification.WVfyBYTU.js",
      "_strings.lS_fR9IB.js",
      "_isEqual.2WbiwtQN.js",
      "_debounce.pX8CUAd-.js",
      "_hasIn.V2LJ5qln.js",
      "_index.RHC8v-li.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/setting/index.vue"
  },
  "index.z1SuaKix.css": {
    "file": "index.z1SuaKix.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/address.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "address.RlqThWjN.css",
      "radio.eYTrrdr6.css",
      "checkbox-group.d5XbR8TY.css"
    ],
    "file": "address.pwbfA8Hb.js",
    "imports": [
      "node_modules/element-plus/es/components/text/index.mjs",
      "node_modules/nuxt/dist/app/entry.js",
      "_scrollbar.ORNOMpK6.js",
      "_checkbox.-VM1AKcy.js",
      "_index.dpEfVPdZ.js",
      "_strings.lS_fR9IB.js",
      "_isEqual.2WbiwtQN.js",
      "_arrays.9GuX8ZvT.js",
      "_flatten.vEaIzau5.js",
      "_cloneDeep.5jaWrBkU.js",
      "_popper.iSU8OKeK.js",
      "_tag.bXVQZ_CA.js",
      "_index.RHC8v-li.js",
      "_debounce.pX8CUAd-.js",
      "_dialog.JNHYOqeE.js",
      "_divider.-dVH-PKa.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_hasIn.V2LJ5qln.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/address.vue"
  },
  "address.RlqThWjN.css": {
    "file": "address.RlqThWjN.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/collect.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "collect.4jK4CO3w.css",
      "checkbox-group.d5XbR8TY.css"
    ],
    "file": "collect.9a06jw4N.js",
    "imports": [
      "_divider.-dVH-PKa.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_checkbox.-VM1AKcy.js",
      "_ElImage.IUF2s1z1.js",
      "_scrollbar.ORNOMpK6.js",
      "_collect.LPGsm3zf.js",
      "_tabs.dXl6PtpM.js",
      "_tag.bXVQZ_CA.js",
      "_nuxt-link.Ql8t_YNY.js",
      "_TagList.vue.dUIFsZvg.js",
      "_AutoIncre.vue.246JS8pi.js",
      "_post.QeaKke8u.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isEqual.2WbiwtQN.js",
      "_hasIn.V2LJ5qln.js",
      "_flatten.vEaIzau5.js",
      "_debounce.pX8CUAd-.js",
      "_strings.lS_fR9IB.js",
      "_index.ttKNZYuc.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/collect.vue"
  },
  "collect.4jK4CO3w.css": {
    "file": "collect.4jK4CO3w.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/info.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "info.iWvGf_B4.css",
      "popover.LAISAeEG.css",
      "menu-item.f0mNRiTD.css"
    ],
    "file": "info.CYPoMRVp.js",
    "imports": [
      "_ElImage.IUF2s1z1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.bIniYoEa.js",
      "_popper.iSU8OKeK.js",
      "_upload.IL95GdQe.js",
      "_date-picker.Y5WXhXqd.js",
      "_select.o_WkKnqZ.js",
      "_progress.RZY92Mej.js",
      "_scrollbar.ORNOMpK6.js",
      "_tag.bXVQZ_CA.js",
      "_nuxt-link.Ql8t_YNY.js",
      "_TagList.vue.dUIFsZvg.js",
      "_AutoIncre.vue.246JS8pi.js",
      "_post.QeaKke8u.js",
      "_tabs.dXl6PtpM.js",
      "_UserPostTotal.vue.tj8ldB8m.js",
      "_SigninCard.vue.LPsVQD8u.js",
      "_index.76zUB18l.js",
      "_debounce.pX8CUAd-.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isUndefined.IZwZ21d-.js",
      "_cloneDeep.5jaWrBkU.js",
      "_isEqual.2WbiwtQN.js",
      "_localeData.Iw9YzluB.js",
      "_arrays.9GuX8ZvT.js",
      "_flatten.vEaIzau5.js",
      "_index.2Imb-KsY.js",
      "_index.RHC8v-li.js",
      "_strings.lS_fR9IB.js",
      "_hasIn.V2LJ5qln.js",
      "_index.ttKNZYuc.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/info.vue"
  },
  "info.iWvGf_B4.css": {
    "file": "info.iWvGf_B4.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/post.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "post.yVQn8Ib0.css"
    ],
    "file": "post.NG97f1kE.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.IUF2s1z1.js",
      "_select.o_WkKnqZ.js",
      "_tag.bXVQZ_CA.js",
      "_scrollbar.ORNOMpK6.js",
      "_popper.iSU8OKeK.js",
      "_StatusTag.NXv1he1g.js",
      "_nuxt-link.Ql8t_YNY.js",
      "_TagList.vue.dUIFsZvg.js",
      "_post.QeaKke8u.js",
      "_AutoIncre.vue.246JS8pi.js",
      "_notification.WVfyBYTU.js",
      "_tabs.dXl6PtpM.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.pX8CUAd-.js",
      "_strings.lS_fR9IB.js",
      "_isEqual.2WbiwtQN.js",
      "_hasIn.V2LJ5qln.js",
      "_index.RHC8v-li.js",
      "_isUndefined.IZwZ21d-.js",
      "_index.ttKNZYuc.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/post.vue"
  },
  "post.yVQn8Ib0.css": {
    "file": "post.yVQn8Ib0.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/safe.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "safe.73roRH3g.css"
    ],
    "file": "safe.GHaPBlVV.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.bXVQZ_CA.js",
      "_scrollbar.ORNOMpK6.js",
      "_avatar.2DAwwOSb.js",
      "_divider.-dVH-PKa.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_useOrderStore.i_fJajYE.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_index._-HOwMct.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/safe.vue"
  },
  "safe.73roRH3g.css": {
    "file": "safe.73roRH3g.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/shopcart.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "shopcart.T7K9gx-c.css",
      "checkbox-group.d5XbR8TY.css"
    ],
    "file": "shopcart.uEEtRPm1.js",
    "imports": [
      "_checkbox.-VM1AKcy.js",
      "_ShopLine.AQlEMlH1.js",
      "_nuxt-link.Ql8t_YNY.js",
      "_AutoIncre.vue.246JS8pi.js",
      "_scrollbar.ORNOMpK6.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useOrderStore.i_fJajYE.js",
      "_isEqual.2WbiwtQN.js",
      "_hasIn.V2LJ5qln.js",
      "_flatten.vEaIzau5.js",
      "_ElImage.IUF2s1z1.js",
      "_debounce.pX8CUAd-.js",
      "_select.o_WkKnqZ.js",
      "_popper.iSU8OKeK.js",
      "_isUndefined.IZwZ21d-.js",
      "_tag.bXVQZ_CA.js",
      "_strings.lS_fR9IB.js",
      "_index.RHC8v-li.js",
      "_input-number.HJiClp0i.js",
      "_index.2Imb-KsY.js",
      "_sku.meA3Ek4K.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_index._-HOwMct.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/shopcart.vue"
  },
  "shopcart.T7K9gx-c.css": {
    "file": "shopcart.T7K9gx-c.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/wallet.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "wallet.JgZZuLIl.css",
      "popover.LAISAeEG.css"
    ],
    "file": "wallet.ZxcchlaB.js",
    "imports": [
      "node_modules/element-plus/es/components/text/index.mjs",
      "node_modules/nuxt/dist/app/entry.js",
      "_create-shadow.ZVmSM78z.js",
      "_progress.RZY92Mej.js",
      "_index.bIniYoEa.js",
      "_popper.iSU8OKeK.js",
      "_bills.HxGYQBow.js",
      "_scrollbar.ORNOMpK6.js",
      "_input-number.HJiClp0i.js",
      "_select.o_WkKnqZ.js",
      "_tag.bXVQZ_CA.js",
      "_localeData.Iw9YzluB.js",
      "_divider.-dVH-PKa.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isUndefined.IZwZ21d-.js",
      "_index.2Imb-KsY.js",
      "_strings.lS_fR9IB.js",
      "_isEqual.2WbiwtQN.js",
      "_debounce.pX8CUAd-.js",
      "_hasIn.V2LJ5qln.js",
      "_index.RHC8v-li.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/wallet.vue"
  },
  "wallet.JgZZuLIl.css": {
    "file": "wallet.JgZZuLIl.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
