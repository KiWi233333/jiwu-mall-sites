const client_manifest = {
  "_ApplyDialog.vue.1e__COkq.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ApplyDialog.vue.1e__COkq.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_dialog.rOyDadKx.js",
      "_notification.QceEx7xQ.js",
      "_friend.oyvYR2y9.js"
    ]
  },
  "_AutoIncre.vue.k83NgvNT.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "AutoIncre.vue.k83NgvNT.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_CategoryTabs.!~{014}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "CategoryTabs.787nBCiN.css",
    "src": "_CategoryTabs.!~{014}~.js"
  },
  "_CategoryTabs.hGsm8gch.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "CategoryTabs.787nBCiN.css"
    ],
    "file": "CategoryTabs.hGsm8gch.js",
    "imports": [
      "_tabs.YHs0qvXw.js",
      "node_modules/nuxt/dist/app/entry.js",
      "components/Comm/PostList.vue",
      "components/list/GoodsList.vue"
    ]
  },
  "CategoryTabs.787nBCiN.css": {
    "file": "CategoryTabs.787nBCiN.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_CommentPreview.!~{019}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "CommentPreview.mYLkOLZt.css",
    "src": "_CommentPreview.!~{019}~.js"
  },
  "_CommentPreview.CjtX3hCl.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "CommentPreview.mYLkOLZt.css"
    ],
    "file": "CommentPreview.CjtX3hCl.js",
    "imports": [
      "_ElImage.o3XwsJBB.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_select.K8Iod6E_.js",
      "_OssFileUpload.OML5B1ON.js",
      "_nuxt-link.w0OLyy5e.js",
      "_tag.AQfsRIUA.js",
      "_AutoIncre.vue.k83NgvNT.js",
      "_scrollbar.sa_8cCgK.js",
      "_popper.PyUaqGjf.js",
      "_notification.QceEx7xQ.js"
    ]
  },
  "CommentPreview.mYLkOLZt.css": {
    "file": "CommentPreview.mYLkOLZt.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_DelayTimer.vue.W0h9L6dM.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "DelayTimer.vue.W0h9L6dM.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_ElImage.!~{00B}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "ElImage.6ybrNKBL.css",
    "src": "_ElImage.!~{00B}~.js"
  },
  "_ElImage.o3XwsJBB.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "ElImage.6ybrNKBL.css"
    ],
    "file": "ElImage.o3XwsJBB.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_debounce.gcXcHc_9.js"
    ]
  },
  "ElImage.6ybrNKBL.css": {
    "file": "ElImage.6ybrNKBL.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_Footer.!~{01Q}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Footer.y5ruypfy.css",
    "src": "_Footer.!~{01Q}~.js"
  },
  "_Footer.80jqEb7I.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "Footer.y5ruypfy.css"
    ],
    "file": "Footer.80jqEb7I.js",
    "imports": [
      "_nuxt-link.w0OLyy5e.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_logo_dark.fboCuseI.js",
      "_Switch._1vn09AW.js"
    ]
  },
  "Footer.y5ruypfy.css": {
    "file": "Footer.y5ruypfy.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_GoodsListSsr.!~{01n}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "GoodsListSsr.P5hBZBtk.css",
    "src": "_GoodsListSsr.!~{01n}~.js"
  },
  "_GoodsListSsr.eB0bUYgv.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "GoodsListSsr.P5hBZBtk.css"
    ],
    "file": "GoodsListSsr.eB0bUYgv.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.QRmbmKRe.js",
      "_nuxt-link.w0OLyy5e.js",
      "node_modules/element-plus/es/components/text/index.mjs"
    ]
  },
  "GoodsListSsr.P5hBZBtk.css": {
    "file": "GoodsListSsr.P5hBZBtk.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_Main.!~{00z}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Main.X0-BW4y4.css",
    "src": "_Main.!~{00z}~.js"
  },
  "_Main.E3TWl6UC.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "Main.X0-BW4y4.css"
    ],
    "file": "Main.E3TWl6UC.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_contact.mtKnYdAr.js",
      "_ElImage.o3XwsJBB.js"
    ]
  },
  "Main.X0-BW4y4.css": {
    "file": "Main.X0-BW4y4.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_OssFileUpload.!~{00W}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "OssFileUpload.f4DKzIfB.css",
    "src": "_OssFileUpload.!~{00W}~.js"
  },
  "_OssFileUpload.OML5B1ON.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "OssFileUpload.f4DKzIfB.css"
    ],
    "file": "OssFileUpload.OML5B1ON.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.o3XwsJBB.js",
      "_progress.8uPnj5lp.js",
      "_index.4VS2Hixh.js"
    ]
  },
  "OssFileUpload.f4DKzIfB.css": {
    "file": "OssFileUpload.f4DKzIfB.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_ShopLine.!~{01K}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "ShopLine.Wq74ulT-.css",
    "src": "_ShopLine.!~{01K}~.js"
  },
  "_ShopLine.fL2HdC7K.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "ShopLine.Wq74ulT-.css"
    ],
    "file": "ShopLine.fL2HdC7K.js",
    "imports": [
      "_ElImage.o3XwsJBB.js",
      "_nuxt-link.w0OLyy5e.js",
      "_select.K8Iod6E_.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_input-number.bAB67xcc.js",
      "_tag.AQfsRIUA.js",
      "_scrollbar.sa_8cCgK.js",
      "_popper.PyUaqGjf.js",
      "_sku.9_xViOEF.js"
    ]
  },
  "ShopLine.Wq74ulT-.css": {
    "file": "ShopLine.Wq74ulT-.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_SigninCard.vue.MRba005L.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "popover.LAISAeEG.css"
    ],
    "file": "SigninCard.vue.MRba005L.js",
    "imports": [
      "_progress.8uPnj5lp.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.VL9-GfT-.js",
      "_popper.PyUaqGjf.js"
    ]
  },
  "popover.LAISAeEG.css": {
    "file": "popover.LAISAeEG.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_StatusTag.!~{01l}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "StatusTag.IETAoY75.css",
    "src": "_StatusTag.!~{01l}~.js"
  },
  "_StatusTag.1G2s6euk.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "StatusTag.IETAoY75.css"
    ],
    "file": "StatusTag.1G2s6euk.js",
    "imports": [
      "_tag.AQfsRIUA.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_post.-pHSimTz.js"
    ]
  },
  "StatusTag.IETAoY75.css": {
    "file": "StatusTag.IETAoY75.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_Switch.!~{01e}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Switch.6FgKIDc6.css",
    "src": "_Switch.!~{01e}~.js"
  },
  "_Switch._1vn09AW.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "Switch.6FgKIDc6.css"
    ],
    "file": "Switch._1vn09AW.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "Switch.6FgKIDc6.css": {
    "file": "Switch.6FgKIDc6.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_TagList.vue.78a36c2a.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TagList.vue.78a36c2a.js",
    "imports": [
      "_tag.AQfsRIUA.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_UserPostTotal.vue.t4NcBYyi.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "UserPostTotal.vue.t4NcBYyi.js",
    "imports": [
      "_ElImage.o3XwsJBB.js",
      "_nuxt-link.w0OLyy5e.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_post.-pHSimTz.js"
    ]
  },
  "___commonjsHelpers__.1J56E-h6.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "__commonjsHelpers__.1J56E-h6.js"
  },
  "_arrays.9GuX8ZvT.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "arrays.9GuX8ZvT.js"
  },
  "_avatar.!~{01J}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "avatar.bZH1-Oig.css",
    "src": "_avatar.!~{01J}~.js"
  },
  "_avatar.Lk7U_SYF.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "avatar.bZH1-Oig.css"
    ],
    "file": "avatar.Lk7U_SYF.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "avatar.bZH1-Oig.css": {
    "file": "avatar.bZH1-Oig.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_bills.Xo-Q7bF_.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "bills.Xo-Q7bF_.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_checkbox-group.!~{01H}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "checkbox-group.d5XbR8TY.css",
    "src": "_checkbox-group.!~{01H}~.js"
  },
  "_checkbox.!~{01y}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "checkbox.MJHvI1xB.css",
    "src": "_checkbox.!~{01y}~.js"
  },
  "_checkbox.-YiuypCJ.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "checkbox.MJHvI1xB.css"
    ],
    "file": "checkbox.-YiuypCJ.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_isEqual.--_JEsOY.js",
      "_hasIn.TlWS3kXH.js",
      "_flatten.MSTacBc6.js"
    ]
  },
  "checkbox.MJHvI1xB.css": {
    "file": "checkbox.MJHvI1xB.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_cloneDeep.2yGkDCYn.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "cloneDeep.2yGkDCYn.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_collect.QvFuKMt4.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "collect.QvFuKMt4.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_contact.mtKnYdAr.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "contact.mtKnYdAr.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_useWs.Wj6yrIto.js"
    ]
  },
  "_create-shadow.8p9Gxjfm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "create-shadow.8p9Gxjfm.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_date-picker.!~{01E}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "date-picker.sSkDKlix.css",
    "src": "_date-picker.!~{01E}~.js"
  },
  "_date-picker.YJ1YnLc6.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "date-picker.sSkDKlix.css"
    ],
    "file": "date-picker.YJ1YnLc6.js",
    "imports": [
      "_localeData.CFSQF4jw.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_arrays.9GuX8ZvT.js",
      "_flatten.MSTacBc6.js",
      "_popper.PyUaqGjf.js",
      "_scrollbar.sa_8cCgK.js",
      "_index.iWTOJU8z.js",
      "_debounce.gcXcHc_9.js",
      "_index.5154XgU3.js",
      "_isEqual.--_JEsOY.js"
    ]
  },
  "date-picker.sSkDKlix.css": {
    "file": "date-picker.sSkDKlix.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_debounce.gcXcHc_9.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "debounce.gcXcHc_9.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_dialog.!~{00Q}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "dialog.mDs1vky2.css",
    "src": "_dialog.!~{00Q}~.js"
  },
  "_dialog.rOyDadKx.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "dialog.mDs1vky2.css"
    ],
    "file": "dialog.rOyDadKx.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_isUndefined.IZwZ21d-.js"
    ]
  },
  "dialog.mDs1vky2.css": {
    "file": "dialog.mDs1vky2.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_divider.!~{00N}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "divider.mvCfgREV.css",
    "src": "_divider.!~{00N}~.js"
  },
  "_divider.AU2dm0Xc.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "divider.mvCfgREV.css"
    ],
    "file": "divider.AU2dm0Xc.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "divider.mvCfgREV.css": {
    "file": "divider.mvCfgREV.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_effect-creative.cSRFyIcO.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "effect-creative.cSRFyIcO.js",
    "imports": [
      "_create-shadow.8p9Gxjfm.js"
    ]
  },
  "_empty.!~{00J}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "empty.sDhVTJEQ.css",
    "src": "_empty.!~{00J}~.js"
  },
  "_empty.3j0PzO1W.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "empty.sDhVTJEQ.css"
    ],
    "file": "empty.3j0PzO1W.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "empty.sDhVTJEQ.css": {
    "file": "empty.sDhVTJEQ.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_flatten.MSTacBc6.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "flatten.MSTacBc6.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_friend.oyvYR2y9.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "friend.oyvYR2y9.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_hasIn.TlWS3kXH.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "hasIn.TlWS3kXH.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.!~{01c}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.BbVs9JM6.css",
    "src": "_index.!~{01c}~.js"
  },
  "_index.4VS2Hixh.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.4VS2Hixh.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ]
  },
  "_index.5154XgU3.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.5154XgU3.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.D8ekCZVn.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.D8ekCZVn.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.QRmbmKRe.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.BbVs9JM6.css"
    ],
    "file": "index.QRmbmKRe.js",
    "imports": [
      "_ElImage.o3XwsJBB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "index.BbVs9JM6.css": {
    "file": "index.BbVs9JM6.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_index.VL9-GfT-.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.VL9-GfT-.js",
    "imports": [
      "_popper.PyUaqGjf.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.WzX4xtfG.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.WzX4xtfG.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.dZinRiMr.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.dZinRiMr.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.e_lt94hP.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.e_lt94hP.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.huUgjEVS.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.huUgjEVS.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.iWTOJU8z.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.iWTOJU8z.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.wGNsytoe.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.wGNsytoe.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_input-number.!~{01p}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "input-number.5AezeF1g.css",
    "src": "_input-number.!~{01p}~.js"
  },
  "_input-number.bAB67xcc.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "input-number.5AezeF1g.css"
    ],
    "file": "input-number.bAB67xcc.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.iWTOJU8z.js"
    ]
  },
  "input-number.5AezeF1g.css": {
    "file": "input-number.5AezeF1g.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_isEqual.--_JEsOY.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "isEqual.--_JEsOY.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_isUndefined.IZwZ21d-.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "isUndefined.IZwZ21d-.js"
  },
  "_localeData.CFSQF4jw.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "localeData.CFSQF4jw.js",
    "imports": [
      "___commonjsHelpers__.1J56E-h6.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_logo_dark.fboCuseI.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "popover.LAISAeEG.css"
    ],
    "dynamicImports": [
      "components/card/UserLine.vue"
    ],
    "file": "logo_dark.fboCuseI.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.w0OLyy5e.js",
      "_scrollbar.sa_8cCgK.js",
      "_index.VL9-GfT-.js",
      "_popper.PyUaqGjf.js"
    ]
  },
  "_menu-item.!~{01O}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "menu-item.f0mNRiTD.css",
    "src": "_tooltip.!~{01I}~.js"
  },
  "_menu.!~{01N}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "menu.6YbFhd-D.css",
    "src": "_menu.!~{01N}~.js"
  },
  "_menu.9V4QrxcK.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "menu.6YbFhd-D.css"
    ],
    "file": "menu.9V4QrxcK.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.huUgjEVS.js",
      "_popper.PyUaqGjf.js",
      "_index.5154XgU3.js"
    ]
  },
  "menu.6YbFhd-D.css": {
    "file": "menu.6YbFhd-D.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_notification.!~{00G}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "notification.8O_B6xHM.css",
    "src": "_notification.!~{00G}~.js"
  },
  "_notification.QceEx7xQ.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "notification.8O_B6xHM.css"
    ],
    "file": "notification.QceEx7xQ.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "notification.8O_B6xHM.css": {
    "file": "notification.8O_B6xHM.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_nuxt-link.w0OLyy5e.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "nuxt-link.w0OLyy5e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_popover.!~{01i}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "popover.LAISAeEG.css",
    "src": "_popover.!~{01i}~.js"
  },
  "_popper.!~{00X}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "popper.nTJkgMH4.css",
    "src": "_popper.!~{00X}~.js"
  },
  "_popper.PyUaqGjf.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "popper.nTJkgMH4.css"
    ],
    "file": "popper.PyUaqGjf.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_isUndefined.IZwZ21d-.js"
    ]
  },
  "popper.nTJkgMH4.css": {
    "file": "popper.nTJkgMH4.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_post.-pHSimTz.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "post.-pHSimTz.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_progress.!~{011}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "progress.rXLlm_9F.css",
    "src": "_progress.!~{011}~.js"
  },
  "_progress.8uPnj5lp.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "progress.rXLlm_9F.css"
    ],
    "file": "progress.8uPnj5lp.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "progress.rXLlm_9F.css": {
    "file": "progress.rXLlm_9F.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_radio-button.!~{012}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "radio-button.l7x146Nf.css",
    "src": "_radio-button.!~{012}~.js"
  },
  "_radio-group.!~{00M}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "radio-group.P_Xz2fNs.css",
    "src": "_radio-group.!~{00M}~.js"
  },
  "_radio.!~{00U}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "radio.eYTrrdr6.css",
    "src": "_radio.!~{00U}~.js"
  },
  "_rate.!~{01s}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "rate.mGuCO7Lx.css",
    "src": "_rate.!~{01s}~.js"
  },
  "_rate.dudl3bDg.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "rate.mGuCO7Lx.css"
    ],
    "file": "rate.dudl3bDg.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "rate.mGuCO7Lx.css": {
    "file": "rate.mGuCO7Lx.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_scrollbar.!~{00A}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "scrollbar.Smf0pYfu.css",
    "src": "_scrollbar.!~{00A}~.js"
  },
  "_scrollbar.sa_8cCgK.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "scrollbar.Smf0pYfu.css"
    ],
    "file": "scrollbar.sa_8cCgK.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "scrollbar.Smf0pYfu.css": {
    "file": "scrollbar.Smf0pYfu.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_select.!~{00V}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "select.xPRdjiL2.css",
    "src": "_select.!~{00V}~.js"
  },
  "_select.K8Iod6E_.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "select.xPRdjiL2.css"
    ],
    "file": "select.K8Iod6E_.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_popper.PyUaqGjf.js",
      "_scrollbar.sa_8cCgK.js",
      "_tag.AQfsRIUA.js",
      "_strings.LW_DAaDk.js",
      "_isEqual.--_JEsOY.js",
      "_debounce.gcXcHc_9.js",
      "_hasIn.TlWS3kXH.js",
      "_index.5154XgU3.js"
    ]
  },
  "select.xPRdjiL2.css": {
    "file": "select.xPRdjiL2.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_sku.9_xViOEF.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sku.9_xViOEF.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_strings.LW_DAaDk.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "strings.LW_DAaDk.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_tabs.!~{015}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "tabs.H-UKPvku.css",
    "src": "_tabs.!~{015}~.js"
  },
  "_tabs.YHs0qvXw.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "tabs.H-UKPvku.css"
    ],
    "file": "tabs.YHs0qvXw.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_strings.LW_DAaDk.js",
      "_index.wGNsytoe.js"
    ]
  },
  "tabs.H-UKPvku.css": {
    "file": "tabs.H-UKPvku.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_tag.!~{00H}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "tag.Wo0upPQu.css",
    "src": "_tag.!~{00H}~.js"
  },
  "_tag.AQfsRIUA.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "tag.Wo0upPQu.css"
    ],
    "file": "tag.AQfsRIUA.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "tag.Wo0upPQu.css": {
    "file": "tag.Wo0upPQu.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_tooltip.!~{01I}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "menu-item.f0mNRiTD.css",
    "src": "_tooltip.!~{01I}~.js"
  },
  "_upload.!~{01x}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "upload.5r92S6hB.css",
    "src": "_upload.!~{01x}~.js"
  },
  "_upload.HXVTQMCu.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "upload.5r92S6hB.css"
    ],
    "file": "upload.HXVTQMCu.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_progress.8uPnj5lp.js",
      "_cloneDeep.2yGkDCYn.js",
      "_isEqual.--_JEsOY.js"
    ]
  },
  "upload.5r92S6hB.css": {
    "file": "upload.5r92S6hB.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_useOrderStore.SGclE4Dp.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useOrderStore.SGclE4Dp.js",
    "imports": [
      "_index.e_lt94hP.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_useWebToast.SWVeK4JP.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useWebToast.SWVeK4JP.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_useWs.Wj6yrIto.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useWs.Wj6yrIto.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_notification.QceEx7xQ.js"
    ]
  },
  "components/Chat/Friend/ApplyDialog.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ApplyDialog.dqFqwFYF.js",
    "imports": [
      "_ApplyDialog.vue.1e__COkq.js",
      "node_modules/nuxt/dist/app/entry.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_dialog.rOyDadKx.js",
      "_isUndefined.IZwZ21d-.js",
      "_notification.QceEx7xQ.js",
      "_friend.oyvYR2y9.js"
    ],
    "isDynamicEntry": true,
    "src": "components/Chat/Friend/ApplyDialog.vue"
  },
  "components/Chat/NewGroupDialog.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "NewGroupDialog.Hm5sbp8R.css",
      "checkbox-group.d5XbR8TY.css"
    ],
    "file": "NewGroupDialog._h9yYVrm.js",
    "imports": [
      "_ElImage.o3XwsJBB.js",
      "_checkbox.-YiuypCJ.js",
      "_AutoIncre.vue.k83NgvNT.js",
      "_scrollbar.sa_8cCgK.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_OssFileUpload.OML5B1ON.js",
      "_dialog.rOyDadKx.js",
      "_notification.QceEx7xQ.js",
      "_contact.mtKnYdAr.js",
      "_Main.E3TWl6UC.js",
      "_friend.oyvYR2y9.js",
      "_debounce.gcXcHc_9.js",
      "_isEqual.--_JEsOY.js",
      "_hasIn.TlWS3kXH.js",
      "_flatten.MSTacBc6.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_progress.8uPnj5lp.js",
      "_index.4VS2Hixh.js",
      "_isUndefined.IZwZ21d-.js",
      "_useWs.Wj6yrIto.js"
    ],
    "isDynamicEntry": true,
    "src": "components/Chat/NewGroupDialog.vue"
  },
  "NewGroupDialog.Hm5sbp8R.css": {
    "file": "NewGroupDialog.Hm5sbp8R.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "checkbox-group.d5XbR8TY.css": {
    "file": "checkbox-group.d5XbR8TY.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/Comm/PostList.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "PostList._i8MVHra.css"
    ],
    "file": "PostList.JyKaOBfV.js",
    "imports": [
      "_ElImage.o3XwsJBB.js",
      "_nuxt-link.w0OLyy5e.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.AQfsRIUA.js",
      "_TagList.vue.78a36c2a.js",
      "_CommentPreview.CjtX3hCl.js",
      "_AutoIncre.vue.k83NgvNT.js",
      "_post.-pHSimTz.js",
      "_debounce.gcXcHc_9.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_select.K8Iod6E_.js",
      "_popper.PyUaqGjf.js",
      "_isUndefined.IZwZ21d-.js",
      "_scrollbar.sa_8cCgK.js",
      "_strings.LW_DAaDk.js",
      "_isEqual.--_JEsOY.js",
      "_hasIn.TlWS3kXH.js",
      "_index.5154XgU3.js",
      "_OssFileUpload.OML5B1ON.js",
      "_progress.8uPnj5lp.js",
      "_index.4VS2Hixh.js",
      "_notification.QceEx7xQ.js"
    ],
    "isDynamicEntry": true,
    "src": "components/Comm/PostList.vue"
  },
  "PostList._i8MVHra.css": {
    "file": "PostList._i8MVHra.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/Comm/post/CateGoryLine.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "CateGoryLine.1pkcUo1n.js",
    "imports": [
      "_ElImage.o3XwsJBB.js",
      "_nuxt-link.w0OLyy5e.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_debounce.gcXcHc_9.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "components/Comm/post/CateGoryLine.vue"
  },
  "components/Comm/post/Rank.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "Rank.y3OSjSFp.css"
    ],
    "file": "Rank.3xAM-PGr.js",
    "imports": [
      "_divider.AU2dm0Xc.js",
      "_tag.AQfsRIUA.js",
      "_ElImage.o3XwsJBB.js",
      "_nuxt-link.w0OLyy5e.js",
      "_empty.3j0PzO1W.js",
      "_scrollbar.sa_8cCgK.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_post.-pHSimTz.js",
      "_debounce.gcXcHc_9.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "components/Comm/post/Rank.vue"
  },
  "Rank.y3OSjSFp.css": {
    "file": "Rank.y3OSjSFp.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/card/UserLine.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "UserLine.G_lnDfVq.css",
      "popover.LAISAeEG.css"
    ],
    "file": "UserLine.ZRIoEgW6.js",
    "imports": [
      "_avatar.Lk7U_SYF.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_upload.HXVTQMCu.js",
      "_nuxt-link.w0OLyy5e.js",
      "_index.VL9-GfT-.js",
      "_progress.8uPnj5lp.js",
      "_popper.PyUaqGjf.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_cloneDeep.2yGkDCYn.js",
      "_isEqual.--_JEsOY.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "components/card/UserLine.vue"
  },
  "UserLine.G_lnDfVq.css": {
    "file": "UserLine.G_lnDfVq.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/list/GoodsList.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "GoodsList.1p6fEF-7.css"
    ],
    "file": "GoodsList.M6nyp6nd.js",
    "imports": [
      "_index.QRmbmKRe.js",
      "_nuxt-link.w0OLyy5e.js",
      "_AutoIncre.vue.k83NgvNT.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.o3XwsJBB.js",
      "_debounce.gcXcHc_9.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "components/list/GoodsList.vue"
  },
  "GoodsList.1p6fEF-7.css": {
    "file": "GoodsList.1p6fEF-7.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/menu/DrawerMenu.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "DrawerMenu.0ja6gThp.css",
      "menu-item.f0mNRiTD.css",
      "popover.LAISAeEG.css"
    ],
    "file": "DrawerMenu.3N20QURr.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_menu.9V4QrxcK.js",
      "_scrollbar.sa_8cCgK.js",
      "_popper.PyUaqGjf.js",
      "_logo_dark.fboCuseI.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_index.huUgjEVS.js",
      "_index.5154XgU3.js",
      "_isUndefined.IZwZ21d-.js",
      "_nuxt-link.w0OLyy5e.js",
      "_index.VL9-GfT-.js"
    ],
    "isDynamicEntry": true,
    "src": "components/menu/DrawerMenu.vue"
  },
  "DrawerMenu.0ja6gThp.css": {
    "file": "DrawerMenu.0ja6gThp.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "menu-item.f0mNRiTD.css": {
    "file": "menu-item.f0mNRiTD.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/menu/RightButtons/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.8SbgYM8h.css",
      "popover.LAISAeEG.css",
      "menu-item.f0mNRiTD.css"
    ],
    "dynamicImports": [
      "components/menu/ShopCartBar.vue"
    ],
    "file": "index.6vmICbJU.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.w0OLyy5e.js",
      "_Main.E3TWl6UC.js",
      "_scrollbar.sa_8cCgK.js",
      "_ElImage.o3XwsJBB.js",
      "_index.VL9-GfT-.js",
      "_popper.PyUaqGjf.js",
      "_contact.mtKnYdAr.js",
      "_useWs.Wj6yrIto.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.gcXcHc_9.js",
      "_isUndefined.IZwZ21d-.js",
      "_notification.QceEx7xQ.js"
    ],
    "isDynamicEntry": true,
    "src": "components/menu/RightButtons/index.vue"
  },
  "index.8SbgYM8h.css": {
    "file": "index.8SbgYM8h.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/menu/ShopCartBar.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "ShopCartBar.BHANagyi.css",
      "checkbox-group.d5XbR8TY.css",
      "popover.LAISAeEG.css"
    ],
    "file": "ShopCartBar.qE-h-Ha0.js",
    "imports": [
      "_checkbox.-YiuypCJ.js",
      "_ShopLine.fL2HdC7K.js",
      "_AutoIncre.vue.k83NgvNT.js",
      "_scrollbar.sa_8cCgK.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.VL9-GfT-.js",
      "_popper.PyUaqGjf.js",
      "_useOrderStore.SGclE4Dp.js",
      "_isEqual.--_JEsOY.js",
      "_hasIn.TlWS3kXH.js",
      "_flatten.MSTacBc6.js",
      "_ElImage.o3XwsJBB.js",
      "_debounce.gcXcHc_9.js",
      "_nuxt-link.w0OLyy5e.js",
      "_select.K8Iod6E_.js",
      "_tag.AQfsRIUA.js",
      "_strings.LW_DAaDk.js",
      "_index.5154XgU3.js",
      "_input-number.bAB67xcc.js",
      "_index.iWTOJU8z.js",
      "_sku.9_xViOEF.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isUndefined.IZwZ21d-.js",
      "_index.e_lt94hP.js"
    ],
    "isDynamicEntry": true,
    "src": "components/menu/ShopCartBar.vue"
  },
  "ShopCartBar.BHANagyi.css": {
    "file": "ShopCartBar.BHANagyi.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "layouts/chat.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "chat.vRH9Isjp.css",
      "menu-item.f0mNRiTD.css",
      "popover.LAISAeEG.css"
    ],
    "dynamicImports": [
      "components/menu/RightButtons/index.vue"
    ],
    "file": "chat.ZukGd9Fd.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.o3XwsJBB.js",
      "components/card/UserLine.vue",
      "_menu.9V4QrxcK.js",
      "_popper.PyUaqGjf.js",
      "_useWs.Wj6yrIto.js",
      "_friend.oyvYR2y9.js",
      "_useWebToast.SWVeK4JP.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.gcXcHc_9.js",
      "_avatar.Lk7U_SYF.js",
      "_upload.HXVTQMCu.js",
      "_progress.8uPnj5lp.js",
      "_cloneDeep.2yGkDCYn.js",
      "_isEqual.--_JEsOY.js",
      "_nuxt-link.w0OLyy5e.js",
      "_index.VL9-GfT-.js",
      "_index.huUgjEVS.js",
      "_index.5154XgU3.js",
      "_isUndefined.IZwZ21d-.js",
      "_notification.QceEx7xQ.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/chat.vue"
  },
  "chat.vRH9Isjp.css": {
    "file": "chat.vRH9Isjp.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "layouts/error.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "error.4lAroaHM.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/error.vue"
  },
  "layouts/main.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "popover.LAISAeEG.css",
      "menu-item.f0mNRiTD.css"
    ],
    "dynamicImports": [
      "components/menu/DrawerMenu.vue"
    ],
    "file": "main.fLLoqu7D.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_Footer.80jqEb7I.js",
      "components/menu/RightButtons/index.vue",
      "___commonjsHelpers__.1J56E-h6.js",
      "_nuxt-link.w0OLyy5e.js",
      "_logo_dark.fboCuseI.js",
      "_scrollbar.sa_8cCgK.js",
      "_index.VL9-GfT-.js",
      "_popper.PyUaqGjf.js",
      "_isUndefined.IZwZ21d-.js",
      "_Switch._1vn09AW.js",
      "_Main.E3TWl6UC.js",
      "_contact.mtKnYdAr.js",
      "_useWs.Wj6yrIto.js",
      "_notification.QceEx7xQ.js",
      "_ElImage.o3XwsJBB.js",
      "_debounce.gcXcHc_9.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/main.vue"
  },
  "layouts/second.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "second.JqdAvVfB.css",
      "popover.LAISAeEG.css",
      "menu-item.f0mNRiTD.css"
    ],
    "file": "second.z7hp5pTJ.js",
    "imports": [
      "_Footer.80jqEb7I.js",
      "components/menu/RightButtons/index.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.w0OLyy5e.js",
      "_logo_dark.fboCuseI.js",
      "_scrollbar.sa_8cCgK.js",
      "_index.VL9-GfT-.js",
      "_popper.PyUaqGjf.js",
      "_isUndefined.IZwZ21d-.js",
      "_Switch._1vn09AW.js",
      "_Main.E3TWl6UC.js",
      "_contact.mtKnYdAr.js",
      "_useWs.Wj6yrIto.js",
      "_notification.QceEx7xQ.js",
      "_ElImage.o3XwsJBB.js",
      "_debounce.gcXcHc_9.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/second.vue"
  },
  "second.JqdAvVfB.css": {
    "file": "second.JqdAvVfB.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "layouts/user.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "user.yAuj-VgQ.css",
      "menu-item.f0mNRiTD.css",
      "popover.LAISAeEG.css"
    ],
    "file": "user.k5Lszula.js",
    "imports": [
      "_nuxt-link.w0OLyy5e.js",
      "_logo_dark.fboCuseI.js",
      "_Switch._1vn09AW.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_menu.9V4QrxcK.js",
      "_popper.PyUaqGjf.js",
      "components/menu/RightButtons/index.vue",
      "_scrollbar.sa_8cCgK.js",
      "_index.VL9-GfT-.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_index.huUgjEVS.js",
      "_index.5154XgU3.js",
      "_isUndefined.IZwZ21d-.js",
      "_Main.E3TWl6UC.js",
      "_contact.mtKnYdAr.js",
      "_useWs.Wj6yrIto.js",
      "_notification.QceEx7xQ.js",
      "_ElImage.o3XwsJBB.js",
      "_debounce.gcXcHc_9.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/user.vue"
  },
  "user.yAuj-VgQ.css": {
    "file": "user.yAuj-VgQ.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/element-plus/es/components/text/index.mjs": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.l5CC8IXT.css"
    ],
    "file": "index.0dtm03h2.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/element-plus/es/components/text/index.mjs"
  },
  "index.l5CC8IXT.css": {
    "file": "index.l5CC8IXT.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "entry.ykJ8RAK6.css"
    ],
    "dynamicImports": [
      "layouts/chat.vue",
      "layouts/error.vue",
      "layouts/main.vue",
      "layouts/second.vue",
      "layouts/user.vue",
      "node_modules/workbox-window/build/workbox-window.prod.es5.mjs"
    ],
    "file": "entry.8ecdJnBa.js",
    "imports": [
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js"
  },
  "entry.ykJ8RAK6.css": {
    "file": "entry.ykJ8RAK6.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/workbox-window/build/workbox-window.prod.es5.mjs": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "workbox-window.prod.es5.prqDwDSL.js",
    "isDynamicEntry": true,
    "src": "node_modules/workbox-window/build/workbox-window.prod.es5.mjs"
  },
  "pages/[...all].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_...all_.4-X8lsGk.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/[...all].vue"
  },
  "pages/chat/ai.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "ai.Si4xrm0l.css"
    ],
    "file": "ai.piNK2aC8.js",
    "imports": [
      "_Main.E3TWl6UC.js",
      "_scrollbar.sa_8cCgK.js",
      "_ElImage.o3XwsJBB.js",
      "_nuxt-link.w0OLyy5e.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_contact.mtKnYdAr.js",
      "_useWs.Wj6yrIto.js",
      "_debounce.gcXcHc_9.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_notification.QceEx7xQ.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/chat/ai.vue"
  },
  "ai.Si4xrm0l.css": {
    "file": "ai.Si4xrm0l.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/chat/friend.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "friend.IKhbuxAS.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "file": "friend.anftjoke.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.AQfsRIUA.js",
      "_ElImage.o3XwsJBB.js",
      "_AutoIncre.vue.k83NgvNT.js",
      "_scrollbar.sa_8cCgK.js",
      "_empty.3j0PzO1W.js",
      "_friend.oyvYR2y9.js",
      "_index.WzX4xtfG.js",
      "_contact.mtKnYdAr.js",
      "_useWs.Wj6yrIto.js",
      "_notification.QceEx7xQ.js",
      "_divider.AU2dm0Xc.js",
      "_ApplyDialog.vue.1e__COkq.js",
      "_index.D8ekCZVn.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.gcXcHc_9.js",
      "_dialog.rOyDadKx.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/chat/friend.vue"
  },
  "friend.IKhbuxAS.css": {
    "file": "friend.IKhbuxAS.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "radio-group.P_Xz2fNs.css": {
    "file": "radio-group.P_Xz2fNs.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/chat/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.A1sjmNyw.css",
      "radio.eYTrrdr6.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "dynamicImports": [
      "components/Chat/NewGroupDialog.vue",
      "components/Chat/NewGroupDialog.vue",
      "components/Chat/Friend/ApplyDialog.vue"
    ],
    "file": "index.17c2Z6DJ.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.o3XwsJBB.js",
      "_index.WzX4xtfG.js",
      "_AutoIncre.vue.k83NgvNT.js",
      "_notification.QceEx7xQ.js",
      "_contact.mtKnYdAr.js",
      "_Main.E3TWl6UC.js",
      "_friend.oyvYR2y9.js",
      "_useWs.Wj6yrIto.js",
      "_tag.AQfsRIUA.js",
      "_scrollbar.sa_8cCgK.js",
      "_select.K8Iod6E_.js",
      "_OssFileUpload.OML5B1ON.js",
      "_nuxt-link.w0OLyy5e.js",
      "_popper.PyUaqGjf.js",
      "_index.4VS2Hixh.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.gcXcHc_9.js",
      "_strings.LW_DAaDk.js",
      "_isEqual.--_JEsOY.js",
      "_hasIn.TlWS3kXH.js",
      "_index.5154XgU3.js",
      "_progress.8uPnj5lp.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/chat/index.vue"
  },
  "index.A1sjmNyw.css": {
    "file": "index.A1sjmNyw.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "radio.eYTrrdr6.css": {
    "file": "radio.eYTrrdr6.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/chat/setting.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "setting.SSmFdXUR.css",
      "radio-button.l7x146Nf.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "file": "setting.P_9Gt1b4.js",
    "imports": [
      "_divider.AU2dm0Xc.js",
      "_select.K8Iod6E_.js",
      "_index.WzX4xtfG.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.AQfsRIUA.js",
      "_scrollbar.sa_8cCgK.js",
      "_popper.PyUaqGjf.js",
      "_notification.QceEx7xQ.js",
      "_strings.LW_DAaDk.js",
      "_isEqual.--_JEsOY.js",
      "_debounce.gcXcHc_9.js",
      "_hasIn.TlWS3kXH.js",
      "_index.5154XgU3.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/chat/setting.vue"
  },
  "setting.SSmFdXUR.css": {
    "file": "setting.SSmFdXUR.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "radio-button.l7x146Nf.css": {
    "file": "radio-button.l7x146Nf.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/category/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "_id_.uLLhAsoU.css"
    ],
    "dynamicImports": [
      "components/Comm/post/Rank.vue"
    ],
    "file": "_id_.hf1fzK64.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.o3XwsJBB.js",
      "_CategoryTabs.hGsm8gch.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.gcXcHc_9.js",
      "_tabs.YHs0qvXw.js",
      "_strings.LW_DAaDk.js",
      "_index.wGNsytoe.js",
      "components/Comm/PostList.vue",
      "_nuxt-link.w0OLyy5e.js",
      "_tag.AQfsRIUA.js",
      "_TagList.vue.78a36c2a.js",
      "_CommentPreview.CjtX3hCl.js",
      "_select.K8Iod6E_.js",
      "_popper.PyUaqGjf.js",
      "_isUndefined.IZwZ21d-.js",
      "_scrollbar.sa_8cCgK.js",
      "_isEqual.--_JEsOY.js",
      "_hasIn.TlWS3kXH.js",
      "_index.5154XgU3.js",
      "_OssFileUpload.OML5B1ON.js",
      "_progress.8uPnj5lp.js",
      "_index.4VS2Hixh.js",
      "_AutoIncre.vue.k83NgvNT.js",
      "_notification.QceEx7xQ.js",
      "_post.-pHSimTz.js",
      "components/list/GoodsList.vue",
      "_index.QRmbmKRe.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/category/[id].vue"
  },
  "_id_.uLLhAsoU.css": {
    "file": "_id_.uLLhAsoU.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/category/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.EaIT1GIC.css"
    ],
    "dynamicImports": [
      "components/Comm/post/Rank.vue"
    ],
    "file": "index.0q-pSdWp.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_CategoryTabs.hGsm8gch.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_tabs.YHs0qvXw.js",
      "_strings.LW_DAaDk.js",
      "_index.wGNsytoe.js",
      "components/Comm/PostList.vue",
      "_ElImage.o3XwsJBB.js",
      "_debounce.gcXcHc_9.js",
      "_nuxt-link.w0OLyy5e.js",
      "_tag.AQfsRIUA.js",
      "_TagList.vue.78a36c2a.js",
      "_CommentPreview.CjtX3hCl.js",
      "_select.K8Iod6E_.js",
      "_popper.PyUaqGjf.js",
      "_isUndefined.IZwZ21d-.js",
      "_scrollbar.sa_8cCgK.js",
      "_isEqual.--_JEsOY.js",
      "_hasIn.TlWS3kXH.js",
      "_index.5154XgU3.js",
      "_OssFileUpload.OML5B1ON.js",
      "_progress.8uPnj5lp.js",
      "_index.4VS2Hixh.js",
      "_AutoIncre.vue.k83NgvNT.js",
      "_notification.QceEx7xQ.js",
      "_post.-pHSimTz.js",
      "components/list/GoodsList.vue",
      "_index.QRmbmKRe.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/category/index.vue"
  },
  "index.EaIT1GIC.css": {
    "file": "index.EaIT1GIC.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/post/detail/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "_id_.8W7c6sq_.css",
      "popover.LAISAeEG.css"
    ],
    "dynamicImports": [
      "components/Comm/post/CateGoryLine.vue"
    ],
    "file": "_id_.2MwvuV0h.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.o3XwsJBB.js",
      "_Switch._1vn09AW.js",
      "_tag.AQfsRIUA.js",
      "_nuxt-link.w0OLyy5e.js",
      "_TagList.vue.78a36c2a.js",
      "_divider.AU2dm0Xc.js",
      "_post.-pHSimTz.js",
      "_CommentPreview.CjtX3hCl.js",
      "_UserPostTotal.vue.t4NcBYyi.js",
      "_SigninCard.vue.MRba005L.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.gcXcHc_9.js",
      "_select.K8Iod6E_.js",
      "_popper.PyUaqGjf.js",
      "_isUndefined.IZwZ21d-.js",
      "_scrollbar.sa_8cCgK.js",
      "_strings.LW_DAaDk.js",
      "_isEqual.--_JEsOY.js",
      "_hasIn.TlWS3kXH.js",
      "_index.5154XgU3.js",
      "_OssFileUpload.OML5B1ON.js",
      "_progress.8uPnj5lp.js",
      "_index.4VS2Hixh.js",
      "_AutoIncre.vue.k83NgvNT.js",
      "_notification.QceEx7xQ.js",
      "_index.VL9-GfT-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/post/detail/[id].vue"
  },
  "_id_.8W7c6sq_.css": {
    "file": "_id_.8W7c6sq_.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/post/list.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "list.aADC_aru.css",
      "popover.LAISAeEG.css"
    ],
    "file": "list.QftlHNDg.js",
    "imports": [
      "_nuxt-link.w0OLyy5e.js",
      "_tag.AQfsRIUA.js",
      "_create-shadow.8p9Gxjfm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_effect-creative.cSRFyIcO.js",
      "_post.-pHSimTz.js",
      "_ElImage.o3XwsJBB.js",
      "components/Comm/PostList.vue",
      "_tabs.YHs0qvXw.js",
      "_SigninCard.vue.MRba005L.js",
      "components/Comm/post/Rank.vue",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.gcXcHc_9.js",
      "_TagList.vue.78a36c2a.js",
      "_CommentPreview.CjtX3hCl.js",
      "_select.K8Iod6E_.js",
      "_popper.PyUaqGjf.js",
      "_isUndefined.IZwZ21d-.js",
      "_scrollbar.sa_8cCgK.js",
      "_strings.LW_DAaDk.js",
      "_isEqual.--_JEsOY.js",
      "_hasIn.TlWS3kXH.js",
      "_index.5154XgU3.js",
      "_OssFileUpload.OML5B1ON.js",
      "_progress.8uPnj5lp.js",
      "_index.4VS2Hixh.js",
      "_AutoIncre.vue.k83NgvNT.js",
      "_notification.QceEx7xQ.js",
      "_index.wGNsytoe.js",
      "_index.VL9-GfT-.js",
      "_divider.AU2dm0Xc.js",
      "_empty.3j0PzO1W.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/post/list.vue"
  },
  "list.aADC_aru.css": {
    "file": "list.aADC_aru.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/post/new.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "new.9wZIBQf0.css",
      "radio-button.l7x146Nf.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "file": "new.4S7weJ0v.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_OssFileUpload.OML5B1ON.js",
      "_index.WzX4xtfG.js",
      "_ElImage.o3XwsJBB.js",
      "_select.K8Iod6E_.js",
      "_tag.AQfsRIUA.js",
      "_scrollbar.sa_8cCgK.js",
      "_popper.PyUaqGjf.js",
      "_notification.QceEx7xQ.js",
      "_index.4VS2Hixh.js",
      "_StatusTag.1G2s6euk.js",
      "_post.-pHSimTz.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_progress.8uPnj5lp.js",
      "_debounce.gcXcHc_9.js",
      "_strings.LW_DAaDk.js",
      "_isEqual.--_JEsOY.js",
      "_hasIn.TlWS3kXH.js",
      "_index.5154XgU3.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/post/new.vue"
  },
  "new.9wZIBQf0.css": {
    "file": "new.9wZIBQf0.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/event/detail/[eid].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "_eid_.NtANQ6Xa.css"
    ],
    "file": "_eid_.gc5QaWzE.js",
    "imports": [
      "_ElImage.o3XwsJBB.js",
      "_tag.AQfsRIUA.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.w0OLyy5e.js",
      "_index.dZinRiMr.js",
      "_debounce.gcXcHc_9.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/event/detail/[eid].vue"
  },
  "_eid_.NtANQ6Xa.css": {
    "file": "_eid_.NtANQ6Xa.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/goods/comments/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_id_.yuDdcIqb.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/goods/comments/[id].vue"
  },
  "pages/goods/detail/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "_id_.spxRS6Bk.css",
      "popover.LAISAeEG.css",
      "radio-button.l7x146Nf.css",
      "radio-group.P_Xz2fNs.css",
      "radio.eYTrrdr6.css"
    ],
    "file": "_id_.N0phuy3g.js",
    "imports": [
      "_nuxt-link.w0OLyy5e.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_GoodsListSsr.eB0bUYgv.js",
      "_ElImage.o3XwsJBB.js",
      "_index.wGNsytoe.js",
      "_scrollbar.sa_8cCgK.js",
      "_tag.AQfsRIUA.js",
      "_popper.PyUaqGjf.js",
      "_collect.QvFuKMt4.js",
      "_index.WzX4xtfG.js",
      "_input-number.bAB67xcc.js",
      "_useOrderStore.SGclE4Dp.js",
      "_index.dZinRiMr.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_tabs.YHs0qvXw.js",
      "_rate.dudl3bDg.js",
      "_AutoIncre.vue.k83NgvNT.js",
      "_dialog.rOyDadKx.js",
      "_index.huUgjEVS.js",
      "_index.QRmbmKRe.js",
      "_sku.9_xViOEF.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.gcXcHc_9.js",
      "_isUndefined.IZwZ21d-.js",
      "_index.iWTOJU8z.js",
      "_index.e_lt94hP.js",
      "_strings.LW_DAaDk.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/goods/detail/[id].vue"
  },
  "_id_.spxRS6Bk.css": {
    "file": "_id_.spxRS6Bk.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.IfgpexZK.css",
      "popover.LAISAeEG.css"
    ],
    "dynamicImports": [
      "components/list/GoodsList.vue"
    ],
    "file": "index.CB7quNGP.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.AQfsRIUA.js",
      "_nuxt-link.w0OLyy5e.js",
      "_AutoIncre.vue.k83NgvNT.js",
      "_empty.3j0PzO1W.js",
      "_scrollbar.sa_8cCgK.js",
      "_index.VL9-GfT-.js",
      "_popper.PyUaqGjf.js",
      "_index.QRmbmKRe.js",
      "_create-shadow.8p9Gxjfm.js",
      "_effect-creative.cSRFyIcO.js",
      "_index.dZinRiMr.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_GoodsListSsr.eB0bUYgv.js",
      "_tabs.YHs0qvXw.js",
      "_ElImage.o3XwsJBB.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isUndefined.IZwZ21d-.js",
      "_strings.LW_DAaDk.js",
      "_index.wGNsytoe.js",
      "_debounce.gcXcHc_9.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.IfgpexZK.css": {
    "file": "index.IfgpexZK.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/order/comment/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "_id_.65PfMBS2.css"
    ],
    "file": "_id_.IzRasDKI.js",
    "imports": [
      "_Switch._1vn09AW.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_progress.8uPnj5lp.js",
      "_upload.HXVTQMCu.js",
      "_dialog.rOyDadKx.js",
      "_index.4VS2Hixh.js",
      "_ElImage.o3XwsJBB.js",
      "_rate.dudl3bDg.js",
      "_checkbox.-YiuypCJ.js",
      "_nuxt-link.w0OLyy5e.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_notification.QceEx7xQ.js",
      "_index.e_lt94hP.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_cloneDeep.2yGkDCYn.js",
      "_isEqual.--_JEsOY.js",
      "_isUndefined.IZwZ21d-.js",
      "_debounce.gcXcHc_9.js",
      "_hasIn.TlWS3kXH.js",
      "_flatten.MSTacBc6.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/order/comment/[id].vue"
  },
  "_id_.65PfMBS2.css": {
    "file": "_id_.65PfMBS2.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/order/detail.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "detail.Cx51aE1F.css",
      "radio.eYTrrdr6.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "dynamicImports": [
      "node_modules/element-plus/es/components/text/index.mjs"
    ],
    "file": "detail.Z3kWc2M_.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.o3XwsJBB.js",
      "_nuxt-link.w0OLyy5e.js",
      "_divider.AU2dm0Xc.js",
      "_DelayTimer.vue.W0h9L6dM.js",
      "_Switch._1vn09AW.js",
      "_index.wGNsytoe.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_bills.Xo-Q7bF_.js",
      "_index.e_lt94hP.js",
      "_useOrderStore.SGclE4Dp.js",
      "_index.WzX4xtfG.js",
      "_tag.AQfsRIUA.js",
      "_scrollbar.sa_8cCgK.js",
      "_select.K8Iod6E_.js",
      "_input-number.bAB67xcc.js",
      "_popper.PyUaqGjf.js",
      "_index.dZinRiMr.js",
      "_sku.9_xViOEF.js",
      "_empty.3j0PzO1W.js",
      "_notification.QceEx7xQ.js",
      "_useWebToast.SWVeK4JP.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.gcXcHc_9.js",
      "_strings.LW_DAaDk.js",
      "_isEqual.--_JEsOY.js",
      "_hasIn.TlWS3kXH.js",
      "_index.5154XgU3.js",
      "_index.iWTOJU8z.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/order/detail.vue"
  },
  "detail.Cx51aE1F.css": {
    "file": "detail.Cx51aE1F.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/order/list.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "list.pKmG3IwD.css"
    ],
    "file": "list.w3CjJMk9.js",
    "imports": [
      "_divider.AU2dm0Xc.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_date-picker.YJ1YnLc6.js",
      "_DelayTimer.vue.W0h9L6dM.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_ElImage.o3XwsJBB.js",
      "_tag.AQfsRIUA.js",
      "_useOrderStore.SGclE4Dp.js",
      "_index.e_lt94hP.js",
      "_AutoIncre.vue.k83NgvNT.js",
      "_scrollbar.sa_8cCgK.js",
      "_popper.PyUaqGjf.js",
      "_notification.QceEx7xQ.js",
      "_tabs.YHs0qvXw.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_localeData.CFSQF4jw.js",
      "_arrays.9GuX8ZvT.js",
      "_flatten.MSTacBc6.js",
      "_index.iWTOJU8z.js",
      "_debounce.gcXcHc_9.js",
      "_index.5154XgU3.js",
      "_isEqual.--_JEsOY.js",
      "_isUndefined.IZwZ21d-.js",
      "_strings.LW_DAaDk.js",
      "_index.wGNsytoe.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/order/list.vue"
  },
  "list.pKmG3IwD.css": {
    "file": "list.pKmG3IwD.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/search/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.avLsXlFQ.css"
    ],
    "dynamicImports": [
      "components/list/GoodsList.vue",
      "components/Comm/PostList.vue"
    ],
    "file": "index.cLQqWhoa.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_checkbox.-YiuypCJ.js",
      "_select.K8Iod6E_.js",
      "_tag.AQfsRIUA.js",
      "_tabs.YHs0qvXw.js",
      "_empty.3j0PzO1W.js",
      "_scrollbar.sa_8cCgK.js",
      "_popper.PyUaqGjf.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isEqual.--_JEsOY.js",
      "_hasIn.TlWS3kXH.js",
      "_flatten.MSTacBc6.js",
      "_strings.LW_DAaDk.js",
      "_debounce.gcXcHc_9.js",
      "_index.5154XgU3.js",
      "_index.wGNsytoe.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/search/index.vue"
  },
  "index.avLsXlFQ.css": {
    "file": "index.avLsXlFQ.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/setting/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.z1SuaKix.css",
      "radio-button.l7x146Nf.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "file": "index.hShCwzVl.js",
    "imports": [
      "_divider.AU2dm0Xc.js",
      "_select.K8Iod6E_.js",
      "_index.WzX4xtfG.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.AQfsRIUA.js",
      "_scrollbar.sa_8cCgK.js",
      "_popper.PyUaqGjf.js",
      "_notification.QceEx7xQ.js",
      "_strings.LW_DAaDk.js",
      "_isEqual.--_JEsOY.js",
      "_debounce.gcXcHc_9.js",
      "_hasIn.TlWS3kXH.js",
      "_index.5154XgU3.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/setting/index.vue"
  },
  "index.z1SuaKix.css": {
    "file": "index.z1SuaKix.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/address.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "address.1z3UCWAo.css",
      "radio.eYTrrdr6.css",
      "checkbox-group.d5XbR8TY.css"
    ],
    "file": "address.gH8CUgcI.js",
    "imports": [
      "node_modules/element-plus/es/components/text/index.mjs",
      "node_modules/nuxt/dist/app/entry.js",
      "_scrollbar.sa_8cCgK.js",
      "_checkbox.-YiuypCJ.js",
      "_index.WzX4xtfG.js",
      "_strings.LW_DAaDk.js",
      "_isEqual.--_JEsOY.js",
      "_arrays.9GuX8ZvT.js",
      "_flatten.MSTacBc6.js",
      "_cloneDeep.2yGkDCYn.js",
      "_popper.PyUaqGjf.js",
      "_tag.AQfsRIUA.js",
      "_index.5154XgU3.js",
      "_debounce.gcXcHc_9.js",
      "_dialog.rOyDadKx.js",
      "_divider.AU2dm0Xc.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_hasIn.TlWS3kXH.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/address.vue"
  },
  "address.1z3UCWAo.css": {
    "file": "address.1z3UCWAo.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/collect.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "collect.4jK4CO3w.css",
      "checkbox-group.d5XbR8TY.css"
    ],
    "file": "collect._DvvW1Wh.js",
    "imports": [
      "_divider.AU2dm0Xc.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_checkbox.-YiuypCJ.js",
      "_ElImage.o3XwsJBB.js",
      "_scrollbar.sa_8cCgK.js",
      "_collect.QvFuKMt4.js",
      "_tabs.YHs0qvXw.js",
      "_tag.AQfsRIUA.js",
      "_nuxt-link.w0OLyy5e.js",
      "_TagList.vue.78a36c2a.js",
      "_AutoIncre.vue.k83NgvNT.js",
      "_post.-pHSimTz.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isEqual.--_JEsOY.js",
      "_hasIn.TlWS3kXH.js",
      "_flatten.MSTacBc6.js",
      "_debounce.gcXcHc_9.js",
      "_strings.LW_DAaDk.js",
      "_index.wGNsytoe.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/collect.vue"
  },
  "collect.4jK4CO3w.css": {
    "file": "collect.4jK4CO3w.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/info.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "info.ZO--Iv68.css",
      "popover.LAISAeEG.css",
      "menu-item.f0mNRiTD.css"
    ],
    "file": "info.W6r5eF7F.js",
    "imports": [
      "_ElImage.o3XwsJBB.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.VL9-GfT-.js",
      "_popper.PyUaqGjf.js",
      "_upload.HXVTQMCu.js",
      "_date-picker.YJ1YnLc6.js",
      "_select.K8Iod6E_.js",
      "_progress.8uPnj5lp.js",
      "_scrollbar.sa_8cCgK.js",
      "_tag.AQfsRIUA.js",
      "_nuxt-link.w0OLyy5e.js",
      "_TagList.vue.78a36c2a.js",
      "_AutoIncre.vue.k83NgvNT.js",
      "_post.-pHSimTz.js",
      "_tabs.YHs0qvXw.js",
      "_UserPostTotal.vue.t4NcBYyi.js",
      "_SigninCard.vue.MRba005L.js",
      "_index.D8ekCZVn.js",
      "_debounce.gcXcHc_9.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isUndefined.IZwZ21d-.js",
      "_cloneDeep.2yGkDCYn.js",
      "_isEqual.--_JEsOY.js",
      "_localeData.CFSQF4jw.js",
      "_arrays.9GuX8ZvT.js",
      "_flatten.MSTacBc6.js",
      "_index.iWTOJU8z.js",
      "_index.5154XgU3.js",
      "_strings.LW_DAaDk.js",
      "_hasIn.TlWS3kXH.js",
      "_index.wGNsytoe.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/info.vue"
  },
  "info.ZO--Iv68.css": {
    "file": "info.ZO--Iv68.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/post.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "post.yVQn8Ib0.css"
    ],
    "file": "post.P0AEn31u.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.o3XwsJBB.js",
      "_select.K8Iod6E_.js",
      "_tag.AQfsRIUA.js",
      "_scrollbar.sa_8cCgK.js",
      "_popper.PyUaqGjf.js",
      "_StatusTag.1G2s6euk.js",
      "_nuxt-link.w0OLyy5e.js",
      "_TagList.vue.78a36c2a.js",
      "_post.-pHSimTz.js",
      "_AutoIncre.vue.k83NgvNT.js",
      "_notification.QceEx7xQ.js",
      "_tabs.YHs0qvXw.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.gcXcHc_9.js",
      "_strings.LW_DAaDk.js",
      "_isEqual.--_JEsOY.js",
      "_hasIn.TlWS3kXH.js",
      "_index.5154XgU3.js",
      "_isUndefined.IZwZ21d-.js",
      "_index.wGNsytoe.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/post.vue"
  },
  "post.yVQn8Ib0.css": {
    "file": "post.yVQn8Ib0.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/safe.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "safe.73roRH3g.css"
    ],
    "file": "safe.7i_hbRPu.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.AQfsRIUA.js",
      "_scrollbar.sa_8cCgK.js",
      "_avatar.Lk7U_SYF.js",
      "_divider.AU2dm0Xc.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_useOrderStore.SGclE4Dp.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_index.e_lt94hP.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/safe.vue"
  },
  "safe.73roRH3g.css": {
    "file": "safe.73roRH3g.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/shopcart.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "shopcart.T7K9gx-c.css",
      "checkbox-group.d5XbR8TY.css"
    ],
    "file": "shopcart.OO5yKXy3.js",
    "imports": [
      "_checkbox.-YiuypCJ.js",
      "_ShopLine.fL2HdC7K.js",
      "_nuxt-link.w0OLyy5e.js",
      "_AutoIncre.vue.k83NgvNT.js",
      "_scrollbar.sa_8cCgK.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useOrderStore.SGclE4Dp.js",
      "_isEqual.--_JEsOY.js",
      "_hasIn.TlWS3kXH.js",
      "_flatten.MSTacBc6.js",
      "_ElImage.o3XwsJBB.js",
      "_debounce.gcXcHc_9.js",
      "_select.K8Iod6E_.js",
      "_popper.PyUaqGjf.js",
      "_isUndefined.IZwZ21d-.js",
      "_tag.AQfsRIUA.js",
      "_strings.LW_DAaDk.js",
      "_index.5154XgU3.js",
      "_input-number.bAB67xcc.js",
      "_index.iWTOJU8z.js",
      "_sku.9_xViOEF.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_index.e_lt94hP.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/shopcart.vue"
  },
  "shopcart.T7K9gx-c.css": {
    "file": "shopcart.T7K9gx-c.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/wallet.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "wallet.JgZZuLIl.css",
      "popover.LAISAeEG.css"
    ],
    "file": "wallet.vGAlGAim.js",
    "imports": [
      "node_modules/element-plus/es/components/text/index.mjs",
      "node_modules/nuxt/dist/app/entry.js",
      "_create-shadow.8p9Gxjfm.js",
      "_progress.8uPnj5lp.js",
      "_index.VL9-GfT-.js",
      "_popper.PyUaqGjf.js",
      "_bills.Xo-Q7bF_.js",
      "_scrollbar.sa_8cCgK.js",
      "_input-number.bAB67xcc.js",
      "_select.K8Iod6E_.js",
      "_tag.AQfsRIUA.js",
      "_localeData.CFSQF4jw.js",
      "_divider.AU2dm0Xc.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isUndefined.IZwZ21d-.js",
      "_index.iWTOJU8z.js",
      "_strings.LW_DAaDk.js",
      "_isEqual.--_JEsOY.js",
      "_debounce.gcXcHc_9.js",
      "_hasIn.TlWS3kXH.js",
      "_index.5154XgU3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/wallet.vue"
  },
  "wallet.JgZZuLIl.css": {
    "file": "wallet.JgZZuLIl.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
