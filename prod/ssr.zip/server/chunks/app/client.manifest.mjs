const client_manifest = {
  "_ApplyDialog.vue.p-7POFSN.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ApplyDialog.vue.p-7POFSN.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_dialog.PfSqVnTp.js",
      "_notification.e-ZJlSA8.js",
      "_friend.SJYOoRYc.js"
    ]
  },
  "_AutoIncre.vue.SsWEnZit.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "AutoIncre.vue.SsWEnZit.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_CategoryTabs.!~{014}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "CategoryTabs.787nBCiN.css",
    "src": "_CategoryTabs.!~{014}~.js"
  },
  "_CategoryTabs.k3KGYI04.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "CategoryTabs.k3KGYI04.js",
    "imports": [
      "_tabs.h9ufq8X2.js",
      "node_modules/nuxt/dist/app/entry.js",
      "components/Comm/PostList.vue",
      "components/list/GoodsList.vue"
    ],
    "css": [
      "CategoryTabs.787nBCiN.css"
    ]
  },
  "CategoryTabs.787nBCiN.css": {
    "file": "CategoryTabs.787nBCiN.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_CommentPreview.!~{019}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "CommentPreview.GjCmskTw.css",
    "src": "_CommentPreview.!~{019}~.js"
  },
  "_CommentPreview.cPYtXJUG.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "CommentPreview.cPYtXJUG.js",
    "imports": [
      "_ElImage.k0tUPKKB.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_select.pKShklwF.js",
      "_OssFileUpload.q27QzonC.js",
      "_nuxt-link.XH-MVhO_.js",
      "_tag.UH49BTNL.js",
      "_AutoIncre.vue.SsWEnZit.js",
      "_scrollbar.vaSaNhfU.js",
      "_popper.QdsbmO3I.js",
      "_notification.e-ZJlSA8.js"
    ],
    "css": [
      "CommentPreview.GjCmskTw.css"
    ]
  },
  "CommentPreview.GjCmskTw.css": {
    "file": "CommentPreview.GjCmskTw.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_DelayTimer.vue.qFVFswae.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "DelayTimer.vue.qFVFswae.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_ElImage.!~{00B}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "ElImage.6ybrNKBL.css",
    "src": "_ElImage.!~{00B}~.js"
  },
  "_ElImage.k0tUPKKB.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ElImage.k0tUPKKB.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_debounce.BZJZ2D2o.js"
    ],
    "css": [
      "ElImage.6ybrNKBL.css"
    ]
  },
  "ElImage.6ybrNKBL.css": {
    "file": "ElImage.6ybrNKBL.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_Footer.!~{01Q}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Footer._4VSJBz3.css",
    "src": "_Footer.!~{01Q}~.js"
  },
  "_Footer.zSEuHHDq.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Footer.zSEuHHDq.js",
    "imports": [
      "_nuxt-link.XH-MVhO_.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_logo_dark.g-2wY0_x.js",
      "_Switch.M8zbDlUV.js"
    ],
    "css": [
      "Footer._4VSJBz3.css"
    ]
  },
  "Footer._4VSJBz3.css": {
    "file": "Footer._4VSJBz3.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_GoodsListSsr.!~{01n}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "GoodsListSsr.P5hBZBtk.css",
    "src": "_GoodsListSsr.!~{01n}~.js"
  },
  "_GoodsListSsr.2N9WV2Fy.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "GoodsListSsr.2N9WV2Fy.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.773IOigk.js",
      "_nuxt-link.XH-MVhO_.js",
      "node_modules/element-plus/es/components/text/index.mjs"
    ],
    "css": [
      "GoodsListSsr.P5hBZBtk.css"
    ]
  },
  "GoodsListSsr.P5hBZBtk.css": {
    "file": "GoodsListSsr.P5hBZBtk.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_Main.!~{00z}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Main.SJ5yTJq1.css",
    "src": "_Main.!~{00z}~.js"
  },
  "_Main.jQVYOPCq.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Main.jQVYOPCq.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_contact.bLBGwGxH.js",
      "_ElImage.k0tUPKKB.js"
    ],
    "css": [
      "Main.SJ5yTJq1.css"
    ]
  },
  "Main.SJ5yTJq1.css": {
    "file": "Main.SJ5yTJq1.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_OssFileUpload.!~{00W}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "OssFileUpload.f4DKzIfB.css",
    "src": "_OssFileUpload.!~{00W}~.js"
  },
  "_OssFileUpload.q27QzonC.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "OssFileUpload.q27QzonC.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.k0tUPKKB.js",
      "_progress.md-od6nt.js",
      "_index.kdLAqwHJ.js"
    ],
    "css": [
      "OssFileUpload.f4DKzIfB.css"
    ]
  },
  "OssFileUpload.f4DKzIfB.css": {
    "file": "OssFileUpload.f4DKzIfB.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_ShopLine.!~{01K}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "ShopLine.Wq74ulT-.css",
    "src": "_ShopLine.!~{01K}~.js"
  },
  "_ShopLine.Hje7RPoh.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ShopLine.Hje7RPoh.js",
    "imports": [
      "_ElImage.k0tUPKKB.js",
      "_nuxt-link.XH-MVhO_.js",
      "_select.pKShklwF.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_input-number.u0zwTS7a.js",
      "_tag.UH49BTNL.js",
      "_scrollbar.vaSaNhfU.js",
      "_popper.QdsbmO3I.js",
      "_sku.HeG39Ytu.js"
    ],
    "css": [
      "ShopLine.Wq74ulT-.css"
    ]
  },
  "ShopLine.Wq74ulT-.css": {
    "file": "ShopLine.Wq74ulT-.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_SigninCard.vue.wop5yLVp.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "SigninCard.vue.wop5yLVp.js",
    "imports": [
      "_progress.md-od6nt.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.vurJ-8I1.js",
      "_popper.QdsbmO3I.js"
    ],
    "css": [
      "popover.LAISAeEG.css"
    ]
  },
  "popover.LAISAeEG.css": {
    "file": "popover.LAISAeEG.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_StatusTag.!~{01l}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "StatusTag.IETAoY75.css",
    "src": "_StatusTag.!~{01l}~.js"
  },
  "_StatusTag.2v5_W-kD.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "StatusTag.2v5_W-kD.js",
    "imports": [
      "_tag.UH49BTNL.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_post.PAYQCZsz.js"
    ],
    "css": [
      "StatusTag.IETAoY75.css"
    ]
  },
  "StatusTag.IETAoY75.css": {
    "file": "StatusTag.IETAoY75.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_Switch.!~{01e}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Switch.6FgKIDc6.css",
    "src": "_Switch.!~{01e}~.js"
  },
  "_Switch.M8zbDlUV.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Switch.M8zbDlUV.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "css": [
      "Switch.6FgKIDc6.css"
    ]
  },
  "Switch.6FgKIDc6.css": {
    "file": "Switch.6FgKIDc6.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_TagList.vue.GI6FYNXx.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TagList.vue.GI6FYNXx.js",
    "imports": [
      "_tag.UH49BTNL.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_UserPostTotal.vue.tbXe7b-A.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "UserPostTotal.vue.tbXe7b-A.js",
    "imports": [
      "_ElImage.k0tUPKKB.js",
      "_nuxt-link.XH-MVhO_.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_post.PAYQCZsz.js"
    ]
  },
  "___commonjsHelpers__.1J56E-h6.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "__commonjsHelpers__.1J56E-h6.js"
  },
  "_arrays.9GuX8ZvT.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "arrays.9GuX8ZvT.js"
  },
  "_avatar.!~{01J}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "avatar.bZH1-Oig.css",
    "src": "_avatar.!~{01J}~.js"
  },
  "_avatar.8EI5kUhP.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "avatar.8EI5kUhP.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "css": [
      "avatar.bZH1-Oig.css"
    ]
  },
  "avatar.bZH1-Oig.css": {
    "file": "avatar.bZH1-Oig.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_bills.BjmaER8r.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "bills.BjmaER8r.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_checkbox-group.!~{01H}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "checkbox-group.d5XbR8TY.css",
    "src": "_checkbox-group.!~{01H}~.js"
  },
  "_checkbox.!~{01y}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "checkbox.MJHvI1xB.css",
    "src": "_checkbox.!~{01y}~.js"
  },
  "_checkbox.rb3XMZbv.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "checkbox.rb3XMZbv.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_isEqual.0EEK5b_c.js",
      "_hasIn.hzmQIp0-.js",
      "_flatten.RrtlTkgk.js"
    ],
    "css": [
      "checkbox.MJHvI1xB.css"
    ]
  },
  "checkbox.MJHvI1xB.css": {
    "file": "checkbox.MJHvI1xB.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_cloneDeep.j3nuMen3.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "cloneDeep.j3nuMen3.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_collect.8jNWkT1R.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "collect.8jNWkT1R.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_contact.bLBGwGxH.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "contact.bLBGwGxH.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_useWs.2RLYHpEC.js"
    ]
  },
  "_create-shadow.bA5h4BDq.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "create-shadow.bA5h4BDq.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_date-picker.!~{01E}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "date-picker.sSkDKlix.css",
    "src": "_date-picker.!~{01E}~.js"
  },
  "_date-picker.fKop_G0U.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "date-picker.fKop_G0U.js",
    "imports": [
      "_localeData.Jy9s0tdq.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_arrays.9GuX8ZvT.js",
      "_flatten.RrtlTkgk.js",
      "_popper.QdsbmO3I.js",
      "_scrollbar.vaSaNhfU.js",
      "_index.qyn17qGn.js",
      "_debounce.BZJZ2D2o.js",
      "_index.XHYZfdwx.js",
      "_isEqual.0EEK5b_c.js"
    ],
    "css": [
      "date-picker.sSkDKlix.css"
    ]
  },
  "date-picker.sSkDKlix.css": {
    "file": "date-picker.sSkDKlix.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_debounce.BZJZ2D2o.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "debounce.BZJZ2D2o.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_dialog.!~{00Q}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "dialog.mDs1vky2.css",
    "src": "_dialog.!~{00Q}~.js"
  },
  "_dialog.PfSqVnTp.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "dialog.PfSqVnTp.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "css": [
      "dialog.mDs1vky2.css"
    ]
  },
  "dialog.mDs1vky2.css": {
    "file": "dialog.mDs1vky2.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_divider.!~{00N}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "divider.mvCfgREV.css",
    "src": "_divider.!~{00N}~.js"
  },
  "_divider.juRht5Xl.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "divider.juRht5Xl.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "css": [
      "divider.mvCfgREV.css"
    ]
  },
  "divider.mvCfgREV.css": {
    "file": "divider.mvCfgREV.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_effect-creative.SneNhbIu.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "effect-creative.SneNhbIu.js",
    "imports": [
      "_create-shadow.bA5h4BDq.js"
    ]
  },
  "_empty.!~{00J}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "empty.sDhVTJEQ.css",
    "src": "_empty.!~{00J}~.js"
  },
  "_empty.fFIhc26R.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "empty.fFIhc26R.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "css": [
      "empty.sDhVTJEQ.css"
    ]
  },
  "empty.sDhVTJEQ.css": {
    "file": "empty.sDhVTJEQ.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_flatten.RrtlTkgk.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "flatten.RrtlTkgk.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_friend.SJYOoRYc.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "friend.SJYOoRYc.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_hasIn.hzmQIp0-.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "hasIn.hzmQIp0-.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.!~{01c}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.BbVs9JM6.css",
    "src": "_index.!~{01c}~.js"
  },
  "_index.3l1IJwnP.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.3l1IJwnP.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.6Zu71XyI.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.6Zu71XyI.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.773IOigk.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.773IOigk.js",
    "imports": [
      "_ElImage.k0tUPKKB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "css": [
      "index.BbVs9JM6.css"
    ]
  },
  "index.BbVs9JM6.css": {
    "file": "index.BbVs9JM6.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_index.AQSM7h3o.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.AQSM7h3o.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.NzpJhA4o.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.NzpJhA4o.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.ULa5qaOS.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.ULa5qaOS.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.XHYZfdwx.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.XHYZfdwx.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.jbqOgio6.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.jbqOgio6.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.kdLAqwHJ.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.kdLAqwHJ.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ]
  },
  "_index.qyn17qGn.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.qyn17qGn.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.vurJ-8I1.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.vurJ-8I1.js",
    "imports": [
      "_popper.QdsbmO3I.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_input-number.!~{01p}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "input-number.5AezeF1g.css",
    "src": "_input-number.!~{01p}~.js"
  },
  "_input-number.u0zwTS7a.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "input-number.u0zwTS7a.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.qyn17qGn.js"
    ],
    "css": [
      "input-number.5AezeF1g.css"
    ]
  },
  "input-number.5AezeF1g.css": {
    "file": "input-number.5AezeF1g.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_isEqual.0EEK5b_c.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "isEqual.0EEK5b_c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_isUndefined.IZwZ21d-.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "isUndefined.IZwZ21d-.js"
  },
  "_localeData.Jy9s0tdq.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "localeData.Jy9s0tdq.js",
    "imports": [
      "___commonjsHelpers__.1J56E-h6.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_logo_dark.g-2wY0_x.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "logo_dark.g-2wY0_x.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.XH-MVhO_.js",
      "_scrollbar.vaSaNhfU.js",
      "_index.vurJ-8I1.js",
      "_popper.QdsbmO3I.js"
    ],
    "dynamicImports": [
      "components/card/UserLine.vue"
    ],
    "css": [
      "popover.LAISAeEG.css"
    ]
  },
  "_menu-item.!~{01O}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "menu-item.f0mNRiTD.css",
    "src": "_tooltip.!~{01I}~.js"
  },
  "_menu.!~{01N}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "menu.6YbFhd-D.css",
    "src": "_menu.!~{01N}~.js"
  },
  "_menu.avkan_Zf.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "menu.avkan_Zf.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.ULa5qaOS.js",
      "_popper.QdsbmO3I.js",
      "_index.XHYZfdwx.js"
    ],
    "css": [
      "menu.6YbFhd-D.css"
    ]
  },
  "menu.6YbFhd-D.css": {
    "file": "menu.6YbFhd-D.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_notification.!~{00G}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "notification.8O_B6xHM.css",
    "src": "_notification.!~{00G}~.js"
  },
  "_notification.e-ZJlSA8.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "notification.e-ZJlSA8.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "css": [
      "notification.8O_B6xHM.css"
    ]
  },
  "notification.8O_B6xHM.css": {
    "file": "notification.8O_B6xHM.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_nuxt-link.XH-MVhO_.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "nuxt-link.XH-MVhO_.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_popover.!~{01i}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "popover.LAISAeEG.css",
    "src": "_popover.!~{01i}~.js"
  },
  "_popper.!~{00X}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "popper.nTJkgMH4.css",
    "src": "_popper.!~{00X}~.js"
  },
  "_popper.QdsbmO3I.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "popper.QdsbmO3I.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "css": [
      "popper.nTJkgMH4.css"
    ]
  },
  "popper.nTJkgMH4.css": {
    "file": "popper.nTJkgMH4.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_post.PAYQCZsz.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "post.PAYQCZsz.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_progress.!~{011}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "progress.rXLlm_9F.css",
    "src": "_progress.!~{011}~.js"
  },
  "_progress.md-od6nt.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "progress.md-od6nt.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "css": [
      "progress.rXLlm_9F.css"
    ]
  },
  "progress.rXLlm_9F.css": {
    "file": "progress.rXLlm_9F.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_radio-button.!~{012}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "radio-button.l7x146Nf.css",
    "src": "_radio-button.!~{012}~.js"
  },
  "_radio-group.!~{00M}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "radio-group.P_Xz2fNs.css",
    "src": "_radio-group.!~{00M}~.js"
  },
  "_radio.!~{00U}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "radio.eYTrrdr6.css",
    "src": "_radio.!~{00U}~.js"
  },
  "_rate.!~{01s}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "rate.mGuCO7Lx.css",
    "src": "_rate.!~{01s}~.js"
  },
  "_rate.v78QfR5p.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "rate.v78QfR5p.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "css": [
      "rate.mGuCO7Lx.css"
    ]
  },
  "rate.mGuCO7Lx.css": {
    "file": "rate.mGuCO7Lx.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_scrollbar.!~{00A}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "scrollbar.Smf0pYfu.css",
    "src": "_scrollbar.!~{00A}~.js"
  },
  "_scrollbar.vaSaNhfU.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "scrollbar.vaSaNhfU.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "css": [
      "scrollbar.Smf0pYfu.css"
    ]
  },
  "scrollbar.Smf0pYfu.css": {
    "file": "scrollbar.Smf0pYfu.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_select.!~{00V}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "select.xPRdjiL2.css",
    "src": "_select.!~{00V}~.js"
  },
  "_select.pKShklwF.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "select.pKShklwF.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_popper.QdsbmO3I.js",
      "_scrollbar.vaSaNhfU.js",
      "_tag.UH49BTNL.js",
      "_strings.S9vBrqjb.js",
      "_isEqual.0EEK5b_c.js",
      "_debounce.BZJZ2D2o.js",
      "_hasIn.hzmQIp0-.js",
      "_index.XHYZfdwx.js"
    ],
    "css": [
      "select.xPRdjiL2.css"
    ]
  },
  "select.xPRdjiL2.css": {
    "file": "select.xPRdjiL2.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_sku.HeG39Ytu.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sku.HeG39Ytu.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_strings.S9vBrqjb.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "strings.S9vBrqjb.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_tabs.!~{015}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "tabs.H-UKPvku.css",
    "src": "_tabs.!~{015}~.js"
  },
  "_tabs.h9ufq8X2.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "tabs.h9ufq8X2.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_strings.S9vBrqjb.js",
      "_index.6Zu71XyI.js"
    ],
    "css": [
      "tabs.H-UKPvku.css"
    ]
  },
  "tabs.H-UKPvku.css": {
    "file": "tabs.H-UKPvku.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_tag.!~{00H}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "tag.Wo0upPQu.css",
    "src": "_tag.!~{00H}~.js"
  },
  "_tag.UH49BTNL.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "tag.UH49BTNL.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "css": [
      "tag.Wo0upPQu.css"
    ]
  },
  "tag.Wo0upPQu.css": {
    "file": "tag.Wo0upPQu.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_tooltip.!~{01I}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "menu-item.f0mNRiTD.css",
    "src": "_tooltip.!~{01I}~.js"
  },
  "_upload.!~{01x}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "upload.5r92S6hB.css",
    "src": "_upload.!~{01x}~.js"
  },
  "_upload.GHyKnOoC.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "upload.GHyKnOoC.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_progress.md-od6nt.js",
      "_cloneDeep.j3nuMen3.js",
      "_isEqual.0EEK5b_c.js"
    ],
    "css": [
      "upload.5r92S6hB.css"
    ]
  },
  "upload.5r92S6hB.css": {
    "file": "upload.5r92S6hB.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_useOrderStore.1ouOE3CG.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useOrderStore.1ouOE3CG.js",
    "imports": [
      "_index.NzpJhA4o.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_useWebToast.aIgCezK0.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useWebToast.aIgCezK0.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_useWs.2RLYHpEC.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useWs.2RLYHpEC.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_notification.e-ZJlSA8.js"
    ]
  },
  "components/Chat/Friend/ApplyDialog.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ApplyDialog.fvexIBfY.js",
    "src": "components/Chat/Friend/ApplyDialog.vue",
    "isDynamicEntry": true,
    "imports": [
      "_ApplyDialog.vue.p-7POFSN.js",
      "node_modules/nuxt/dist/app/entry.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_dialog.PfSqVnTp.js",
      "_isUndefined.IZwZ21d-.js",
      "_notification.e-ZJlSA8.js",
      "_friend.SJYOoRYc.js"
    ]
  },
  "components/Chat/NewGroupDialog.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "NewGroupDialog.RzEqM9V5.js",
    "src": "components/Chat/NewGroupDialog.vue",
    "isDynamicEntry": true,
    "imports": [
      "_ElImage.k0tUPKKB.js",
      "_checkbox.rb3XMZbv.js",
      "_AutoIncre.vue.SsWEnZit.js",
      "_scrollbar.vaSaNhfU.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_OssFileUpload.q27QzonC.js",
      "_dialog.PfSqVnTp.js",
      "_notification.e-ZJlSA8.js",
      "_contact.bLBGwGxH.js",
      "_Main.jQVYOPCq.js",
      "_friend.SJYOoRYc.js",
      "_debounce.BZJZ2D2o.js",
      "_isEqual.0EEK5b_c.js",
      "_hasIn.hzmQIp0-.js",
      "_flatten.RrtlTkgk.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_progress.md-od6nt.js",
      "_index.kdLAqwHJ.js",
      "_isUndefined.IZwZ21d-.js",
      "_useWs.2RLYHpEC.js"
    ],
    "css": [
      "NewGroupDialog.Hm5sbp8R.css",
      "checkbox-group.d5XbR8TY.css"
    ]
  },
  "NewGroupDialog.Hm5sbp8R.css": {
    "file": "NewGroupDialog.Hm5sbp8R.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "checkbox-group.d5XbR8TY.css": {
    "file": "checkbox-group.d5XbR8TY.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/Comm/PostList.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "PostList.Nb0gaqj6.js",
    "src": "components/Comm/PostList.vue",
    "isDynamicEntry": true,
    "imports": [
      "_ElImage.k0tUPKKB.js",
      "_nuxt-link.XH-MVhO_.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.UH49BTNL.js",
      "_TagList.vue.GI6FYNXx.js",
      "_CommentPreview.cPYtXJUG.js",
      "_AutoIncre.vue.SsWEnZit.js",
      "_post.PAYQCZsz.js",
      "_debounce.BZJZ2D2o.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_select.pKShklwF.js",
      "_popper.QdsbmO3I.js",
      "_isUndefined.IZwZ21d-.js",
      "_scrollbar.vaSaNhfU.js",
      "_strings.S9vBrqjb.js",
      "_isEqual.0EEK5b_c.js",
      "_hasIn.hzmQIp0-.js",
      "_index.XHYZfdwx.js",
      "_OssFileUpload.q27QzonC.js",
      "_progress.md-od6nt.js",
      "_index.kdLAqwHJ.js",
      "_notification.e-ZJlSA8.js"
    ],
    "css": [
      "PostList.zoch9zzo.css"
    ]
  },
  "PostList.zoch9zzo.css": {
    "file": "PostList.zoch9zzo.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/Comm/post/CateGoryLine.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "CateGoryLine.SPKz71rA.js",
    "src": "components/Comm/post/CateGoryLine.vue",
    "isDynamicEntry": true,
    "imports": [
      "_ElImage.k0tUPKKB.js",
      "_nuxt-link.XH-MVhO_.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_debounce.BZJZ2D2o.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ]
  },
  "components/Comm/post/Rank.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Rank.Ht9weY11.js",
    "src": "components/Comm/post/Rank.vue",
    "isDynamicEntry": true,
    "imports": [
      "_divider.juRht5Xl.js",
      "_tag.UH49BTNL.js",
      "_ElImage.k0tUPKKB.js",
      "_nuxt-link.XH-MVhO_.js",
      "_empty.fFIhc26R.js",
      "_scrollbar.vaSaNhfU.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_post.PAYQCZsz.js",
      "_debounce.BZJZ2D2o.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "css": [
      "Rank.y3dQ8fHf.css"
    ]
  },
  "Rank.y3dQ8fHf.css": {
    "file": "Rank.y3dQ8fHf.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/card/UserLine.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "UserLine.8vkLz--Y.js",
    "src": "components/card/UserLine.vue",
    "isDynamicEntry": true,
    "imports": [
      "_avatar.8EI5kUhP.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_upload.GHyKnOoC.js",
      "_nuxt-link.XH-MVhO_.js",
      "_index.vurJ-8I1.js",
      "_progress.md-od6nt.js",
      "_popper.QdsbmO3I.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_cloneDeep.j3nuMen3.js",
      "_isEqual.0EEK5b_c.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "css": [
      "UserLine.G_lnDfVq.css",
      "popover.LAISAeEG.css"
    ]
  },
  "UserLine.G_lnDfVq.css": {
    "file": "UserLine.G_lnDfVq.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/list/GoodsList.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "GoodsList.pz_o1KCX.js",
    "src": "components/list/GoodsList.vue",
    "isDynamicEntry": true,
    "imports": [
      "_index.773IOigk.js",
      "_nuxt-link.XH-MVhO_.js",
      "_AutoIncre.vue.SsWEnZit.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.k0tUPKKB.js",
      "_debounce.BZJZ2D2o.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "css": [
      "GoodsList.1p6fEF-7.css"
    ]
  },
  "GoodsList.1p6fEF-7.css": {
    "file": "GoodsList.1p6fEF-7.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/menu/DrawerMenu.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "DrawerMenu._WGxvogg.js",
    "src": "components/menu/DrawerMenu.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_menu.avkan_Zf.js",
      "_scrollbar.vaSaNhfU.js",
      "_popper.QdsbmO3I.js",
      "_logo_dark.g-2wY0_x.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_index.ULa5qaOS.js",
      "_index.XHYZfdwx.js",
      "_isUndefined.IZwZ21d-.js",
      "_nuxt-link.XH-MVhO_.js",
      "_index.vurJ-8I1.js"
    ],
    "css": [
      "DrawerMenu.0ja6gThp.css",
      "menu-item.f0mNRiTD.css",
      "popover.LAISAeEG.css"
    ]
  },
  "DrawerMenu.0ja6gThp.css": {
    "file": "DrawerMenu.0ja6gThp.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "menu-item.f0mNRiTD.css": {
    "file": "menu-item.f0mNRiTD.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/menu/RightButtons/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.kxfehPZt.js",
    "src": "components/menu/RightButtons/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.XH-MVhO_.js",
      "_Main.jQVYOPCq.js",
      "_scrollbar.vaSaNhfU.js",
      "_ElImage.k0tUPKKB.js",
      "_index.vurJ-8I1.js",
      "_popper.QdsbmO3I.js",
      "_contact.bLBGwGxH.js",
      "_useWs.2RLYHpEC.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.BZJZ2D2o.js",
      "_isUndefined.IZwZ21d-.js",
      "_notification.e-ZJlSA8.js"
    ],
    "dynamicImports": [
      "components/menu/ShopCartBar.vue"
    ],
    "css": [
      "index.qlwUIxJd.css",
      "popover.LAISAeEG.css",
      "menu-item.f0mNRiTD.css"
    ]
  },
  "index.qlwUIxJd.css": {
    "file": "index.qlwUIxJd.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/menu/ShopCartBar.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ShopCartBar.FfZl8u5j.js",
    "src": "components/menu/ShopCartBar.vue",
    "isDynamicEntry": true,
    "imports": [
      "_checkbox.rb3XMZbv.js",
      "_ShopLine.Hje7RPoh.js",
      "_AutoIncre.vue.SsWEnZit.js",
      "_scrollbar.vaSaNhfU.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.vurJ-8I1.js",
      "_popper.QdsbmO3I.js",
      "_useOrderStore.1ouOE3CG.js",
      "_isEqual.0EEK5b_c.js",
      "_hasIn.hzmQIp0-.js",
      "_flatten.RrtlTkgk.js",
      "_ElImage.k0tUPKKB.js",
      "_debounce.BZJZ2D2o.js",
      "_nuxt-link.XH-MVhO_.js",
      "_select.pKShklwF.js",
      "_tag.UH49BTNL.js",
      "_strings.S9vBrqjb.js",
      "_index.XHYZfdwx.js",
      "_input-number.u0zwTS7a.js",
      "_index.qyn17qGn.js",
      "_sku.HeG39Ytu.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isUndefined.IZwZ21d-.js",
      "_index.NzpJhA4o.js"
    ],
    "css": [
      "ShopCartBar.BHANagyi.css",
      "checkbox-group.d5XbR8TY.css",
      "popover.LAISAeEG.css"
    ]
  },
  "ShopCartBar.BHANagyi.css": {
    "file": "ShopCartBar.BHANagyi.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "layouts/chat.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "chat.9VxxYQZd.js",
    "src": "layouts/chat.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.k0tUPKKB.js",
      "components/card/UserLine.vue",
      "_menu.avkan_Zf.js",
      "_popper.QdsbmO3I.js",
      "_useWs.2RLYHpEC.js",
      "_friend.SJYOoRYc.js",
      "_useWebToast.aIgCezK0.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.BZJZ2D2o.js",
      "_avatar.8EI5kUhP.js",
      "_upload.GHyKnOoC.js",
      "_progress.md-od6nt.js",
      "_cloneDeep.j3nuMen3.js",
      "_isEqual.0EEK5b_c.js",
      "_nuxt-link.XH-MVhO_.js",
      "_index.vurJ-8I1.js",
      "_index.ULa5qaOS.js",
      "_index.XHYZfdwx.js",
      "_isUndefined.IZwZ21d-.js",
      "_notification.e-ZJlSA8.js"
    ],
    "dynamicImports": [
      "components/menu/RightButtons/index.vue"
    ],
    "css": [
      "chat.vRH9Isjp.css",
      "menu-item.f0mNRiTD.css",
      "popover.LAISAeEG.css"
    ]
  },
  "chat.vRH9Isjp.css": {
    "file": "chat.vRH9Isjp.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "layouts/error.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "error.hJolfeWp.js",
    "src": "layouts/error.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ]
  },
  "layouts/main.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "main.qAVOVXqo.js",
    "src": "layouts/main.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_Footer.zSEuHHDq.js",
      "components/menu/RightButtons/index.vue",
      "___commonjsHelpers__.1J56E-h6.js",
      "_nuxt-link.XH-MVhO_.js",
      "_logo_dark.g-2wY0_x.js",
      "_scrollbar.vaSaNhfU.js",
      "_index.vurJ-8I1.js",
      "_popper.QdsbmO3I.js",
      "_isUndefined.IZwZ21d-.js",
      "_Switch.M8zbDlUV.js",
      "_Main.jQVYOPCq.js",
      "_contact.bLBGwGxH.js",
      "_useWs.2RLYHpEC.js",
      "_notification.e-ZJlSA8.js",
      "_ElImage.k0tUPKKB.js",
      "_debounce.BZJZ2D2o.js"
    ],
    "dynamicImports": [
      "components/menu/DrawerMenu.vue"
    ],
    "css": [
      "popover.LAISAeEG.css",
      "menu-item.f0mNRiTD.css"
    ]
  },
  "layouts/second.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "second.w-o6fnPv.js",
    "src": "layouts/second.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Footer.zSEuHHDq.js",
      "components/menu/RightButtons/index.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.XH-MVhO_.js",
      "_logo_dark.g-2wY0_x.js",
      "_scrollbar.vaSaNhfU.js",
      "_index.vurJ-8I1.js",
      "_popper.QdsbmO3I.js",
      "_isUndefined.IZwZ21d-.js",
      "_Switch.M8zbDlUV.js",
      "_Main.jQVYOPCq.js",
      "_contact.bLBGwGxH.js",
      "_useWs.2RLYHpEC.js",
      "_notification.e-ZJlSA8.js",
      "_ElImage.k0tUPKKB.js",
      "_debounce.BZJZ2D2o.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "css": [
      "second.JqdAvVfB.css",
      "popover.LAISAeEG.css",
      "menu-item.f0mNRiTD.css"
    ]
  },
  "second.JqdAvVfB.css": {
    "file": "second.JqdAvVfB.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "layouts/user.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "user.w8LEiWTb.js",
    "src": "layouts/user.vue",
    "isDynamicEntry": true,
    "imports": [
      "_nuxt-link.XH-MVhO_.js",
      "_logo_dark.g-2wY0_x.js",
      "_Switch.M8zbDlUV.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_menu.avkan_Zf.js",
      "_popper.QdsbmO3I.js",
      "components/menu/RightButtons/index.vue",
      "_scrollbar.vaSaNhfU.js",
      "_index.vurJ-8I1.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_index.ULa5qaOS.js",
      "_index.XHYZfdwx.js",
      "_isUndefined.IZwZ21d-.js",
      "_Main.jQVYOPCq.js",
      "_contact.bLBGwGxH.js",
      "_useWs.2RLYHpEC.js",
      "_notification.e-ZJlSA8.js",
      "_ElImage.k0tUPKKB.js",
      "_debounce.BZJZ2D2o.js"
    ],
    "css": [
      "user.yAuj-VgQ.css",
      "menu-item.f0mNRiTD.css",
      "popover.LAISAeEG.css"
    ]
  },
  "user.yAuj-VgQ.css": {
    "file": "user.yAuj-VgQ.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/element-plus/es/components/text/index.mjs": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.mJhz_9vh.js",
    "src": "node_modules/element-plus/es/components/text/index.mjs",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "css": [
      "index.l5CC8IXT.css"
    ]
  },
  "index.l5CC8IXT.css": {
    "file": "index.l5CC8IXT.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "entry.2CJ4nrLU.js",
    "src": "node_modules/nuxt/dist/app/entry.js",
    "isEntry": true,
    "imports": [
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "dynamicImports": [
      "layouts/chat.vue",
      "layouts/error.vue",
      "layouts/main.vue",
      "layouts/second.vue",
      "layouts/user.vue",
      "node_modules/workbox-window/build/workbox-window.prod.es5.mjs"
    ],
    "css": [
      "entry.OCEmENdu.css"
    ]
  },
  "entry.OCEmENdu.css": {
    "file": "entry.OCEmENdu.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/workbox-window/build/workbox-window.prod.es5.mjs": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "workbox-window.prod.es5.prqDwDSL.js",
    "src": "node_modules/workbox-window/build/workbox-window.prod.es5.mjs",
    "isDynamicEntry": true
  },
  "pages/[...all].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_...all_.j3bUU8Zf.js",
    "src": "pages/[...all].vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ]
  },
  "pages/chat/ai.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ai.Kyb_kKZK.js",
    "src": "pages/chat/ai.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Main.jQVYOPCq.js",
      "_scrollbar.vaSaNhfU.js",
      "_ElImage.k0tUPKKB.js",
      "_nuxt-link.XH-MVhO_.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_contact.bLBGwGxH.js",
      "_useWs.2RLYHpEC.js",
      "_debounce.BZJZ2D2o.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_notification.e-ZJlSA8.js"
    ],
    "css": [
      "ai.SiTMStRP.css"
    ]
  },
  "ai.SiTMStRP.css": {
    "file": "ai.SiTMStRP.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/chat/friend.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "friend.955iT_7S.js",
    "src": "pages/chat/friend.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.UH49BTNL.js",
      "_ElImage.k0tUPKKB.js",
      "_AutoIncre.vue.SsWEnZit.js",
      "_scrollbar.vaSaNhfU.js",
      "_empty.fFIhc26R.js",
      "_friend.SJYOoRYc.js",
      "_index.AQSM7h3o.js",
      "_contact.bLBGwGxH.js",
      "_useWs.2RLYHpEC.js",
      "_notification.e-ZJlSA8.js",
      "_divider.juRht5Xl.js",
      "_ApplyDialog.vue.p-7POFSN.js",
      "_index.jbqOgio6.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.BZJZ2D2o.js",
      "_dialog.PfSqVnTp.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "css": [
      "friend.IKhbuxAS.css",
      "radio-group.P_Xz2fNs.css"
    ]
  },
  "friend.IKhbuxAS.css": {
    "file": "friend.IKhbuxAS.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "radio-group.P_Xz2fNs.css": {
    "file": "radio-group.P_Xz2fNs.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/chat/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.BnPylQVd.js",
    "src": "pages/chat/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.k0tUPKKB.js",
      "_index.AQSM7h3o.js",
      "_AutoIncre.vue.SsWEnZit.js",
      "_notification.e-ZJlSA8.js",
      "_contact.bLBGwGxH.js",
      "_Main.jQVYOPCq.js",
      "_friend.SJYOoRYc.js",
      "_useWs.2RLYHpEC.js",
      "_tag.UH49BTNL.js",
      "_scrollbar.vaSaNhfU.js",
      "_select.pKShklwF.js",
      "_OssFileUpload.q27QzonC.js",
      "_nuxt-link.XH-MVhO_.js",
      "_popper.QdsbmO3I.js",
      "_index.kdLAqwHJ.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.BZJZ2D2o.js",
      "_strings.S9vBrqjb.js",
      "_isEqual.0EEK5b_c.js",
      "_hasIn.hzmQIp0-.js",
      "_index.XHYZfdwx.js",
      "_progress.md-od6nt.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "dynamicImports": [
      "components/Chat/NewGroupDialog.vue",
      "components/Chat/NewGroupDialog.vue",
      "components/Chat/Friend/ApplyDialog.vue"
    ],
    "css": [
      "index.qEcPa3dd.css",
      "radio.eYTrrdr6.css",
      "radio-group.P_Xz2fNs.css"
    ]
  },
  "index.qEcPa3dd.css": {
    "file": "index.qEcPa3dd.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "radio.eYTrrdr6.css": {
    "file": "radio.eYTrrdr6.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/chat/setting.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "setting.S9oW9iNx.js",
    "src": "pages/chat/setting.vue",
    "isDynamicEntry": true,
    "imports": [
      "_divider.juRht5Xl.js",
      "_select.pKShklwF.js",
      "_index.AQSM7h3o.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.UH49BTNL.js",
      "_scrollbar.vaSaNhfU.js",
      "_popper.QdsbmO3I.js",
      "_notification.e-ZJlSA8.js",
      "_strings.S9vBrqjb.js",
      "_isEqual.0EEK5b_c.js",
      "_debounce.BZJZ2D2o.js",
      "_hasIn.hzmQIp0-.js",
      "_index.XHYZfdwx.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "css": [
      "setting.SSmFdXUR.css",
      "radio-button.l7x146Nf.css",
      "radio-group.P_Xz2fNs.css"
    ]
  },
  "setting.SSmFdXUR.css": {
    "file": "setting.SSmFdXUR.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "radio-button.l7x146Nf.css": {
    "file": "radio-button.l7x146Nf.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/category/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_id_.xMIsL3QZ.js",
    "src": "pages/community/category/[id].vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.k0tUPKKB.js",
      "_CategoryTabs.k3KGYI04.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.BZJZ2D2o.js",
      "_tabs.h9ufq8X2.js",
      "_strings.S9vBrqjb.js",
      "_index.6Zu71XyI.js",
      "components/Comm/PostList.vue",
      "_nuxt-link.XH-MVhO_.js",
      "_tag.UH49BTNL.js",
      "_TagList.vue.GI6FYNXx.js",
      "_CommentPreview.cPYtXJUG.js",
      "_select.pKShklwF.js",
      "_popper.QdsbmO3I.js",
      "_isUndefined.IZwZ21d-.js",
      "_scrollbar.vaSaNhfU.js",
      "_isEqual.0EEK5b_c.js",
      "_hasIn.hzmQIp0-.js",
      "_index.XHYZfdwx.js",
      "_OssFileUpload.q27QzonC.js",
      "_progress.md-od6nt.js",
      "_index.kdLAqwHJ.js",
      "_AutoIncre.vue.SsWEnZit.js",
      "_notification.e-ZJlSA8.js",
      "_post.PAYQCZsz.js",
      "components/list/GoodsList.vue",
      "_index.773IOigk.js"
    ],
    "dynamicImports": [
      "components/Comm/post/Rank.vue"
    ],
    "css": [
      "_id_.uLLhAsoU.css"
    ]
  },
  "_id_.uLLhAsoU.css": {
    "file": "_id_.uLLhAsoU.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/category/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.mqU-cztn.js",
    "src": "pages/community/category/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_CategoryTabs.k3KGYI04.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_tabs.h9ufq8X2.js",
      "_strings.S9vBrqjb.js",
      "_index.6Zu71XyI.js",
      "components/Comm/PostList.vue",
      "_ElImage.k0tUPKKB.js",
      "_debounce.BZJZ2D2o.js",
      "_nuxt-link.XH-MVhO_.js",
      "_tag.UH49BTNL.js",
      "_TagList.vue.GI6FYNXx.js",
      "_CommentPreview.cPYtXJUG.js",
      "_select.pKShklwF.js",
      "_popper.QdsbmO3I.js",
      "_isUndefined.IZwZ21d-.js",
      "_scrollbar.vaSaNhfU.js",
      "_isEqual.0EEK5b_c.js",
      "_hasIn.hzmQIp0-.js",
      "_index.XHYZfdwx.js",
      "_OssFileUpload.q27QzonC.js",
      "_progress.md-od6nt.js",
      "_index.kdLAqwHJ.js",
      "_AutoIncre.vue.SsWEnZit.js",
      "_notification.e-ZJlSA8.js",
      "_post.PAYQCZsz.js",
      "components/list/GoodsList.vue",
      "_index.773IOigk.js"
    ],
    "dynamicImports": [
      "components/Comm/post/Rank.vue"
    ],
    "css": [
      "index.EaIT1GIC.css"
    ]
  },
  "index.EaIT1GIC.css": {
    "file": "index.EaIT1GIC.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/post/detail/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_id_.y9V9wfUY.js",
    "src": "pages/community/post/detail/[id].vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.k0tUPKKB.js",
      "_Switch.M8zbDlUV.js",
      "_tag.UH49BTNL.js",
      "_nuxt-link.XH-MVhO_.js",
      "_TagList.vue.GI6FYNXx.js",
      "_divider.juRht5Xl.js",
      "_post.PAYQCZsz.js",
      "_CommentPreview.cPYtXJUG.js",
      "_UserPostTotal.vue.tbXe7b-A.js",
      "_SigninCard.vue.wop5yLVp.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.BZJZ2D2o.js",
      "_select.pKShklwF.js",
      "_popper.QdsbmO3I.js",
      "_isUndefined.IZwZ21d-.js",
      "_scrollbar.vaSaNhfU.js",
      "_strings.S9vBrqjb.js",
      "_isEqual.0EEK5b_c.js",
      "_hasIn.hzmQIp0-.js",
      "_index.XHYZfdwx.js",
      "_OssFileUpload.q27QzonC.js",
      "_progress.md-od6nt.js",
      "_index.kdLAqwHJ.js",
      "_AutoIncre.vue.SsWEnZit.js",
      "_notification.e-ZJlSA8.js",
      "_index.vurJ-8I1.js"
    ],
    "dynamicImports": [
      "components/Comm/post/CateGoryLine.vue"
    ],
    "css": [
      "_id_.zKV61XL4.css",
      "popover.LAISAeEG.css"
    ]
  },
  "_id_.zKV61XL4.css": {
    "file": "_id_.zKV61XL4.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/post/list.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "list.6uzkt47S.js",
    "src": "pages/community/post/list.vue",
    "isDynamicEntry": true,
    "imports": [
      "_nuxt-link.XH-MVhO_.js",
      "_tag.UH49BTNL.js",
      "_create-shadow.bA5h4BDq.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_effect-creative.SneNhbIu.js",
      "_post.PAYQCZsz.js",
      "_ElImage.k0tUPKKB.js",
      "components/Comm/PostList.vue",
      "_tabs.h9ufq8X2.js",
      "_SigninCard.vue.wop5yLVp.js",
      "components/Comm/post/Rank.vue",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.BZJZ2D2o.js",
      "_TagList.vue.GI6FYNXx.js",
      "_CommentPreview.cPYtXJUG.js",
      "_select.pKShklwF.js",
      "_popper.QdsbmO3I.js",
      "_isUndefined.IZwZ21d-.js",
      "_scrollbar.vaSaNhfU.js",
      "_strings.S9vBrqjb.js",
      "_isEqual.0EEK5b_c.js",
      "_hasIn.hzmQIp0-.js",
      "_index.XHYZfdwx.js",
      "_OssFileUpload.q27QzonC.js",
      "_progress.md-od6nt.js",
      "_index.kdLAqwHJ.js",
      "_AutoIncre.vue.SsWEnZit.js",
      "_notification.e-ZJlSA8.js",
      "_index.6Zu71XyI.js",
      "_index.vurJ-8I1.js",
      "_divider.juRht5Xl.js",
      "_empty.fFIhc26R.js"
    ],
    "css": [
      "list.aADC_aru.css",
      "popover.LAISAeEG.css"
    ]
  },
  "list.aADC_aru.css": {
    "file": "list.aADC_aru.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/post/new.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "new.jkKm6t1t.js",
    "src": "pages/community/post/new.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_OssFileUpload.q27QzonC.js",
      "_index.AQSM7h3o.js",
      "_ElImage.k0tUPKKB.js",
      "_select.pKShklwF.js",
      "_tag.UH49BTNL.js",
      "_scrollbar.vaSaNhfU.js",
      "_popper.QdsbmO3I.js",
      "_notification.e-ZJlSA8.js",
      "_index.kdLAqwHJ.js",
      "_StatusTag.2v5_W-kD.js",
      "_post.PAYQCZsz.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_progress.md-od6nt.js",
      "_debounce.BZJZ2D2o.js",
      "_strings.S9vBrqjb.js",
      "_isEqual.0EEK5b_c.js",
      "_hasIn.hzmQIp0-.js",
      "_index.XHYZfdwx.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "css": [
      "new.9wZIBQf0.css",
      "radio-button.l7x146Nf.css",
      "radio-group.P_Xz2fNs.css"
    ]
  },
  "new.9wZIBQf0.css": {
    "file": "new.9wZIBQf0.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/event/detail/[eid].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_eid_._EUcq0Fc.js",
    "src": "pages/event/detail/[eid].vue",
    "isDynamicEntry": true,
    "imports": [
      "_ElImage.k0tUPKKB.js",
      "_tag.UH49BTNL.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.XH-MVhO_.js",
      "_index.3l1IJwnP.js",
      "_debounce.BZJZ2D2o.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ],
    "css": [
      "_eid_.NtANQ6Xa.css"
    ]
  },
  "_eid_.NtANQ6Xa.css": {
    "file": "_eid_.NtANQ6Xa.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/goods/comments/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_id_.qhcQkE2D.js",
    "src": "pages/goods/comments/[id].vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "___commonjsHelpers__.1J56E-h6.js"
    ]
  },
  "pages/goods/detail/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_id_.qislfpRJ.js",
    "src": "pages/goods/detail/[id].vue",
    "isDynamicEntry": true,
    "imports": [
      "_nuxt-link.XH-MVhO_.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_GoodsListSsr.2N9WV2Fy.js",
      "_ElImage.k0tUPKKB.js",
      "_index.6Zu71XyI.js",
      "_scrollbar.vaSaNhfU.js",
      "_tag.UH49BTNL.js",
      "_popper.QdsbmO3I.js",
      "_collect.8jNWkT1R.js",
      "_index.AQSM7h3o.js",
      "_input-number.u0zwTS7a.js",
      "_useOrderStore.1ouOE3CG.js",
      "_index.3l1IJwnP.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_tabs.h9ufq8X2.js",
      "_rate.v78QfR5p.js",
      "_AutoIncre.vue.SsWEnZit.js",
      "_dialog.PfSqVnTp.js",
      "_index.ULa5qaOS.js",
      "_index.773IOigk.js",
      "_sku.HeG39Ytu.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.BZJZ2D2o.js",
      "_isUndefined.IZwZ21d-.js",
      "_index.qyn17qGn.js",
      "_index.NzpJhA4o.js",
      "_strings.S9vBrqjb.js"
    ],
    "css": [
      "_id_.m-29Dv0K.css",
      "popover.LAISAeEG.css",
      "radio-button.l7x146Nf.css",
      "radio-group.P_Xz2fNs.css",
      "radio.eYTrrdr6.css"
    ]
  },
  "_id_.m-29Dv0K.css": {
    "file": "_id_.m-29Dv0K.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.WNPV23Wi.js",
    "src": "pages/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.UH49BTNL.js",
      "_nuxt-link.XH-MVhO_.js",
      "_AutoIncre.vue.SsWEnZit.js",
      "_empty.fFIhc26R.js",
      "_scrollbar.vaSaNhfU.js",
      "_index.vurJ-8I1.js",
      "_popper.QdsbmO3I.js",
      "_index.773IOigk.js",
      "_create-shadow.bA5h4BDq.js",
      "_effect-creative.SneNhbIu.js",
      "_index.3l1IJwnP.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_GoodsListSsr.2N9WV2Fy.js",
      "_tabs.h9ufq8X2.js",
      "_ElImage.k0tUPKKB.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isUndefined.IZwZ21d-.js",
      "_strings.S9vBrqjb.js",
      "_index.6Zu71XyI.js",
      "_debounce.BZJZ2D2o.js"
    ],
    "dynamicImports": [
      "components/list/GoodsList.vue"
    ],
    "css": [
      "index.IfgpexZK.css",
      "popover.LAISAeEG.css"
    ]
  },
  "index.IfgpexZK.css": {
    "file": "index.IfgpexZK.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/order/comment/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_id_.n5pCxff0.js",
    "src": "pages/order/comment/[id].vue",
    "isDynamicEntry": true,
    "imports": [
      "_Switch.M8zbDlUV.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_progress.md-od6nt.js",
      "_upload.GHyKnOoC.js",
      "_dialog.PfSqVnTp.js",
      "_index.kdLAqwHJ.js",
      "_ElImage.k0tUPKKB.js",
      "_rate.v78QfR5p.js",
      "_checkbox.rb3XMZbv.js",
      "_nuxt-link.XH-MVhO_.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_notification.e-ZJlSA8.js",
      "_index.NzpJhA4o.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_cloneDeep.j3nuMen3.js",
      "_isEqual.0EEK5b_c.js",
      "_isUndefined.IZwZ21d-.js",
      "_debounce.BZJZ2D2o.js",
      "_hasIn.hzmQIp0-.js",
      "_flatten.RrtlTkgk.js"
    ],
    "css": [
      "_id_.65PfMBS2.css"
    ]
  },
  "_id_.65PfMBS2.css": {
    "file": "_id_.65PfMBS2.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/order/detail.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "detail.qVR-KRFx.js",
    "src": "pages/order/detail.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.k0tUPKKB.js",
      "_nuxt-link.XH-MVhO_.js",
      "_divider.juRht5Xl.js",
      "_DelayTimer.vue.qFVFswae.js",
      "_Switch.M8zbDlUV.js",
      "_index.6Zu71XyI.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_bills.BjmaER8r.js",
      "_index.NzpJhA4o.js",
      "_useOrderStore.1ouOE3CG.js",
      "_index.AQSM7h3o.js",
      "_tag.UH49BTNL.js",
      "_scrollbar.vaSaNhfU.js",
      "_select.pKShklwF.js",
      "_input-number.u0zwTS7a.js",
      "_popper.QdsbmO3I.js",
      "_index.3l1IJwnP.js",
      "_sku.HeG39Ytu.js",
      "_empty.fFIhc26R.js",
      "_notification.e-ZJlSA8.js",
      "_useWebToast.aIgCezK0.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.BZJZ2D2o.js",
      "_strings.S9vBrqjb.js",
      "_isEqual.0EEK5b_c.js",
      "_hasIn.hzmQIp0-.js",
      "_index.XHYZfdwx.js",
      "_index.qyn17qGn.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "dynamicImports": [
      "node_modules/element-plus/es/components/text/index.mjs"
    ],
    "css": [
      "detail.BmClJIDc.css",
      "radio.eYTrrdr6.css",
      "radio-group.P_Xz2fNs.css"
    ]
  },
  "detail.BmClJIDc.css": {
    "file": "detail.BmClJIDc.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/order/list.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "list.fXeQK2VK.js",
    "src": "pages/order/list.vue",
    "isDynamicEntry": true,
    "imports": [
      "_divider.juRht5Xl.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_date-picker.fKop_G0U.js",
      "_DelayTimer.vue.qFVFswae.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_ElImage.k0tUPKKB.js",
      "_tag.UH49BTNL.js",
      "_useOrderStore.1ouOE3CG.js",
      "_index.NzpJhA4o.js",
      "_AutoIncre.vue.SsWEnZit.js",
      "_scrollbar.vaSaNhfU.js",
      "_popper.QdsbmO3I.js",
      "_notification.e-ZJlSA8.js",
      "_tabs.h9ufq8X2.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_localeData.Jy9s0tdq.js",
      "_arrays.9GuX8ZvT.js",
      "_flatten.RrtlTkgk.js",
      "_index.qyn17qGn.js",
      "_debounce.BZJZ2D2o.js",
      "_index.XHYZfdwx.js",
      "_isEqual.0EEK5b_c.js",
      "_isUndefined.IZwZ21d-.js",
      "_strings.S9vBrqjb.js",
      "_index.6Zu71XyI.js"
    ],
    "css": [
      "list.pKmG3IwD.css"
    ]
  },
  "list.pKmG3IwD.css": {
    "file": "list.pKmG3IwD.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/search/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.w-FsccMz.js",
    "src": "pages/search/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_checkbox.rb3XMZbv.js",
      "_select.pKShklwF.js",
      "_tag.UH49BTNL.js",
      "_tabs.h9ufq8X2.js",
      "_empty.fFIhc26R.js",
      "_scrollbar.vaSaNhfU.js",
      "_popper.QdsbmO3I.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isEqual.0EEK5b_c.js",
      "_hasIn.hzmQIp0-.js",
      "_flatten.RrtlTkgk.js",
      "_strings.S9vBrqjb.js",
      "_debounce.BZJZ2D2o.js",
      "_index.XHYZfdwx.js",
      "_index.6Zu71XyI.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "dynamicImports": [
      "components/list/GoodsList.vue",
      "components/Comm/PostList.vue"
    ],
    "css": [
      "index.J2x3iyFg.css"
    ]
  },
  "index.J2x3iyFg.css": {
    "file": "index.J2x3iyFg.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/setting/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.3NXrQ9dw.js",
    "src": "pages/setting/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "_divider.juRht5Xl.js",
      "_select.pKShklwF.js",
      "_index.AQSM7h3o.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.UH49BTNL.js",
      "_scrollbar.vaSaNhfU.js",
      "_popper.QdsbmO3I.js",
      "_notification.e-ZJlSA8.js",
      "_strings.S9vBrqjb.js",
      "_isEqual.0EEK5b_c.js",
      "_debounce.BZJZ2D2o.js",
      "_hasIn.hzmQIp0-.js",
      "_index.XHYZfdwx.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "css": [
      "index.z1SuaKix.css",
      "radio-button.l7x146Nf.css",
      "radio-group.P_Xz2fNs.css"
    ]
  },
  "index.z1SuaKix.css": {
    "file": "index.z1SuaKix.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/address.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "address.10nUEJnU.js",
    "src": "pages/user/address.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/element-plus/es/components/text/index.mjs",
      "node_modules/nuxt/dist/app/entry.js",
      "_scrollbar.vaSaNhfU.js",
      "_checkbox.rb3XMZbv.js",
      "_index.AQSM7h3o.js",
      "_strings.S9vBrqjb.js",
      "_isEqual.0EEK5b_c.js",
      "_arrays.9GuX8ZvT.js",
      "_flatten.RrtlTkgk.js",
      "_cloneDeep.j3nuMen3.js",
      "_popper.QdsbmO3I.js",
      "_tag.UH49BTNL.js",
      "_index.XHYZfdwx.js",
      "_debounce.BZJZ2D2o.js",
      "_dialog.PfSqVnTp.js",
      "_divider.juRht5Xl.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_hasIn.hzmQIp0-.js",
      "_isUndefined.IZwZ21d-.js"
    ],
    "css": [
      "address.1z3UCWAo.css",
      "radio.eYTrrdr6.css",
      "checkbox-group.d5XbR8TY.css"
    ]
  },
  "address.1z3UCWAo.css": {
    "file": "address.1z3UCWAo.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/collect.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "collect.5zKj2dFh.js",
    "src": "pages/user/collect.vue",
    "isDynamicEntry": true,
    "imports": [
      "_divider.juRht5Xl.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_checkbox.rb3XMZbv.js",
      "_ElImage.k0tUPKKB.js",
      "_scrollbar.vaSaNhfU.js",
      "_collect.8jNWkT1R.js",
      "_tabs.h9ufq8X2.js",
      "_tag.UH49BTNL.js",
      "_nuxt-link.XH-MVhO_.js",
      "_TagList.vue.GI6FYNXx.js",
      "_AutoIncre.vue.SsWEnZit.js",
      "_post.PAYQCZsz.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isEqual.0EEK5b_c.js",
      "_hasIn.hzmQIp0-.js",
      "_flatten.RrtlTkgk.js",
      "_debounce.BZJZ2D2o.js",
      "_strings.S9vBrqjb.js",
      "_index.6Zu71XyI.js"
    ],
    "css": [
      "collect.4jK4CO3w.css",
      "checkbox-group.d5XbR8TY.css"
    ]
  },
  "collect.4jK4CO3w.css": {
    "file": "collect.4jK4CO3w.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/info.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "info.bW8Pgrda.js",
    "src": "pages/user/info.vue",
    "isDynamicEntry": true,
    "imports": [
      "_ElImage.k0tUPKKB.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.vurJ-8I1.js",
      "_popper.QdsbmO3I.js",
      "_upload.GHyKnOoC.js",
      "_date-picker.fKop_G0U.js",
      "_select.pKShklwF.js",
      "_progress.md-od6nt.js",
      "_scrollbar.vaSaNhfU.js",
      "_tag.UH49BTNL.js",
      "_nuxt-link.XH-MVhO_.js",
      "_TagList.vue.GI6FYNXx.js",
      "_AutoIncre.vue.SsWEnZit.js",
      "_post.PAYQCZsz.js",
      "_tabs.h9ufq8X2.js",
      "_UserPostTotal.vue.tbXe7b-A.js",
      "_SigninCard.vue.wop5yLVp.js",
      "_index.jbqOgio6.js",
      "_debounce.BZJZ2D2o.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isUndefined.IZwZ21d-.js",
      "_cloneDeep.j3nuMen3.js",
      "_isEqual.0EEK5b_c.js",
      "_localeData.Jy9s0tdq.js",
      "_arrays.9GuX8ZvT.js",
      "_flatten.RrtlTkgk.js",
      "_index.qyn17qGn.js",
      "_index.XHYZfdwx.js",
      "_strings.S9vBrqjb.js",
      "_hasIn.hzmQIp0-.js",
      "_index.6Zu71XyI.js"
    ],
    "css": [
      "info.ZO--Iv68.css",
      "popover.LAISAeEG.css",
      "menu-item.f0mNRiTD.css"
    ]
  },
  "info.ZO--Iv68.css": {
    "file": "info.ZO--Iv68.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/post.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "post.X9ksi4dt.js",
    "src": "pages/user/post.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.k0tUPKKB.js",
      "_select.pKShklwF.js",
      "_tag.UH49BTNL.js",
      "_scrollbar.vaSaNhfU.js",
      "_popper.QdsbmO3I.js",
      "_StatusTag.2v5_W-kD.js",
      "_nuxt-link.XH-MVhO_.js",
      "_TagList.vue.GI6FYNXx.js",
      "_post.PAYQCZsz.js",
      "_AutoIncre.vue.SsWEnZit.js",
      "_notification.e-ZJlSA8.js",
      "_tabs.h9ufq8X2.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_debounce.BZJZ2D2o.js",
      "_strings.S9vBrqjb.js",
      "_isEqual.0EEK5b_c.js",
      "_hasIn.hzmQIp0-.js",
      "_index.XHYZfdwx.js",
      "_isUndefined.IZwZ21d-.js",
      "_index.6Zu71XyI.js"
    ],
    "css": [
      "post.yVQn8Ib0.css"
    ]
  },
  "post.yVQn8Ib0.css": {
    "file": "post.yVQn8Ib0.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/safe.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "safe.LBEuX7Lp.js",
    "src": "pages/user/safe.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.UH49BTNL.js",
      "_scrollbar.vaSaNhfU.js",
      "_avatar.8EI5kUhP.js",
      "_divider.juRht5Xl.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_useOrderStore.1ouOE3CG.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_index.NzpJhA4o.js"
    ],
    "css": [
      "safe.73roRH3g.css"
    ]
  },
  "safe.73roRH3g.css": {
    "file": "safe.73roRH3g.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/shopcart.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "shopcart.Vm_oSm7G.js",
    "src": "pages/user/shopcart.vue",
    "isDynamicEntry": true,
    "imports": [
      "_checkbox.rb3XMZbv.js",
      "_ShopLine.Hje7RPoh.js",
      "_nuxt-link.XH-MVhO_.js",
      "_AutoIncre.vue.SsWEnZit.js",
      "_scrollbar.vaSaNhfU.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useOrderStore.1ouOE3CG.js",
      "_isEqual.0EEK5b_c.js",
      "_hasIn.hzmQIp0-.js",
      "_flatten.RrtlTkgk.js",
      "_ElImage.k0tUPKKB.js",
      "_debounce.BZJZ2D2o.js",
      "_select.pKShklwF.js",
      "_popper.QdsbmO3I.js",
      "_isUndefined.IZwZ21d-.js",
      "_tag.UH49BTNL.js",
      "_strings.S9vBrqjb.js",
      "_index.XHYZfdwx.js",
      "_input-number.u0zwTS7a.js",
      "_index.qyn17qGn.js",
      "_sku.HeG39Ytu.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_index.NzpJhA4o.js"
    ],
    "css": [
      "shopcart.T7K9gx-c.css",
      "checkbox-group.d5XbR8TY.css"
    ]
  },
  "shopcart.T7K9gx-c.css": {
    "file": "shopcart.T7K9gx-c.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/wallet.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "wallet.1FcBfl84.js",
    "src": "pages/user/wallet.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/element-plus/es/components/text/index.mjs",
      "node_modules/nuxt/dist/app/entry.js",
      "_create-shadow.bA5h4BDq.js",
      "_progress.md-od6nt.js",
      "_index.vurJ-8I1.js",
      "_popper.QdsbmO3I.js",
      "_bills.BjmaER8r.js",
      "_scrollbar.vaSaNhfU.js",
      "_input-number.u0zwTS7a.js",
      "_select.pKShklwF.js",
      "_tag.UH49BTNL.js",
      "_localeData.Jy9s0tdq.js",
      "_divider.juRht5Xl.js",
      "___commonjsHelpers__.1J56E-h6.js",
      "_isUndefined.IZwZ21d-.js",
      "_index.qyn17qGn.js",
      "_strings.S9vBrqjb.js",
      "_isEqual.0EEK5b_c.js",
      "_debounce.BZJZ2D2o.js",
      "_hasIn.hzmQIp0-.js",
      "_index.XHYZfdwx.js"
    ],
    "css": [
      "wallet.0lzzqGc7.css",
      "popover.LAISAeEG.css"
    ]
  },
  "wallet.0lzzqGc7.css": {
    "file": "wallet.0lzzqGc7.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
