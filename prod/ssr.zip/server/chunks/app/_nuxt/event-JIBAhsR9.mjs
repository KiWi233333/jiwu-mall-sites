const UPDATE_MODEL_EVENT = "update:modelValue";
const CHANGE_EVENT = "change";
const INPUT_EVENT = "input";

export { CHANGE_EVENT as C, INPUT_EVENT as I, UPDATE_MODEL_EVENT as U };
//# sourceMappingURL=event-JIBAhsR9.mjs.map
