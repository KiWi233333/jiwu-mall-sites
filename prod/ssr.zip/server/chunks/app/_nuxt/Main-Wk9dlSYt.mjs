import { m as useFetch, o as BaseUrl, p as useHttp, u as useUserStore, B as BaseUrlImg, k as useColorMode, b as _export_sfc, h as ElMessageBox, S as StatusCode, E as ElMessage } from '../server.mjs';
import { u as useChatStore, M as MessageType, r as refundChatMessage, R as RoomType, d as deleteChatMessage } from './contact-sCHXj914.mjs';
import { useSSRContext, defineComponent, toRefs, resolveComponent, mergeProps, unref, withCtx, createTextVNode, computed, createVNode, resolveDynamicComponent } from 'vue';
import { _ as __nuxt_component_1 } from './ElImage-8tI1WWPA.mjs';
import { E as ElTag } from './index-yIbwfnuv.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderStyle, ssrRenderVNode } from 'vue/server-renderer';
import { d as useDateFormat } from './index-jPFN1mQz.mjs';
import ContextMenu from '@imengyu/vue3-context-menu';

function getRoomGroupUserPage(roomId = null, pageSize = 10, cursor = null, token) {
  return useHttp.get("/chat/room/group/member/page", {
    roomId,
    pageSize,
    cursor
  }, {
    headers: {
      Authorization: token
    }
  });
}
var ChatOfflineType = /* @__PURE__ */ ((ChatOfflineType2) => {
  ChatOfflineType2[ChatOfflineType2["ONLINE"] = 1] = "ONLINE";
  ChatOfflineType2[ChatOfflineType2["OFFLINE"] = 0] = "OFFLINE";
  return ChatOfflineType2;
})(ChatOfflineType || {});
var ChatRoomRoleEnum = /* @__PURE__ */ ((ChatRoomRoleEnum2) => {
  ChatRoomRoleEnum2[ChatRoomRoleEnum2["OWNER"] = 1] = "OWNER";
  ChatRoomRoleEnum2[ChatRoomRoleEnum2["ADMIN"] = 2] = "ADMIN";
  ChatRoomRoleEnum2[ChatRoomRoleEnum2["MEMBER"] = 3] = "MEMBER";
  return ChatRoomRoleEnum2;
})(ChatRoomRoleEnum || {});
const ChatRoomRoleEnumMap = {
  [
    1
    /* OWNER */
  ]: "\u7FA4\u4E3B",
  [
    2
    /* ADMIN */
  ]: "\u7BA1\u7406\u5458",
  [
    3
    /* MEMBER */
  ]: "\u6210\u5458"
};
function getRoomGroupAllUser(roomId, token) {
  return useFetch(`${BaseUrl}/chat/room/group/member/list/${roomId}`, {
    headers: {
      Authorization: token
    }
  }, "$nzaFCPeOAS");
}
function addNewGroupRoom(dto, token) {
  return useHttp.post("/chat/room/group", dto, {
    headers: {
      Authorization: token
    }
  });
}
function addGroupMember(dto, token) {
  return useHttp.post("/chat/room/group/member", dto, {
    headers: {
      Authorization: token
    }
  });
}
function exitRoomGroup(roomId, token) {
  return useHttp.deleted(`/chat/room/group/member/exit/${roomId}`, {}, {
    headers: {
      Authorization: token
    }
  });
}
function exitRoomGroupByUid(roomId, uid, token) {
  return useHttp.deleted(`/chat/room/group/member/${roomId}/${uid}`, {}, {
    headers: {
      Authorization: token
    }
  });
}
function addChatRoomAdmin(dto, token) {
  return useHttp.put("/chat/room/group/admin", dto, {
    headers: {
      Authorization: token
    }
  });
}
function delChatRoomAdmin(dto, token) {
  return useHttp.deleted("/chat/room/group/admin", {}, {
    headers: {
      Authorization: token
    },
    params: {
      ...dto
    }
  });
}
const _sfc_main$6 = /* @__PURE__ */ defineComponent({
  __name: "AiMsg",
  __ssrInlineRender: true,
  props: {
    data: {},
    index: {}
  },
  setup(__props) {
    var _a;
    const props = __props;
    const {
      data
    } = toRefs(props);
    useChatStore();
    const user = useUserStore();
    const nowDate = Date.now();
    function getTime(time) {
      return nowDate - +time > 24 * 3600 ? useDateFormat(time, "YYYY-MM-DD HH:mm:ss").value.toString() : useDateFormat(time, "HH:mm:ss").value.toString();
    }
    const body = ((_a = props.data.message) == null ? void 0 : _a.body) || {};
    return (_ctx, _push, _parent, _attrs) => {
      var _a2, _b, _c, _d, _e, _f, _g;
      const _component_CardElImage = __nuxt_component_1;
      const _component_el_tag = ElTag;
      const _component_v_md_preview = resolveComponent("v-md-preview");
      _push(`<!--[--><div${ssrRenderAttrs(mergeProps(_ctx.$attrs, {
        label: unref(data).roomId,
        class: {
          self: ((_b = (_a2 = unref(data)) == null ? void 0 : _a2.fromUser) == null ? void 0 : _b.userId) === ((_c = unref(user)) == null ? void 0 : _c.userInfo.id)
        },
        "max-w-full": "",
        "w-fit": "",
        flex: "",
        "flex-shrink-0": "",
        "gap-4": "",
        "p-2": "",
        "py-3": "",
        "transition-300": "",
        "transition-transform": "",
        "active:scale-95": ""
      }))} data-v-d29b8465>`);
      _push(ssrRenderComponent(_component_CardElImage, {
        src: ("BaseUrlImg" in _ctx ? _ctx.BaseUrlImg : unref(BaseUrlImg)) + unref(data).fromUser.avatar,
        fit: "cover",
        class: "avatar h-2.4rem w-2.4rem flex-shrink-0 rounded-1/2 object-cover border-default"
      }, null, _parent));
      _push(`<div class="flex flex-col" data-v-d29b8465><div class="mb-2 block flex flex-row items-center gap-2" data-v-d29b8465><small data-v-d29b8465>${ssrInterpolate(unref(data).fromUser.nickName)}</small>`);
      if (unref(data).fromUser.userId === unref(user).userInfo.id) {
        _push(ssrRenderComponent(_component_el_tag, {
          class: "op-80",
          effect: "dark",
          size: "small"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(` \u81EA\u5DF1 `);
            } else {
              return [createTextVNode(" \u81EA\u5DF1 ")];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="self-child msg-popper w-fit p-2 px-4 leading-1.2em shadow-sm card-default" data-v-d29b8465>`);
      if (unref(data).fromUser.userId === unref(user).userInfo.id) {
        _push(`<!--[-->${ssrInterpolate((_d = unref(data).message) == null ? void 0 : _d.content)}<!--]-->`);
      } else {
        _push(ssrRenderComponent(_component_v_md_preview, {
          class: "markdown",
          text: ((_e = unref(data).message) == null ? void 0 : _e.content) || ""
        }, null, _parent));
      }
      _push(`</div>`);
      if ((_f = unref(body)) == null ? void 0 : _f.reply) {
        _push(`<small mt-2 class="cursor-pointer truncate px-2 py-1 op-70 border-default card-default" data-v-d29b8465> \u56DE\u590D: ${ssrInterpolate(`${unref(body).reply.nickName}:${((_g = unref(body).reply) == null ? void 0 : _g.body) || ""}`)}</small>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
      if (_ctx.index % 8 === 0) {
        _push(`<p w-full py-2 text-center text-0.8em op-80 data-v-d29b8465>${ssrInterpolate(getTime(unref(data).message.sendTime))}</p>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Chat/Msg/AiMsg.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const ChatMsgAiMsg = /* @__PURE__ */ _export_sfc(_sfc_main$6, [["__scopeId", "data-v-d29b8465"]]);
const _sfc_main$5 = /* @__PURE__ */ defineComponent({
  __name: "Delete",
  __ssrInlineRender: true,
  props: {
    data: {}
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b;
      _push(`<span${ssrRenderAttrs(mergeProps({
        class: "mx-a my-2 w-fit rounded-1em px-4 py-1 text-0.8rem font-500 op-60 border-default card-default"
      }, _attrs))} data-v-0bb61cbc>${ssrInterpolate((_b = (_a = _ctx.data) == null ? void 0 : _a.message) == null ? void 0 : _b.content)}</span>`);
    };
  }
});
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Chat/Msg/Delete.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const ChatMsgDelete = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["__scopeId", "data-v-0bb61cbc"]]);
const _sfc_main$4 = /* @__PURE__ */ defineComponent({
  __name: "Img",
  __ssrInlineRender: true,
  props: {
    data: {},
    index: {}
  },
  setup(__props) {
    var _a;
    const props = __props;
    const {
      data
    } = toRefs(props);
    useChatStore();
    const user = useUserStore();
    const nowDate = Date.now();
    function getTime(time) {
      return nowDate - +time > 24 * 3600 ? useDateFormat(time, "YYYY-MM-DD HH:mm:ss").value.toString() : useDateFormat(time, "HH:mm:ss").value.toString();
    }
    const body = ((_a = props.data.message) == null ? void 0 : _a.body) || {};
    return (_ctx, _push, _parent, _attrs) => {
      var _a2, _b, _c, _d, _e;
      const _component_CardElImage = __nuxt_component_1;
      const _component_el_tag = ElTag;
      _push(`<!--[--><div${ssrRenderAttrs(mergeProps(_ctx.$attrs, {
        label: unref(data).roomId,
        class: {
          self: ((_b = (_a2 = unref(data)) == null ? void 0 : _a2.fromUser) == null ? void 0 : _b.userId) === ((_c = unref(user)) == null ? void 0 : _c.userInfo.id)
        },
        "max-w-full": "",
        "w-fit": "",
        flex: "",
        "gap-4": "",
        "p-2": "",
        "py-3": "",
        "transition-300": "",
        "transition-transform": "",
        "active:scale-95": ""
      }))} data-v-19797a6d>`);
      _push(ssrRenderComponent(_component_CardElImage, {
        src: ("BaseUrlImg" in _ctx ? _ctx.BaseUrlImg : unref(BaseUrlImg)) + unref(data).fromUser.avatar,
        fit: "cover",
        class: "avatar h-2.4rem w-2.4rem rounded-1/2 object-cover border-default"
      }, null, _parent));
      _push(`<div class="flex flex-col" data-v-19797a6d><small class="mb-2 block flex flex-row items-center gap-2" data-v-19797a6d>${ssrInterpolate(unref(data).fromUser.nickName)}</small><div class="msg-popper w-fit" style="${ssrRenderStyle({
        "border-radius": "6px"
      })}" data-v-19797a6d>`);
      if (unref(body).url) {
        _push(ssrRenderComponent(_component_CardElImage, {
          src: ("BaseUrlImg" in _ctx ? _ctx.BaseUrlImg : unref(BaseUrlImg)) + unref(body).url,
          class: "h-8rem w-8rem shadow-sm border-default v-card",
          "preview-teleported": "",
          alt: unref(body).url,
          "preview-src-list": [("BaseUrlImg" in _ctx ? _ctx.BaseUrlImg : unref(BaseUrlImg)) + unref(body).url]
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<p w-fit p-2 leading-1.2em class="self-child msg-popper transform-origin-ct transition-300 transition-transform active:scale-95" card-default data-v-19797a6d>${ssrInterpolate(unref(data).message.content)}</p></div>`);
      if ((_d = unref(body)) == null ? void 0 : _d.reply) {
        _push(`<small mt-2 class="max-h-4rem max-w-20rem w-fit cursor-pointer break-words px-2 py-1 op-70 border-default card-default" data-v-19797a6d>`);
        _push(ssrRenderComponent(_component_el_tag, {
          size: "small"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`\u56DE\u590D`);
            } else {
              return [createTextVNode("\u56DE\u590D")];
            }
          }),
          _: 1
        }, _parent));
        _push(` ${ssrInterpolate(`${unref(body).reply.nickName}:${((_e = unref(body).reply) == null ? void 0 : _e.body) || ""}`)}</small>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
      if (_ctx.index % 8 === 0) {
        _push(`<p w-full py-2 text-center text-0.8em op-80 data-v-19797a6d>${ssrInterpolate(getTime(unref(data).message.sendTime))}</p>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Chat/Msg/Img.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const ChatMsgImg = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["__scopeId", "data-v-19797a6d"]]);
const _sfc_main$3 = /* @__PURE__ */ defineComponent({
  __name: "Recall",
  __ssrInlineRender: true,
  props: {
    data: {}
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b;
      _push(`<span${ssrRenderAttrs(mergeProps({
        class: "mx-a my-2 w-fit rounded-1em px-4 py-1 text-0.8rem font-500 op-60 border-default card-default"
      }, _attrs))} data-v-6ddeba73>${ssrInterpolate((_b = (_a = _ctx.data) == null ? void 0 : _a.message) == null ? void 0 : _b.content)}</span>`);
    };
  }
});
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Chat/Msg/Recall.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const ChatMsgRecall = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["__scopeId", "data-v-6ddeba73"]]);
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "System",
  __ssrInlineRender: true,
  props: {
    data: {}
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b;
      _push(`<div${ssrRenderAttrs(mergeProps({
        "w-full": "",
        "flex-row-c-c": "",
        truncate: "",
        "p-2": "",
        "text-center": ""
      }, _attrs))} data-v-80902259><span class="rounded-1em px-4 py-1 text-0.8rem font-500 op-60" data-v-80902259>${ssrInterpolate((_b = (_a = _ctx.data) == null ? void 0 : _a.message) == null ? void 0 : _b.content)}</span></div>`);
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Chat/Msg/System.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const ChatMsgSystem = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-80902259"]]);
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "Text",
  __ssrInlineRender: true,
  props: {
    data: {},
    index: {}
  },
  setup(__props) {
    var _a;
    const props = __props;
    const {
      data
    } = toRefs(props);
    const chat = useChatStore();
    const user = useUserStore();
    const nowDate = Date.now();
    function getTime(time) {
      return nowDate - +time > 24 * 3600 ? useDateFormat(time, "YYYY-MM-DD HH:mm:ss").value.toString() : useDateFormat(time, "HH:mm:ss").value.toString();
    }
    const body = ((_a = props.data.message) == null ? void 0 : _a.body) || {};
    const getAtText = computed(() => {
      if ((body == null ? void 0 : body.atUidList) && (body == null ? void 0 : body.atUidList.length) > 0)
        return chat.onOfflineList.filter((item) => {
          var _a2;
          return (_a2 = body == null ? void 0 : body.atUidList) == null ? void 0 : _a2.includes(item.userId);
        }).map((item) => `@${item.nickName}`).join("\u3001");
      else
        return "";
    });
    return (_ctx, _push, _parent, _attrs) => {
      var _a2, _b, _c, _d, _e, _f, _g;
      const _component_CardElImage = __nuxt_component_1;
      _push(`<!--[--><div${ssrRenderAttrs(mergeProps(_ctx.$attrs, {
        label: unref(data).roomId,
        class: {
          self: ((_b = (_a2 = unref(data)) == null ? void 0 : _a2.fromUser) == null ? void 0 : _b.userId) === ((_c = unref(user)) == null ? void 0 : _c.userInfo.id)
        },
        "max-w-full": "",
        "w-fit": "",
        flex: "",
        "gap-4": "",
        "p-2": "",
        "py-3": ""
      }))} data-v-5ee8d67a>`);
      _push(ssrRenderComponent(_component_CardElImage, {
        src: ("BaseUrlImg" in _ctx ? _ctx.BaseUrlImg : unref(BaseUrlImg)) + unref(data).fromUser.avatar,
        fit: "cover",
        class: "avatar h-2.4rem w-2.4rem flex-shrink-0 rounded-1/2 object-cover border-default"
      }, null, _parent));
      _push(`<div class="flex flex-col" data-v-5ee8d67a><small class="mb-2 block flex flex-row items-center gap-2" data-v-5ee8d67a>${ssrInterpolate(unref(data).fromUser.nickName)}</small><p transform-origin-ct transition-300 transition-transform active:scale-95 class="self-child msg-popper w-fit p-2 px-4 leading-1.2em shadow-sm card-default" data-v-5ee8d67a>${ssrInterpolate(unref(data).message.content)}</p>`);
      if (((_d = unref(body)) == null ? void 0 : _d.atUidList) && ((_e = unref(body)) == null ? void 0 : _e.atUidList.length)) {
        _push(`<small mt-2 class="flex-ml-a w-fit cursor-pointer truncate px-2 py-1 op-70 border-default card-default" data-v-5ee8d67a>${ssrInterpolate(unref(getAtText))}</small>`);
      } else {
        _push(`<!---->`);
      }
      if ((_f = unref(body)) == null ? void 0 : _f.reply) {
        _push(`<small mt-2 class="cursor-pointer truncate px-2 py-1 op-70 border-default card-default" data-v-5ee8d67a> \u56DE\u590D: ${ssrInterpolate(`${unref(body).reply.nickName}:${((_g = unref(body).reply) == null ? void 0 : _g.body) || ""}`)}</small>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
      if (_ctx.index % 8 === 0) {
        _push(`<p w-full py-2 text-center text-0.8em op-80 data-v-5ee8d67a>${ssrInterpolate(getTime(unref(data).message.sendTime))}</p>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Chat/Msg/Text.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const ChatMsgText = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-5ee8d67a"]]);
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Main",
  __ssrInlineRender: true,
  props: {
    data: {},
    index: {}
  },
  setup(__props) {
    const props = __props;
    const map = {
      [MessageType.TEXT]: ChatMsgText,
      [MessageType.RECALL]: ChatMsgRecall,
      [MessageType.DELETE]: ChatMsgDelete,
      [MessageType.IMG]: ChatMsgImg,
      [MessageType.SYSTEM]: ChatMsgSystem,
      [MessageType.AI_CHAT]: ChatMsgAiMsg
    };
    const chat = useChatStore();
    const user = useUserStore();
    computed(() => {
      var _a, _b;
      return (_b = (_a = chat.theContact) == null ? void 0 : _a.member) == null ? void 0 : _b.role;
    });
    computed(() => {
      var _a, _b;
      return ((_b = (_a = chat.theContact) == null ? void 0 : _a.member) == null ? void 0 : _b.role) === ChatRoomRoleEnum.OWNER;
    });
    const isTheGroupPermission = computed(() => {
      var _a, _b, _c, _d;
      return ((_b = (_a = chat.theContact) == null ? void 0 : _a.member) == null ? void 0 : _b.role) === ChatRoomRoleEnum.OWNER || ((_d = (_c = chat.theContact) == null ? void 0 : _c.member) == null ? void 0 : _d.role) === ChatRoomRoleEnum.ADMIN;
    });
    const colorMode = useColorMode();
    function onContextMenu(e, item) {
      e.preventDefault();
      const isSelf = user.userInfo.id === item.fromUser.userId;
      const opt = {
        x: e.x,
        y: e.y,
        theme: colorMode.preference === "dark" ? "mac dark" : "wind10",
        items: [{
          label: "\u64A4\u56DE",
          hidden: !isSelf,
          customClass: "group",
          icon: "i-solar:backspace-broken group-btn-danger",
          onClick: () => {
            refundMsg(item.message.roomId, item.message.id);
          }
        }, {
          label: "\u5220\u9664",
          customClass: "group",
          icon: "i-solar:trash-bin-minimalistic-outline group-btn-danger",
          hidden: !isTheGroupPermission.value,
          onClick: () => {
            deleteMsg(item.message.roomId, item.message.id);
          }
        }, {
          label: "@TA",
          customClass: "group",
          hidden: isSelf,
          onClick: () => {
            chat.setAtUid(item.fromUser.userId);
          }
        }, {
          label: "\u56DE\u590D",
          icon: "i-solar:arrow-to-down-right-line-duotone -rotate-90 group-btn-info",
          hidden: isSelf,
          onClick: () => {
            chat.setReplyMsg(item);
          }
        }]
      };
      ContextMenu.showContextMenu(opt);
    }
    function refundMsg(roomId, msgId) {
      ElMessageBox.confirm("\u662F\u5426\u786E\u8BA4\u64A4\u56DE\u6D88\u606F\uFF1F", "\u64A4\u56DE\u63D0\u793A", {
        lockScroll: false,
        confirmButtonText: "\u786E \u8BA4",
        confirmButtonClass: "el-button--primary is-plain border-default ",
        cancelButtonText: "\u53D6 \u6D88",
        center: true,
        callback: async (action) => {
          if (action !== "confirm")
            return;
          const res = await refundChatMessage(roomId, msgId, user.getToken);
          if (res.code === StatusCode.SUCCESS) {
            ElMessage.success("\u64A4\u56DE\u6210\u529F\uFF01");
            if (props.data.message.id === msgId) {
              props.data.message.type = MessageType.RECALL;
              props.data.message.content = `${chat.theContact.type === RoomType.GROUP ? `"${props.data.fromUser.nickName}"` : '"\u5BF9\u65B9"'}\u64A4\u56DE\u4E86\u4E00\u6761\u6D88\u606F`;
              props.data.message.body = void 0;
            }
          }
        }
      });
    }
    function deleteMsg(roomId, msgId) {
      ElMessageBox.confirm("\u662F\u5426\u786E\u8BA4\u5220\u9664\u6D88\u606F\uFF1F", "\u5220\u9664\u63D0\u793A", {
        lockScroll: false,
        confirmButtonText: "\u786E \u8BA4",
        confirmButtonClass: "el-button--primary is-plain border-default ",
        cancelButtonText: "\u53D6 \u6D88",
        center: true,
        callback: async (action) => {
          if (action !== "confirm")
            return;
          const res = await deleteChatMessage(roomId, msgId, user.getToken);
          if (res.code === StatusCode.SUCCESS) {
            ElMessage.success("\u5220\u9664\u6210\u529F\uFF01");
            if (props.data.message.id === msgId) {
              props.data.message.type = MessageType.RECALL;
              props.data.message.content = "\u5220\u9664\u4E86\u4E00\u6761\u6D88\u606F";
              props.data.message.body = void 0;
            }
          }
        }
      });
    }
    return (_ctx, _push, _parent, _attrs) => {
      var _a;
      ssrRenderVNode(_push, createVNode(resolveDynamicComponent(map[((_a = _ctx.data.message) == null ? void 0 : _a.type) || unref(MessageType).TEXT]), mergeProps({
        index: _ctx.index,
        data: _ctx.data
      }, _ctx.$attrs, {
        onContextmenu: ($event) => onContextMenu($event, _ctx.data)
      }, _attrs), null), _parent);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Chat/Msg/Main.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { ChatRoomRoleEnum as C, _sfc_main as _, ChatOfflineType as a, ChatRoomRoleEnumMap as b, getRoomGroupUserPage as c, exitRoomGroup as d, exitRoomGroupByUid as e, addChatRoomAdmin as f, getRoomGroupAllUser as g, delChatRoomAdmin as h, addGroupMember as i, addNewGroupRoom as j };
//# sourceMappingURL=Main-Wk9dlSYt.mjs.map
