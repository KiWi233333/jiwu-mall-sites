import { s as useWebNotification } from './index-jPFN1mQz.mjs';

function useWebToast(title, body, opts) {
  const windToast = useWebNotification({
    title,
    body,
    icon: "/logo.png",
    ...opts
  });
  if (windToast.isSupported)
    windToast.show();
}

export { useWebToast as u };
//# sourceMappingURL=useWebToast-VoGOplNu.mjs.map
