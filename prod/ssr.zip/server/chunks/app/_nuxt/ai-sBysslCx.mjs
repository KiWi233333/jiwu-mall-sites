import { b as _export_sfc, u as useUserStore, G as Gender, B as BaseUrlImg, _ as __nuxt_component_0, c as __nuxt_component_2 } from '../server.mjs';
import { E as ElScrollbar } from './scrollbar-PgUd-hJF.mjs';
import { _ as __nuxt_component_1 } from './Main-pp0zq3Uh.mjs';
import { E as ElForm, a as ElFormItem } from './form-item-ytrwvrsg.mjs';
import { _ as __nuxt_component_0$1 } from './nuxt-link-0N-juoBB.mjs';
import { _ as __nuxt_component_1$1 } from './ElImage-8tI1WWPA.mjs';
import { E as ElInput } from './index-X-uyRvzs.mjs';
import { useSSRContext, defineComponent, ref, watch, resolveDirective, withCtx, unref, mergeProps, withDirectives, openBlock, createBlock, Fragment, renderList, createVNode, createTextVNode, withModifiers } from 'vue';
import { u as useLocalStorage, a as useFullscreen } from './index-wP5MLg4Q.mjs';
import { M as MessageType } from './contact-sCHXj914.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderClass, ssrGetDirectiveProps, ssrRenderList } from 'vue/server-renderer';
import { W as WsStatusEnum } from './useWs-ZYDD5ZHV.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@formkit/auto-animate/vue';
import '@vue/shared';
import 'pinia-plugin-persistedstate';
import 'lodash-unified';
import 'currency.js';
import 'gsap';
import '@imengyu/vue3-context-menu';
import '@kangc/v-md-editor/lib/theme/vuepress.js';
import '@ctrl/tinycolor';
import 'async-validator';
import './objects-HNc5gIZI.mjs';
import './PreLoading-Sou-hyZj.mjs';
import './event-JIBAhsR9.mjs';
import './index-cZ2FI0MT.mjs';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "ai",
  __ssrInlineRender: true,
  setup(__props) {
    ref(false);
    ref({
      isHistory: true
      // 是否开启历史记录
    });
    const user = useUserStore();
    const form = ref({
      role: "user",
      content: ""
    });
    const status = ref(WsStatusEnum.CLOSE);
    const body = ref({
      ws: null
    });
    const dto = ref({
      header: {
        app_id: "3b3875ac",
        uid: user.userInfo.id
      },
      parameter: {
        chat: {
          domain: "general",
          temperature: 0.8,
          top_k: 4,
          max_tokens: 2028
        }
      },
      payload: {
        message: {
          text: [{
            role: "user",
            content: ""
          }]
        }
      }
    });
    const isChat = ref(false);
    const formRef = ref();
    function onSubmit() {
      var _a;
      if (status.value === WsStatusEnum.OPEN)
        return;
      (_a = formRef.value) == null ? void 0 : _a.validate((action) => {
        if (!action)
          return;
        isChat.value = true;
        senMsg(form.value.content, user.userInfo.id);
        scrollBottom();
        form.value.content = "";
      });
    }
    const msgList = useLocalStorage(`ai_chat_history_${user.userInfo.id}`, [{
      fromUser: {
        userId: "1739333818150862850",
        avatar: "image/2023-12-27/1653240351484801026/fab3eab2-e721-4e82-a98f-0bdbdb6e0068",
        gender: Gender.DEFAULT,
        nickName: "\u6781\u7269AI\u5BA2\u670D"
      },
      message: {
        id: 1,
        roomId: 0,
        sendTime: (/* @__PURE__ */ new Date()).toDateString(),
        content: "\u4F60\u597D\uFF01\u6B22\u8FCE\u5149\u4E34\u6781\u7269\u5708\uFF0C\u6709\u4EC0\u4E48\u53EF\u4EE5\u5E2E\u60A8\u7684\u5417\uFF1F",
        type: MessageType.AI_CHAT,
        body: {}
      }
    }]);
    function senMsg(msg, id) {
      if (body.value.ws && body.value.ws.OPEN === 1)
        return;
      msgList.value.push({
        fromUser: {
          userId: user.userInfo.id,
          avatar: user.userInfo.avatar,
          gender: user.userInfo.gender,
          nickName: user.userInfo.nickname
        },
        message: {
          id: Math.random() * 1e3,
          roomId: 0,
          sendTime: (/* @__PURE__ */ new Date()).toDateString(),
          content: msg,
          type: MessageType.TEXT,
          body: {}
        }
      });
      body.value.ws = new WebSocket("wss://spark-openapi.cn-huabei-1.xf-yun.com/v1/assistants/u8h3bh6wxkq8_v1");
      status.value = WsStatusEnum.OPEN;
      body.value.ws.onopen = (e) => {
        var _a;
        const last10 = msgList.value.slice(-10).map((item) => ({
          content: item.message.content,
          role: item.fromUser.userId === user.userInfo.id ? "user" : "assistant"
        }));
        last10.push({
          content: msg,
          role: "user"
        });
        dto.value.payload.message.text = last10;
        dto.value.header.uid = id;
        (_a = body.value.ws) == null ? void 0 : _a.send(JSON.stringify(dto.value));
        status.value = WsStatusEnum.OPEN;
      };
      body.value.ws.onclose = () => {
        status.value = WsStatusEnum.SAFE_CLOSE;
        body.value.ws = null;
        scrollBottom();
      };
      body.value.ws.onerror = () => {
        status.value = WsStatusEnum.CLOSE;
        body.value.ws = null;
        scrollBottom();
      };
      body.value.ws.onmessage = (e) => {
        var _a, _b;
        const data = JSON.parse(e.data);
        if (data) {
          status.value = data.header.code;
          const text = ((_b = (_a = data == null ? void 0 : data.payload) == null ? void 0 : _a.choices) == null ? void 0 : _b.text) || [];
          text.value = "";
          text.forEach((p) => {
            if (p && p.role === "assistant")
              text.value += p.content;
          });
          const theMsg = msgList.value.find((p) => {
            var _a2;
            return p.message.id === ((_a2 = data == null ? void 0 : data.header) == null ? void 0 : _a2.sid);
          });
          if (theMsg) {
            theMsg.message.content += text.value;
            return;
          }
          msgList.value.push({
            fromUser: {
              userId: "1739333818150862850",
              avatar: "image/2023-12-27/1653240351484801026/fab3eab2-e721-4e82-a98f-0bdbdb6e0068",
              gender: Gender.DEFAULT,
              nickName: "\u6781\u7269AI\u5BA2\u670D"
            },
            message: {
              id: data.header.sid,
              roomId: 0,
              sendTime: (/* @__PURE__ */ new Date()).toDateString(),
              content: text.value,
              type: MessageType.AI_CHAT,
              body: {}
            }
          });
        }
        status.value = WsStatusEnum.CLOSE;
        scrollBottom();
      };
    }
    watch(status, (newVal, oldVal) => {
      if (newVal === WsStatusEnum.OPEN) {
        isChat.value = newVal === WsStatusEnum.OPEN;
      } else {
        isChat.value = false;
        body.value.ws = null;
      }
    });
    const scollRef = ref();
    function scrollBottom() {
      var _a, _b, _c, _d, _e, _f, _g, _h, _i;
      if ((_b = (_a = scollRef.value) == null ? void 0 : _a.wrapRef) == null ? void 0 : _b.scrollTo) {
        (_f = (_c = scollRef.value) == null ? void 0 : _c.wrapRef) == null ? void 0 : _f.scrollTo({
          top: ((_e = (_d = scollRef == null ? void 0 : scollRef.value) == null ? void 0 : _d.wrapRef) == null ? void 0 : _e.scrollHeight) + 20 || 0,
          behavior: "smooth"
        });
      } else {
        (_i = scollRef.value) == null ? void 0 : _i.setScrollTop(((_h = (_g = scollRef == null ? void 0 : scollRef.value) == null ? void 0 : _g.wrapRef) == null ? void 0 : _h.scrollHeight) + 20 || 0);
      }
    }
    const useFull = useFullscreen();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLayout = __nuxt_component_0;
      const _component_el_scrollbar = ElScrollbar;
      const _component_ChatMsgMain = __nuxt_component_1;
      const _component_el_form = ElForm;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_CardElImage = __nuxt_component_1$1;
      const _component_el_form_item = ElFormItem;
      const _component_el_input = ElInput;
      const _component_BtnElButton = __nuxt_component_2;
      const _directive_auto_animate = resolveDirective("auto-animate");
      const _directive_auth = resolveDirective("auth");
      _push(`<div${ssrRenderAttrs(_attrs)} data-v-d10e1894>`);
      _push(ssrRenderComponent(_component_NuxtLayout, {
        name: "chat"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a, _b;
          if (_push2) {
            _push2(`<section class="w-full flex flex-col p-4 bg-color" data-v-d10e1894${_scopeId}><div class="mb-4 flex items-center gap-2 font-600 tracking-0.2em" data-v-d10e1894${_scopeId}><i class="i-solar:ghost-bold mr-2 p-0.8em text-[var(--el-color-primary)]" data-v-d10e1894${_scopeId}></i><p class="text-[var(--el-color-primary)]" data-v-d10e1894${_scopeId}> \u6781\u7269AI </p><i class="${ssrRenderClass([unref(useFull).isFullscreen ? "i-solar:full-screen-square-broken" : "i-solar:full-screen-linear", "ml-a p-0.6em transition-all btn-info"])}" data-v-d10e1894${_scopeId}></i></div>`);
            _push2(ssrRenderComponent(_component_el_scrollbar, {
              ref_key: "scollRef",
              ref: scollRef,
              "view-class": "p-2 md:p-4",
              class: "flex-1 bg-light shadow-sm shadow-inset border-default card-default dark:bg-dark-9"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div${ssrRenderAttrs(mergeProps({
                    relative: "",
                    flex: "",
                    "flex-col": ""
                  }, ssrGetDirectiveProps(_ctx, _directive_auto_animate)))} data-v-d10e1894${_scopeId2}><!--[-->`);
                  ssrRenderList(unref(msgList), (msg, i) => {
                    _push3(ssrRenderComponent(_component_ChatMsgMain, {
                      id: `chat-msg-${msg.message.id}`,
                      key: msg.message.id,
                      index: i,
                      data: msg
                    }, null, _parent3, _scopeId2));
                  });
                  _push3(`<!--]--></div>`);
                } else {
                  return [withDirectives((openBlock(), createBlock("div", {
                    relative: "",
                    flex: "",
                    "flex-col": ""
                  }, [(openBlock(true), createBlock(Fragment, null, renderList(unref(msgList), (msg, i) => {
                    return openBlock(), createBlock(_component_ChatMsgMain, {
                      id: `chat-msg-${msg.message.id}`,
                      key: msg.message.id,
                      index: i,
                      data: msg
                    }, null, 8, ["id", "index", "data"]);
                  }), 128))])), [[_directive_auto_animate]])];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_el_form, mergeProps({
              ref_key: "formRef",
              ref: formRef,
              model: unref(form),
              disabled: !((_a = unref(user)) == null ? void 0 : _a.isLogin) || unref(isChat),
              class: "mt-2 mt-a flex items-center gap-3 p-2 sm:p-4",
              onSubmit
            }, ssrGetDirectiveProps(_ctx, _directive_auth)), {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_NuxtLink, {
                    to: "/user/info"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_CardElImage, {
                          src: unref(user).userInfo.avatar ? ("BaseUrlImg" in _ctx ? _ctx.BaseUrlImg : unref(BaseUrlImg)) + unref(user).userInfo.avatar : "",
                          class: "h-2.4rem w-2.4rem rounded-1/2 border-default"
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [createVNode(_component_CardElImage, {
                          src: unref(user).userInfo.avatar ? ("BaseUrlImg" in _ctx ? _ctx.BaseUrlImg : unref(BaseUrlImg)) + unref(user).userInfo.avatar : "",
                          class: "h-2.4rem w-2.4rem rounded-1/2 border-default"
                        }, null, 8, ["src"])];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_el_form_item, {
                    prop: "content",
                    class: "w-full",
                    rules: [{
                      required: true,
                      message: "\u5185\u5BB9\u4E0D\u80FD\u4E3A\u7A7A\uFF01",
                      trigger: "change"
                    }]
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_el_input, {
                          modelValue: unref(form).content,
                          "onUpdate:modelValue": ($event) => unref(form).content = $event,
                          modelModifiers: {
                            lazy: true
                          },
                          disabled: !unref(user).isLogin || unref(isChat),
                          placeholder: "\u5FEB\u5F00\u59CB\u5BF9\u8BDD\u5427 \u2728",
                          class: "content border-0 border-b-1px pt-4 border-default"
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [createVNode(_component_el_input, {
                          modelValue: unref(form).content,
                          "onUpdate:modelValue": ($event) => unref(form).content = $event,
                          modelModifiers: {
                            lazy: true
                          },
                          disabled: !unref(user).isLogin || unref(isChat),
                          placeholder: "\u5FEB\u5F00\u59CB\u5BF9\u8BDD\u5427 \u2728",
                          class: "content border-0 border-b-1px pt-4 border-default"
                        }, null, 8, ["modelValue", "onUpdate:modelValue", "disabled"])];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_BtnElButton, {
                    class: "group ml-a",
                    "icon-class": "i-solar:map-arrow-right-bold-duotone block mr-1",
                    round: "",
                    disabled: !unref(user).isLogin || unref(isChat),
                    "transition-icon": "",
                    type: "info",
                    onClick: onSubmit
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(` \u53D1\u9001\xA0 `);
                      } else {
                        return [createTextVNode(" \u53D1\u9001\xA0 ")];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [createVNode(_component_NuxtLink, {
                    to: "/user/info"
                  }, {
                    default: withCtx(() => [createVNode(_component_CardElImage, {
                      src: unref(user).userInfo.avatar ? ("BaseUrlImg" in _ctx ? _ctx.BaseUrlImg : unref(BaseUrlImg)) + unref(user).userInfo.avatar : "",
                      class: "h-2.4rem w-2.4rem rounded-1/2 border-default"
                    }, null, 8, ["src"])]),
                    _: 1
                  }), createVNode(_component_el_form_item, {
                    prop: "content",
                    class: "w-full",
                    rules: [{
                      required: true,
                      message: "\u5185\u5BB9\u4E0D\u80FD\u4E3A\u7A7A\uFF01",
                      trigger: "change"
                    }]
                  }, {
                    default: withCtx(() => [createVNode(_component_el_input, {
                      modelValue: unref(form).content,
                      "onUpdate:modelValue": ($event) => unref(form).content = $event,
                      modelModifiers: {
                        lazy: true
                      },
                      disabled: !unref(user).isLogin || unref(isChat),
                      placeholder: "\u5FEB\u5F00\u59CB\u5BF9\u8BDD\u5427 \u2728",
                      class: "content border-0 border-b-1px pt-4 border-default"
                    }, null, 8, ["modelValue", "onUpdate:modelValue", "disabled"])]),
                    _: 1
                  }), createVNode(_component_BtnElButton, {
                    class: "group ml-a",
                    "icon-class": "i-solar:map-arrow-right-bold-duotone block mr-1",
                    round: "",
                    disabled: !unref(user).isLogin || unref(isChat),
                    "transition-icon": "",
                    type: "info",
                    onClick: onSubmit
                  }, {
                    default: withCtx(() => [createTextVNode(" \u53D1\u9001\xA0 ")]),
                    _: 1
                  }, 8, ["disabled", "onClick"])];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</section>`);
          } else {
            return [createVNode("section", {
              class: "w-full flex flex-col p-4 bg-color"
            }, [createVNode("div", {
              class: "mb-4 flex items-center gap-2 font-600 tracking-0.2em"
            }, [createVNode("i", {
              class: "i-solar:ghost-bold mr-2 p-0.8em text-[var(--el-color-primary)]"
            }), createVNode("p", {
              class: "text-[var(--el-color-primary)]"
            }, " \u6781\u7269AI "), createVNode("i", {
              class: ["ml-a p-0.6em transition-all btn-info", unref(useFull).isFullscreen ? "i-solar:full-screen-square-broken" : "i-solar:full-screen-linear"],
              onClick: unref(useFull).toggle
            }, null, 10, ["onClick"])]), createVNode(_component_el_scrollbar, {
              ref_key: "scollRef",
              ref: scollRef,
              "view-class": "p-2 md:p-4",
              class: "flex-1 bg-light shadow-sm shadow-inset border-default card-default dark:bg-dark-9"
            }, {
              default: withCtx(() => [withDirectives((openBlock(), createBlock("div", {
                relative: "",
                flex: "",
                "flex-col": ""
              }, [(openBlock(true), createBlock(Fragment, null, renderList(unref(msgList), (msg, i) => {
                return openBlock(), createBlock(_component_ChatMsgMain, {
                  id: `chat-msg-${msg.message.id}`,
                  key: msg.message.id,
                  index: i,
                  data: msg
                }, null, 8, ["id", "index", "data"]);
              }), 128))])), [[_directive_auto_animate]])]),
              _: 1
            }, 512), withDirectives((openBlock(), createBlock(_component_el_form, {
              ref_key: "formRef",
              ref: formRef,
              model: unref(form),
              disabled: !((_b = unref(user)) == null ? void 0 : _b.isLogin) || unref(isChat),
              class: "mt-2 mt-a flex items-center gap-3 p-2 sm:p-4",
              onSubmit: withModifiers(onSubmit, ["prevent"])
            }, {
              default: withCtx(() => [createVNode(_component_NuxtLink, {
                to: "/user/info"
              }, {
                default: withCtx(() => [createVNode(_component_CardElImage, {
                  src: unref(user).userInfo.avatar ? ("BaseUrlImg" in _ctx ? _ctx.BaseUrlImg : unref(BaseUrlImg)) + unref(user).userInfo.avatar : "",
                  class: "h-2.4rem w-2.4rem rounded-1/2 border-default"
                }, null, 8, ["src"])]),
                _: 1
              }), createVNode(_component_el_form_item, {
                prop: "content",
                class: "w-full",
                rules: [{
                  required: true,
                  message: "\u5185\u5BB9\u4E0D\u80FD\u4E3A\u7A7A\uFF01",
                  trigger: "change"
                }]
              }, {
                default: withCtx(() => [createVNode(_component_el_input, {
                  modelValue: unref(form).content,
                  "onUpdate:modelValue": ($event) => unref(form).content = $event,
                  modelModifiers: {
                    lazy: true
                  },
                  disabled: !unref(user).isLogin || unref(isChat),
                  placeholder: "\u5FEB\u5F00\u59CB\u5BF9\u8BDD\u5427 \u2728",
                  class: "content border-0 border-b-1px pt-4 border-default"
                }, null, 8, ["modelValue", "onUpdate:modelValue", "disabled"])]),
                _: 1
              }), createVNode(_component_BtnElButton, {
                class: "group ml-a",
                "icon-class": "i-solar:map-arrow-right-bold-duotone block mr-1",
                round: "",
                disabled: !unref(user).isLogin || unref(isChat),
                "transition-icon": "",
                type: "info",
                onClick: onSubmit
              }, {
                default: withCtx(() => [createTextVNode(" \u53D1\u9001\xA0 ")]),
                _: 1
              }, 8, ["disabled", "onClick"])]),
              _: 1
            }, 8, ["model", "disabled"])), [[_directive_auth]])])];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/chat/ai.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const ai = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-d10e1894"]]);

export { ai as default };
//# sourceMappingURL=ai-sBysslCx.mjs.map
