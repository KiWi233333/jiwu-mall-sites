import { v as useWebNotification } from './index-wP5MLg4Q.mjs';

function useWebToast(title, body, opts) {
  const windToast = useWebNotification({
    title,
    body,
    icon: "/logo.png",
    ...opts
  });
  if (windToast.isSupported)
    windToast.show();
}

export { useWebToast as u };
//# sourceMappingURL=useWebToast-6UlrNMob.mjs.map
