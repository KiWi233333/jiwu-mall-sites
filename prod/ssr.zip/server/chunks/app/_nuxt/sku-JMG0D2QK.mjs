import { o as useFetch, p as BaseUrl, q as useHttp } from '../server.mjs';

function getGoodsSkuByGid(gid) {
  return useFetch(`${BaseUrl}/goods/sku?gid=${gid}`, "$AfkcphgTcz");
}
function getGoodsSkuByIds(ids) {
  return useHttp.post("/goods/sku", {
    ids: [...ids]
  });
}

export { getGoodsSkuByIds as a, getGoodsSkuByGid as g };
//# sourceMappingURL=sku-JMG0D2QK.mjs.map
