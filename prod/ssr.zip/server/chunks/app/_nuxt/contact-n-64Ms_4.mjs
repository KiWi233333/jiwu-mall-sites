import { ref, computed } from 'vue';
import { z as defineStore, A as persistedState, q as useHttp, u as useUserStore, S as StatusCode } from '../server.mjs';
import { u as useWs } from './useWs-9VcJlLQj.mjs';

function getChatMessagePage(roomId, pageSize = 10, cursor = null, token) {
  return useHttp.get(
    "/chat/message/page",
    {
      roomId,
      pageSize,
      cursor
    },
    {
      headers: {
        Authorization: token
      }
    }
  );
}
var MessageType = /* @__PURE__ */ ((MessageType2) => {
  MessageType2[MessageType2["TEXT"] = 1] = "TEXT";
  MessageType2[MessageType2["RECALL"] = 2] = "RECALL";
  MessageType2[MessageType2["IMG"] = 3] = "IMG";
  MessageType2[MessageType2["FILE"] = 4] = "FILE";
  MessageType2[MessageType2["SOUND"] = 5] = "SOUND";
  MessageType2[MessageType2["VIDEO"] = 6] = "VIDEO";
  MessageType2[MessageType2["EMOJI"] = 7] = "EMOJI";
  MessageType2[MessageType2["SYSTEM"] = 8] = "SYSTEM";
  MessageType2[MessageType2["AI_CHAT"] = 9] = "AI_CHAT";
  MessageType2[MessageType2["DELETE"] = 10] = "DELETE";
  return MessageType2;
})(MessageType || {});
function addChatMessage(dto, token) {
  return useHttp.post(
    "/chat/message",
    { ...dto },
    {
      headers: {
        Authorization: token
      }
    }
  );
}
function refundChatMessage(roomId, id, token) {
  return useHttp.put(
    `/chat/message/recall/${roomId}/${id}`,
    {},
    {
      headers: {
        Authorization: token
      }
    }
  );
}
function deleteChatMessage(roomId, id, token) {
  return useHttp.deleted(
    `/chat/message/recall/${roomId}/${id}`,
    {},
    {
      headers: {
        Authorization: token
      }
    }
  );
}
function setMsgReadByRoomId(roomId, token) {
  return useHttp.put(
    `/chat/message/msg/read/${roomId}`,
    {},
    {
      headers: {
        Authorization: token
      }
    }
  );
}
const useChatStore = defineStore(
  "chat",
  () => {
    const isOpenContact = ref(true);
    const contactList = ref([]);
    const theContact = ref({
      activeTime: 0,
      avatar: "",
      roomId: 1,
      hotFlag: 1,
      name: "",
      text: "",
      type: 1,
      unreadCount: 0,
      // 消息列表
      msgList: [],
      unreadMsgList: [],
      roomGroup: void 0,
      member: void 0
    });
    function setContact(vo, list = [], unReadList = []) {
      if (vo)
        vo.unreadCount = 0;
      theContact.value = vo || {
        activeTime: 0,
        avatar: "",
        roomId: 1,
        hotFlag: 1,
        name: "",
        text: "",
        type: 1,
        unreadCount: 0,
        // 消息列表
        msgList: [],
        unreadMsgList: []
      };
      if (list)
        theContact.value.msgList = list;
      if (unReadList)
        theContact.value.unreadMsgList = unReadList;
    }
    const onOfflineList = ref([]);
    function setGroupMember(list) {
      onOfflineList.value = list;
    }
    function setReadList(roomId, lastMsg = "") {
      const user = useUserStore();
      setMsgReadByRoomId(roomId, user.getToken).then((res) => {
        if (res.code !== StatusCode.SUCCESS)
          return false;
        const ctx = contactList.value.find((p) => p.roomId === roomId);
        if (ctx) {
          ctx.unreadCount = 0;
          if (lastMsg)
            ctx.text = lastMsg;
        }
        const ws = useWs();
        ws.wsMsgList.newMsg = ws.wsMsgList.newMsg.filter((k) => k.message.roomId !== roomId);
      }).catch(() => {
      });
    }
    const onReloadContact = (size = 10, dto, isAll = true, roomId) => {
    };
    const scrollBottom = () => {
    };
    const scrollTopSize = ref(0);
    const scrollReplyMsg = (msgId, gapCount = 0) => {
    };
    const saveScrollTop = () => {
    };
    const scrollTop = (size) => {
    };
    const atUserList = ref([]);
    function setAtUid(userId) {
      const find = atUserList.value.includes(userId);
      if (!find)
        atUserList.value.push(userId);
    }
    function removeAtUid(userId) {
      return atUserList.value = atUserList.value.filter((p) => p === userId);
    }
    const replyMsg = ref();
    function setReplyMsg(item) {
      replyMsg.value = item;
    }
    const theFriendOpt = ref({
      type: -1,
      data: {}
    });
    function setTheFriendOpt(type, data) {
      theFriendOpt.value.type = type;
      theFriendOpt.value.data = data;
    }
    const delUserId = ref("");
    function setDelUserId(userId) {
      delUserId.value = userId;
    }
    const isAddNewFriend = ref(false);
    function setIsAddNewFriend(val) {
      isAddNewFriend.value = val;
    }
    const showTheFriendPanel = computed({
      get: () => theFriendOpt.value.type !== -1,
      set: (val) => {
        if (!val)
          setTheFriendOpt(
            -1
            /* Empty */
          );
      }
    });
    return {
      // state
      contactList,
      theContact,
      replyMsg,
      atUserList,
      theFriendOpt,
      showTheFriendPanel,
      delUserId,
      isAddNewFriend,
      isOpenContact,
      onOfflineList,
      // 方法
      setContact,
      setReadList,
      setGroupMember,
      setIsAddNewFriend,
      setAtUid,
      removeAtUid,
      setReplyMsg,
      setDelUserId,
      setTheFriendOpt,
      onReloadContact,
      // dom
      scrollTopSize,
      saveScrollTop,
      scrollReplyMsg,
      scrollBottom,
      scrollTop
    };
  },
  {
    // https://prazdevs.github.io/pinia-plugin-persistedstate/frameworks/nuxt-3.html
    persist: {
      storage: persistedState.localStorage
    }
  }
);
function getChatContactPage(pageSize = 10, cursor = null, token) {
  return useHttp.get(
    "/chat/contact/page",
    {
      pageSize,
      cursor
    },
    {
      headers: {
        Authorization: token
      }
    }
  );
}
var RoomType = /* @__PURE__ */ ((RoomType2) => {
  RoomType2[RoomType2["GROUP"] = 1] = "GROUP";
  RoomType2[RoomType2["SELFT"] = 2] = "SELFT";
  RoomType2[RoomType2["AICHAT"] = 3] = "AICHAT";
  return RoomType2;
})(RoomType || {});
function getChatContactInfo(id, roomType = 1, token) {
  if (roomType === 1) {
    return useHttp.get(
      `/chat/contact/${id}`,
      {},
      {
        headers: {
          Authorization: token
        }
      }
    );
  } else if (roomType === 2) {
    return useHttp.get(
      `/chat/contact/self/${id}`,
      {},
      {
        headers: {
          Authorization: token
        }
      }
    );
  }
}

export { MessageType as M, RoomType as R, getChatContactPage as a, getChatMessagePage as b, addChatMessage as c, deleteChatMessage as d, getChatContactInfo as g, refundChatMessage as r, useChatStore as u };
//# sourceMappingURL=contact-n-64Ms_4.mjs.map
