import { s as useWebNotification } from './index-6_J865EA.mjs';

function useWebToast(title, body, opts) {
  const windToast = useWebNotification({
    title,
    body,
    icon: "/logo.png",
    ...opts
  });
  if (windToast.isSupported)
    windToast.show();
}

export { useWebToast as u };
//# sourceMappingURL=useWebToast-tPYHv_vL.mjs.map
