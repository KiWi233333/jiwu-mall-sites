import { defineComponent, computed, openBlock, createElementBlock, normalizeClass, unref, renderSlot, createVNode, Transition, withCtx, withDirectives, createElementVNode, toDisplayString, vShow } from 'vue';
import { q as buildProps, r as useNamespace, t as isNumber, w as withInstall, v as _export_sfc$1, p as useHttp } from '../server.mjs';

const badgeProps = buildProps({
  value: {
    type: [String, Number],
    default: ""
  },
  max: {
    type: Number,
    default: 99
  },
  isDot: Boolean,
  hidden: Boolean,
  type: {
    type: String,
    values: ["primary", "success", "warning", "info", "danger"],
    default: "danger"
  }
});
const _hoisted_1 = ["textContent"];
const __default__ = defineComponent({
  name: "ElBadge"
});
const _sfc_main = /* @__PURE__ */ defineComponent({
  ...__default__,
  props: badgeProps,
  setup(__props, { expose }) {
    const props = __props;
    const ns = useNamespace("badge");
    const content = computed(() => {
      if (props.isDot)
        return "";
      if (isNumber(props.value) && isNumber(props.max)) {
        return props.max < props.value ? `${props.max}+` : `${props.value}`;
      }
      return `${props.value}`;
    });
    expose({
      content
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass(unref(ns).b())
      }, [
        renderSlot(_ctx.$slots, "default"),
        createVNode(Transition, {
          name: `${unref(ns).namespace.value}-zoom-in-center`,
          persisted: ""
        }, {
          default: withCtx(() => [
            withDirectives(createElementVNode("sup", {
              class: normalizeClass([
                unref(ns).e("content"),
                unref(ns).em("content", _ctx.type),
                unref(ns).is("fixed", !!_ctx.$slots.default),
                unref(ns).is("dot", _ctx.isDot)
              ]),
              textContent: toDisplayString(unref(content))
            }, null, 10, _hoisted_1), [
              [vShow, !_ctx.hidden && (unref(content) || _ctx.isDot)]
            ])
          ]),
          _: 1
        }, 8, ["name"])
      ], 2);
    };
  }
});
var Badge = /* @__PURE__ */ _export_sfc$1(_sfc_main, [["__file", "/home/runner/work/element-plus/element-plus/packages/components/badge/src/badge.vue"]]);
const ElBadge = withInstall(Badge);
function getChatFriendPage(pageSize = 10, cursor, token) {
  return useHttp.get(
    "/chat/user/friend/page",
    {
      pageSize,
      cursor
    },
    {
      headers: {
        Authorization: token
      }
    }
  );
}
function getChatFriendApplyPage(page = 10, size, token) {
  return useHttp.get(
    "/chat/user/friend/apply/page",
    {
      page,
      size
    },
    {
      headers: {
        Authorization: token
      }
    }
  );
}
function getUserSeListByPage(page, size, dto, token) {
  return useHttp.post(
    `/chat/user/friend/user/${page}/${size}`,
    { ...dto },
    {
      headers: {
        Authorization: token
      }
    }
  );
}
var ChatApplyStatusType = /* @__PURE__ */ ((ChatApplyStatusType2) => {
  ChatApplyStatusType2[ChatApplyStatusType2["Load"] = 0] = "Load";
  ChatApplyStatusType2[ChatApplyStatusType2["Argee"] = 1] = "Argee";
  return ChatApplyStatusType2;
})(ChatApplyStatusType || {});
function addFriendApply(dto, token) {
  return useHttp.post(
    "/chat/user/friend/apply",
    {
      ...dto
    },
    {
      headers: {
        Authorization: token
      }
    }
  );
}
function isChatFriend(dto, token) {
  return useHttp.post(
    "/chat/user/friend/check",
    {
      ...dto
    },
    {
      headers: {
        Authorization: token
      }
    }
  );
}
function deleteFriendById(targetUid, token) {
  return useHttp.deleted(
    `/chat/user/friend/${targetUid}`,
    {},
    {
      headers: {
        Authorization: token
      }
    }
  );
}
var FriendOptType = /* @__PURE__ */ ((FriendOptType2) => {
  FriendOptType2[FriendOptType2["Empty"] = -1] = "Empty";
  FriendOptType2[FriendOptType2["User"] = 0] = "User";
  FriendOptType2[FriendOptType2["NewFriend"] = 1] = "NewFriend";
  FriendOptType2[FriendOptType2["GroupFriend"] = 2] = "GroupFriend";
  return FriendOptType2;
})(FriendOptType || {});
function argeeFriendApply(dto, token) {
  return useHttp.put(
    "/chat/user/friend/apply",
    {
      ...dto
    },
    {
      headers: {
        Authorization: token
      }
    }
  );
}

export { ChatApplyStatusType as C, ElBadge as E, FriendOptType as F, getChatFriendPage as a, getChatFriendApplyPage as b, argeeFriendApply as c, deleteFriendById as d, addFriendApply as e, getUserSeListByPage as g, isChatFriend as i };
//# sourceMappingURL=friend-krOLB77r.mjs.map
