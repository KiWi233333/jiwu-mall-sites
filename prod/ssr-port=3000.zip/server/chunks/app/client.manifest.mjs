const client_manifest = {
  "_ApplyDialog.vue.YZYcLkFi.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ApplyDialog.vue.YZYcLkFi.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_dialog.CaAHiX9A.js",
      "_notification.Q_nNtR8t.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_friend.HOY7VQKz.js"
    ]
  },
  "_AutoIncre.vue.TtiP3fHm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "AutoIncre.vue.TtiP3fHm.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "_CategoryTabs.!~{012}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "CategoryTabs.787nBCiN.css",
    "src": "_CategoryTabs.!~{012}~.js"
  },
  "_CategoryTabs.M9UbgK-M.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "CategoryTabs.787nBCiN.css"
    ],
    "file": "CategoryTabs.M9UbgK-M.js",
    "imports": [
      "_tabs.WnvjjJQ1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "components/Comm/PostList.vue",
      "components/list/GoodsList.vue",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "CategoryTabs.787nBCiN.css": {
    "file": "CategoryTabs.787nBCiN.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_CommentPreview.!~{017}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "CommentPreview.JFJ3T4Gg.css",
    "src": "_CommentPreview.!~{017}~.js"
  },
  "_CommentPreview.G-Xywm6m.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "CommentPreview.JFJ3T4Gg.css"
    ],
    "file": "CommentPreview.G-Xywm6m.js",
    "imports": [
      "_ElImage.BY_iSMtR.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_select.PmZcTmT4.js",
      "_OssFileUpload.pEDLM9U-.js",
      "_nuxt-link.lxn6Pk9R.js",
      "_tag.TzwDj60f.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_AutoIncre.vue.TtiP3fHm.js",
      "_scrollbar.wb_P4sCD.js",
      "_popper.cjhOvqyO.js",
      "_notification.Q_nNtR8t.js"
    ]
  },
  "CommentPreview.JFJ3T4Gg.css": {
    "file": "CommentPreview.JFJ3T4Gg.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_DelayTimer.vue.hkGxYdrD.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "DelayTimer.vue.hkGxYdrD.js",
    "imports": [
      "_swiper-vue.Dj7aAS3P.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_ElImage.!~{00z}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "ElImage.t6Ajzk8E.css",
    "src": "_ElImage.!~{00z}~.js"
  },
  "_ElImage.BY_iSMtR.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "ElImage.t6Ajzk8E.css"
    ],
    "file": "ElImage.BY_iSMtR.js",
    "imports": [
      "_swiper-vue.Dj7aAS3P.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_debounce.rDCbVktl.js"
    ]
  },
  "ElImage.t6Ajzk8E.css": {
    "file": "ElImage.t6Ajzk8E.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_Footer.!~{01N}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Footer.y5ruypfy.css",
    "src": "_Footer.!~{01N}~.js"
  },
  "_Footer.CRQS_PGT.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "Footer.y5ruypfy.css"
    ],
    "file": "Footer.CRQS_PGT.js",
    "imports": [
      "_nuxt-link.lxn6Pk9R.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_logo_dark.DAdYXcdH.js",
      "_Switch.udPgGRYL.js"
    ]
  },
  "Footer.y5ruypfy.css": {
    "file": "Footer.y5ruypfy.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_GoodsListSsr.!~{01j}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "GoodsListSsr.P5hBZBtk.css",
    "src": "_GoodsListSsr.!~{01j}~.js"
  },
  "_GoodsListSsr.6NLnx7YW.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "GoodsListSsr.P5hBZBtk.css"
    ],
    "file": "GoodsListSsr.6NLnx7YW.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.9Ely185F.js",
      "_nuxt-link.lxn6Pk9R.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "GoodsListSsr.P5hBZBtk.css": {
    "file": "GoodsListSsr.P5hBZBtk.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_Main.vue.!~{00R}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Main.IaUZe0bo.css",
    "src": "_Main.vue.!~{00R}~.js"
  },
  "_Main.vue.B83vyFhi.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "Main.IaUZe0bo.css"
    ],
    "file": "Main.vue.B83vyFhi.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_contact.mrkwsl6m.js",
      "_ElImage.BY_iSMtR.js",
      "_tag.TzwDj60f.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "Main.IaUZe0bo.css": {
    "file": "Main.IaUZe0bo.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_OssFileUpload.!~{00T}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "OssFileUpload.-TDo8IgO.css",
    "src": "_OssFileUpload.!~{00T}~.js"
  },
  "_OssFileUpload.pEDLM9U-.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "OssFileUpload.-TDo8IgO.css"
    ],
    "file": "OssFileUpload.pEDLM9U-.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.BY_iSMtR.js",
      "_progress.9Rta0wsd.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_index.F3hl3u3-.js"
    ]
  },
  "OssFileUpload.-TDo8IgO.css": {
    "file": "OssFileUpload.-TDo8IgO.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_ShopLine.!~{01H}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "ShopLine.PGliGu9i.css",
    "src": "_ShopLine.!~{01H}~.js"
  },
  "_ShopLine.1ycSDMT2.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "ShopLine.PGliGu9i.css"
    ],
    "file": "ShopLine.1ycSDMT2.js",
    "imports": [
      "_ElImage.BY_iSMtR.js",
      "_nuxt-link.lxn6Pk9R.js",
      "_select.PmZcTmT4.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_input-number.CZnCGSJB.js",
      "_tag.TzwDj60f.js",
      "_scrollbar.wb_P4sCD.js",
      "_popper.cjhOvqyO.js",
      "_sku.E4aUln0z.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "ShopLine.PGliGu9i.css": {
    "file": "ShopLine.PGliGu9i.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_SigninCard.vue.vtcC-DF7.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "popover.N-GW0j1A.css"
    ],
    "file": "SigninCard.vue.vtcC-DF7.js",
    "imports": [
      "_progress.9Rta0wsd.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.c9G0tYhv.js",
      "_popper.cjhOvqyO.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "popover.N-GW0j1A.css": {
    "file": "popover.N-GW0j1A.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_StatusTag.!~{01h}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "StatusTag.IETAoY75.css",
    "src": "_StatusTag.!~{01h}~.js"
  },
  "_StatusTag.Rv3fxdDR.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "StatusTag.IETAoY75.css"
    ],
    "file": "StatusTag.Rv3fxdDR.js",
    "imports": [
      "_tag.TzwDj60f.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_post.ljep56mz.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "StatusTag.IETAoY75.css": {
    "file": "StatusTag.IETAoY75.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_Switch.!~{01c}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Switch.JXXa2UnD.css",
    "src": "_Switch.!~{01c}~.js"
  },
  "_Switch.udPgGRYL.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "Switch.JXXa2UnD.css"
    ],
    "file": "Switch.udPgGRYL.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "Switch.JXXa2UnD.css": {
    "file": "Switch.JXXa2UnD.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_TagList.vue.Opuc7lVD.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TagList.vue.Opuc7lVD.js",
    "imports": [
      "_tag.TzwDj60f.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "_UserPostTotal.vue.hTPHLcRD.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "UserPostTotal.vue.hTPHLcRD.js",
    "imports": [
      "_ElImage.BY_iSMtR.js",
      "_nuxt-link.lxn6Pk9R.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_post.ljep56mz.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "_arrays.9GuX8ZvT.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "arrays.9GuX8ZvT.js"
  },
  "_avatar.!~{01G}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "avatar.bZH1-Oig.css",
    "src": "_avatar.!~{01G}~.js"
  },
  "_avatar.Xqlr04No.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "avatar.bZH1-Oig.css"
    ],
    "file": "avatar.Xqlr04No.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "avatar.bZH1-Oig.css": {
    "file": "avatar.bZH1-Oig.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_bills.rxU_HeZW.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "bills.rxU_HeZW.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_checkbox-group.!~{01E}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "checkbox-group.d5XbR8TY.css",
    "src": "_checkbox-group.!~{01E}~.js"
  },
  "_checkbox.!~{01v}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "checkbox.MJHvI1xB.css",
    "src": "_checkbox.!~{01v}~.js"
  },
  "_checkbox.oVr9ht7C.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "checkbox.MJHvI1xB.css"
    ],
    "file": "checkbox.oVr9ht7C.js",
    "imports": [
      "_swiper-vue.Dj7aAS3P.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_isEqual.kSCWbLwW.js",
      "_hasIn.wpY4XSY7.js",
      "_flatten.mqqocT4_.js"
    ]
  },
  "checkbox.MJHvI1xB.css": {
    "file": "checkbox.MJHvI1xB.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_cloneDeep.MXrbYbCD.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "cloneDeep.MXrbYbCD.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_collect.HvW0DaCO.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "collect.HvW0DaCO.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_contact.mrkwsl6m.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "contact.mrkwsl6m.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_useWs._PlXJD1b.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "_date-picker.!~{01B}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "date-picker.Nk-pBymI.css",
    "src": "_date-picker.!~{01B}~.js"
  },
  "_date-picker.SiYDvXl4.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "date-picker.Nk-pBymI.css"
    ],
    "file": "date-picker.SiYDvXl4.js",
    "imports": [
      "_localeData.fByHNnFW.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_arrays.9GuX8ZvT.js",
      "_flatten.mqqocT4_.js",
      "_popper.cjhOvqyO.js",
      "_scrollbar.wb_P4sCD.js",
      "_index.m5OxfFYg.js",
      "_debounce.rDCbVktl.js",
      "_index.Guwzp7dI.js",
      "_isEqual.kSCWbLwW.js"
    ]
  },
  "date-picker.Nk-pBymI.css": {
    "file": "date-picker.Nk-pBymI.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_debounce.rDCbVktl.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "debounce.rDCbVktl.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_dialog.!~{00N}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "dialog.NzY-5hTp.css",
    "src": "_dialog.!~{00N}~.js"
  },
  "_dialog.CaAHiX9A.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "dialog.NzY-5hTp.css"
    ],
    "file": "dialog.CaAHiX9A.js",
    "imports": [
      "_swiper-vue.Dj7aAS3P.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "dialog.NzY-5hTp.css": {
    "file": "dialog.NzY-5hTp.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_divider.!~{00J}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "divider.mvCfgREV.css",
    "src": "_divider.!~{00J}~.js"
  },
  "_divider.RwvYdWPC.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "divider.mvCfgREV.css"
    ],
    "file": "divider.RwvYdWPC.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "divider.mvCfgREV.css": {
    "file": "divider.mvCfgREV.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_empty.!~{00C}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "empty.sDhVTJEQ.css",
    "src": "_empty.!~{00C}~.js"
  },
  "_empty.IHZ29T3R.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "empty.sDhVTJEQ.css"
    ],
    "file": "empty.IHZ29T3R.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "empty.sDhVTJEQ.css": {
    "file": "empty.sDhVTJEQ.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_flatten.mqqocT4_.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "flatten.mqqocT4_.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_friend.HOY7VQKz.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "friend.HOY7VQKz.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_hasIn.wpY4XSY7.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "hasIn.wpY4XSY7.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.!~{01a}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.8uyA1Q9v.css",
    "src": "_index.!~{01a}~.js"
  },
  "_index.9Ely185F.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.8uyA1Q9v.css"
    ],
    "file": "index.9Ely185F.js",
    "imports": [
      "_ElImage.BY_iSMtR.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "index.8uyA1Q9v.css": {
    "file": "index.8uyA1Q9v.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_index.F3hl3u3-.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.F3hl3u3-.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.Guwzp7dI.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.Guwzp7dI.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.H_db_cZm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.H_db_cZm.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.TErpPJT5.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.TErpPJT5.js",
    "imports": [
      "_swiper-vue.Dj7aAS3P.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.VDnR5ZRx.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.VDnR5ZRx.js",
    "imports": [
      "_swiper-vue.Dj7aAS3P.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.c9G0tYhv.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.c9G0tYhv.js",
    "imports": [
      "_popper.cjhOvqyO.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "_index.m5OxfFYg.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.m5OxfFYg.js",
    "imports": [
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "_index.nR0g6DS1.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.nR0g6DS1.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.oq21xmZ4.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.oq21xmZ4.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.vS44-DLf.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.vS44-DLf.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "_input-number.!~{01l}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "input-number.5AezeF1g.css",
    "src": "_input-number.!~{01l}~.js"
  },
  "_input-number.CZnCGSJB.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "input-number.5AezeF1g.css"
    ],
    "file": "input-number.CZnCGSJB.js",
    "imports": [
      "_swiper-vue.Dj7aAS3P.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.m5OxfFYg.js"
    ]
  },
  "input-number.5AezeF1g.css": {
    "file": "input-number.5AezeF1g.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_isEqual.kSCWbLwW.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "isEqual.kSCWbLwW.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_localeData.fByHNnFW.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "localeData.fByHNnFW.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "_logo_dark.DAdYXcdH.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "popover.N-GW0j1A.css"
    ],
    "dynamicImports": [
      "components/card/UserLine.vue"
    ],
    "file": "logo_dark.DAdYXcdH.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.lxn6Pk9R.js",
      "_scrollbar.wb_P4sCD.js",
      "_index.c9G0tYhv.js",
      "_popper.cjhOvqyO.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "_menu-item.!~{01L}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "menu-item.f0mNRiTD.css",
    "src": "_tooltip.!~{01F}~.js"
  },
  "_menu.!~{01K}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "menu.QOppk9eM.css",
    "src": "_menu.!~{01K}~.js"
  },
  "_menu.FJEhNG3E.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "menu.QOppk9eM.css"
    ],
    "file": "menu.FJEhNG3E.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_index.VDnR5ZRx.js",
      "_popper.cjhOvqyO.js"
    ]
  },
  "menu.QOppk9eM.css": {
    "file": "menu.QOppk9eM.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_notification.!~{00I}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "notification.6oJvQm9r.css",
    "src": "_notification.!~{00I}~.js"
  },
  "_notification.Q_nNtR8t.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "notification.6oJvQm9r.css"
    ],
    "file": "notification.Q_nNtR8t.js",
    "imports": [
      "_swiper-vue.Dj7aAS3P.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "notification.6oJvQm9r.css": {
    "file": "notification.6oJvQm9r.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_nuxt-link.lxn6Pk9R.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "nuxt-link.lxn6Pk9R.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "_popover.!~{01g}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "popover.N-GW0j1A.css",
    "src": "_popover.!~{01g}~.js"
  },
  "_popper.!~{00V}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "popper.2BhxBuwE.css",
    "src": "_popper.!~{00V}~.js"
  },
  "_popper.cjhOvqyO.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "popper.2BhxBuwE.css"
    ],
    "file": "popper.cjhOvqyO.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "popper.2BhxBuwE.css": {
    "file": "popper.2BhxBuwE.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_post.ljep56mz.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "post.ljep56mz.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_progress.!~{00$}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "progress.rXLlm_9F.css",
    "src": "_progress.!~{00$}~.js"
  },
  "_progress.9Rta0wsd.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "progress.rXLlm_9F.css"
    ],
    "file": "progress.9Rta0wsd.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "progress.rXLlm_9F.css": {
    "file": "progress.rXLlm_9F.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_radio-button.!~{010}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "radio-button.l7x146Nf.css",
    "src": "_radio-button.!~{010}~.js"
  },
  "_radio-group.!~{00F}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "radio-group.P_Xz2fNs.css",
    "src": "_radio-group.!~{00F}~.js"
  },
  "_radio.!~{00Q}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "radio.eYTrrdr6.css",
    "src": "_radio.!~{00Q}~.js"
  },
  "_rand.mzGjE9Jh.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "rand.mzGjE9Jh.js"
  },
  "_rate.!~{01o}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "rate.xvbXIp1h.css",
    "src": "_rate.!~{01o}~.js"
  },
  "_rate.j8YCg03p.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "rate.xvbXIp1h.css"
    ],
    "file": "rate.j8YCg03p.js",
    "imports": [
      "_swiper-vue.Dj7aAS3P.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "rate.xvbXIp1h.css": {
    "file": "rate.xvbXIp1h.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_scrollbar.!~{00B}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "scrollbar.Smf0pYfu.css",
    "src": "_scrollbar.!~{00B}~.js"
  },
  "_scrollbar.wb_P4sCD.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "scrollbar.Smf0pYfu.css"
    ],
    "file": "scrollbar.wb_P4sCD.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "scrollbar.Smf0pYfu.css": {
    "file": "scrollbar.Smf0pYfu.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_select.!~{00S}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "select.WyCmEko8.css",
    "src": "_select.!~{00S}~.js"
  },
  "_select.PmZcTmT4.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "select.WyCmEko8.css"
    ],
    "file": "select.PmZcTmT4.js",
    "imports": [
      "_swiper-vue.Dj7aAS3P.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_popper.cjhOvqyO.js",
      "_scrollbar.wb_P4sCD.js",
      "_tag.TzwDj60f.js",
      "_strings.Y1vdtDWm.js",
      "_isEqual.kSCWbLwW.js",
      "_debounce.rDCbVktl.js",
      "_hasIn.wpY4XSY7.js",
      "_index.Guwzp7dI.js"
    ]
  },
  "select.WyCmEko8.css": {
    "file": "select.WyCmEko8.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_sku.E4aUln0z.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sku.E4aUln0z.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_strings.Y1vdtDWm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "strings.Y1vdtDWm.js",
    "imports": [
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "_swiper-vue.!~{002}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "swiper-vue.CRufKKKm.css",
    "src": "_swiper-vue.!~{002}~.js"
  },
  "_swiper-vue.Dj7aAS3P.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "swiper-vue.CRufKKKm.css"
    ],
    "file": "swiper-vue.Dj7aAS3P.js"
  },
  "swiper-vue.CRufKKKm.css": {
    "file": "swiper-vue.CRufKKKm.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_tabs.!~{013}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "tabs.H-UKPvku.css",
    "src": "_tabs.!~{013}~.js"
  },
  "_tabs.WnvjjJQ1.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "tabs.H-UKPvku.css"
    ],
    "file": "tabs.WnvjjJQ1.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_strings.Y1vdtDWm.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_index.vS44-DLf.js"
    ]
  },
  "tabs.H-UKPvku.css": {
    "file": "tabs.H-UKPvku.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_tag.!~{00y}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "tag.ItIytdvz.css",
    "src": "_tag.!~{00y}~.js"
  },
  "_tag.TzwDj60f.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "tag.ItIytdvz.css"
    ],
    "file": "tag.TzwDj60f.js",
    "imports": [
      "_swiper-vue.Dj7aAS3P.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "tag.ItIytdvz.css": {
    "file": "tag.ItIytdvz.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_tooltip.!~{01F}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "menu-item.f0mNRiTD.css",
    "src": "_tooltip.!~{01F}~.js"
  },
  "_upload.!~{01u}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "upload.5r92S6hB.css",
    "src": "_upload.!~{01u}~.js"
  },
  "_upload.ApfaF2k3.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "upload.5r92S6hB.css"
    ],
    "file": "upload.ApfaF2k3.js",
    "imports": [
      "_swiper-vue.Dj7aAS3P.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_progress.9Rta0wsd.js",
      "_cloneDeep.MXrbYbCD.js",
      "_isEqual.kSCWbLwW.js"
    ]
  },
  "upload.5r92S6hB.css": {
    "file": "upload.5r92S6hB.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_useOrderStore.Ef1_umBl.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useOrderStore.Ef1_umBl.js",
    "imports": [
      "_index.oq21xmZ4.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "_useWebToast.wtzyb2Fk.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useWebToast.wtzyb2Fk.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_useWs._PlXJD1b.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useWs._PlXJD1b.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_notification.Q_nNtR8t.js",
      "_swiper-vue.Dj7aAS3P.js"
    ]
  },
  "components/Chat/Friend/ApplyDialog.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ApplyDialog.9uc--_4j.js",
    "imports": [
      "_ApplyDialog.vue.YZYcLkFi.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_dialog.CaAHiX9A.js",
      "_notification.Q_nNtR8t.js",
      "_friend.HOY7VQKz.js"
    ],
    "isDynamicEntry": true,
    "src": "components/Chat/Friend/ApplyDialog.vue"
  },
  "components/Chat/NewGroupDialog.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "NewGroupDialog.VBKd-Cia.css",
      "checkbox-group.d5XbR8TY.css"
    ],
    "file": "NewGroupDialog.fVFOv1qp.js",
    "imports": [
      "_ElImage.BY_iSMtR.js",
      "_checkbox.oVr9ht7C.js",
      "_AutoIncre.vue.TtiP3fHm.js",
      "_scrollbar.wb_P4sCD.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_OssFileUpload.pEDLM9U-.js",
      "_dialog.CaAHiX9A.js",
      "_notification.Q_nNtR8t.js",
      "_contact.mrkwsl6m.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_Main.vue.B83vyFhi.js",
      "_friend.HOY7VQKz.js",
      "_debounce.rDCbVktl.js",
      "_isEqual.kSCWbLwW.js",
      "_hasIn.wpY4XSY7.js",
      "_flatten.mqqocT4_.js",
      "_progress.9Rta0wsd.js",
      "_index.F3hl3u3-.js",
      "_useWs._PlXJD1b.js",
      "_tag.TzwDj60f.js"
    ],
    "isDynamicEntry": true,
    "src": "components/Chat/NewGroupDialog.vue"
  },
  "NewGroupDialog.VBKd-Cia.css": {
    "file": "NewGroupDialog.VBKd-Cia.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "checkbox-group.d5XbR8TY.css": {
    "file": "checkbox-group.d5XbR8TY.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/Comm/PostList.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "PostList.BPaQlUWh.css"
    ],
    "file": "PostList.JLk0Vcvu.js",
    "imports": [
      "_ElImage.BY_iSMtR.js",
      "_nuxt-link.lxn6Pk9R.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.TzwDj60f.js",
      "_TagList.vue.Opuc7lVD.js",
      "_CommentPreview.G-Xywm6m.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_AutoIncre.vue.TtiP3fHm.js",
      "_post.ljep56mz.js",
      "_debounce.rDCbVktl.js",
      "_select.PmZcTmT4.js",
      "_popper.cjhOvqyO.js",
      "_scrollbar.wb_P4sCD.js",
      "_strings.Y1vdtDWm.js",
      "_isEqual.kSCWbLwW.js",
      "_hasIn.wpY4XSY7.js",
      "_index.Guwzp7dI.js",
      "_OssFileUpload.pEDLM9U-.js",
      "_progress.9Rta0wsd.js",
      "_index.F3hl3u3-.js",
      "_notification.Q_nNtR8t.js"
    ],
    "isDynamicEntry": true,
    "src": "components/Comm/PostList.vue"
  },
  "PostList.BPaQlUWh.css": {
    "file": "PostList.BPaQlUWh.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/Comm/post/CateGoryLine.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "CateGoryLine.QJdD93vf.js",
    "imports": [
      "_ElImage.BY_iSMtR.js",
      "_nuxt-link.lxn6Pk9R.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_debounce.rDCbVktl.js"
    ],
    "isDynamicEntry": true,
    "src": "components/Comm/post/CateGoryLine.vue"
  },
  "components/Comm/post/Rank.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "Rank.y3OSjSFp.css"
    ],
    "file": "Rank.3MscI19h.js",
    "imports": [
      "_divider.RwvYdWPC.js",
      "_tag.TzwDj60f.js",
      "_ElImage.BY_iSMtR.js",
      "_nuxt-link.lxn6Pk9R.js",
      "_empty.IHZ29T3R.js",
      "_scrollbar.wb_P4sCD.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_post.ljep56mz.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_debounce.rDCbVktl.js"
    ],
    "isDynamicEntry": true,
    "src": "components/Comm/post/Rank.vue"
  },
  "Rank.y3OSjSFp.css": {
    "file": "Rank.y3OSjSFp.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/card/UserLine.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "UserLine.G_lnDfVq.css",
      "popover.N-GW0j1A.css"
    ],
    "file": "UserLine.ZDuMBWXG.js",
    "imports": [
      "_avatar.Xqlr04No.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_upload.ApfaF2k3.js",
      "_nuxt-link.lxn6Pk9R.js",
      "_index.c9G0tYhv.js",
      "_progress.9Rta0wsd.js",
      "_popper.cjhOvqyO.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_cloneDeep.MXrbYbCD.js",
      "_isEqual.kSCWbLwW.js"
    ],
    "isDynamicEntry": true,
    "src": "components/card/UserLine.vue"
  },
  "UserLine.G_lnDfVq.css": {
    "file": "UserLine.G_lnDfVq.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/list/GoodsList.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "GoodsList.1p6fEF-7.css"
    ],
    "file": "GoodsList.l4hoJqx0.js",
    "imports": [
      "_index.9Ely185F.js",
      "_nuxt-link.lxn6Pk9R.js",
      "_AutoIncre.vue.TtiP3fHm.js",
      "_swiper-vue.Dj7aAS3P.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.BY_iSMtR.js",
      "_debounce.rDCbVktl.js"
    ],
    "isDynamicEntry": true,
    "src": "components/list/GoodsList.vue"
  },
  "GoodsList.1p6fEF-7.css": {
    "file": "GoodsList.1p6fEF-7.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/menu/DrawerMenu.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "DrawerMenu.0ja6gThp.css",
      "menu-item.f0mNRiTD.css",
      "popover.N-GW0j1A.css"
    ],
    "file": "DrawerMenu.E810wKTK.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_menu.FJEhNG3E.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_scrollbar.wb_P4sCD.js",
      "_popper.cjhOvqyO.js",
      "_logo_dark.DAdYXcdH.js",
      "_index.VDnR5ZRx.js",
      "_nuxt-link.lxn6Pk9R.js",
      "_index.c9G0tYhv.js"
    ],
    "isDynamicEntry": true,
    "src": "components/menu/DrawerMenu.vue"
  },
  "DrawerMenu.0ja6gThp.css": {
    "file": "DrawerMenu.0ja6gThp.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "menu-item.f0mNRiTD.css": {
    "file": "menu-item.f0mNRiTD.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/menu/RightButtons/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.d8QRz2qr.css",
      "popover.N-GW0j1A.css",
      "menu-item.f0mNRiTD.css"
    ],
    "dynamicImports": [
      "components/menu/ShopCartBar.vue"
    ],
    "file": "index.oZXbkvnx.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_nuxt-link.lxn6Pk9R.js",
      "_Main.vue.B83vyFhi.js",
      "_scrollbar.wb_P4sCD.js",
      "_ElImage.BY_iSMtR.js",
      "_index.c9G0tYhv.js",
      "_popper.cjhOvqyO.js",
      "_contact.mrkwsl6m.js",
      "_useWs._PlXJD1b.js",
      "_tag.TzwDj60f.js",
      "_debounce.rDCbVktl.js",
      "_notification.Q_nNtR8t.js"
    ],
    "isDynamicEntry": true,
    "src": "components/menu/RightButtons/index.vue"
  },
  "index.d8QRz2qr.css": {
    "file": "index.d8QRz2qr.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/menu/ShopCartBar.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "ShopCartBar.iS6Wm7Is.css",
      "checkbox-group.d5XbR8TY.css",
      "popover.N-GW0j1A.css"
    ],
    "file": "ShopCartBar.S-922U0K.js",
    "imports": [
      "_checkbox.oVr9ht7C.js",
      "_ShopLine.1ycSDMT2.js",
      "_AutoIncre.vue.TtiP3fHm.js",
      "_scrollbar.wb_P4sCD.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.c9G0tYhv.js",
      "_popper.cjhOvqyO.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_useOrderStore.Ef1_umBl.js",
      "_isEqual.kSCWbLwW.js",
      "_hasIn.wpY4XSY7.js",
      "_flatten.mqqocT4_.js",
      "_ElImage.BY_iSMtR.js",
      "_debounce.rDCbVktl.js",
      "_nuxt-link.lxn6Pk9R.js",
      "_select.PmZcTmT4.js",
      "_tag.TzwDj60f.js",
      "_strings.Y1vdtDWm.js",
      "_index.Guwzp7dI.js",
      "_input-number.CZnCGSJB.js",
      "_index.m5OxfFYg.js",
      "_sku.E4aUln0z.js",
      "_index.oq21xmZ4.js"
    ],
    "isDynamicEntry": true,
    "src": "components/menu/ShopCartBar.vue"
  },
  "ShopCartBar.iS6Wm7Is.css": {
    "file": "ShopCartBar.iS6Wm7Is.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "layouts/chat.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "chat.v6D4Qv8B.css",
      "menu-item.f0mNRiTD.css",
      "popover.N-GW0j1A.css"
    ],
    "dynamicImports": [
      "components/menu/RightButtons/index.vue"
    ],
    "file": "chat.5ns13Jjq.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.BY_iSMtR.js",
      "components/card/UserLine.vue",
      "_swiper-vue.Dj7aAS3P.js",
      "_menu.FJEhNG3E.js",
      "_popper.cjhOvqyO.js",
      "_useWs._PlXJD1b.js",
      "_friend.HOY7VQKz.js",
      "_useWebToast.wtzyb2Fk.js",
      "_debounce.rDCbVktl.js",
      "_avatar.Xqlr04No.js",
      "_upload.ApfaF2k3.js",
      "_progress.9Rta0wsd.js",
      "_cloneDeep.MXrbYbCD.js",
      "_isEqual.kSCWbLwW.js",
      "_nuxt-link.lxn6Pk9R.js",
      "_index.c9G0tYhv.js",
      "_index.VDnR5ZRx.js",
      "_notification.Q_nNtR8t.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/chat.vue"
  },
  "chat.v6D4Qv8B.css": {
    "file": "chat.v6D4Qv8B.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "layouts/error.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "error.BLGT6MmT.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/error.vue"
  },
  "layouts/main.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "popover.N-GW0j1A.css",
      "menu-item.f0mNRiTD.css"
    ],
    "dynamicImports": [
      "components/menu/DrawerMenu.vue"
    ],
    "file": "main.jB6c8xjc.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_Footer.CRQS_PGT.js",
      "components/menu/RightButtons/index.vue",
      "_swiper-vue.Dj7aAS3P.js",
      "_nuxt-link.lxn6Pk9R.js",
      "_logo_dark.DAdYXcdH.js",
      "_scrollbar.wb_P4sCD.js",
      "_index.c9G0tYhv.js",
      "_popper.cjhOvqyO.js",
      "_Switch.udPgGRYL.js",
      "_Main.vue.B83vyFhi.js",
      "_contact.mrkwsl6m.js",
      "_useWs._PlXJD1b.js",
      "_notification.Q_nNtR8t.js",
      "_ElImage.BY_iSMtR.js",
      "_debounce.rDCbVktl.js",
      "_tag.TzwDj60f.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/main.vue"
  },
  "layouts/second.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "second.JqdAvVfB.css",
      "popover.N-GW0j1A.css",
      "menu-item.f0mNRiTD.css"
    ],
    "file": "second._seplsuE.js",
    "imports": [
      "_Footer.CRQS_PGT.js",
      "components/menu/RightButtons/index.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_nuxt-link.lxn6Pk9R.js",
      "_logo_dark.DAdYXcdH.js",
      "_scrollbar.wb_P4sCD.js",
      "_index.c9G0tYhv.js",
      "_popper.cjhOvqyO.js",
      "_Switch.udPgGRYL.js",
      "_Main.vue.B83vyFhi.js",
      "_contact.mrkwsl6m.js",
      "_useWs._PlXJD1b.js",
      "_notification.Q_nNtR8t.js",
      "_ElImage.BY_iSMtR.js",
      "_debounce.rDCbVktl.js",
      "_tag.TzwDj60f.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/second.vue"
  },
  "second.JqdAvVfB.css": {
    "file": "second.JqdAvVfB.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "layouts/user.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "user.yAuj-VgQ.css",
      "menu-item.f0mNRiTD.css",
      "popover.N-GW0j1A.css"
    ],
    "file": "user.-3mUl00r.js",
    "imports": [
      "_nuxt-link.lxn6Pk9R.js",
      "_logo_dark.DAdYXcdH.js",
      "_Switch.udPgGRYL.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_menu.FJEhNG3E.js",
      "_popper.cjhOvqyO.js",
      "components/menu/RightButtons/index.vue",
      "_scrollbar.wb_P4sCD.js",
      "_index.c9G0tYhv.js",
      "_index.VDnR5ZRx.js",
      "_Main.vue.B83vyFhi.js",
      "_contact.mrkwsl6m.js",
      "_useWs._PlXJD1b.js",
      "_notification.Q_nNtR8t.js",
      "_ElImage.BY_iSMtR.js",
      "_debounce.rDCbVktl.js",
      "_tag.TzwDj60f.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/user.vue"
  },
  "user.yAuj-VgQ.css": {
    "file": "user.yAuj-VgQ.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/element-plus/es/components/text/index.mjs": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.R13h4Vtw.css"
    ],
    "file": "index.cbinA3cR.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/element-plus/es/components/text/index.mjs"
  },
  "index.R13h4Vtw.css": {
    "file": "index.R13h4Vtw.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "entry.3PN328n9.css"
    ],
    "dynamicImports": [
      "layouts/chat.vue",
      "layouts/error.vue",
      "layouts/main.vue",
      "layouts/second.vue",
      "layouts/user.vue",
      "node_modules/workbox-window/build/workbox-window.prod.es5.mjs"
    ],
    "file": "entry.mRaChMjT.js",
    "imports": [
      "_swiper-vue.Dj7aAS3P.js"
    ],
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js"
  },
  "entry.3PN328n9.css": {
    "file": "entry.3PN328n9.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/workbox-window/build/workbox-window.prod.es5.mjs": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "workbox-window.prod.es5.prqDwDSL.js",
    "isDynamicEntry": true,
    "src": "node_modules/workbox-window/build/workbox-window.prod.es5.mjs"
  },
  "pages/[...all].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_...all_.p2Q6xsBg.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/[...all].vue"
  },
  "pages/chat/friend.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "friend.9C4eh_nv.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "file": "friend.WOg5mti3.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.TzwDj60f.js",
      "_ElImage.BY_iSMtR.js",
      "_AutoIncre.vue.TtiP3fHm.js",
      "_scrollbar.wb_P4sCD.js",
      "_empty.IHZ29T3R.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_friend.HOY7VQKz.js",
      "_index.TErpPJT5.js",
      "_contact.mrkwsl6m.js",
      "_useWs._PlXJD1b.js",
      "_notification.Q_nNtR8t.js",
      "_divider.RwvYdWPC.js",
      "_ApplyDialog.vue.YZYcLkFi.js",
      "_index.nR0g6DS1.js",
      "_debounce.rDCbVktl.js",
      "_dialog.CaAHiX9A.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/chat/friend.vue"
  },
  "friend.9C4eh_nv.css": {
    "file": "friend.9C4eh_nv.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "radio-group.P_Xz2fNs.css": {
    "file": "radio-group.P_Xz2fNs.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/chat/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.xScC5fds.css",
      "radio.eYTrrdr6.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "dynamicImports": [
      "components/Chat/NewGroupDialog.vue",
      "components/Chat/NewGroupDialog.vue",
      "components/Chat/Friend/ApplyDialog.vue"
    ],
    "file": "index.wTfQliRf.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.BY_iSMtR.js",
      "_index.TErpPJT5.js",
      "_AutoIncre.vue.TtiP3fHm.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_notification.Q_nNtR8t.js",
      "_contact.mrkwsl6m.js",
      "_Main.vue.B83vyFhi.js",
      "_friend.HOY7VQKz.js",
      "_useWs._PlXJD1b.js",
      "_tag.TzwDj60f.js",
      "_scrollbar.wb_P4sCD.js",
      "_select.PmZcTmT4.js",
      "_OssFileUpload.pEDLM9U-.js",
      "_nuxt-link.lxn6Pk9R.js",
      "_popper.cjhOvqyO.js",
      "_index.F3hl3u3-.js",
      "_debounce.rDCbVktl.js",
      "_strings.Y1vdtDWm.js",
      "_isEqual.kSCWbLwW.js",
      "_hasIn.wpY4XSY7.js",
      "_index.Guwzp7dI.js",
      "_progress.9Rta0wsd.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/chat/index.vue"
  },
  "index.xScC5fds.css": {
    "file": "index.xScC5fds.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "radio.eYTrrdr6.css": {
    "file": "radio.eYTrrdr6.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/chat/setting.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "setting.1OV0DNN5.css",
      "radio-button.l7x146Nf.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "file": "setting.D5QvSbJx.js",
    "imports": [
      "_divider.RwvYdWPC.js",
      "_select.PmZcTmT4.js",
      "_index.TErpPJT5.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.TzwDj60f.js",
      "_scrollbar.wb_P4sCD.js",
      "_popper.cjhOvqyO.js",
      "_notification.Q_nNtR8t.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_strings.Y1vdtDWm.js",
      "_isEqual.kSCWbLwW.js",
      "_debounce.rDCbVktl.js",
      "_hasIn.wpY4XSY7.js",
      "_index.Guwzp7dI.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/chat/setting.vue"
  },
  "setting.1OV0DNN5.css": {
    "file": "setting.1OV0DNN5.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "radio-button.l7x146Nf.css": {
    "file": "radio-button.l7x146Nf.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/category/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "_id_.uLLhAsoU.css"
    ],
    "dynamicImports": [
      "components/Comm/post/Rank.vue"
    ],
    "file": "_id_.2opYB5MJ.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.BY_iSMtR.js",
      "_CategoryTabs.M9UbgK-M.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_debounce.rDCbVktl.js",
      "_tabs.WnvjjJQ1.js",
      "_strings.Y1vdtDWm.js",
      "_index.vS44-DLf.js",
      "components/Comm/PostList.vue",
      "_nuxt-link.lxn6Pk9R.js",
      "_tag.TzwDj60f.js",
      "_TagList.vue.Opuc7lVD.js",
      "_CommentPreview.G-Xywm6m.js",
      "_select.PmZcTmT4.js",
      "_popper.cjhOvqyO.js",
      "_scrollbar.wb_P4sCD.js",
      "_isEqual.kSCWbLwW.js",
      "_hasIn.wpY4XSY7.js",
      "_index.Guwzp7dI.js",
      "_OssFileUpload.pEDLM9U-.js",
      "_progress.9Rta0wsd.js",
      "_index.F3hl3u3-.js",
      "_AutoIncre.vue.TtiP3fHm.js",
      "_notification.Q_nNtR8t.js",
      "_post.ljep56mz.js",
      "components/list/GoodsList.vue",
      "_index.9Ely185F.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/category/[id].vue"
  },
  "_id_.uLLhAsoU.css": {
    "file": "_id_.uLLhAsoU.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/category/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.EaIT1GIC.css"
    ],
    "dynamicImports": [
      "components/Comm/post/Rank.vue"
    ],
    "file": "index.mL7GSgvc.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_CategoryTabs.M9UbgK-M.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_tabs.WnvjjJQ1.js",
      "_strings.Y1vdtDWm.js",
      "_index.vS44-DLf.js",
      "components/Comm/PostList.vue",
      "_ElImage.BY_iSMtR.js",
      "_debounce.rDCbVktl.js",
      "_nuxt-link.lxn6Pk9R.js",
      "_tag.TzwDj60f.js",
      "_TagList.vue.Opuc7lVD.js",
      "_CommentPreview.G-Xywm6m.js",
      "_select.PmZcTmT4.js",
      "_popper.cjhOvqyO.js",
      "_scrollbar.wb_P4sCD.js",
      "_isEqual.kSCWbLwW.js",
      "_hasIn.wpY4XSY7.js",
      "_index.Guwzp7dI.js",
      "_OssFileUpload.pEDLM9U-.js",
      "_progress.9Rta0wsd.js",
      "_index.F3hl3u3-.js",
      "_AutoIncre.vue.TtiP3fHm.js",
      "_notification.Q_nNtR8t.js",
      "_post.ljep56mz.js",
      "components/list/GoodsList.vue",
      "_index.9Ely185F.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/category/index.vue"
  },
  "index.EaIT1GIC.css": {
    "file": "index.EaIT1GIC.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/post/detail/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "_id_.72oiqwWe.css",
      "popover.N-GW0j1A.css"
    ],
    "dynamicImports": [
      "components/Comm/post/CateGoryLine.vue"
    ],
    "file": "_id_.83DeDoeF.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.BY_iSMtR.js",
      "_Switch.udPgGRYL.js",
      "_tag.TzwDj60f.js",
      "_nuxt-link.lxn6Pk9R.js",
      "_TagList.vue.Opuc7lVD.js",
      "_divider.RwvYdWPC.js",
      "_post.ljep56mz.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_CommentPreview.G-Xywm6m.js",
      "_UserPostTotal.vue.hTPHLcRD.js",
      "_SigninCard.vue.vtcC-DF7.js",
      "_debounce.rDCbVktl.js",
      "_select.PmZcTmT4.js",
      "_popper.cjhOvqyO.js",
      "_scrollbar.wb_P4sCD.js",
      "_strings.Y1vdtDWm.js",
      "_isEqual.kSCWbLwW.js",
      "_hasIn.wpY4XSY7.js",
      "_index.Guwzp7dI.js",
      "_OssFileUpload.pEDLM9U-.js",
      "_progress.9Rta0wsd.js",
      "_index.F3hl3u3-.js",
      "_AutoIncre.vue.TtiP3fHm.js",
      "_notification.Q_nNtR8t.js",
      "_index.c9G0tYhv.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/post/detail/[id].vue"
  },
  "_id_.72oiqwWe.css": {
    "file": "_id_.72oiqwWe.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/post/list.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "list.aADC_aru.css",
      "popover.N-GW0j1A.css"
    ],
    "file": "list.iac_8O3k.js",
    "imports": [
      "_nuxt-link.lxn6Pk9R.js",
      "_tag.TzwDj60f.js",
      "_swiper-vue.Dj7aAS3P.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_post.ljep56mz.js",
      "_ElImage.BY_iSMtR.js",
      "components/Comm/PostList.vue",
      "_tabs.WnvjjJQ1.js",
      "_SigninCard.vue.vtcC-DF7.js",
      "components/Comm/post/Rank.vue",
      "_debounce.rDCbVktl.js",
      "_TagList.vue.Opuc7lVD.js",
      "_CommentPreview.G-Xywm6m.js",
      "_select.PmZcTmT4.js",
      "_popper.cjhOvqyO.js",
      "_scrollbar.wb_P4sCD.js",
      "_strings.Y1vdtDWm.js",
      "_isEqual.kSCWbLwW.js",
      "_hasIn.wpY4XSY7.js",
      "_index.Guwzp7dI.js",
      "_OssFileUpload.pEDLM9U-.js",
      "_progress.9Rta0wsd.js",
      "_index.F3hl3u3-.js",
      "_AutoIncre.vue.TtiP3fHm.js",
      "_notification.Q_nNtR8t.js",
      "_index.vS44-DLf.js",
      "_index.c9G0tYhv.js",
      "_divider.RwvYdWPC.js",
      "_empty.IHZ29T3R.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/post/list.vue"
  },
  "list.aADC_aru.css": {
    "file": "list.aADC_aru.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/post/new.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "new.0TTT8KuO.css",
      "radio-button.l7x146Nf.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "file": "new.OVbGSJzy.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_OssFileUpload.pEDLM9U-.js",
      "_index.TErpPJT5.js",
      "_ElImage.BY_iSMtR.js",
      "_select.PmZcTmT4.js",
      "_tag.TzwDj60f.js",
      "_scrollbar.wb_P4sCD.js",
      "_popper.cjhOvqyO.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_notification.Q_nNtR8t.js",
      "_index.F3hl3u3-.js",
      "_StatusTag.Rv3fxdDR.js",
      "_post.ljep56mz.js",
      "_progress.9Rta0wsd.js",
      "_debounce.rDCbVktl.js",
      "_strings.Y1vdtDWm.js",
      "_isEqual.kSCWbLwW.js",
      "_hasIn.wpY4XSY7.js",
      "_index.Guwzp7dI.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/post/new.vue"
  },
  "new.0TTT8KuO.css": {
    "file": "new.0TTT8KuO.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/event/detail/[eid].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "_eid_.NtANQ6Xa.css"
    ],
    "file": "_eid_.Xt-EMt5W.js",
    "imports": [
      "_ElImage.BY_iSMtR.js",
      "_tag.TzwDj60f.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_nuxt-link.lxn6Pk9R.js",
      "_index.H_db_cZm.js",
      "_debounce.rDCbVktl.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/event/detail/[eid].vue"
  },
  "_eid_.NtANQ6Xa.css": {
    "file": "_eid_.NtANQ6Xa.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/goods/comments/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_id_.tQEhgRZ6.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/goods/comments/[id].vue"
  },
  "pages/goods/detail/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "_id_.6sdekYJX.css",
      "popover.N-GW0j1A.css",
      "radio-button.l7x146Nf.css",
      "radio-group.P_Xz2fNs.css",
      "radio.eYTrrdr6.css"
    ],
    "file": "_id_.p64oSYaN.js",
    "imports": [
      "_nuxt-link.lxn6Pk9R.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_GoodsListSsr.6NLnx7YW.js",
      "_ElImage.BY_iSMtR.js",
      "_index.vS44-DLf.js",
      "_scrollbar.wb_P4sCD.js",
      "_tag.TzwDj60f.js",
      "_popper.cjhOvqyO.js",
      "_collect.HvW0DaCO.js",
      "_index.TErpPJT5.js",
      "_input-number.CZnCGSJB.js",
      "_useOrderStore.Ef1_umBl.js",
      "_index.H_db_cZm.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_tabs.WnvjjJQ1.js",
      "_rate.j8YCg03p.js",
      "_AutoIncre.vue.TtiP3fHm.js",
      "_dialog.CaAHiX9A.js",
      "_index.VDnR5ZRx.js",
      "_rand.mzGjE9Jh.js",
      "_index.9Ely185F.js",
      "_sku.E4aUln0z.js",
      "_debounce.rDCbVktl.js",
      "_index.m5OxfFYg.js",
      "_index.oq21xmZ4.js",
      "_strings.Y1vdtDWm.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/goods/detail/[id].vue"
  },
  "_id_.6sdekYJX.css": {
    "file": "_id_.6sdekYJX.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.Ik5BYhtU.css",
      "popover.N-GW0j1A.css"
    ],
    "dynamicImports": [
      "components/list/GoodsList.vue"
    ],
    "file": "index.kSMMHD8e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.TzwDj60f.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_nuxt-link.lxn6Pk9R.js",
      "_AutoIncre.vue.TtiP3fHm.js",
      "_empty.IHZ29T3R.js",
      "_scrollbar.wb_P4sCD.js",
      "_index.c9G0tYhv.js",
      "_popper.cjhOvqyO.js",
      "_index.9Ely185F.js",
      "_index.H_db_cZm.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_GoodsListSsr.6NLnx7YW.js",
      "_tabs.WnvjjJQ1.js",
      "_ElImage.BY_iSMtR.js",
      "_strings.Y1vdtDWm.js",
      "_index.vS44-DLf.js",
      "_debounce.rDCbVktl.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.Ik5BYhtU.css": {
    "file": "index.Ik5BYhtU.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/order/comment/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "_id_.65PfMBS2.css"
    ],
    "file": "_id_.lvGXZid7.js",
    "imports": [
      "_Switch.udPgGRYL.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_progress.9Rta0wsd.js",
      "_upload.ApfaF2k3.js",
      "_dialog.CaAHiX9A.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_index.F3hl3u3-.js",
      "_ElImage.BY_iSMtR.js",
      "_rate.j8YCg03p.js",
      "_checkbox.oVr9ht7C.js",
      "_nuxt-link.lxn6Pk9R.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_notification.Q_nNtR8t.js",
      "_index.oq21xmZ4.js",
      "_cloneDeep.MXrbYbCD.js",
      "_isEqual.kSCWbLwW.js",
      "_debounce.rDCbVktl.js",
      "_hasIn.wpY4XSY7.js",
      "_flatten.mqqocT4_.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/order/comment/[id].vue"
  },
  "_id_.65PfMBS2.css": {
    "file": "_id_.65PfMBS2.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/order/detail.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "detail.FQzghYYY.css",
      "radio.eYTrrdr6.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "dynamicImports": [
      "node_modules/element-plus/es/components/text/index.mjs"
    ],
    "file": "detail.A-i2DL1Z.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.BY_iSMtR.js",
      "_nuxt-link.lxn6Pk9R.js",
      "_divider.RwvYdWPC.js",
      "_DelayTimer.vue.hkGxYdrD.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_Switch.udPgGRYL.js",
      "_index.vS44-DLf.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_bills.rxU_HeZW.js",
      "_index.oq21xmZ4.js",
      "_useOrderStore.Ef1_umBl.js",
      "_index.TErpPJT5.js",
      "_tag.TzwDj60f.js",
      "_scrollbar.wb_P4sCD.js",
      "_select.PmZcTmT4.js",
      "_input-number.CZnCGSJB.js",
      "_popper.cjhOvqyO.js",
      "_index.H_db_cZm.js",
      "_sku.E4aUln0z.js",
      "_empty.IHZ29T3R.js",
      "_notification.Q_nNtR8t.js",
      "_useWebToast.wtzyb2Fk.js",
      "_debounce.rDCbVktl.js",
      "_strings.Y1vdtDWm.js",
      "_isEqual.kSCWbLwW.js",
      "_hasIn.wpY4XSY7.js",
      "_index.Guwzp7dI.js",
      "_index.m5OxfFYg.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/order/detail.vue"
  },
  "detail.FQzghYYY.css": {
    "file": "detail.FQzghYYY.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/order/list.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "list.pKmG3IwD.css"
    ],
    "file": "list.x7hXyPTx.js",
    "imports": [
      "_divider.RwvYdWPC.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_date-picker.SiYDvXl4.js",
      "_DelayTimer.vue.hkGxYdrD.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_ElImage.BY_iSMtR.js",
      "_tag.TzwDj60f.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_useOrderStore.Ef1_umBl.js",
      "_index.oq21xmZ4.js",
      "_AutoIncre.vue.TtiP3fHm.js",
      "_scrollbar.wb_P4sCD.js",
      "_popper.cjhOvqyO.js",
      "_notification.Q_nNtR8t.js",
      "_tabs.WnvjjJQ1.js",
      "_localeData.fByHNnFW.js",
      "_arrays.9GuX8ZvT.js",
      "_flatten.mqqocT4_.js",
      "_index.m5OxfFYg.js",
      "_debounce.rDCbVktl.js",
      "_index.Guwzp7dI.js",
      "_isEqual.kSCWbLwW.js",
      "_strings.Y1vdtDWm.js",
      "_index.vS44-DLf.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/order/list.vue"
  },
  "list.pKmG3IwD.css": {
    "file": "list.pKmG3IwD.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/search/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.gADI8LgY.css"
    ],
    "dynamicImports": [
      "components/list/GoodsList.vue",
      "components/Comm/PostList.vue"
    ],
    "file": "index.7ufGIHnE.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_checkbox.oVr9ht7C.js",
      "_select.PmZcTmT4.js",
      "_tag.TzwDj60f.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_tabs.WnvjjJQ1.js",
      "_empty.IHZ29T3R.js",
      "_scrollbar.wb_P4sCD.js",
      "_popper.cjhOvqyO.js",
      "_isEqual.kSCWbLwW.js",
      "_hasIn.wpY4XSY7.js",
      "_flatten.mqqocT4_.js",
      "_strings.Y1vdtDWm.js",
      "_debounce.rDCbVktl.js",
      "_index.Guwzp7dI.js",
      "_index.vS44-DLf.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/search/index.vue"
  },
  "index.gADI8LgY.css": {
    "file": "index.gADI8LgY.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/setting/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.p8ZulH49.css",
      "radio-button.l7x146Nf.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "file": "index.vjg2SyWZ.js",
    "imports": [
      "_divider.RwvYdWPC.js",
      "_select.PmZcTmT4.js",
      "_index.TErpPJT5.js",
      "_swiper-vue.Dj7aAS3P.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.TzwDj60f.js",
      "_scrollbar.wb_P4sCD.js",
      "_popper.cjhOvqyO.js",
      "_notification.Q_nNtR8t.js",
      "_strings.Y1vdtDWm.js",
      "_isEqual.kSCWbLwW.js",
      "_debounce.rDCbVktl.js",
      "_hasIn.wpY4XSY7.js",
      "_index.Guwzp7dI.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/setting/index.vue"
  },
  "index.p8ZulH49.css": {
    "file": "index.p8ZulH49.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/address.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "address.WdFNjMwU.css",
      "radio.eYTrrdr6.css",
      "checkbox-group.d5XbR8TY.css"
    ],
    "file": "address.n3het30A.js",
    "imports": [
      "node_modules/element-plus/es/components/text/index.mjs",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_scrollbar.wb_P4sCD.js",
      "_checkbox.oVr9ht7C.js",
      "_index.TErpPJT5.js",
      "_rand.mzGjE9Jh.js",
      "_strings.Y1vdtDWm.js",
      "_isEqual.kSCWbLwW.js",
      "_arrays.9GuX8ZvT.js",
      "_flatten.mqqocT4_.js",
      "_cloneDeep.MXrbYbCD.js",
      "_popper.cjhOvqyO.js",
      "_tag.TzwDj60f.js",
      "_index.Guwzp7dI.js",
      "_debounce.rDCbVktl.js",
      "_dialog.CaAHiX9A.js",
      "_divider.RwvYdWPC.js",
      "_hasIn.wpY4XSY7.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/address.vue"
  },
  "address.WdFNjMwU.css": {
    "file": "address.WdFNjMwU.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/collect.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "collect.7bC4-ld9.css",
      "checkbox-group.d5XbR8TY.css"
    ],
    "file": "collect.5N91u9Lo.js",
    "imports": [
      "_divider.RwvYdWPC.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_checkbox.oVr9ht7C.js",
      "_ElImage.BY_iSMtR.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_scrollbar.wb_P4sCD.js",
      "_collect.HvW0DaCO.js",
      "_tabs.WnvjjJQ1.js",
      "_tag.TzwDj60f.js",
      "_nuxt-link.lxn6Pk9R.js",
      "_TagList.vue.Opuc7lVD.js",
      "_AutoIncre.vue.TtiP3fHm.js",
      "_post.ljep56mz.js",
      "_isEqual.kSCWbLwW.js",
      "_hasIn.wpY4XSY7.js",
      "_flatten.mqqocT4_.js",
      "_debounce.rDCbVktl.js",
      "_strings.Y1vdtDWm.js",
      "_index.vS44-DLf.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/collect.vue"
  },
  "collect.7bC4-ld9.css": {
    "file": "collect.7bC4-ld9.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/info.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "info._k_JpRFF.css",
      "popover.N-GW0j1A.css",
      "menu-item.f0mNRiTD.css"
    ],
    "file": "info.VQSqwmzO.js",
    "imports": [
      "_ElImage.BY_iSMtR.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.c9G0tYhv.js",
      "_popper.cjhOvqyO.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_upload.ApfaF2k3.js",
      "_date-picker.SiYDvXl4.js",
      "_select.PmZcTmT4.js",
      "_progress.9Rta0wsd.js",
      "_scrollbar.wb_P4sCD.js",
      "_tag.TzwDj60f.js",
      "_nuxt-link.lxn6Pk9R.js",
      "_TagList.vue.Opuc7lVD.js",
      "_AutoIncre.vue.TtiP3fHm.js",
      "_post.ljep56mz.js",
      "_tabs.WnvjjJQ1.js",
      "_UserPostTotal.vue.hTPHLcRD.js",
      "_SigninCard.vue.vtcC-DF7.js",
      "_index.nR0g6DS1.js",
      "_debounce.rDCbVktl.js",
      "_cloneDeep.MXrbYbCD.js",
      "_isEqual.kSCWbLwW.js",
      "_localeData.fByHNnFW.js",
      "_arrays.9GuX8ZvT.js",
      "_flatten.mqqocT4_.js",
      "_index.m5OxfFYg.js",
      "_index.Guwzp7dI.js",
      "_strings.Y1vdtDWm.js",
      "_hasIn.wpY4XSY7.js",
      "_index.vS44-DLf.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/info.vue"
  },
  "info._k_JpRFF.css": {
    "file": "info._k_JpRFF.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/post.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "post.yVQn8Ib0.css"
    ],
    "file": "post.o4lW2Qvu.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.BY_iSMtR.js",
      "_select.PmZcTmT4.js",
      "_tag.TzwDj60f.js",
      "_scrollbar.wb_P4sCD.js",
      "_popper.cjhOvqyO.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_StatusTag.Rv3fxdDR.js",
      "_nuxt-link.lxn6Pk9R.js",
      "_TagList.vue.Opuc7lVD.js",
      "_post.ljep56mz.js",
      "_AutoIncre.vue.TtiP3fHm.js",
      "_notification.Q_nNtR8t.js",
      "_tabs.WnvjjJQ1.js",
      "_debounce.rDCbVktl.js",
      "_strings.Y1vdtDWm.js",
      "_isEqual.kSCWbLwW.js",
      "_hasIn.wpY4XSY7.js",
      "_index.Guwzp7dI.js",
      "_index.vS44-DLf.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/post.vue"
  },
  "post.yVQn8Ib0.css": {
    "file": "post.yVQn8Ib0.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/safe.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "safe.73roRH3g.css"
    ],
    "file": "safe.VT22yn98.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.TzwDj60f.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_scrollbar.wb_P4sCD.js",
      "_avatar.Xqlr04No.js",
      "_divider.RwvYdWPC.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_useOrderStore.Ef1_umBl.js",
      "_index.oq21xmZ4.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/safe.vue"
  },
  "safe.73roRH3g.css": {
    "file": "safe.73roRH3g.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/shopcart.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "shopcart.cNizIJyk.css",
      "checkbox-group.d5XbR8TY.css"
    ],
    "file": "shopcart.pWYB7zVu.js",
    "imports": [
      "_checkbox.oVr9ht7C.js",
      "_ShopLine.1ycSDMT2.js",
      "_nuxt-link.lxn6Pk9R.js",
      "_AutoIncre.vue.TtiP3fHm.js",
      "_scrollbar.wb_P4sCD.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_useOrderStore.Ef1_umBl.js",
      "_isEqual.kSCWbLwW.js",
      "_hasIn.wpY4XSY7.js",
      "_flatten.mqqocT4_.js",
      "_ElImage.BY_iSMtR.js",
      "_debounce.rDCbVktl.js",
      "_select.PmZcTmT4.js",
      "_popper.cjhOvqyO.js",
      "_tag.TzwDj60f.js",
      "_strings.Y1vdtDWm.js",
      "_index.Guwzp7dI.js",
      "_input-number.CZnCGSJB.js",
      "_index.m5OxfFYg.js",
      "_sku.E4aUln0z.js",
      "_index.oq21xmZ4.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/shopcart.vue"
  },
  "shopcart.cNizIJyk.css": {
    "file": "shopcart.cNizIJyk.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/wallet.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "wallet.7z599r9w.css",
      "popover.N-GW0j1A.css"
    ],
    "file": "wallet.P7tSR_YU.js",
    "imports": [
      "node_modules/element-plus/es/components/text/index.mjs",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.Dj7aAS3P.js",
      "_progress.9Rta0wsd.js",
      "_index.c9G0tYhv.js",
      "_popper.cjhOvqyO.js",
      "_bills.rxU_HeZW.js",
      "_scrollbar.wb_P4sCD.js",
      "_input-number.CZnCGSJB.js",
      "_select.PmZcTmT4.js",
      "_tag.TzwDj60f.js",
      "_localeData.fByHNnFW.js",
      "_divider.RwvYdWPC.js",
      "_index.m5OxfFYg.js",
      "_strings.Y1vdtDWm.js",
      "_isEqual.kSCWbLwW.js",
      "_debounce.rDCbVktl.js",
      "_hasIn.wpY4XSY7.js",
      "_index.Guwzp7dI.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/wallet.vue"
  },
  "wallet.7z599r9w.css": {
    "file": "wallet.7z599r9w.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
