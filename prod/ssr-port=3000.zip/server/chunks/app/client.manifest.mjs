const client_manifest = {
  "_ApplyDialog.vue.KU2lfaks.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ApplyDialog.vue.KU2lfaks.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_dialog.v8AEwbT3.js",
      "_notification.2ssjOGF0.js",
      "_swiper-vue.5ECkG8-Q.js",
      "_friend.4xCtfHzK.js"
    ]
  },
  "_AutoIncre.vue.UypBYN5v.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "AutoIncre.vue.UypBYN5v.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.5ECkG8-Q.js"
    ]
  },
  "_CategoryTabs.!~{013}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "CategoryTabs.787nBCiN.css",
    "src": "_CategoryTabs.!~{013}~.js"
  },
  "_CategoryTabs.wEStPtHU.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "CategoryTabs.787nBCiN.css"
    ],
    "file": "CategoryTabs.wEStPtHU.js",
    "imports": [
      "_tabs.iK6Tfp8g.js",
      "node_modules/nuxt/dist/app/entry.js",
      "components/Comm/PostList.vue",
      "components/list/GoodsList.vue",
      "_swiper-vue.5ECkG8-Q.js"
    ]
  },
  "CategoryTabs.787nBCiN.css": {
    "file": "CategoryTabs.787nBCiN.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_CommentPreview.!~{018}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "CommentPreview.JFJ3T4Gg.css",
    "src": "_CommentPreview.!~{018}~.js"
  },
  "_CommentPreview.Lr8y2oj8.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "CommentPreview.JFJ3T4Gg.css"
    ],
    "file": "CommentPreview.Lr8y2oj8.js",
    "imports": [
      "_ElImage.Tm38mu9Z.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_select.gDkGZjKY.js",
      "_OssFileUpload.fMW_IpLz.js",
      "_nuxt-link.rZQe5F-Q.js",
      "_tag.1Rvuo_2t.js",
      "_swiper-vue.5ECkG8-Q.js",
      "_AutoIncre.vue.UypBYN5v.js",
      "_scrollbar.ZX_qVIEl.js",
      "_popper.T3b0UgM8.js",
      "_notification.2ssjOGF0.js"
    ]
  },
  "CommentPreview.JFJ3T4Gg.css": {
    "file": "CommentPreview.JFJ3T4Gg.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_DelayTimer.vue.krZqos6x.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "DelayTimer.vue.krZqos6x.js",
    "imports": [
      "_swiper-vue.5ECkG8-Q.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_ElImage.!~{00B}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "ElImage.t6Ajzk8E.css",
    "src": "_ElImage.!~{00B}~.js"
  },
  "_ElImage.Tm38mu9Z.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "ElImage.t6Ajzk8E.css"
    ],
    "file": "ElImage.Tm38mu9Z.js",
    "imports": [
      "_swiper-vue.5ECkG8-Q.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_debounce.L5KS2NIz.js"
    ]
  },
  "ElImage.t6Ajzk8E.css": {
    "file": "ElImage.t6Ajzk8E.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_Footer.!~{01O}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Footer.y5ruypfy.css",
    "src": "_Footer.!~{01O}~.js"
  },
  "_Footer.8HzSDD6o.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "Footer.y5ruypfy.css"
    ],
    "file": "Footer.8HzSDD6o.js",
    "imports": [
      "_nuxt-link.rZQe5F-Q.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.5ECkG8-Q.js",
      "_logo_dark.yfAlRlDM.js",
      "_Switch.q2nOHIl4.js"
    ]
  },
  "Footer.y5ruypfy.css": {
    "file": "Footer.y5ruypfy.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_GoodsListSsr.!~{01k}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "GoodsListSsr.P5hBZBtk.css",
    "src": "_GoodsListSsr.!~{01k}~.js"
  },
  "_GoodsListSsr.6xJep-PF.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "GoodsListSsr.P5hBZBtk.css"
    ],
    "file": "GoodsListSsr.6xJep-PF.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.tQQlQ1tL.js",
      "_nuxt-link.rZQe5F-Q.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_swiper-vue.5ECkG8-Q.js"
    ]
  },
  "GoodsListSsr.P5hBZBtk.css": {
    "file": "GoodsListSsr.P5hBZBtk.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_Main.vue.!~{00z}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Main.XfhtTA6U.css",
    "src": "_Main.vue.!~{00z}~.js"
  },
  "_Main.vue.2D0_-JNz.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "Main.XfhtTA6U.css"
    ],
    "file": "Main.vue.2D0_-JNz.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_contact.oP_UKSod.js",
      "_ElImage.Tm38mu9Z.js",
      "_tag.1Rvuo_2t.js",
      "_swiper-vue.5ECkG8-Q.js"
    ]
  },
  "Main.XfhtTA6U.css": {
    "file": "Main.XfhtTA6U.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_OssFileUpload.!~{00V}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "OssFileUpload.-TDo8IgO.css",
    "src": "_OssFileUpload.!~{00V}~.js"
  },
  "_OssFileUpload.fMW_IpLz.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "OssFileUpload.-TDo8IgO.css"
    ],
    "file": "OssFileUpload.fMW_IpLz.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.Tm38mu9Z.js",
      "_progress.ouy8u672.js",
      "_swiper-vue.5ECkG8-Q.js",
      "_index.4uh-YJZY.js"
    ]
  },
  "OssFileUpload.-TDo8IgO.css": {
    "file": "OssFileUpload.-TDo8IgO.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_ShopLine.!~{01I}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "ShopLine.PGliGu9i.css",
    "src": "_ShopLine.!~{01I}~.js"
  },
  "_ShopLine.49iIUZzU.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "ShopLine.PGliGu9i.css"
    ],
    "file": "ShopLine.49iIUZzU.js",
    "imports": [
      "_ElImage.Tm38mu9Z.js",
      "_nuxt-link.rZQe5F-Q.js",
      "_select.gDkGZjKY.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_input-number.XWc4ZMs0.js",
      "_tag.1Rvuo_2t.js",
      "_scrollbar.ZX_qVIEl.js",
      "_popper.T3b0UgM8.js",
      "_sku.OHqJoZ-H.js",
      "_swiper-vue.5ECkG8-Q.js"
    ]
  },
  "ShopLine.PGliGu9i.css": {
    "file": "ShopLine.PGliGu9i.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_SigninCard.vue.wNcQ5KU8.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "popover.N-GW0j1A.css"
    ],
    "file": "SigninCard.vue.wNcQ5KU8.js",
    "imports": [
      "_progress.ouy8u672.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.ebsGpq5D.js",
      "_popper.T3b0UgM8.js",
      "_swiper-vue.5ECkG8-Q.js"
    ]
  },
  "popover.N-GW0j1A.css": {
    "file": "popover.N-GW0j1A.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_StatusTag.!~{01i}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "StatusTag.IETAoY75.css",
    "src": "_StatusTag.!~{01i}~.js"
  },
  "_StatusTag.anJWoRAJ.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "StatusTag.IETAoY75.css"
    ],
    "file": "StatusTag.anJWoRAJ.js",
    "imports": [
      "_tag.1Rvuo_2t.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_post.BNFCR9p8.js",
      "_swiper-vue.5ECkG8-Q.js"
    ]
  },
  "StatusTag.IETAoY75.css": {
    "file": "StatusTag.IETAoY75.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_Switch.!~{01d}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Switch.JXXa2UnD.css",
    "src": "_Switch.!~{01d}~.js"
  },
  "_Switch.q2nOHIl4.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "Switch.JXXa2UnD.css"
    ],
    "file": "Switch.q2nOHIl4.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.5ECkG8-Q.js"
    ]
  },
  "Switch.JXXa2UnD.css": {
    "file": "Switch.JXXa2UnD.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_TagList.vue.KHhsT06_.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TagList.vue.KHhsT06_.js",
    "imports": [
      "_tag.1Rvuo_2t.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.5ECkG8-Q.js"
    ]
  },
  "_UserPostTotal.vue.yVumc-G1.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "UserPostTotal.vue.yVumc-G1.js",
    "imports": [
      "_ElImage.Tm38mu9Z.js",
      "_nuxt-link.rZQe5F-Q.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_post.BNFCR9p8.js",
      "_swiper-vue.5ECkG8-Q.js"
    ]
  },
  "_arrays.9GuX8ZvT.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "arrays.9GuX8ZvT.js"
  },
  "_avatar.!~{01H}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "avatar.bZH1-Oig.css",
    "src": "_avatar.!~{01H}~.js"
  },
  "_avatar.tHc-xrfE.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "avatar.bZH1-Oig.css"
    ],
    "file": "avatar.tHc-xrfE.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.5ECkG8-Q.js"
    ]
  },
  "avatar.bZH1-Oig.css": {
    "file": "avatar.bZH1-Oig.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_bills.5WATG5rA.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "bills.5WATG5rA.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_checkbox-group.!~{01F}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "checkbox-group.d5XbR8TY.css",
    "src": "_checkbox-group.!~{01F}~.js"
  },
  "_checkbox.!~{01w}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "checkbox.MJHvI1xB.css",
    "src": "_checkbox.!~{01w}~.js"
  },
  "_checkbox.kzMONj_o.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "checkbox.MJHvI1xB.css"
    ],
    "file": "checkbox.kzMONj_o.js",
    "imports": [
      "_swiper-vue.5ECkG8-Q.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_isEqual.RX5lYXQ8.js",
      "_hasIn.EB7TRmmq.js",
      "_flatten.GFQElkN6.js"
    ]
  },
  "checkbox.MJHvI1xB.css": {
    "file": "checkbox.MJHvI1xB.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_cloneDeep.SCKivc2r.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "cloneDeep.SCKivc2r.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_collect.h3-PosHR.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "collect.h3-PosHR.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_contact.oP_UKSod.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "contact.oP_UKSod.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_useWs.KsLXspUB.js",
      "_swiper-vue.5ECkG8-Q.js"
    ]
  },
  "_date-picker.!~{01C}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "date-picker.Nk-pBymI.css",
    "src": "_date-picker.!~{01C}~.js"
  },
  "_date-picker.beRGc18y.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "date-picker.Nk-pBymI.css"
    ],
    "file": "date-picker.beRGc18y.js",
    "imports": [
      "_localeData.02WDyiAj.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.5ECkG8-Q.js",
      "_arrays.9GuX8ZvT.js",
      "_flatten.GFQElkN6.js",
      "_popper.T3b0UgM8.js",
      "_scrollbar.ZX_qVIEl.js",
      "_index.D-A9PzKI.js",
      "_debounce.L5KS2NIz.js",
      "_index.l8r_1ce6.js",
      "_isEqual.RX5lYXQ8.js"
    ]
  },
  "date-picker.Nk-pBymI.css": {
    "file": "date-picker.Nk-pBymI.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_debounce.L5KS2NIz.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "debounce.L5KS2NIz.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_dialog.!~{00Q}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "dialog.NzY-5hTp.css",
    "src": "_dialog.!~{00Q}~.js"
  },
  "_dialog.v8AEwbT3.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "dialog.NzY-5hTp.css"
    ],
    "file": "dialog.v8AEwbT3.js",
    "imports": [
      "_swiper-vue.5ECkG8-Q.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "dialog.NzY-5hTp.css": {
    "file": "dialog.NzY-5hTp.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_divider.!~{00N}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "divider.mvCfgREV.css",
    "src": "_divider.!~{00N}~.js"
  },
  "_divider.gIaZw_m0.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "divider.mvCfgREV.css"
    ],
    "file": "divider.gIaZw_m0.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.5ECkG8-Q.js"
    ]
  },
  "divider.mvCfgREV.css": {
    "file": "divider.mvCfgREV.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_empty.!~{00J}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "empty.sDhVTJEQ.css",
    "src": "_empty.!~{00J}~.js"
  },
  "_empty.999XiLmU.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "empty.sDhVTJEQ.css"
    ],
    "file": "empty.999XiLmU.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.5ECkG8-Q.js"
    ]
  },
  "empty.sDhVTJEQ.css": {
    "file": "empty.sDhVTJEQ.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_flatten.GFQElkN6.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "flatten.GFQElkN6.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_friend.4xCtfHzK.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "friend.4xCtfHzK.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_hasIn.EB7TRmmq.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "hasIn.EB7TRmmq.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.!~{01b}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.8uyA1Q9v.css",
    "src": "_index.!~{01b}~.js"
  },
  "_index.4uh-YJZY.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.4uh-YJZY.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.D-A9PzKI.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.D-A9PzKI.js",
    "imports": [
      "_swiper-vue.5ECkG8-Q.js"
    ]
  },
  "_index.IZKO70LI.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.IZKO70LI.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.R64AGA1q.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.R64AGA1q.js",
    "imports": [
      "_swiper-vue.5ECkG8-Q.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.VR5MI-9t.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.VR5MI-9t.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.VisGtA4A.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.VisGtA4A.js",
    "imports": [
      "_swiper-vue.5ECkG8-Q.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.ebsGpq5D.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.ebsGpq5D.js",
    "imports": [
      "_popper.T3b0UgM8.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.5ECkG8-Q.js"
    ]
  },
  "_index.l8r_1ce6.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.l8r_1ce6.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.nX2ofbvL.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.nX2ofbvL.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.5ECkG8-Q.js"
    ]
  },
  "_index.tQQlQ1tL.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.8uyA1Q9v.css"
    ],
    "file": "index.tQQlQ1tL.js",
    "imports": [
      "_ElImage.Tm38mu9Z.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.5ECkG8-Q.js"
    ]
  },
  "index.8uyA1Q9v.css": {
    "file": "index.8uyA1Q9v.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_index.wg-7p-H5.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.wg-7p-H5.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_input-number.!~{01m}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "input-number.5AezeF1g.css",
    "src": "_input-number.!~{01m}~.js"
  },
  "_input-number.XWc4ZMs0.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "input-number.5AezeF1g.css"
    ],
    "file": "input-number.XWc4ZMs0.js",
    "imports": [
      "_swiper-vue.5ECkG8-Q.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.D-A9PzKI.js"
    ]
  },
  "input-number.5AezeF1g.css": {
    "file": "input-number.5AezeF1g.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_isEqual.RX5lYXQ8.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "isEqual.RX5lYXQ8.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_localeData.02WDyiAj.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "localeData.02WDyiAj.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.5ECkG8-Q.js"
    ]
  },
  "_logo_dark.yfAlRlDM.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "popover.N-GW0j1A.css"
    ],
    "dynamicImports": [
      "components/card/UserLine.vue"
    ],
    "file": "logo_dark.yfAlRlDM.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.rZQe5F-Q.js",
      "_scrollbar.ZX_qVIEl.js",
      "_index.ebsGpq5D.js",
      "_popper.T3b0UgM8.js",
      "_swiper-vue.5ECkG8-Q.js"
    ]
  },
  "_menu-item.!~{01M}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "menu-item.f0mNRiTD.css",
    "src": "_tooltip.!~{01G}~.js"
  },
  "_menu.!~{01L}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "menu.QOppk9eM.css",
    "src": "_menu.!~{01L}~.js"
  },
  "_menu.i30zUngV.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "menu.QOppk9eM.css"
    ],
    "file": "menu.i30zUngV.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.5ECkG8-Q.js",
      "_index.R64AGA1q.js",
      "_popper.T3b0UgM8.js"
    ]
  },
  "menu.QOppk9eM.css": {
    "file": "menu.QOppk9eM.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_notification.!~{00H}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "notification.6oJvQm9r.css",
    "src": "_notification.!~{00H}~.js"
  },
  "_notification.2ssjOGF0.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "notification.6oJvQm9r.css"
    ],
    "file": "notification.2ssjOGF0.js",
    "imports": [
      "_swiper-vue.5ECkG8-Q.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "notification.6oJvQm9r.css": {
    "file": "notification.6oJvQm9r.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_nuxt-link.rZQe5F-Q.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "nuxt-link.rZQe5F-Q.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.5ECkG8-Q.js"
    ]
  },
  "_popover.!~{01h}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "popover.N-GW0j1A.css",
    "src": "_popover.!~{01h}~.js"
  },
  "_popper.!~{00W}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "popper.2BhxBuwE.css",
    "src": "_popper.!~{00W}~.js"
  },
  "_popper.T3b0UgM8.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "popper.2BhxBuwE.css"
    ],
    "file": "popper.T3b0UgM8.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.5ECkG8-Q.js"
    ]
  },
  "popper.2BhxBuwE.css": {
    "file": "popper.2BhxBuwE.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_post.BNFCR9p8.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "post.BNFCR9p8.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_progress.!~{010}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "progress.rXLlm_9F.css",
    "src": "_progress.!~{010}~.js"
  },
  "_progress.ouy8u672.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "progress.rXLlm_9F.css"
    ],
    "file": "progress.ouy8u672.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.5ECkG8-Q.js"
    ]
  },
  "progress.rXLlm_9F.css": {
    "file": "progress.rXLlm_9F.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_radio-button.!~{011}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "radio-button.l7x146Nf.css",
    "src": "_radio-button.!~{011}~.js"
  },
  "_radio-group.!~{00M}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "radio-group.P_Xz2fNs.css",
    "src": "_radio-group.!~{00M}~.js"
  },
  "_radio.!~{00T}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "radio.eYTrrdr6.css",
    "src": "_radio.!~{00T}~.js"
  },
  "_rand.mzGjE9Jh.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "rand.mzGjE9Jh.js"
  },
  "_rate.!~{01p}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "rate.xvbXIp1h.css",
    "src": "_rate.!~{01p}~.js"
  },
  "_rate.2PCgb6Rv.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "rate.xvbXIp1h.css"
    ],
    "file": "rate.2PCgb6Rv.js",
    "imports": [
      "_swiper-vue.5ECkG8-Q.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "rate.xvbXIp1h.css": {
    "file": "rate.xvbXIp1h.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_scrollbar.!~{00A}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "scrollbar.Smf0pYfu.css",
    "src": "_scrollbar.!~{00A}~.js"
  },
  "_scrollbar.ZX_qVIEl.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "scrollbar.Smf0pYfu.css"
    ],
    "file": "scrollbar.ZX_qVIEl.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.5ECkG8-Q.js"
    ]
  },
  "scrollbar.Smf0pYfu.css": {
    "file": "scrollbar.Smf0pYfu.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_select.!~{00U}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "select.WyCmEko8.css",
    "src": "_select.!~{00U}~.js"
  },
  "_select.gDkGZjKY.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "select.WyCmEko8.css"
    ],
    "file": "select.gDkGZjKY.js",
    "imports": [
      "_swiper-vue.5ECkG8-Q.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_popper.T3b0UgM8.js",
      "_scrollbar.ZX_qVIEl.js",
      "_tag.1Rvuo_2t.js",
      "_strings.JyzI4XAj.js",
      "_isEqual.RX5lYXQ8.js",
      "_debounce.L5KS2NIz.js",
      "_hasIn.EB7TRmmq.js",
      "_index.l8r_1ce6.js"
    ]
  },
  "select.WyCmEko8.css": {
    "file": "select.WyCmEko8.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_sku.OHqJoZ-H.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sku.OHqJoZ-H.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_strings.JyzI4XAj.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "strings.JyzI4XAj.js",
    "imports": [
      "_swiper-vue.5ECkG8-Q.js"
    ]
  },
  "_swiper-vue.!~{002}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "swiper-vue.CRufKKKm.css",
    "src": "_swiper-vue.!~{002}~.js"
  },
  "_swiper-vue.5ECkG8-Q.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "swiper-vue.CRufKKKm.css"
    ],
    "file": "swiper-vue.5ECkG8-Q.js"
  },
  "swiper-vue.CRufKKKm.css": {
    "file": "swiper-vue.CRufKKKm.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_tabs.!~{014}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "tabs.H-UKPvku.css",
    "src": "_tabs.!~{014}~.js"
  },
  "_tabs.iK6Tfp8g.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "tabs.H-UKPvku.css"
    ],
    "file": "tabs.iK6Tfp8g.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_strings.JyzI4XAj.js",
      "_swiper-vue.5ECkG8-Q.js",
      "_index.nX2ofbvL.js"
    ]
  },
  "tabs.H-UKPvku.css": {
    "file": "tabs.H-UKPvku.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_tag.!~{00F}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "tag.ItIytdvz.css",
    "src": "_tag.!~{00F}~.js"
  },
  "_tag.1Rvuo_2t.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "tag.ItIytdvz.css"
    ],
    "file": "tag.1Rvuo_2t.js",
    "imports": [
      "_swiper-vue.5ECkG8-Q.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "tag.ItIytdvz.css": {
    "file": "tag.ItIytdvz.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_tooltip.!~{01G}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "menu-item.f0mNRiTD.css",
    "src": "_tooltip.!~{01G}~.js"
  },
  "_upload.!~{01v}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "upload.5r92S6hB.css",
    "src": "_upload.!~{01v}~.js"
  },
  "_upload.DxXo5SDh.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "upload.5r92S6hB.css"
    ],
    "file": "upload.DxXo5SDh.js",
    "imports": [
      "_swiper-vue.5ECkG8-Q.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_progress.ouy8u672.js",
      "_cloneDeep.SCKivc2r.js",
      "_isEqual.RX5lYXQ8.js"
    ]
  },
  "upload.5r92S6hB.css": {
    "file": "upload.5r92S6hB.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_useOrderStore.ya7Y55Wk.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useOrderStore.ya7Y55Wk.js",
    "imports": [
      "_index.IZKO70LI.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.5ECkG8-Q.js"
    ]
  },
  "_useWebToast.9jao5Ulu.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useWebToast.9jao5Ulu.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_useWs.KsLXspUB.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useWs.KsLXspUB.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_notification.2ssjOGF0.js",
      "_swiper-vue.5ECkG8-Q.js"
    ]
  },
  "components/Chat/Friend/ApplyDialog.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ApplyDialog.CcTDs_03.js",
    "imports": [
      "_ApplyDialog.vue.KU2lfaks.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.5ECkG8-Q.js",
      "_dialog.v8AEwbT3.js",
      "_notification.2ssjOGF0.js",
      "_friend.4xCtfHzK.js"
    ],
    "isDynamicEntry": true,
    "src": "components/Chat/Friend/ApplyDialog.vue"
  },
  "components/Chat/NewGroupDialog.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "NewGroupDialog.VBKd-Cia.css",
      "checkbox-group.d5XbR8TY.css"
    ],
    "file": "NewGroupDialog.lxwPWFjo.js",
    "imports": [
      "_ElImage.Tm38mu9Z.js",
      "_checkbox.kzMONj_o.js",
      "_AutoIncre.vue.UypBYN5v.js",
      "_scrollbar.ZX_qVIEl.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_OssFileUpload.fMW_IpLz.js",
      "_dialog.v8AEwbT3.js",
      "_notification.2ssjOGF0.js",
      "_contact.oP_UKSod.js",
      "_swiper-vue.5ECkG8-Q.js",
      "_Main.vue.2D0_-JNz.js",
      "_friend.4xCtfHzK.js",
      "_debounce.L5KS2NIz.js",
      "_isEqual.RX5lYXQ8.js",
      "_hasIn.EB7TRmmq.js",
      "_flatten.GFQElkN6.js",
      "_progress.ouy8u672.js",
      "_index.4uh-YJZY.js",
      "_useWs.KsLXspUB.js",
      "_tag.1Rvuo_2t.js"
    ],
    "isDynamicEntry": true,
    "src": "components/Chat/NewGroupDialog.vue"
  },
  "NewGroupDialog.VBKd-Cia.css": {
    "file": "NewGroupDialog.VBKd-Cia.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "checkbox-group.d5XbR8TY.css": {
    "file": "checkbox-group.d5XbR8TY.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/Comm/PostList.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "PostList.BPaQlUWh.css"
    ],
    "file": "PostList.bweKqisg.js",
    "imports": [
      "_ElImage.Tm38mu9Z.js",
      "_nuxt-link.rZQe5F-Q.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.1Rvuo_2t.js",
      "_TagList.vue.KHhsT06_.js",
      "_CommentPreview.Lr8y2oj8.js",
      "_swiper-vue.5ECkG8-Q.js",
      "_AutoIncre.vue.UypBYN5v.js",
      "_post.BNFCR9p8.js",
      "_debounce.L5KS2NIz.js",
      "_select.gDkGZjKY.js",
      "_popper.T3b0UgM8.js",
      "_scrollbar.ZX_qVIEl.js",
      "_strings.JyzI4XAj.js",
      "_isEqual.RX5lYXQ8.js",
      "_hasIn.EB7TRmmq.js",
      "_index.l8r_1ce6.js",
      "_OssFileUpload.fMW_IpLz.js",
      "_progress.ouy8u672.js",
      "_index.4uh-YJZY.js",
      "_notification.2ssjOGF0.js"
    ],
    "isDynamicEntry": true,
    "src": "components/Comm/PostList.vue"
  },
  "PostList.BPaQlUWh.css": {
    "file": "PostList.BPaQlUWh.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/Comm/post/CateGoryLine.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "CateGoryLine.HUbAIWWX.js",
    "imports": [
      "_ElImage.Tm38mu9Z.js",
      "_nuxt-link.rZQe5F-Q.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.5ECkG8-Q.js",
      "_debounce.L5KS2NIz.js"
    ],
    "isDynamicEntry": true,
    "src": "components/Comm/post/CateGoryLine.vue"
  },
  "components/Comm/post/Rank.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "Rank.y3OSjSFp.css"
    ],
    "file": "Rank.q0SKC_Vt.js",
    "imports": [
      "_divider.gIaZw_m0.js",
      "_tag.1Rvuo_2t.js",
      "_ElImage.Tm38mu9Z.js",
      "_nuxt-link.rZQe5F-Q.js",
      "_empty.999XiLmU.js",
      "_scrollbar.ZX_qVIEl.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_post.BNFCR9p8.js",
      "_swiper-vue.5ECkG8-Q.js",
      "_debounce.L5KS2NIz.js"
    ],
    "isDynamicEntry": true,
    "src": "components/Comm/post/Rank.vue"
  },
  "Rank.y3OSjSFp.css": {
    "file": "Rank.y3OSjSFp.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/card/UserLine.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "UserLine.G_lnDfVq.css",
      "popover.N-GW0j1A.css"
    ],
    "file": "UserLine.ZOukFQRk.js",
    "imports": [
      "_avatar.tHc-xrfE.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_upload.DxXo5SDh.js",
      "_nuxt-link.rZQe5F-Q.js",
      "_index.ebsGpq5D.js",
      "_progress.ouy8u672.js",
      "_popper.T3b0UgM8.js",
      "_swiper-vue.5ECkG8-Q.js",
      "_cloneDeep.SCKivc2r.js",
      "_isEqual.RX5lYXQ8.js"
    ],
    "isDynamicEntry": true,
    "src": "components/card/UserLine.vue"
  },
  "UserLine.G_lnDfVq.css": {
    "file": "UserLine.G_lnDfVq.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/list/GoodsList.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "GoodsList.1p6fEF-7.css"
    ],
    "file": "GoodsList.chB99Q_y.js",
    "imports": [
      "_index.tQQlQ1tL.js",
      "_nuxt-link.rZQe5F-Q.js",
      "_AutoIncre.vue.UypBYN5v.js",
      "_swiper-vue.5ECkG8-Q.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.Tm38mu9Z.js",
      "_debounce.L5KS2NIz.js"
    ],
    "isDynamicEntry": true,
    "src": "components/list/GoodsList.vue"
  },
  "GoodsList.1p6fEF-7.css": {
    "file": "GoodsList.1p6fEF-7.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/menu/DrawerMenu.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "DrawerMenu.0ja6gThp.css",
      "menu-item.f0mNRiTD.css",
      "popover.N-GW0j1A.css"
    ],
    "file": "DrawerMenu.V4VAYodC.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_menu.i30zUngV.js",
      "_swiper-vue.5ECkG8-Q.js",
      "_scrollbar.ZX_qVIEl.js",
      "_popper.T3b0UgM8.js",
      "_logo_dark.yfAlRlDM.js",
      "_index.R64AGA1q.js",
      "_nuxt-link.rZQe5F-Q.js",
      "_index.ebsGpq5D.js"
    ],
    "isDynamicEntry": true,
    "src": "components/menu/DrawerMenu.vue"
  },
  "DrawerMenu.0ja6gThp.css": {
    "file": "DrawerMenu.0ja6gThp.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "menu-item.f0mNRiTD.css": {
    "file": "menu-item.f0mNRiTD.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/menu/RightButtons/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.d8QRz2qr.css",
      "popover.N-GW0j1A.css",
      "menu-item.f0mNRiTD.css"
    ],
    "dynamicImports": [
      "components/menu/ShopCartBar.vue"
    ],
    "file": "index.N67Y49l3.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.5ECkG8-Q.js",
      "_nuxt-link.rZQe5F-Q.js",
      "_Main.vue.2D0_-JNz.js",
      "_scrollbar.ZX_qVIEl.js",
      "_ElImage.Tm38mu9Z.js",
      "_index.ebsGpq5D.js",
      "_popper.T3b0UgM8.js",
      "_contact.oP_UKSod.js",
      "_useWs.KsLXspUB.js",
      "_tag.1Rvuo_2t.js",
      "_debounce.L5KS2NIz.js",
      "_notification.2ssjOGF0.js"
    ],
    "isDynamicEntry": true,
    "src": "components/menu/RightButtons/index.vue"
  },
  "index.d8QRz2qr.css": {
    "file": "index.d8QRz2qr.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "components/menu/ShopCartBar.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "ShopCartBar.iS6Wm7Is.css",
      "checkbox-group.d5XbR8TY.css",
      "popover.N-GW0j1A.css"
    ],
    "file": "ShopCartBar.20Eg_PhF.js",
    "imports": [
      "_checkbox.kzMONj_o.js",
      "_ShopLine.49iIUZzU.js",
      "_AutoIncre.vue.UypBYN5v.js",
      "_scrollbar.ZX_qVIEl.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.ebsGpq5D.js",
      "_popper.T3b0UgM8.js",
      "_swiper-vue.5ECkG8-Q.js",
      "_useOrderStore.ya7Y55Wk.js",
      "_isEqual.RX5lYXQ8.js",
      "_hasIn.EB7TRmmq.js",
      "_flatten.GFQElkN6.js",
      "_ElImage.Tm38mu9Z.js",
      "_debounce.L5KS2NIz.js",
      "_nuxt-link.rZQe5F-Q.js",
      "_select.gDkGZjKY.js",
      "_tag.1Rvuo_2t.js",
      "_strings.JyzI4XAj.js",
      "_index.l8r_1ce6.js",
      "_input-number.XWc4ZMs0.js",
      "_index.D-A9PzKI.js",
      "_sku.OHqJoZ-H.js",
      "_index.IZKO70LI.js"
    ],
    "isDynamicEntry": true,
    "src": "components/menu/ShopCartBar.vue"
  },
  "ShopCartBar.iS6Wm7Is.css": {
    "file": "ShopCartBar.iS6Wm7Is.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "layouts/chat.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "chat.4EMa9LHa.css",
      "menu-item.f0mNRiTD.css",
      "popover.N-GW0j1A.css"
    ],
    "dynamicImports": [
      "components/menu/RightButtons/index.vue"
    ],
    "file": "chat.199Ywel0.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.Tm38mu9Z.js",
      "components/card/UserLine.vue",
      "_swiper-vue.5ECkG8-Q.js",
      "_menu.i30zUngV.js",
      "_popper.T3b0UgM8.js",
      "_useWs.KsLXspUB.js",
      "_friend.4xCtfHzK.js",
      "_useWebToast.9jao5Ulu.js",
      "_debounce.L5KS2NIz.js",
      "_avatar.tHc-xrfE.js",
      "_upload.DxXo5SDh.js",
      "_progress.ouy8u672.js",
      "_cloneDeep.SCKivc2r.js",
      "_isEqual.RX5lYXQ8.js",
      "_nuxt-link.rZQe5F-Q.js",
      "_index.ebsGpq5D.js",
      "_index.R64AGA1q.js",
      "_notification.2ssjOGF0.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/chat.vue"
  },
  "chat.4EMa9LHa.css": {
    "file": "chat.4EMa9LHa.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "layouts/error.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "error.txd21q4j.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.5ECkG8-Q.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/error.vue"
  },
  "layouts/main.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "popover.N-GW0j1A.css",
      "menu-item.f0mNRiTD.css"
    ],
    "dynamicImports": [
      "components/menu/DrawerMenu.vue"
    ],
    "file": "main.MM5-i9hY.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_Footer.8HzSDD6o.js",
      "components/menu/RightButtons/index.vue",
      "_swiper-vue.5ECkG8-Q.js",
      "_nuxt-link.rZQe5F-Q.js",
      "_logo_dark.yfAlRlDM.js",
      "_scrollbar.ZX_qVIEl.js",
      "_index.ebsGpq5D.js",
      "_popper.T3b0UgM8.js",
      "_Switch.q2nOHIl4.js",
      "_Main.vue.2D0_-JNz.js",
      "_contact.oP_UKSod.js",
      "_useWs.KsLXspUB.js",
      "_notification.2ssjOGF0.js",
      "_ElImage.Tm38mu9Z.js",
      "_debounce.L5KS2NIz.js",
      "_tag.1Rvuo_2t.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/main.vue"
  },
  "layouts/second.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "second.JqdAvVfB.css",
      "popover.N-GW0j1A.css",
      "menu-item.f0mNRiTD.css"
    ],
    "file": "second.ZBUsHecA.js",
    "imports": [
      "_Footer.8HzSDD6o.js",
      "components/menu/RightButtons/index.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.5ECkG8-Q.js",
      "_nuxt-link.rZQe5F-Q.js",
      "_logo_dark.yfAlRlDM.js",
      "_scrollbar.ZX_qVIEl.js",
      "_index.ebsGpq5D.js",
      "_popper.T3b0UgM8.js",
      "_Switch.q2nOHIl4.js",
      "_Main.vue.2D0_-JNz.js",
      "_contact.oP_UKSod.js",
      "_useWs.KsLXspUB.js",
      "_notification.2ssjOGF0.js",
      "_ElImage.Tm38mu9Z.js",
      "_debounce.L5KS2NIz.js",
      "_tag.1Rvuo_2t.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/second.vue"
  },
  "second.JqdAvVfB.css": {
    "file": "second.JqdAvVfB.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "layouts/user.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "user.yAuj-VgQ.css",
      "menu-item.f0mNRiTD.css",
      "popover.N-GW0j1A.css"
    ],
    "file": "user.uNcZ3cmH.js",
    "imports": [
      "_nuxt-link.rZQe5F-Q.js",
      "_logo_dark.yfAlRlDM.js",
      "_Switch.q2nOHIl4.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.5ECkG8-Q.js",
      "_menu.i30zUngV.js",
      "_popper.T3b0UgM8.js",
      "components/menu/RightButtons/index.vue",
      "_scrollbar.ZX_qVIEl.js",
      "_index.ebsGpq5D.js",
      "_index.R64AGA1q.js",
      "_Main.vue.2D0_-JNz.js",
      "_contact.oP_UKSod.js",
      "_useWs.KsLXspUB.js",
      "_notification.2ssjOGF0.js",
      "_ElImage.Tm38mu9Z.js",
      "_debounce.L5KS2NIz.js",
      "_tag.1Rvuo_2t.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/user.vue"
  },
  "user.yAuj-VgQ.css": {
    "file": "user.yAuj-VgQ.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/element-plus/es/components/text/index.mjs": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.R13h4Vtw.css"
    ],
    "file": "index.yk-gw_1U.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.5ECkG8-Q.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/element-plus/es/components/text/index.mjs"
  },
  "index.R13h4Vtw.css": {
    "file": "index.R13h4Vtw.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "entry.4GKYRbBk.css"
    ],
    "dynamicImports": [
      "layouts/chat.vue",
      "layouts/error.vue",
      "layouts/main.vue",
      "layouts/second.vue",
      "layouts/user.vue",
      "node_modules/workbox-window/build/workbox-window.prod.es5.mjs"
    ],
    "file": "entry.8gtw3JK5.js",
    "imports": [
      "_swiper-vue.5ECkG8-Q.js"
    ],
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js"
  },
  "entry.4GKYRbBk.css": {
    "file": "entry.4GKYRbBk.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/workbox-window/build/workbox-window.prod.es5.mjs": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "workbox-window.prod.es5.prqDwDSL.js",
    "isDynamicEntry": true,
    "src": "node_modules/workbox-window/build/workbox-window.prod.es5.mjs"
  },
  "pages/[...all].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_...all_.rfGxozy3.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.5ECkG8-Q.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/[...all].vue"
  },
  "pages/chat/ai.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "ai.gFhifI5j.css"
    ],
    "file": "ai._Nx7-YuB.js",
    "imports": [
      "_Main.vue.2D0_-JNz.js",
      "_scrollbar.ZX_qVIEl.js",
      "_ElImage.Tm38mu9Z.js",
      "_nuxt-link.rZQe5F-Q.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.5ECkG8-Q.js",
      "_contact.oP_UKSod.js",
      "_useWs.KsLXspUB.js",
      "_tag.1Rvuo_2t.js",
      "_debounce.L5KS2NIz.js",
      "_notification.2ssjOGF0.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/chat/ai.vue"
  },
  "ai.gFhifI5j.css": {
    "file": "ai.gFhifI5j.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/chat/friend.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "friend.WNfEdlBe.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "file": "friend.mlLAQwJn.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.1Rvuo_2t.js",
      "_ElImage.Tm38mu9Z.js",
      "_AutoIncre.vue.UypBYN5v.js",
      "_scrollbar.ZX_qVIEl.js",
      "_empty.999XiLmU.js",
      "_swiper-vue.5ECkG8-Q.js",
      "_friend.4xCtfHzK.js",
      "_index.VisGtA4A.js",
      "_contact.oP_UKSod.js",
      "_useWs.KsLXspUB.js",
      "_notification.2ssjOGF0.js",
      "_divider.gIaZw_m0.js",
      "_ApplyDialog.vue.KU2lfaks.js",
      "_index.VR5MI-9t.js",
      "_debounce.L5KS2NIz.js",
      "_dialog.v8AEwbT3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/chat/friend.vue"
  },
  "friend.WNfEdlBe.css": {
    "file": "friend.WNfEdlBe.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "radio-group.P_Xz2fNs.css": {
    "file": "radio-group.P_Xz2fNs.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/chat/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.pRAfIphv.css",
      "radio.eYTrrdr6.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "dynamicImports": [
      "components/Chat/NewGroupDialog.vue",
      "components/Chat/NewGroupDialog.vue",
      "components/Chat/Friend/ApplyDialog.vue"
    ],
    "file": "index.aZNET3he.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.Tm38mu9Z.js",
      "_index.VisGtA4A.js",
      "_AutoIncre.vue.UypBYN5v.js",
      "_swiper-vue.5ECkG8-Q.js",
      "_notification.2ssjOGF0.js",
      "_contact.oP_UKSod.js",
      "_Main.vue.2D0_-JNz.js",
      "_friend.4xCtfHzK.js",
      "_useWs.KsLXspUB.js",
      "_tag.1Rvuo_2t.js",
      "_scrollbar.ZX_qVIEl.js",
      "_select.gDkGZjKY.js",
      "_OssFileUpload.fMW_IpLz.js",
      "_nuxt-link.rZQe5F-Q.js",
      "_popper.T3b0UgM8.js",
      "_index.4uh-YJZY.js",
      "_debounce.L5KS2NIz.js",
      "_strings.JyzI4XAj.js",
      "_isEqual.RX5lYXQ8.js",
      "_hasIn.EB7TRmmq.js",
      "_index.l8r_1ce6.js",
      "_progress.ouy8u672.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/chat/index.vue"
  },
  "index.pRAfIphv.css": {
    "file": "index.pRAfIphv.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "radio.eYTrrdr6.css": {
    "file": "radio.eYTrrdr6.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/chat/setting.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "setting.1OV0DNN5.css",
      "radio-button.l7x146Nf.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "file": "setting.4egeKmAu.js",
    "imports": [
      "_divider.gIaZw_m0.js",
      "_select.gDkGZjKY.js",
      "_index.VisGtA4A.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.1Rvuo_2t.js",
      "_scrollbar.ZX_qVIEl.js",
      "_popper.T3b0UgM8.js",
      "_notification.2ssjOGF0.js",
      "_swiper-vue.5ECkG8-Q.js",
      "_strings.JyzI4XAj.js",
      "_isEqual.RX5lYXQ8.js",
      "_debounce.L5KS2NIz.js",
      "_hasIn.EB7TRmmq.js",
      "_index.l8r_1ce6.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/chat/setting.vue"
  },
  "setting.1OV0DNN5.css": {
    "file": "setting.1OV0DNN5.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "radio-button.l7x146Nf.css": {
    "file": "radio-button.l7x146Nf.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/category/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "_id_.uLLhAsoU.css"
    ],
    "dynamicImports": [
      "components/Comm/post/Rank.vue"
    ],
    "file": "_id_.ceFJItJK.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.Tm38mu9Z.js",
      "_CategoryTabs.wEStPtHU.js",
      "_swiper-vue.5ECkG8-Q.js",
      "_debounce.L5KS2NIz.js",
      "_tabs.iK6Tfp8g.js",
      "_strings.JyzI4XAj.js",
      "_index.nX2ofbvL.js",
      "components/Comm/PostList.vue",
      "_nuxt-link.rZQe5F-Q.js",
      "_tag.1Rvuo_2t.js",
      "_TagList.vue.KHhsT06_.js",
      "_CommentPreview.Lr8y2oj8.js",
      "_select.gDkGZjKY.js",
      "_popper.T3b0UgM8.js",
      "_scrollbar.ZX_qVIEl.js",
      "_isEqual.RX5lYXQ8.js",
      "_hasIn.EB7TRmmq.js",
      "_index.l8r_1ce6.js",
      "_OssFileUpload.fMW_IpLz.js",
      "_progress.ouy8u672.js",
      "_index.4uh-YJZY.js",
      "_AutoIncre.vue.UypBYN5v.js",
      "_notification.2ssjOGF0.js",
      "_post.BNFCR9p8.js",
      "components/list/GoodsList.vue",
      "_index.tQQlQ1tL.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/category/[id].vue"
  },
  "_id_.uLLhAsoU.css": {
    "file": "_id_.uLLhAsoU.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/category/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.EaIT1GIC.css"
    ],
    "dynamicImports": [
      "components/Comm/post/Rank.vue"
    ],
    "file": "index.6v8voFkl.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_CategoryTabs.wEStPtHU.js",
      "_swiper-vue.5ECkG8-Q.js",
      "_tabs.iK6Tfp8g.js",
      "_strings.JyzI4XAj.js",
      "_index.nX2ofbvL.js",
      "components/Comm/PostList.vue",
      "_ElImage.Tm38mu9Z.js",
      "_debounce.L5KS2NIz.js",
      "_nuxt-link.rZQe5F-Q.js",
      "_tag.1Rvuo_2t.js",
      "_TagList.vue.KHhsT06_.js",
      "_CommentPreview.Lr8y2oj8.js",
      "_select.gDkGZjKY.js",
      "_popper.T3b0UgM8.js",
      "_scrollbar.ZX_qVIEl.js",
      "_isEqual.RX5lYXQ8.js",
      "_hasIn.EB7TRmmq.js",
      "_index.l8r_1ce6.js",
      "_OssFileUpload.fMW_IpLz.js",
      "_progress.ouy8u672.js",
      "_index.4uh-YJZY.js",
      "_AutoIncre.vue.UypBYN5v.js",
      "_notification.2ssjOGF0.js",
      "_post.BNFCR9p8.js",
      "components/list/GoodsList.vue",
      "_index.tQQlQ1tL.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/category/index.vue"
  },
  "index.EaIT1GIC.css": {
    "file": "index.EaIT1GIC.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/post/detail/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "_id_.72oiqwWe.css",
      "popover.N-GW0j1A.css"
    ],
    "dynamicImports": [
      "components/Comm/post/CateGoryLine.vue"
    ],
    "file": "_id_.VZevWNLN.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.Tm38mu9Z.js",
      "_Switch.q2nOHIl4.js",
      "_tag.1Rvuo_2t.js",
      "_nuxt-link.rZQe5F-Q.js",
      "_TagList.vue.KHhsT06_.js",
      "_divider.gIaZw_m0.js",
      "_post.BNFCR9p8.js",
      "_swiper-vue.5ECkG8-Q.js",
      "_CommentPreview.Lr8y2oj8.js",
      "_UserPostTotal.vue.yVumc-G1.js",
      "_SigninCard.vue.wNcQ5KU8.js",
      "_debounce.L5KS2NIz.js",
      "_select.gDkGZjKY.js",
      "_popper.T3b0UgM8.js",
      "_scrollbar.ZX_qVIEl.js",
      "_strings.JyzI4XAj.js",
      "_isEqual.RX5lYXQ8.js",
      "_hasIn.EB7TRmmq.js",
      "_index.l8r_1ce6.js",
      "_OssFileUpload.fMW_IpLz.js",
      "_progress.ouy8u672.js",
      "_index.4uh-YJZY.js",
      "_AutoIncre.vue.UypBYN5v.js",
      "_notification.2ssjOGF0.js",
      "_index.ebsGpq5D.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/post/detail/[id].vue"
  },
  "_id_.72oiqwWe.css": {
    "file": "_id_.72oiqwWe.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/post/list.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "list.aADC_aru.css",
      "popover.N-GW0j1A.css"
    ],
    "file": "list.sQ1TWR_i.js",
    "imports": [
      "_nuxt-link.rZQe5F-Q.js",
      "_tag.1Rvuo_2t.js",
      "_swiper-vue.5ECkG8-Q.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_post.BNFCR9p8.js",
      "_ElImage.Tm38mu9Z.js",
      "components/Comm/PostList.vue",
      "_tabs.iK6Tfp8g.js",
      "_SigninCard.vue.wNcQ5KU8.js",
      "components/Comm/post/Rank.vue",
      "_debounce.L5KS2NIz.js",
      "_TagList.vue.KHhsT06_.js",
      "_CommentPreview.Lr8y2oj8.js",
      "_select.gDkGZjKY.js",
      "_popper.T3b0UgM8.js",
      "_scrollbar.ZX_qVIEl.js",
      "_strings.JyzI4XAj.js",
      "_isEqual.RX5lYXQ8.js",
      "_hasIn.EB7TRmmq.js",
      "_index.l8r_1ce6.js",
      "_OssFileUpload.fMW_IpLz.js",
      "_progress.ouy8u672.js",
      "_index.4uh-YJZY.js",
      "_AutoIncre.vue.UypBYN5v.js",
      "_notification.2ssjOGF0.js",
      "_index.nX2ofbvL.js",
      "_index.ebsGpq5D.js",
      "_divider.gIaZw_m0.js",
      "_empty.999XiLmU.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/post/list.vue"
  },
  "list.aADC_aru.css": {
    "file": "list.aADC_aru.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/community/post/new.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "new.0TTT8KuO.css",
      "radio-button.l7x146Nf.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "file": "new.fp1zN1Wt.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_OssFileUpload.fMW_IpLz.js",
      "_index.VisGtA4A.js",
      "_ElImage.Tm38mu9Z.js",
      "_select.gDkGZjKY.js",
      "_tag.1Rvuo_2t.js",
      "_scrollbar.ZX_qVIEl.js",
      "_popper.T3b0UgM8.js",
      "_swiper-vue.5ECkG8-Q.js",
      "_notification.2ssjOGF0.js",
      "_index.4uh-YJZY.js",
      "_StatusTag.anJWoRAJ.js",
      "_post.BNFCR9p8.js",
      "_progress.ouy8u672.js",
      "_debounce.L5KS2NIz.js",
      "_strings.JyzI4XAj.js",
      "_isEqual.RX5lYXQ8.js",
      "_hasIn.EB7TRmmq.js",
      "_index.l8r_1ce6.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/community/post/new.vue"
  },
  "new.0TTT8KuO.css": {
    "file": "new.0TTT8KuO.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/event/detail/[eid].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "_eid_.NtANQ6Xa.css"
    ],
    "file": "_eid_.vh5l2AB9.js",
    "imports": [
      "_ElImage.Tm38mu9Z.js",
      "_tag.1Rvuo_2t.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.5ECkG8-Q.js",
      "_nuxt-link.rZQe5F-Q.js",
      "_index.wg-7p-H5.js",
      "_debounce.L5KS2NIz.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/event/detail/[eid].vue"
  },
  "_eid_.NtANQ6Xa.css": {
    "file": "_eid_.NtANQ6Xa.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/goods/comments/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_id_.GQM4HbbO.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.5ECkG8-Q.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/goods/comments/[id].vue"
  },
  "pages/goods/detail/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "_id_.spxRS6Bk.css",
      "popover.N-GW0j1A.css",
      "radio-button.l7x146Nf.css",
      "radio-group.P_Xz2fNs.css",
      "radio.eYTrrdr6.css"
    ],
    "file": "_id_.3DZnFTu6.js",
    "imports": [
      "_nuxt-link.rZQe5F-Q.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.5ECkG8-Q.js",
      "_GoodsListSsr.6xJep-PF.js",
      "_ElImage.Tm38mu9Z.js",
      "_index.nX2ofbvL.js",
      "_scrollbar.ZX_qVIEl.js",
      "_tag.1Rvuo_2t.js",
      "_popper.T3b0UgM8.js",
      "_collect.h3-PosHR.js",
      "_index.VisGtA4A.js",
      "_input-number.XWc4ZMs0.js",
      "_useOrderStore.ya7Y55Wk.js",
      "_index.wg-7p-H5.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_tabs.iK6Tfp8g.js",
      "_rate.2PCgb6Rv.js",
      "_AutoIncre.vue.UypBYN5v.js",
      "_dialog.v8AEwbT3.js",
      "_index.R64AGA1q.js",
      "_rand.mzGjE9Jh.js",
      "_index.tQQlQ1tL.js",
      "_sku.OHqJoZ-H.js",
      "_debounce.L5KS2NIz.js",
      "_index.D-A9PzKI.js",
      "_index.IZKO70LI.js",
      "_strings.JyzI4XAj.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/goods/detail/[id].vue"
  },
  "_id_.spxRS6Bk.css": {
    "file": "_id_.spxRS6Bk.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.TUNn2oWQ.css",
      "popover.N-GW0j1A.css"
    ],
    "dynamicImports": [
      "components/list/GoodsList.vue"
    ],
    "file": "index.2MhS4m22.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.1Rvuo_2t.js",
      "_swiper-vue.5ECkG8-Q.js",
      "_nuxt-link.rZQe5F-Q.js",
      "_AutoIncre.vue.UypBYN5v.js",
      "_empty.999XiLmU.js",
      "_scrollbar.ZX_qVIEl.js",
      "_index.ebsGpq5D.js",
      "_popper.T3b0UgM8.js",
      "_index.tQQlQ1tL.js",
      "_index.wg-7p-H5.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_GoodsListSsr.6xJep-PF.js",
      "_tabs.iK6Tfp8g.js",
      "_ElImage.Tm38mu9Z.js",
      "_strings.JyzI4XAj.js",
      "_index.nX2ofbvL.js",
      "_debounce.L5KS2NIz.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.TUNn2oWQ.css": {
    "file": "index.TUNn2oWQ.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/order/comment/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "_id_.65PfMBS2.css"
    ],
    "file": "_id_.tgnfmZe6.js",
    "imports": [
      "_Switch.q2nOHIl4.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_progress.ouy8u672.js",
      "_upload.DxXo5SDh.js",
      "_dialog.v8AEwbT3.js",
      "_swiper-vue.5ECkG8-Q.js",
      "_index.4uh-YJZY.js",
      "_ElImage.Tm38mu9Z.js",
      "_rate.2PCgb6Rv.js",
      "_checkbox.kzMONj_o.js",
      "_nuxt-link.rZQe5F-Q.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_notification.2ssjOGF0.js",
      "_index.IZKO70LI.js",
      "_cloneDeep.SCKivc2r.js",
      "_isEqual.RX5lYXQ8.js",
      "_debounce.L5KS2NIz.js",
      "_hasIn.EB7TRmmq.js",
      "_flatten.GFQElkN6.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/order/comment/[id].vue"
  },
  "_id_.65PfMBS2.css": {
    "file": "_id_.65PfMBS2.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/order/detail.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "detail.FQzghYYY.css",
      "radio.eYTrrdr6.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "dynamicImports": [
      "node_modules/element-plus/es/components/text/index.mjs"
    ],
    "file": "detail.a8qlMaXn.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.Tm38mu9Z.js",
      "_nuxt-link.rZQe5F-Q.js",
      "_divider.gIaZw_m0.js",
      "_DelayTimer.vue.krZqos6x.js",
      "_swiper-vue.5ECkG8-Q.js",
      "_Switch.q2nOHIl4.js",
      "_index.nX2ofbvL.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_bills.5WATG5rA.js",
      "_index.IZKO70LI.js",
      "_useOrderStore.ya7Y55Wk.js",
      "_index.VisGtA4A.js",
      "_tag.1Rvuo_2t.js",
      "_scrollbar.ZX_qVIEl.js",
      "_select.gDkGZjKY.js",
      "_input-number.XWc4ZMs0.js",
      "_popper.T3b0UgM8.js",
      "_index.wg-7p-H5.js",
      "_sku.OHqJoZ-H.js",
      "_empty.999XiLmU.js",
      "_notification.2ssjOGF0.js",
      "_useWebToast.9jao5Ulu.js",
      "_debounce.L5KS2NIz.js",
      "_strings.JyzI4XAj.js",
      "_isEqual.RX5lYXQ8.js",
      "_hasIn.EB7TRmmq.js",
      "_index.l8r_1ce6.js",
      "_index.D-A9PzKI.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/order/detail.vue"
  },
  "detail.FQzghYYY.css": {
    "file": "detail.FQzghYYY.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/order/list.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "list.pKmG3IwD.css"
    ],
    "file": "list.nhk-aNsr.js",
    "imports": [
      "_divider.gIaZw_m0.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_date-picker.beRGc18y.js",
      "_DelayTimer.vue.krZqos6x.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_ElImage.Tm38mu9Z.js",
      "_tag.1Rvuo_2t.js",
      "_swiper-vue.5ECkG8-Q.js",
      "_useOrderStore.ya7Y55Wk.js",
      "_index.IZKO70LI.js",
      "_AutoIncre.vue.UypBYN5v.js",
      "_scrollbar.ZX_qVIEl.js",
      "_popper.T3b0UgM8.js",
      "_notification.2ssjOGF0.js",
      "_tabs.iK6Tfp8g.js",
      "_localeData.02WDyiAj.js",
      "_arrays.9GuX8ZvT.js",
      "_flatten.GFQElkN6.js",
      "_index.D-A9PzKI.js",
      "_debounce.L5KS2NIz.js",
      "_index.l8r_1ce6.js",
      "_isEqual.RX5lYXQ8.js",
      "_strings.JyzI4XAj.js",
      "_index.nX2ofbvL.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/order/list.vue"
  },
  "list.pKmG3IwD.css": {
    "file": "list.pKmG3IwD.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/search/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.gADI8LgY.css"
    ],
    "dynamicImports": [
      "components/list/GoodsList.vue",
      "components/Comm/PostList.vue"
    ],
    "file": "index.vchm0cqq.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_checkbox.kzMONj_o.js",
      "_select.gDkGZjKY.js",
      "_tag.1Rvuo_2t.js",
      "_swiper-vue.5ECkG8-Q.js",
      "_tabs.iK6Tfp8g.js",
      "_empty.999XiLmU.js",
      "_scrollbar.ZX_qVIEl.js",
      "_popper.T3b0UgM8.js",
      "_isEqual.RX5lYXQ8.js",
      "_hasIn.EB7TRmmq.js",
      "_flatten.GFQElkN6.js",
      "_strings.JyzI4XAj.js",
      "_debounce.L5KS2NIz.js",
      "_index.l8r_1ce6.js",
      "_index.nX2ofbvL.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/search/index.vue"
  },
  "index.gADI8LgY.css": {
    "file": "index.gADI8LgY.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/setting/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.p8ZulH49.css",
      "radio-button.l7x146Nf.css",
      "radio-group.P_Xz2fNs.css"
    ],
    "file": "index.TaTTejWj.js",
    "imports": [
      "_divider.gIaZw_m0.js",
      "_select.gDkGZjKY.js",
      "_index.VisGtA4A.js",
      "_swiper-vue.5ECkG8-Q.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.1Rvuo_2t.js",
      "_scrollbar.ZX_qVIEl.js",
      "_popper.T3b0UgM8.js",
      "_notification.2ssjOGF0.js",
      "_strings.JyzI4XAj.js",
      "_isEqual.RX5lYXQ8.js",
      "_debounce.L5KS2NIz.js",
      "_hasIn.EB7TRmmq.js",
      "_index.l8r_1ce6.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/setting/index.vue"
  },
  "index.p8ZulH49.css": {
    "file": "index.p8ZulH49.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/address.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "address.WdFNjMwU.css",
      "radio.eYTrrdr6.css",
      "checkbox-group.d5XbR8TY.css"
    ],
    "file": "address.VO3zAjNx.js",
    "imports": [
      "node_modules/element-plus/es/components/text/index.mjs",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.5ECkG8-Q.js",
      "_scrollbar.ZX_qVIEl.js",
      "_checkbox.kzMONj_o.js",
      "_index.VisGtA4A.js",
      "_rand.mzGjE9Jh.js",
      "_strings.JyzI4XAj.js",
      "_isEqual.RX5lYXQ8.js",
      "_arrays.9GuX8ZvT.js",
      "_flatten.GFQElkN6.js",
      "_cloneDeep.SCKivc2r.js",
      "_popper.T3b0UgM8.js",
      "_tag.1Rvuo_2t.js",
      "_index.l8r_1ce6.js",
      "_debounce.L5KS2NIz.js",
      "_dialog.v8AEwbT3.js",
      "_divider.gIaZw_m0.js",
      "_hasIn.EB7TRmmq.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/address.vue"
  },
  "address.WdFNjMwU.css": {
    "file": "address.WdFNjMwU.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/collect.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "collect.7bC4-ld9.css",
      "checkbox-group.d5XbR8TY.css"
    ],
    "file": "collect.vlYQKOdV.js",
    "imports": [
      "_divider.gIaZw_m0.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_checkbox.kzMONj_o.js",
      "_ElImage.Tm38mu9Z.js",
      "_swiper-vue.5ECkG8-Q.js",
      "_scrollbar.ZX_qVIEl.js",
      "_collect.h3-PosHR.js",
      "_tabs.iK6Tfp8g.js",
      "_tag.1Rvuo_2t.js",
      "_nuxt-link.rZQe5F-Q.js",
      "_TagList.vue.KHhsT06_.js",
      "_AutoIncre.vue.UypBYN5v.js",
      "_post.BNFCR9p8.js",
      "_isEqual.RX5lYXQ8.js",
      "_hasIn.EB7TRmmq.js",
      "_flatten.GFQElkN6.js",
      "_debounce.L5KS2NIz.js",
      "_strings.JyzI4XAj.js",
      "_index.nX2ofbvL.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/collect.vue"
  },
  "collect.7bC4-ld9.css": {
    "file": "collect.7bC4-ld9.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/info.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "info._k_JpRFF.css",
      "popover.N-GW0j1A.css",
      "menu-item.f0mNRiTD.css"
    ],
    "file": "info.wKyemGKE.js",
    "imports": [
      "_ElImage.Tm38mu9Z.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.ebsGpq5D.js",
      "_popper.T3b0UgM8.js",
      "_swiper-vue.5ECkG8-Q.js",
      "_upload.DxXo5SDh.js",
      "_date-picker.beRGc18y.js",
      "_select.gDkGZjKY.js",
      "_progress.ouy8u672.js",
      "_scrollbar.ZX_qVIEl.js",
      "_tag.1Rvuo_2t.js",
      "_nuxt-link.rZQe5F-Q.js",
      "_TagList.vue.KHhsT06_.js",
      "_AutoIncre.vue.UypBYN5v.js",
      "_post.BNFCR9p8.js",
      "_tabs.iK6Tfp8g.js",
      "_UserPostTotal.vue.yVumc-G1.js",
      "_SigninCard.vue.wNcQ5KU8.js",
      "_index.VR5MI-9t.js",
      "_debounce.L5KS2NIz.js",
      "_cloneDeep.SCKivc2r.js",
      "_isEqual.RX5lYXQ8.js",
      "_localeData.02WDyiAj.js",
      "_arrays.9GuX8ZvT.js",
      "_flatten.GFQElkN6.js",
      "_index.D-A9PzKI.js",
      "_index.l8r_1ce6.js",
      "_strings.JyzI4XAj.js",
      "_hasIn.EB7TRmmq.js",
      "_index.nX2ofbvL.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/info.vue"
  },
  "info._k_JpRFF.css": {
    "file": "info._k_JpRFF.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/post.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "post.yVQn8Ib0.css"
    ],
    "file": "post.9CAxE9o9.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_ElImage.Tm38mu9Z.js",
      "_select.gDkGZjKY.js",
      "_tag.1Rvuo_2t.js",
      "_scrollbar.ZX_qVIEl.js",
      "_popper.T3b0UgM8.js",
      "_swiper-vue.5ECkG8-Q.js",
      "_StatusTag.anJWoRAJ.js",
      "_nuxt-link.rZQe5F-Q.js",
      "_TagList.vue.KHhsT06_.js",
      "_post.BNFCR9p8.js",
      "_AutoIncre.vue.UypBYN5v.js",
      "_notification.2ssjOGF0.js",
      "_tabs.iK6Tfp8g.js",
      "_debounce.L5KS2NIz.js",
      "_strings.JyzI4XAj.js",
      "_isEqual.RX5lYXQ8.js",
      "_hasIn.EB7TRmmq.js",
      "_index.l8r_1ce6.js",
      "_index.nX2ofbvL.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/post.vue"
  },
  "post.yVQn8Ib0.css": {
    "file": "post.yVQn8Ib0.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/safe.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "safe.73roRH3g.css"
    ],
    "file": "safe.BezEg_r9.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_tag.1Rvuo_2t.js",
      "_swiper-vue.5ECkG8-Q.js",
      "_scrollbar.ZX_qVIEl.js",
      "_avatar.tHc-xrfE.js",
      "_divider.gIaZw_m0.js",
      "node_modules/element-plus/es/components/text/index.mjs",
      "_useOrderStore.ya7Y55Wk.js",
      "_index.IZKO70LI.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/safe.vue"
  },
  "safe.73roRH3g.css": {
    "file": "safe.73roRH3g.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/shopcart.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "shopcart.cNizIJyk.css",
      "checkbox-group.d5XbR8TY.css"
    ],
    "file": "shopcart.D4Z-FauK.js",
    "imports": [
      "_checkbox.kzMONj_o.js",
      "_ShopLine.49iIUZzU.js",
      "_nuxt-link.rZQe5F-Q.js",
      "_AutoIncre.vue.UypBYN5v.js",
      "_scrollbar.ZX_qVIEl.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.5ECkG8-Q.js",
      "_useOrderStore.ya7Y55Wk.js",
      "_isEqual.RX5lYXQ8.js",
      "_hasIn.EB7TRmmq.js",
      "_flatten.GFQElkN6.js",
      "_ElImage.Tm38mu9Z.js",
      "_debounce.L5KS2NIz.js",
      "_select.gDkGZjKY.js",
      "_popper.T3b0UgM8.js",
      "_tag.1Rvuo_2t.js",
      "_strings.JyzI4XAj.js",
      "_index.l8r_1ce6.js",
      "_input-number.XWc4ZMs0.js",
      "_index.D-A9PzKI.js",
      "_sku.OHqJoZ-H.js",
      "_index.IZKO70LI.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/shopcart.vue"
  },
  "shopcart.cNizIJyk.css": {
    "file": "shopcart.cNizIJyk.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/wallet.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "wallet.7z599r9w.css",
      "popover.N-GW0j1A.css"
    ],
    "file": "wallet.20wCMbt8.js",
    "imports": [
      "node_modules/element-plus/es/components/text/index.mjs",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.5ECkG8-Q.js",
      "_progress.ouy8u672.js",
      "_index.ebsGpq5D.js",
      "_popper.T3b0UgM8.js",
      "_bills.5WATG5rA.js",
      "_scrollbar.ZX_qVIEl.js",
      "_input-number.XWc4ZMs0.js",
      "_select.gDkGZjKY.js",
      "_tag.1Rvuo_2t.js",
      "_localeData.02WDyiAj.js",
      "_divider.gIaZw_m0.js",
      "_index.D-A9PzKI.js",
      "_strings.JyzI4XAj.js",
      "_isEqual.RX5lYXQ8.js",
      "_debounce.L5KS2NIz.js",
      "_hasIn.EB7TRmmq.js",
      "_index.l8r_1ce6.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/wallet.vue"
  },
  "wallet.7z599r9w.css": {
    "file": "wallet.7z599r9w.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
