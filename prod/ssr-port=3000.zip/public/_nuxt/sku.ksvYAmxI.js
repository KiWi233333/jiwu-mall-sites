import{ad as o,ae as t,b3 as e}from"./entry.-8Cz29iT.js";function a(s){return o(`${t}/goods/sku?gid=${s}`,"$AfkcphgTcz")}function d(s){return e.post("/goods/sku",{ids:[...s]})}export{d as a,a as g};
