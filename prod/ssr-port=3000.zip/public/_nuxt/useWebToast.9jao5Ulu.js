import{go as n}from"./entry.8gtw3JK5.js";function a(i,s,t){const o=n({title:i,body:s,icon:"/logo.png",...t});o.isSupported&&o.show()}export{a as u};
