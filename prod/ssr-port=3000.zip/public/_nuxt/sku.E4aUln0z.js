import{ad as o,ae as t,b3 as e}from"./entry.mRaChMjT.js";function a(s){return o(`${t}/goods/sku?gid=${s}`,"$AfkcphgTcz")}function d(s){return e.post("/goods/sku",{ids:[...s]})}export{d as a,a as g};
