import{hH as o}from"./entry.8gtw3JK5.js";var r=1,n=4;function a(e){return o(e,r|n)}export{a as c};
