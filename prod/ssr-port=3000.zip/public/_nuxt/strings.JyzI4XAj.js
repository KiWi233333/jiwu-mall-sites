import{aQ as a}from"./swiper-vue.5ECkG8-Q.js";const p=(e="")=>e.replace(/[|\\{}()[\]^$+*?.]/g,"\\$&").replace(/-/g,"\\x2d"),t=e=>a(e);export{t as c,p as e};
