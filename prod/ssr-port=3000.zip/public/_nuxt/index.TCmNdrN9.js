import{b3 as r,ae as o}from"./entry.-8Cz29iT.js";function a(e,t){return r.get(`${o}/community/user/${e}`,{},{headers:{Authorization:t}})}export{a as g};
