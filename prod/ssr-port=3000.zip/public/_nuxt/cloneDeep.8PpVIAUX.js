import{hF as o}from"./entry.-8Cz29iT.js";var r=1,n=4;function a(e){return o(e,r|n)}export{a as c};
