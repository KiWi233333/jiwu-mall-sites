import{b4 as r,ag as o}from"./entry.8gtw3JK5.js";function a(e,t){return r.get(`${o}/community/user/${e}`,{},{headers:{Authorization:t}})}export{a as g};
