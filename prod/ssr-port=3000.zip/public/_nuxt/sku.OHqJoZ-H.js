import{af as o,ag as t,b4 as u}from"./entry.8gtw3JK5.js";function e(s){return o(`${t}/goods/sku?gid=${s}`,"$AfkcphgTcz")}function d(s){return u.post("/goods/sku",{ids:[...s]})}export{d as a,e as g};
